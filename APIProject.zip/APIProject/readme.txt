This is a sample project demonstrates step feature and WebService testing feature and live reporting. It covers example of bean, component and test page.

To change/modify dependencies check ivy.xml

To run the project, follow this link.
https://infostretch.zendesk.com/hc/en-us/articles/204301509-How-to-Run-QAS-Project

Open dashboard.htm to view results.
 
Thanks,
QAS Team.