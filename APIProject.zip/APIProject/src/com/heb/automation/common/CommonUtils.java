package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;
import com.sun.jersey.api.representation.Form;

public class CommonUtils extends RestWSTestCase {

	
	public static String GET(String resource, Map<String, String> headers) throws ProcessingException, IOException {

		// Getting the response
		String response = createWebResourceBuilder(resource, headers).get(String.class);
		System.out.println(response);
		ReusableUtils.printresponse(response);
		return response;
	}

	public static String GET(String resource, Map<String, String> headers, String authorization) {
		String response = createWebResourceBuilder(resource, headers)
				.header("apikey", getBundle().getString("common.apikey")).header("Authorization", authorization)
				.get(String.class);

		Reporter.log("******Response******", MessageTypes.Pass);
		Reporter.log(response);

		return response;
	}

	/*
	 * public static String POST(String resource, Form f) { String response =
	 * createWebResourceBuilder(resource, null).post(String.class, f);
	 * 
	 * ReusableUtils.printresponse(response);
	 * 
	 * return response; }
	 */
	public static String POST(String resource, Map<String, String> headers) {
		String response = createWebResourceBuilder(resource, headers).post(String.class);

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String POST(String resource, Map<String, String> headers, JsonArray bodyParameter) throws Exception {

		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());
		ReusableUtils.printresponse(response);
		return response;
	}

	public static String POST(String resource, Map<String, String> headers, String bodyParameter) throws Exception {

		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());
		ReusableUtils.printresponse(response);
		return response;
	}

	public static ClientResponse POST(String resource, MultivaluedMap queryPar, Map<String, String> headers,
			JsonObject body) {
		ClientResponse response = createWebResourceBuilder(resource, queryPar, headers).post(ClientResponse.class,
				body.toString());
		ReusableUtils.printresponse(response.toString());
		return response;
	}
	public static String POST(String baseUrl, String resource, Map<String, String> headers, JsonArray bodyParameter) {
		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String DELETE(String resource, Map<String, String> headers) throws ProcessingException, IOException {

		// Getting the response
		String response = createWebResourceBuilder(resource, headers).delete(String.class);
		ReusableUtils.printresponse(response);
		return response;
	}

	public static String DELETE(String resource, Map<String, String> headers, String BodyParamter)
			throws ProcessingException, IOException {

		// Getting the response
		String response = createWebResourceBuilder(resource, headers).delete(String.class, BodyParamter);
		ReusableUtils.printresponse(response);
		return response;
	}

	public static String POST(String resource, Map<String, String> headers, String[] bodyParameter) {
		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String POST(String resource, Map<String, String> headers, List<String> bodyParameter) {
		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String POST(String resource, Map<String, String> headers, JsonObject bodyParameter) {
		String response = createWebResourceBuilder(resource, headers).post(String.class, bodyParameter.toString());

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String PUT(String resource, Map<String, String> headers, JsonObject bodyParameter) throws Exception {
		String response = createWebResourceBuilder(resource, headers).put(String.class, bodyParameter.toString());

		ReusableUtils.printresponse(response);
		return response;
	}

	public static String PUT(String resource, Map<String, String> headers, String bodyParameter) {
		String response = createWebResourceBuilder(resource, headers).put(String.class, bodyParameter);

		ReusableUtils.printresponse(response);

		return response;
	}

	public static String DELETE(String resource, Map<String, String> headers, JsonArray BodyParamter)
			throws ProcessingException, IOException {
		String response = createWebResourceBuilder(resource, headers).delete(String.class, BodyParamter.toString());
		ReusableUtils.printresponse(response);
		return response;
	}

	private static Builder createWebResourceBuilder(String resource, MultivaluedMap queryPar) {
		return createWebResourceBuilder(resource, queryPar, Collections.<String, String> emptyMap());
	}

	private static Builder createWebResourceBuilder(String resource, MultivaluedMap queryPar,
			Map<String, String> headers) {
		WebResource webResource = new RestTestBase().getWebResource(getBundle().getString("ws.endurl", resource));
		if (queryPar != null) {
			webResource = webResource.queryParams(queryPar);
		}
		Builder builder = webResource.getRequestBuilder().type("application/json").accept("application/json");
		if (headers != null && !headers.isEmpty()) {
			for (String key : headers.keySet()) {
				builder = builder.header(key, headers.get(key));
			}
		}
		System.out.println(webResource);
		System.out.println(builder);
		return builder;
	}

	@SuppressWarnings("unused")
	private static Builder createWebResourceBuilder(String resource, Map<String, String> headers) {
		WebResource webResource = new RestTestBase().getWebResource(getBundle().getString("ws.endurl", resource));

		Builder builder = webResource.getRequestBuilder().type("application/json").accept("application/json");
		if (headers != null && !headers.isEmpty()) {
			for (String key : headers.keySet()) {
				builder = builder.header(key, headers.get(key));
			}
		}
		
		//builder.header("x-api-key", "AIzaSyCHSS1cpgkLf1RLLGY-S9L2houQ628KWdA").header("Referer", "qa-regression-heb-mls-prd1");
		System.out.println(webResource);
		System.out.println(builder);
		return builder;

		
	}
}
