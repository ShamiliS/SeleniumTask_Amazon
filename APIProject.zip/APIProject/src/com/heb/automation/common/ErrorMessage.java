package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map.Entry;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class ErrorMessage {

	public static void validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(String actualErrorMessage,
			String ExpectederrorMsg) {
		/*
		 * 
		 * if (actualErrorMessage == null) { Reporter.log(
		 * "Response is success with no failure message!", MessageTypes.Fail); }
		 * else {
		 * 
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class);
		 * 
		 * for (Entry<String, JsonElement> JsonErrorObject :
		 * gson.getAsJsonObject().entrySet()) {
		 * System.out.println(JsonErrorObject.getKey()); if
		 * (JsonErrorObject.getKey().equalsIgnoreCase("message")) {
		 * System.out.println(ExpectederrorMsg);
		 * System.out.println(JsonErrorObject.getValue().toString().replace(
		 * "\"", "")); for (Entry<String, JsonElement> ErrorMessageObject :
		 * JsonErrorObject.getValue().getAsJsonObject() .entrySet()) {
		 * 
		 * if (ErrorMessageObject.getKey().equalsIgnoreCase("text")) {
		 * 
		 * System.out.println(ErrorMessageObject.getValue().toString().replace(
		 * "\"", "")); System.out.println(ExpectederrorMsg);
		 * 
		 * if (ErrorMessageObject.getValue().toString().replace("\"", "").trim()
		 * .equalsIgnoreCase(ExpectederrorMsg.trim())) { Reporter.log(
		 * "Error Message Validated Successfully: " + ExpectederrorMsg,
		 * MessageTypes.Pass); } else { Reporter.log(
		 * "Error Message Validation Failed", MessageTypes.Fail); Reporter.log(
		 * "Actual Error message: " +
		 * ErrorMessageObject.getValue().toString().replace("\"", "").trim());
		 * Reporter.log("ExpectederrorMsg: " + ExpectederrorMsg); } }
		 * 
		 * } } } }
		 * 
		 */}

	public static void validateErrorMessageOfJsonObjectMessage(String actualErrorMessage, String ExpectederrorMsg) {
		/*
		 * 
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class); String Errormessage =
		 * gson.getAsJsonObject().get("message").toString().replace("\"", "");
		 * if (Errormessage.equalsIgnoreCase(ExpectederrorMsg)) { Reporter.log(
		 * "Error Message Validated Successfully: " + Errormessage,
		 * MessageTypes.Pass); } else { Reporter.log(
		 * "Error Message Validated Failed", MessageTypes.Fail); Reporter.log(
		 * "ExpectederrorMsg: " + ExpectederrorMsg); Reporter.log(
		 * "Actual Errormessage: " + Errormessage); }
		 * 
		 */}

	public static void validateErrorResponse(int errorCode) {

		int statusCode = new RestTestBase().getResponse().getStatus().getStatusCode();
		String status = new RestTestBase().getResponse().getStatus().toString();

		Reporter.log("Status: " + status);
		if (statusCode == errorCode) {
			Reporter.log("Response code is " + statusCode + " as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to code " + new RestTestBase().getResponse().getStatus().getStatusCode(),
					MessageTypes.Fail);
		}
	}

	public static void validateObjectJsonObject(String actualErrorMessage, JsonObject ExpectedObject) {
		/*
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class);
		 * 
		 * for (Entry<String, JsonElement> JsonErrorObject :
		 * gson.getAsJsonObject().entrySet()) { if
		 * (JsonErrorObject.getKey().equalsIgnoreCase("object")) { JsonObject
		 * actualObject = JsonErrorObject.getValue().getAsJsonObject();
		 * 
		 * if (actualObject.equals(ExpectedObject)) { Reporter.log(
		 * "Given Body parameter is displayed in Object element",
		 * MessageTypes.Pass); } else { Reporter.log(
		 * "Given Body parameter is not displayed in Object element",
		 * MessageTypes.Fail); } } }
		 */}

	public static void validateIdInErrorResponse(String actualErrorMessage, String collectionId) {
		/*
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class);
		 * 
		 * for (Entry<String, JsonElement> JsonErrorObject :
		 * gson.getAsJsonObject().entrySet()) { if
		 * (JsonErrorObject.getKey().equalsIgnoreCase("id")) { String
		 * actualCollectionId =
		 * JsonErrorObject.getValue().toString().replace("\"", "");
		 * 
		 * if (actualCollectionId.equals(collectionId)) { Reporter.log(
		 * "Collection Id is displayed in Error Response Correctly as " +
		 * actualCollectionId, MessageTypes.Pass); } else { Reporter.log(
		 * "Collection Id is displayed in Error Response Wrongly as " +
		 * actualCollectionId, MessageTypes.Fail); } } }
		 */}

	public static void validateStatusInErrorResponse(String actualErrorMessage, String status) {
		/*
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class);
		 * 
		 * for (Entry<String, JsonElement> JsonErrorObject :
		 * gson.getAsJsonObject().entrySet()) { if
		 * (JsonErrorObject.getKey().equalsIgnoreCase("status")) { String
		 * actualstatus = JsonErrorObject.getValue().toString().replace("\"",
		 * "");
		 * 
		 * if (actualstatus.equals(status)) { Reporter.log(
		 * "Status is displayed in Error Response Correctly as " + actualstatus,
		 * MessageTypes.Pass); } else { Reporter.log(
		 * "Status Id is displayed in Error Response Wrongly as " +
		 * actualstatus, MessageTypes.Fail); }
		 * 
		 * } }
		 */}

	public static String getErrorMessageOfJsonObjectTextUnderJsonObjectMessage(JsonArray errors) {

		String errorMsg = null;

		for (JsonElement gson : errors) {
			for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {
				System.out.println(JsonErrorObject.getKey());
				if (JsonErrorObject.getKey().equalsIgnoreCase("message")) {
					for (Entry<String, JsonElement> ErrorMessageObject : JsonErrorObject.getValue().getAsJsonObject()
							.entrySet()) {
						if (ErrorMessageObject.getKey().equalsIgnoreCase("text")) {
							errorMsg = ErrorMessageObject.getValue().toString().replace("\"", "");
						}
					}
				}
			}
		}
		return errorMsg;
	}

	public static void validateErrorForNotFound_text_id_status(String actualErrorMessage, String ExpectederrorMsg) {
		/*
		 * 
		 * boolean isMessageVailable = false, isIdAvailable = false,
		 * isStatusAvailable = false;
		 * 
		 * if (actualErrorMessage == null) { Reporter.log(
		 * "Response is success with no failure message!", MessageTypes.Fail); }
		 * else {
		 * 
		 * JsonElement gson = new Gson().fromJson(actualErrorMessage,
		 * JsonElement.class);
		 * 
		 * for (Entry<String, JsonElement> JsonErrorObject :
		 * gson.getAsJsonObject().entrySet()) {
		 * 
		 * if (JsonErrorObject.getKey().equalsIgnoreCase("message")) {
		 * 
		 * isMessageVailable = true;
		 * 
		 * for (Entry<String, JsonElement> ErrorMessageObject :
		 * JsonErrorObject.getValue().getAsJsonObject() .entrySet()) {
		 * 
		 * if (ErrorMessageObject.getKey().equalsIgnoreCase("text")) {
		 * 
		 * if (ErrorMessageObject.getValue().toString().replace("\"", "").trim()
		 * .equalsIgnoreCase(ExpectederrorMsg.trim())) { Reporter.log(
		 * "Error Message Validated Successfully: " + ExpectederrorMsg,
		 * MessageTypes.Pass); } else { Reporter.log(
		 * "Error Message Validation Failed", MessageTypes.Fail); Reporter.log(
		 * "Actual Error message: " +
		 * ErrorMessageObject.getValue().toString().replace("\"", "").trim());
		 * Reporter.log("ExpectederrorMsg: " + ExpectederrorMsg); } }
		 * 
		 * } } else if (JsonErrorObject.getKey().equalsIgnoreCase("id")) {
		 * isIdAvailable = true; Reporter.log("id: " +
		 * JsonErrorObject.getValue().toString().replace("\"", ""));
		 * 
		 * } else if (JsonErrorObject.getKey().equalsIgnoreCase("status")) {
		 * isStatusAvailable = true; Reporter.log("status: " +
		 * JsonErrorObject.getValue().toString().replace("\"", "")); } }
		 * 
		 * if (isMessageVailable && isIdAvailable && isStatusAvailable) {
		 * Reporter.log("Gor the response as expected.", MessageTypes.Pass); }
		 * else { Reporter.log(
		 * "Few of the required fields are missing in the response.",
		 * MessageTypes.Fail); Reporter.log("isMessageVailable: " +
		 * isMessageVailable); Reporter.log("isIdAvailable: " + isIdAvailable);
		 * Reporter.log("isStatusAvailable: " + isStatusAvailable); }
		 * 
		 * }
		 * 
		 */}

	public static void validErrorMessageOfJSONObjectMessage() {

		/*
		 * JsonElement gson = new
		 * Gson().fromJson(getBundle().getString("errorMsg"),
		 * JsonElement.class); String errMsg =
		 * gson.getAsJsonObject().get("message").toString().replace("\"", "");
		 * String CollectionID = getBundle().getString("CollectionID"); String
		 * expErrorMsg = "getDataItem Could not read data item for id " +
		 * CollectionID;
		 * 
		 * if (errMsg.equals(expErrorMsg)) { Reporter.log(
		 * "Could not read data item for id " + CollectionID + " as expected",
		 * MessageTypes.Pass); } else { Reporter.log("Item id " + CollectionID +
		 * " is not deleted from cutomer portal", MessageTypes.Fail); }
		 */
	}

	public static void validateMessageFieldFromErrorResponse(String ErrorResponse) {

		boolean isMessageAvailable = false;

		if (ErrorResponse == null) {
			Reporter.log("Response is success with no failure message!", MessageTypes.Fail);
		} else {

			JsonElement gson = new Gson().fromJson(ErrorResponse, JsonElement.class);

			for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {

				if (JsonErrorObject.getKey().equalsIgnoreCase("message")) {

					isMessageAvailable = true;

					if (!JsonErrorObject.getValue().toString().isEmpty()) {
						Reporter.log("Message: " + JsonErrorObject.getValue().toString(), MessageTypes.Pass);
					} else {
						Reporter.log("Message field is empty.", MessageTypes.Fail);
					}

					break;
				}
			}

			if (!isMessageAvailable) {

				JsonArray jArray = (JsonArray) gson.getAsJsonObject().get("errors");

				for (JsonElement jElement : jArray) {
					for (Entry<String, JsonElement> errorObject : jElement.getAsJsonObject().entrySet()) {

						if (errorObject.getKey().equalsIgnoreCase("message")) {

							isMessageAvailable = true;

							if (!errorObject.getValue().toString().isEmpty()) {
								Reporter.log("Message: " + errorObject.getValue().toString(), MessageTypes.Pass);
							} else {
								Reporter.log("Message field is empty.", MessageTypes.Fail);
							}

							break;
						}
					}
					if (isMessageAvailable) {
						break;
					}
				}

				if (!isMessageAvailable) {
					Reporter.log("Message field is not available in the error resposne.", MessageTypes.Fail);
					Reporter.log(ErrorResponse);
				}

			}
		}
	}
}
