package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class ReusableUtils extends RestWSTestCase {

	public static MultivaluedMap<String, String> validApikey() {

		MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
		queryParams.add("key", getBundle().getString("common.apikey"));

		return queryParams;
	}

	public static MultivaluedMap<String, String> iHaveAInValidApikey() {

		MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
		queryParams.add("key", getBundle().getString("common.invalidAPIkey"));

		return queryParams;

	}

	public static void compareStrings(String actual, String expected) {
		if (actual.equalsIgnoreCase(expected)) {
			Reporter.log("Valuess are matching", MessageTypes.Pass);
			Reporter.log("Actual: " + actual);
			Reporter.log("Expected: " + expected);
		} else {
			Reporter.log("Valuess are not matching", MessageTypes.Fail);
			Reporter.log("Actual: " + actual);
			Reporter.log("Expected: " + expected);
		}
	}

	public static String getCurrentTime() {
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		return strTimeStmp;
	}

	public static void printresponse(String result) {

		Reporter.log("*********Response********", MessageTypes.Pass);
		Reporter.log("Reponse STATUS : " + new RestTestBase().getResponse().getStatus());
		Reporter.log("Response for the API : " + result);
		// getlistofJsonObject(result);

	}

	public static void getlistofJsonObject(String response) {

		JsonElement gson = new Gson().fromJson(response, JsonElement.class);

		int i = 1;
		System.out.println("List of Objects in the response ");
		Reporter.log("List of Objects in the response ");

		try {
			for (Entry<String, JsonElement> gsonlist : gson.getAsJsonObject().entrySet()) {

				Reporter.log(gsonlist.getKey());

				if (gsonlist.getValue().isJsonObject()) {

					System.out.println("List of Objects under   :" + gsonlist.getKey());
					Reporter.log("List of Objects under JSON Object:" + gsonlist.getKey(), MessageTypes.Pass);

					getnestedlistofjsonObject(gsonlist.getValue().getAsJsonObject());

					Reporter.log("End of Objects under JSON Object: " + gsonlist.getKey(), MessageTypes.Pass);

				} else if (gsonlist.getValue().isJsonArray()) {

					System.out.println("List of Objects under   :" + gsonlist.getKey());
					Reporter.log("List of Objects under JSON Array :" + gsonlist.getKey());

					getnestedlistofjsonArray(gsonlist.getValue().getAsJsonArray());

					Reporter.log("End of Objects under JSON Array :" + gsonlist.getKey());

				}
			}
		} catch (Exception e) {
			for (JsonElement listIterator : gson.getAsJsonArray()) {

				int TotArraySize = gson.getAsJsonArray().size();

				Reporter.log("Elements of Array: " + i, MessageTypes.Pass);
				Reporter.log("*********************************************", MessageTypes.Pass);

				for (Entry<String, JsonElement> gsonlist : listIterator.getAsJsonObject().entrySet()) {

					Reporter.log(gsonlist.getKey());

					if (gsonlist.getValue().isJsonObject()) {

						System.out.println("List of Objects under   :" + gsonlist.getKey());
						Reporter.log("List of Objects under   :" + gsonlist.getKey(), MessageTypes.Pass);

						getnestedlistofjsonObject(gsonlist.getValue().getAsJsonObject());

						Reporter.log("End of Objects under   :" + gsonlist.getKey(), MessageTypes.Pass);

					} else if (gsonlist.getValue().isJsonArray()) {

						System.out.println("List of Objects under   :" + gsonlist.getKey());
						Reporter.log("List of Objects under JSON Array :" + gsonlist.getKey(), MessageTypes.Pass);

						gsonlist.getValue().getAsJsonArray();

						getnestedlistofjsonArray(gsonlist.getValue().getAsJsonArray());

						Reporter.log("End of Objects under JSON Array :" + gsonlist.getKey(), MessageTypes.Pass);

					}
				}

				i++;

				Reporter.log("*********************************************", MessageTypes.Pass);
			}
		}

	}

	public static ArrayList<String> actualkeyList(String RESPONSE) {

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		getBundle().setProperty("appVersionId",
				gson.getAsJsonObject().get("appVersionId").toString().replace("\"", ""));

		ArrayList<String> ActualKeyList = new ArrayList<String>();
		for (Entry<String, JsonElement> JsonresponseObject : gson.getAsJsonObject().entrySet()) {
			ActualKeyList.add(JsonresponseObject.getKey());
		}

		System.out.println(ActualKeyList);
		return ActualKeyList;
	}

	public static void responseStatusforOK() {

		if (new RestTestBase().getResponse().getStatus().toString().equalsIgnoreCase("OK")) {
			Reporter.log("Response is OK as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to " + new RestTestBase().getResponse().getStatus(), MessageTypes.Fail);
		}

		if (new RestTestBase().getResponse().getStatus().getStatusCode() == 200) {
			Reporter.log("Response code is 200 as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to code " + new RestTestBase().getResponse().getStatus().getStatusCode(),
					MessageTypes.Fail);
		}

	}

	public static void writeJSONreponse(String Response, String filename) throws IOException {

		FileWriter sample = new FileWriter(
				"resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		sample.write(Response);
		sample.close();
	}

	public static void writeJSONreponse(JsonObject asJsonObject, String filename) throws IOException {

		FileWriter sample = new FileWriter(
				"resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(asJsonObject);
		System.out.println(json);

		sample.write(json);
		sample.close();

	}

	public static void validateJSONschema(String schemaname, String filename) throws IOException, ProcessingException {

		File schemaFile = new File(
				"resources" + File.separator + "API_validationSchema" + File.separator + schemaname + ".json");

		File jsonFile = new File("resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		if (ValidationUtils.isJsonValid(schemaFile, jsonFile)) {
			Reporter.log("JSON validated successful", MessageTypes.Pass);
		} else {
			Reporter.log("JSON validation Failed ", MessageTypes.Fail);

		}
	}

	public static void writeJSONreponse(JsonArray asJsonObject, String filename) throws IOException {
		FileWriter sample = new FileWriter(
				"resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String json = gson.toJson(asJsonObject);
		System.out.println(json);

		sample.write(json);
		sample.close();
	}

	public static JsonObject TopcollectionaddJSONObjectwith_outsideddefi(String appID, String Description,
			String outsideDefinition) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("appId", appID);
		objTestBody.addProperty("description", Description);
		objTestBody.addProperty("outsidePara", outsideDefinition);

		return objTestBody;

	}

	public static JsonObject TopcollectionaddJSONObjectcompletedefinition(String appID, String Description) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("appId", appID);
		objTestBody.addProperty("description", Description);
		return objTestBody;
	}

	public static JsonObject TopcollectionaddJSONObjectwithSubcollection(String appID, String Description,
			JsonElement subcollection) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("appId", appID);
		objTestBody.addProperty("description", Description);
		objTestBody.add("appVersions", subcollection);

		return objTestBody;

	}

	public static JsonObject TopcollectionaddJSONObjectwithOnlyMandatory(String appID) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("appId", appID);
		return objTestBody;

	}

	public static String getAppId() {
		return "appId_" + System.currentTimeMillis();

	}

	public static JsonObject TopcollectionaddJSONObjectwithoutMandatory(String Description, String outsideDefinition) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", Description);
		objTestBody.addProperty("outsidePara", outsideDefinition);

		return objTestBody;

	}

	public static JsonObject SubcollectionaddJSONObjectwithOnlyMandatory(String appOSVersion, String appOSName) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("osVersion", appOSVersion);
		objTestBody.addProperty("osName", appOSName);
		return objTestBody;

	}

	public static JsonObject SubcolladdJObjectwithoutoneMandatoryOSver(String appOSName) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("osName", appOSName);
		return objTestBody;

	}

	public static JsonObject SubcolladdJObjectwithoutoneMandatoryOSName(String apposVersion) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("osVersion", apposVersion);
		return objTestBody;

	}

	public static List<String> getAppIdsFromRead() throws Exception {
		// Calling the Read Batch request for getting the existing AppIDs
		// ML_Admin_Url_Read.readTheTopLevelCollectionResultsToFullSuccess();

		List<String> appIdsFromread = getBundle().getList("appIdsFromread");

		if (appIdsFromread.size() > 0) {
			Reporter.log(appIdsFromread + " APP Elements found.", MessageTypes.Pass);
			return appIdsFromread;
		} else {
			Reporter.log("APP Elements not found. Please Create APP Elemnts and try again.", MessageTypes.Fail);
			return null;
		}
	}

	public static void validateErrorMessage() {

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray Error = (JsonArray) gson.getAsJsonObject().get("errors");

		Reporter.log("Total Failures: " + Error.size(), MessageTypes.Pass);

		int i = 0;
		for (JsonElement JsonErrorlist : Error.getAsJsonArray()) {

			boolean isOsNameAvailable = false;
			boolean isOsVersionAvailable = false;
			String text = null;

			Reporter.log("Error Section " + i, MessageTypes.Pass);
			for (Entry<String, JsonElement> JsonErrorObject : JsonErrorlist.getAsJsonObject().entrySet()) {

				if (JsonErrorObject.getKey().equalsIgnoreCase("object")) {

					JsonElement json = gson.getAsJsonObject().get("object");

					for (Entry<String, JsonElement> ObjectDescription : JsonErrorObject.getValue().getAsJsonObject()
							.entrySet()) {

						if (ObjectDescription.getKey().equalsIgnoreCase("osVersion")) {
							isOsVersionAvailable = true;
							break;
						}
						if (ObjectDescription.getKey().equalsIgnoreCase("osName")) {
							isOsNameAvailable = true;
							break;
						}
					}
				}

				if (JsonErrorObject.getKey().equalsIgnoreCase("message")) {

					JsonElement json = gson.getAsJsonObject().get("message");

					for (Entry<String, JsonElement> MessageDescription : JsonErrorObject.getValue().getAsJsonObject()
							.entrySet()) {

						if (MessageDescription.getKey().equalsIgnoreCase("text")) {
							text = MessageDescription.getValue().toString().replace("\"", "");
							break;

						}
					}
				}

			}

			// Validating the Mandatory Property under "Object" and the Missing
			// text property under "Message" sections

			if (isOsVersionAvailable) {
				if (text.contains("osName")) {
					Reporter.log("Available Mandatory Value: osVersion");
					Reporter.log("Required property missing: osName");
				} else {
					Reporter.log("Available Mandatory Value in Object section: osVersion");
					Reporter.log("Missing mandatory Value text not available in \"text\" section", MessageTypes.Fail);
					Reporter.log("Required property missing: osName");
				}
			} else if (isOsNameAvailable) {
				if (text.contains("osVersion")) {
					Reporter.log("Available Mandatory Value: osName");
					Reporter.log("Required property missing: osVersion");
				} else {
					Reporter.log("Available Mandatory Value in Object section: osName");
					Reporter.log("Missing mandatory Value text not available in \"text\" section", MessageTypes.Fail);
					Reporter.log("Required property missing: osVersion");
				}
			} else {
				Reporter.log("No Mandaroty fields found.", MessageTypes.Fail);
			}
			i++;

		}

	}

	public static JsonObject TopcollectionUpdateJSONObjectWithoutAppVersion(String Description) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", Description);

		return objTestBody;

	}

	public static String getCurrentTimeasYYYYMMDD() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "-");
		return strTimeStmp + ".0";
	}

	public static JsonObject SC_Update_AddJsonBodyObjects(String osVersion, String osName) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("osVersion", osVersion);
		objTestBody.addProperty("osName", osName);

		return objTestBody;

	}

	public static void verifyCreated_LastModifiedDate_Autogenerated() {

		boolean isLastModifiedDateAvailable = false;
		boolean isCreateddateAvailable = false;

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {
			System.out.println(JsonErrorObject.getKey());
			if (JsonErrorObject.getKey().equalsIgnoreCase("lastModifiedDate")) {
				isLastModifiedDateAvailable = true;
				continue;
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("creationDate")) {
				isCreateddateAvailable = true;
				continue;
			}

		}

		if (isLastModifiedDateAvailable & isCreateddateAvailable) {
			Reporter.log("Last Modified Date and Creation Date Auto generated", MessageTypes.Pass);

		} else if (isLastModifiedDateAvailable & (!isCreateddateAvailable)) {
			Reporter.log("Creation Date Not Auto generated", MessageTypes.Fail);

		} else if ((!isLastModifiedDateAvailable) & (!isCreateddateAvailable)) {
			Reporter.log("Last Modified Date Not Auto generated", MessageTypes.Fail);

		} else {
			Reporter.log("Last Modified Date and Creation Date Not Auto generated", MessageTypes.Fail);
		}
	}

	public static JsonObject SC_Update_AddJsonBodyObjects_OutsideDefinition(String osVersion, String osName,
			String OutsideDef) {

		String outsideDefProperty = getBundle().getString("update.subcollection.outsidedefProperty");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("osVersion", osVersion);
		objTestBody.addProperty("osName", osName);
		objTestBody.addProperty(outsideDefProperty, OutsideDef);

		return objTestBody;

	}

	public static JsonObject SC_Update_AddJsonBodyObjects_OnlyOneMandatoryfield(String osName) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("osName", osName);
		return objTestBody;
	}

	public static JsonObject TopcollectionUpdateJSONObjectNewFields(String newField1, String newField2)
			throws NoSuchFieldException, SecurityException {

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("newField1", newField1);
		objTestBody.addProperty("newField2", newField2);

		return objTestBody;
	}

	public static JsonObject TopcollectionUpdateJSONObjectwithAppVersion(String Description, JsonArray appVersions)
			throws NoSuchFieldException, SecurityException {

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", Description);
		objTestBody.add("appVersions", appVersions);

		return objTestBody;
	}

	public static JsonArray getUpdatedAppVersion(String AppVersionId) {
		String updatedOsversion = "OsVersion_" + ReusableUtils.getCurrentTime();
		String updatedOsname = "OSName" + ReusableUtils.getCurrentTime();

		JsonObject objAppversion = new JsonObject();
		objAppversion.addProperty("osVersion", updatedOsversion);
		objAppversion.addProperty("osName", updatedOsname);
		objAppversion.addProperty("appVersionId", AppVersionId);

		JsonArray objAppVersionArray = new JsonArray();
		objAppVersionArray.add(objAppversion);

		return objAppVersionArray;
	}

	public static JsonObject TopcollectionUpdateJSONObjectDescriptionAlone(String Description) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", Description);
		return objTestBody;

	}

	public static JsonObject TopcollectionUpdateJSONObjectDescriptionAndAppId(String Description, String appId) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", Description);
		objTestBody.addProperty("appId", appId);
		return objTestBody;

	}

	public static JsonObject TopcollectionUpdateInvalidJSONObjectDescription(String Description) {
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("", Description);
		return objTestBody;

	}

	public static JsonObject SC_Update_AddJsonBodyObjects_Mandatory_and_NewValue(String appVersionId,
			String OutsideDef) {

		String outsideDefProperty = getBundle().getString("update.subcollection.outsidedefProperty");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("appVersionId", appVersionId);
		objTestBody.addProperty(outsideDefProperty, OutsideDef);

		return objTestBody;

	}

	public static JsonObject APIcollectionUpdateEditableFields(String name, String contactInfo, String description) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("name", name);
		objTestBody.addProperty("contactInfo", contactInfo);
		objTestBody.addProperty("description", description);
		return objTestBody;
	}

	public static ArrayList<String> actualkeyListCommon(String RESPONSE) {

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		ArrayList<String> ActualKeyList = new ArrayList<String>();
		for (Entry<String, JsonElement> JsonresponseObject : gson.getAsJsonObject().entrySet()) {
			ActualKeyList.add(JsonresponseObject.getKey());
		}
		System.out.println(ActualKeyList);
		return ActualKeyList;
	}

	public static void validateRequiredFieldsInResponse(String CRUDaction, String RESPONSE) {

		int expectedfields = 0;
		ArrayList<String> ActualKeyListArray;
		ArrayList<String> keys;
		Collection<String> ExpectedKeyList;
		Collection<String> ActualKeyList;
		Collection<String> ExpectedCompareKeyList;
		boolean isAvailable = false;
		switch (CRUDaction) {

		case "apiCollection_Update_Success":

			keys = (ArrayList<String>) getBundle().getList("apicollection.update.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}

			break;

		case "Create_Batch_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.create.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "Create_Batch_Partial_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.create.partialsuccess.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "apiCollection_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.read.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;
			
		case "Resourcepath_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("resourcepath.read.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;
		
		case "Resourcepath_BatchRead_Success":
			JsonElement gson3 = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarray3 = gson3.getAsJsonArray();

			for (JsonElement jelement : jarray3) {

				@SuppressWarnings("unchecked")
				ArrayList<String> req_keys = (ArrayList<String>) getBundle()
						.getList("resourcepath.read.requiredField");
				
				Collection<String> Expected_KeyList = new ArrayList(req_keys);
				ExpectedCompareKeyList = Expected_KeyList;

				ArrayList<String> ActualKeyListArray1= ReusableUtils.actualkeyListCommon(jelement.toString());
				@SuppressWarnings({ "rawtypes", "unchecked" })
				Collection<List<String>> ActualKeyList1 = new ArrayList(ActualKeyListArray1);

				Expected_KeyList.retainAll(ActualKeyList1);

				for (String str : ExpectedCompareKeyList) {
					if (Expected_KeyList.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						isAvailable = false;
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}

			break;
			
		case "apiCollection_BatchRead_Success":
			JsonElement gson1 = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarray1 = gson1.getAsJsonArray();

			for (JsonElement jelement : jarray1) {

				@SuppressWarnings("unchecked")
				ArrayList<String> req_keys = (ArrayList<String>) getBundle()
						.getList("apicollection.read.requiredField");
				
				Collection<String> Expected_KeyList = new ArrayList(req_keys);
				ExpectedCompareKeyList = Expected_KeyList;

				ArrayList<String> ActualKeyListArray1= ReusableUtils.actualkeyListCommon(jelement.toString());
				@SuppressWarnings({ "rawtypes", "unchecked" })
				Collection<List<String>> ActualKeyList1 = new ArrayList(ActualKeyListArray1);

				Expected_KeyList.retainAll(ActualKeyList1);

				for (String str : ExpectedCompareKeyList) {
					if (Expected_KeyList.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						isAvailable = false;
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}

			break;

		case "Delete_Batch_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.delete.tags.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "Delete_Batch_Partial_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.delete.partialsuccess.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "Delete_Specific_Success":
			keys = (ArrayList<String>) getBundle().getList("apicollection.delete.specific.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "serviceDescription_Read_Success":
			JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarray = gson.getAsJsonArray();

			for (JsonElement jele : jarray) {

				int expectedfields1 = 0;
				ArrayList<String> keys1 = (ArrayList<String>) getBundle()
						.getList("servicedescription.read.specific.requiredField");
				Collection<String> ExpectedKeyList1 = new ArrayList(keys1);
				System.out.println(ExpectedKeyList1);
				ExpectedCompareKeyList = ExpectedKeyList1;

				ArrayList<String> ActualKeyListArray1;
				ActualKeyListArray1 = ReusableUtils.actualkeyListCommon(jele.toString());
				Collection<List<String>> ActualKeyList1 = new ArrayList(ActualKeyListArray1);
				System.out.println(ActualKeyList1);

				expectedfields1 = ExpectedKeyList1.size();
				ExpectedKeyList1.retainAll(ActualKeyList1);
				System.out.println(ExpectedKeyList1);

				for (String str : ExpectedCompareKeyList) {
					if (ExpectedKeyList1.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}

			break;

		case "serviceDescription_ReadSpecific_Success":

			keys = (ArrayList<String>) getBundle().getList("servicedescription.read.specific.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "serviceVersion_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("serviceversion.read.batch.requiredField");

			JsonElement gson2 = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarray2 = gson2.getAsJsonArray();

			for (JsonElement jele : jarray2) {
				ActualKeyListArray = ReusableUtils.actualkeyListCommon(jele.toString());
				ActualKeyList = new ArrayList(ActualKeyListArray);

				ExpectedCompareKeyList = new ArrayList(keys);

				for (String str : ExpectedCompareKeyList) {
					if (ActualKeyList.contains(str)) {
						isAvailable = true;
					} else {
						isAvailable = false;
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}

			break;

		case "serviceVersion_ReadSpecific_Success":
			keys = (ArrayList<String>) getBundle().getList("serviceversion.read.batch.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}

			break;

		case "Discovery_Customer_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("discovery_customer.read.requiredField");
			ExpectedCompareKeyList = new ArrayList(keys);

			ActualKeyListArray = ReusableUtils.actualkeyListCommon(RESPONSE);
			ActualKeyList = new ArrayList(ActualKeyListArray);

			for (String str : ExpectedCompareKeyList) {
				if (ActualKeyList.contains(str)) {
					Reporter.log("Exptected Key " + str + " is present in Response", MessageTypes.Pass);
				} else {
					Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
					break;
				}
			}
			break;

		case "Discovery_Customer_SD_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("serviceversion.read.batch.requiredField");
			ExpectedKeyList = new ArrayList(keys);
			ExpectedCompareKeyList = ExpectedKeyList;

			JsonElement gsonSD = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarraySD = gsonSD.getAsJsonArray();

			for (JsonElement jele : jarraySD) {
				ActualKeyListArray = ReusableUtils.actualkeyListCommon(jele.toString());
				ActualKeyList = new ArrayList(ActualKeyListArray);

				expectedfields = ExpectedKeyList.size();
				ExpectedKeyList.retainAll(ActualKeyList);
				System.out.println(ExpectedKeyList);

				for (String str : ExpectedCompareKeyList) {
					if (ExpectedKeyList.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}
			break;

		case "Discovery_Customer_SV_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("serviceversion.read.batch.requiredField");
			ExpectedKeyList = new ArrayList(keys);
			ExpectedCompareKeyList = ExpectedKeyList;

			JsonElement gsonSV = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarraySV = gsonSV.getAsJsonArray();

			for (JsonElement jele : jarraySV) {
				ActualKeyListArray = ReusableUtils.actualkeyListCommon(jele.toString());
				ActualKeyList = new ArrayList(ActualKeyListArray);

				expectedfields = ExpectedKeyList.size();
				ExpectedKeyList.retainAll(ActualKeyList);
				System.out.println(ExpectedKeyList);

				for (String str : ExpectedCompareKeyList) {
					if (ExpectedKeyList.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}
			break;

		case "Discovery_Customer_RP_Read_Success":
			keys = (ArrayList<String>) getBundle().getList("serviceversion.read.batch.requiredField");
			ExpectedKeyList = new ArrayList(keys);
			ExpectedCompareKeyList = ExpectedKeyList;

			JsonElement gsonRP = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jarrayRP = gsonRP.getAsJsonArray();

			for (JsonElement jele : jarrayRP) {
				ActualKeyListArray = ReusableUtils.actualkeyListCommon(jele.toString());
				ActualKeyList = new ArrayList(ActualKeyListArray);

				expectedfields = ExpectedKeyList.size();
				ExpectedKeyList.retainAll(ActualKeyList);
				System.out.println(ExpectedKeyList);

				for (String str : ExpectedCompareKeyList) {
					if (ExpectedKeyList.contains(str)) {
						isAvailable = true;
					} else {
						Reporter.log("Exptected Key " + str + " is not Present in Response", MessageTypes.Fail);
						break;
					}
				}
				if (isAvailable)
					Reporter.log("All Exptected Keys are present in Response", MessageTypes.Pass);
			}
			break;

		default:
			break;
		}

	}

	public static JsonObject APIcollectionUpdateOutsideDinition(String outsideDef1, String outsideDef2) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("outsideDef1", outsideDef1);
		objTestBody.addProperty("outsideDef2", outsideDef2);

		return objTestBody;

	}

	public static JsonObject APIcollectionUpdateServiceDescription(String serviceDescriptionId, String name) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("serviceDescriptionId", serviceDescriptionId);
		objTestBody.addProperty("name", name);

		return objTestBody;

	}

	public static JsonObject APIcollectionUpdateFewEditableFields(String name, String contactInfo) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("name", name);
		objTestBody.addProperty("contactInfo", contactInfo);

		return objTestBody;

	}

	public static JsonObject APIcollectionAddMandatoryFields(String collectionId) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("collectionId", collectionId);

		return objTestBody;

	}

	public static JsonObject serviceDescriptionUpdateEditableFields(String name, String contactInfo,
			String description) {
		JsonObject objTestBody = new JsonObject();

		objTestBody.addProperty("name", name);
		objTestBody.addProperty("contactInfo", contactInfo);
		objTestBody.addProperty("description", description);

		return objTestBody;

	}

	public static void validateJSONschema_ApiDiscovery(String schemaname, String filename) throws Exception {

		File schemaFile = new File("resources" + File.separator + "API_validationSchema" + File.separator
				+ "ApiDiscovery" + File.separator + schemaname + ".json");

		File jsonFile = new File("resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		if (ValidationUtils.isJsonValid(schemaFile, jsonFile)) {
			Reporter.log("JSON validated successful", MessageTypes.Pass);
		} else {
			Reporter.log("JSON validation Failed ", MessageTypes.Fail);

		}
	}

	public static void writeJSONreponse_ApiDiscovery(String Response, String filename) throws Exception {

		FileWriter sample = new FileWriter(
				"resources" + File.separator + "API_JSON" + File.separator + filename + ".json");

		sample.write(Response);
		sample.close();
	}

	public static void verifyResponseStatusfor207() {

		if (new RestTestBase().getResponse().getStatus().getStatusCode() == 0) {
			Reporter.log("Response is Multi-Status as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to " + new RestTestBase().getResponse().getStatus(), MessageTypes.Fail);
		}

		if (new RestTestBase().getResponse().getStatus().getStatusCode() == 207) {
			Reporter.log("Response code is 207 as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to code " + new RestTestBase().getResponse().getStatus().getStatusCode(),
					MessageTypes.Fail);
		}
	}

	public static void verifyResponseCode(int ResponseCode) {

		if (new RestTestBase().getResponse().getStatus().getStatusCode() == ResponseCode) {
			Reporter.log("Response code is " + ResponseCode + " as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response Failed due to code " + new RestTestBase().getResponse().getStatus().getStatusCode(),
					MessageTypes.Fail);
		}
	}

	public static void getnestedlistofjsonObject(JsonObject JObject) {

		JsonElement nestedgson = new Gson().fromJson(JObject, JsonElement.class);

		for (Entry<String, JsonElement> nestedgsonlist : nestedgson.getAsJsonObject().entrySet()) {

			Reporter.log(nestedgsonlist.getKey());

			if (nestedgsonlist.getValue().isJsonObject()) {

				System.out.println("List of Objects under   :" + nestedgsonlist.getKey());
				Reporter.log("List of Objects under JSON Object :" + nestedgsonlist.getKey(), MessageTypes.Pass);

				getnestedlistofjsonObject(nestedgsonlist.getValue().getAsJsonObject());

				Reporter.log("END of Objects under JSON Object :" + nestedgsonlist.getKey(), MessageTypes.Pass);

			} else if (nestedgsonlist.getValue().isJsonArray()) {

				System.out.println("List of Objects under   :" + nestedgsonlist.getKey());
				Reporter.log("List of Objects under JSON Array :" + nestedgsonlist.getKey(), MessageTypes.Pass);

				getnestedlistofjsonArray(nestedgsonlist.getValue().getAsJsonArray());

				Reporter.log("END of Objects under JSON Array :" + nestedgsonlist.getKey(), MessageTypes.Pass);
			}

		}

	}

	public static void getnestedlistofjsonArray(JsonArray JObject) {

		JsonElement nestedgson = new Gson().fromJson(JObject, JsonElement.class);

		int i = 1;

		for (JsonElement listIterator : nestedgson.getAsJsonArray()) {

			Reporter.log("Array Iteration: " + i, MessageTypes.Pass);

			for (Entry<String, JsonElement> gsonlist : listIterator.getAsJsonObject().entrySet()) {

				Reporter.log(gsonlist.getKey());

				if (gsonlist.getValue().isJsonObject()) {

					System.out.println("List of Objects under JSON Object :" + gsonlist.getKey());
					Reporter.log("List of Objects under JSON Object :" + gsonlist.getKey(), MessageTypes.Pass);

					getnestedlistofjsonObject(gsonlist.getValue().getAsJsonObject());

					Reporter.log("END of Objects under JSON Object :" + gsonlist.getKey(), MessageTypes.Pass);

				} else if (gsonlist.getValue().isJsonArray()) {

					System.out.println("List of Objects under   :" + gsonlist.getKey());
					Reporter.log("List of Objects under JSON Array :" + gsonlist.getKey(), MessageTypes.Pass);

					gsonlist.getValue().getAsJsonArray();

					getnestedlistofjsonArray(gsonlist.getValue().getAsJsonArray());

					Reporter.log("END of Objects under JSON Array :" + gsonlist.getKey(), MessageTypes.Pass);

				}

			}
			i++;
		}

	}

}