package com.heb.automation.common.yaml;

import java.util.Map;

public class ReadApiDiscoveryFields {
	
	private String lastModifiedDate;
	private String name;
	private String creationDate;
	private String collectionId;
	private String contactInfo;
	private String description;
	private serviceDescriptionsFields[] serviceDescriptions;
	
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getCollectionId() {
		return collectionId;
	}
	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}
	public String getContactInfo() {
		return contactInfo;
	}
	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public serviceDescriptionsFields[] getServiceDescriptions() {
		return serviceDescriptions;
	}
	public void setServiceDescriptions(serviceDescriptionsFields[] serviceDescriptions) {
		this.serviceDescriptions = serviceDescriptions;
	}
	
}