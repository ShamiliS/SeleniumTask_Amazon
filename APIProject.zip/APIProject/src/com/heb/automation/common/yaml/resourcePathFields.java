package com.heb.automation.common.yaml;

public class resourcePathFields{
	
	private String path;
	private String resourcePathId;
	private String lastModifiedDate;
	private String creationDate;
	private String name;
	private String description;
	
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getResourcePathId() {
		return resourcePathId;
	}
	public void setResourcePathId(String resourcePathId) {
		this.resourcePathId = resourcePathId;
	}
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}