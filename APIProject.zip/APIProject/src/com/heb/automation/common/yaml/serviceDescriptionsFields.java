package com.heb.automation.common.yaml;


public class serviceDescriptionsFields{
	
	private String lastModifiedDate;
	private String name;
	private String creationDate;
	private String serviceDescriptionId;
	private String documentationUrl;
	private String description;
	private String currentVersion;
	private String labels;
	private String openApiSpecUrl;
	private serviceVersionFields[] serviceVersions;
	
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getServiceDescriptionId() {
		return serviceDescriptionId;
	}
	public void setServiceDescriptionId(String serviceDescriptionId) {
		this.serviceDescriptionId = serviceDescriptionId;
	}
	public String getDocumentationUrl() {
		return documentationUrl;
	}
	public void setDocumentationUrl(String documentationUrl) {
		this.documentationUrl = documentationUrl;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCurrentVersion() {
		return currentVersion;
	}
	public void setCurrentVersion(String currentVersion) {
		this.currentVersion = currentVersion;
	}
	public String getLabels() {
		return labels;
	}
	public void setLabels(String labels) {
		this.labels = labels;
	}
	public String getOpenApiSpecUrl() {
		return openApiSpecUrl;
	}
	public void setOpenApiSpecUrl(String openApiSpecUrl) {
		this.openApiSpecUrl = openApiSpecUrl;
	}
	public serviceVersionFields[] getServiceVersions() {
		return serviceVersions;
	}
	public void setServiceVersions(serviceVersionFields[] serviceVersions) {
		this.serviceVersions = serviceVersions;
	}
	
	
}