package com.heb.automation.common.yaml;

public class serviceVersionFields{
	
	private String hostName;
	private String serviceVersionId;
	private String lastModifiedDate;
	private String creationDate;
	private String versionNumber;
	private String basePath;
	private String description;
	private String openApiSpecUrl;
	private resourcePathFields[] resourcePaths;
	
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getServiceVersionId() {
		return serviceVersionId;
	}
	public void setServiceVersionId(String serviceVersionId) {
		this.serviceVersionId = serviceVersionId;
	}
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getBasePath() {
		return basePath;
	}
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getOpenApiSpecUrl() {
		return openApiSpecUrl;
	}
	public void setOpenApiSpecUrl(String openApiSpecUrl) {
		this.openApiSpecUrl = openApiSpecUrl;
	}
	public resourcePathFields[] getResourcePaths() {
		return resourcePaths;
	}
	public void setResourcePaths(resourcePathFields[] resourcePaths) {
		this.resourcePaths = resourcePaths;
	}
}