package com.heb.automation.steps.Adminservices.Appversion.AuditLog;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;

public class ML_AuditLogStepDef extends RestWSTestCase {

	/**
	 * POST Request for creating AppVersion sub collection in batch 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I Post Create Resource for App version Sub-collection")
	public void iPostCreateResourceForAppVersionSubCollection() throws Exception {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.CreateBatch");

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		System.out.println(BodyParamter.toString());

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
		getBundle().setProperty("APIresponse", RESPONSE);
	}

	/**
	 * Read request for audit logs of App Properties 
	 * @throws Exception
	 * @throws IOException
	 */
	@QAFTestStep(description = "i post audit log request for read all")
	public void iPostAuditLogRequestForReadAll() throws Exception, IOException {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.AuditLogURL");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = CommonUtils.GET(resource, headers);
		getBundle().setProperty("AuditLog_Reponse", RESPONSE);
	}

	/**
	 * Validate the collection of audit log response  for AppVersion Id's.
	 */
	@QAFTestStep(description = "Validate the collection of response from audit log")
	public void validateTheCollectionOfResponseFromAuditLog() {
		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		String appversionID = getBundle().getString("AppVersionID").replace("\"", "");
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(appversionID)) {
					Reporter.log("The value of created batch" + appversionID + "is exist in Audit log",
							MessageTypes.Pass);
					break;
				} else {
					Reporter.log("The value of created batch" + appversionID + "is not exist in Audit log",
							MessageTypes.Fail);
				}
			}
		}
	}

	/**
	 * Validate Audit log response for updating sub collection - App version
	 * 1. Validate OS Version and OS name field updates
	 */
	@QAFTestStep(description = "Validate update subcollection of response from audit log")
	public void validateUpdateSubcollectionOfResponseFromAuditLog() {

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		String appversionID = getBundle().getString("AppVersionID").replace("\"", "");
		String appOSVersion = getBundle().getString("AppOSVersion").replace("\"", "");
		String appOSName = getBundle().getString("AppOSName").replace("\"", "");

		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {
			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals(appversionID)) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(appOSVersion) && val.contains(appOSName)) {
					Reporter.log("Updated subcollections value for " + appversionID + "is available in Audit log",
							MessageTypes.Pass);
					break;
				} else {
					Reporter.log("Updated subcollections value for " + appversionID + "is available in Audit log",
							MessageTypes.Fail);
				}
			}
		}

	}

	/**
	 * Validate audit log response for deleting App Properties
	 * 1. Validate  deleted app version id.
	 */
	@QAFTestStep(description = "Validate response of delete operation in audit log")
	public void validateResponseOfDeleteOperationInAuditLog() {

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		String appversionID = getBundle().getString("AppVersionID").replace("\"", "");

		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {
			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals(appversionID)) {
				String val = element.getAsJsonObject().get("operation").toString().replace("\"", "");

				if (val.equals("delete")) {
					Reporter.log(appversionID + "is deleted from Audit log", MessageTypes.Pass);
					break;
				} else {
					Reporter.log(appversionID + "is not deleted from Audit log", MessageTypes.Fail);
				}
			}
		}

	}
}
