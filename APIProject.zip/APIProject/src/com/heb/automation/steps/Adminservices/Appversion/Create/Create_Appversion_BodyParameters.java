package com.heb.automation.steps.Adminservices.Appversion.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map;
import java.util.Map.Entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Create_Appversion_BodyParameters {

	/**
	 * Add Top Collection level, One resource with a complete definition One resource with only minimal /
	 * mandatory definition
	 * 
	 * @return
	 * 
	 * 		Extracted all the appID into an new ArrayList
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter should contain valid array of Property details")
	public static JsonArray theCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails() {

		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectcompletedefinition(ReusableUtils.getAppId(),
				"valid data will full definition"));
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectwithOnlyMandatory(ReusableUtils.getAppId() + "1"));
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectwith_outsideddefi(ReusableUtils.getAppId() + "2",
				"valid data will full definition2", "Outside valdiation"));
		JsonArray AppIDlist = new JsonArray();
		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			if (Jsonlist.isJsonObject()) {
				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {
					if (nestedgsonlist.getKey().equals("appId")) {
						AppIDlist.add(nestedgsonlist.getValue());
					}
				}
			}
		}

		System.out.println(AppIDlist);
		System.out.println(BodyParameter.size());
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("AppIDs", AppIDlist.toString());
		getBundle().setProperty("AppIDsJsonArray", AppIDlist);
		getBundle().setProperty("TotalAppIDscount", String.valueOf(AppIDlist.size()));
		System.out.println(getBundle().getString("TotalAppIDscount"));
		return BodyParameter;

	}

	/**
	 * Add Top Collection level, One resource with duplicate mandatory field
	 * Two unique resources in body parameter.  
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter should contain atleast one resource with duplicate mandatory field")
	public static JsonArray theCreateBatchRequestBodyParameterShouldContainAtleastOneResourceWithDuplicateMandatoryField() {
		
		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectcompletedefinition(ReusableUtils.getAppId(),
				"valid data will full definition"));
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectwithOnlyMandatory(ReusableUtils.getAppId() + "1"));
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectwith_outsideddefi(ReusableUtils.getAppId() + "1",
				"valid data will full definition2", "Outside valdiation"));
		JsonArray AppIDlist = new JsonArray();
		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			System.out.println(Jsonlist);
			if (Jsonlist.isJsonObject()) {

				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {

					if (nestedgsonlist.getKey().equals("appId")) {

						AppIDlist.add(nestedgsonlist.getValue());
					}
				}
			}
		}
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("AppIDs", AppIDlist.toString());
		getBundle().setProperty("TotalAppIDscount", String.valueOf(AppIDlist.size()));
		System.out.println(getBundle().getString("TotalAppIDscount"));
		return BodyParameter;

	}

	/**
	 * Add Top Collection level Body Parameter for create request without mandatory key and value 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter without  Mandatory key & value")
	public static JsonArray theCreateBatchRequestBodyParameterWithoutMandatoryKeyValue() {

		JsonArray BodyParameter = new JsonArray();
		BodyParameter
				.add(ReusableUtils.TopcollectionaddJSONObjectwithoutMandatory("Without Mandatory", "Extra variable"));

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}

	/**
	 * Add Sub Collection level body parameter contains valid array of mandatory fields for create request 
	 * 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter for subcollection level containing a valid array of version details")
	public static JsonArray theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAValidArrayOfVersionDetails() {

		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "Android"));
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "iOS"));
		getBundle().setProperty("TotalAppversioncount", String.valueOf(BodyParameter.size()));
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}

	/**
	 * Add Sub Collection level body parameter contains single resource of mandatory fields for create request 
	 * 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter for subcollection level containing an single Appversion detail")
	public static JsonArray theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAnSingleAppversionDetail() {
	
		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "Android"));
		getBundle().setProperty("TotalAppversioncount", String.valueOf(BodyParameter.size()));
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}

	/**
	 * Add Sub Collection level body parameter contains valid and in-valid array of mandatory fields for create request 
	 * 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter for subcollection level containing an in-valid array of version details")
	public static JsonArray theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAnInValidArrayOfVersionDetails() {
	
		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "iOS"));
		BodyParameter.add(ReusableUtils.SubcolladdJObjectwithoutoneMandatoryOSName("1.8"));
		BodyParameter.add(ReusableUtils.SubcolladdJObjectwithoutoneMandatoryOSName("3.1"));
		getBundle().setProperty("TotalAppversioncount", String.valueOf(BodyParameter.size()));
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}
	
	/**
	 * Add Sub Collection level body parameter contains only in-valid array of mandatory fields for create request 
	 * 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter for subcollection level containing only in-valid array of version details")
	public static JsonArray theCreateBatchRequestBodyParameterForSubcollectionLevelContainingOnlyInValidArrayOfVersionDetails() {

		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.SubcolladdJObjectwithoutoneMandatoryOSName("1.8"));
		BodyParameter.add(ReusableUtils.SubcolladdJObjectwithoutoneMandatoryOSver("Android"));

		System.out.println(BodyParameter);
		getBundle().setProperty("TotalAppversioncount", String.valueOf(BodyParameter.size()));
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}

	/**
	 * Add Sub Collection level body parameter contains duplicate version details for create request 
	 * 
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter for subcollection level containing duplicate version details")
	public static JsonArray theCreateBatchRequestBodyParameterForSubcollectionLevelContainingDuplicateVersionDetails() {
		
		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "Android"));
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "iOS"));
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "Android"));
		BodyParameter.add(ReusableUtils.SubcollectionaddJSONObjectwithOnlyMandatory("2.0", "iOS"));
		getBundle().setProperty("TotalAppversioncount", String.valueOf(BodyParameter.size()));
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;
	}

	/**
	 * Creating an APP Property
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I create an AppProperty")
	public static void iCreateAnAppProperty() throws Exception {

		JsonArray BodyParameter = new JsonArray();
		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectcompletedefinition(ReusableUtils.getAppId(),
				"valid data will full definition"));
		String AppIDlist = null;

		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			if (Jsonlist.isJsonObject()) {
				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {
					if (nestedgsonlist.getKey().equals("appId")) {
						AppIDlist = nestedgsonlist.getValue().toString();
					}
				}
			}
		}
		getBundle().setProperty("AppID", AppIDlist.replace("\"", ""));
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.CreateBatch");
		getBundle().setProperty("env.baseurl", baseurl);
	
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = CommonUtils.POST(resource, headers, BodyParameter);
		getBundle().setProperty("APIresponse", RESPONSE);

			
	}

}
