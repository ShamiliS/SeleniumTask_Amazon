package com.heb.automation.steps.Adminservices.Appversion.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.JsonArray;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;;

public class Create_Appversion_POSTcalls {

	/**
	 * POST call for Create Resource Top level Collection - App Property
	 */
	@QAFTestStep(description = "I Post Create Resource for App Property collection")
	public static void iPostCreateResourceForAppPropertyCollection() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.CreateBatch");
		getBundle().setProperty("env.baseurl", baseurl);
		
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Successfully created new App Id!", MessageTypes.Info);
		} catch (Exception e) {
			Reporter.log("Error while creating new App Id!", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * POST call for Create Resource Sub level Collection - App Version
	 * @param collectionName appId for which sub level collection needs to be created
	 */
	@QAFTestStep(description = "I Post Create Resource for App version Sub-collection under {0}")
	public static void iPostCreateResourceForAppVersionSubCollectionUnder(String collectionName) {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.CreateBatch") + "/" + collectionName + "/appversion";
		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("AppID", collectionName);
		String RESPONSE = null;
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Successfully created new App Versions!", MessageTypes.Info);
		} catch (Exception e) {
			Reporter.log("Error while creating new App Versions!", MessageTypes.Info);
			System.out.println(RESPONSE);
			String errorMsg=null;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			System.out.println("error:" + errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

}
