package com.heb.automation.steps.Adminservices.Appversion.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map.Entry;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Create_Appversion_validations {

	/**
	 * Validating full success response for App Version batch create, compare
	 * the appId's list which are passed as body parameter with response,
	 * Validate OK response
	 */
	@QAFTestStep(description = "Validate the response for Full success")
	public void validateTheResponseForFullSuccess() {
		String AppIDList = getBundle().getString("AppIDs");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		if (successList.toString().equalsIgnoreCase(AppIDList)) {
			Reporter.log("All the APPID's are successful and valdiated ", MessageTypes.Pass);
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

	}

	/**
	 * Validating partial success response for App Version batch create, 1)
	 * Validate both success list and Error list are present for Partial success
	 * 207 2) Validate the Count of Successful and failed matches the expected
	 * number [ Not completed ]
	 */
	@QAFTestStep(description = "Validate the response for Partial success")
	public void validateTheResponseForPartialSuccess() {
		String AppIDList = getBundle().getString("AppIDs");
		String TotalAppIDscount = getBundle().getString("TotalAppIDscount");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray Error = (JsonArray) gson.getAsJsonObject().get("errors");

		int Totalsuccess = successList.size();
		int TotalError = Error.size();

		int overAllcount = Totalsuccess + TotalError;

		String OverALLCount = String.valueOf(overAllcount);

		System.out.println("Complete App list  :" + AppIDList);
		System.out.println("Success list 	:" + successList);
		System.out.println("Error list		: " + Error);

		if (!successList.isJsonNull() && !Error.isJsonNull()) {
			Reporter.log("Only few App property is successful- So Partial successful is valdiated", MessageTypes.Pass);
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
		}

		if (OverALLCount.equalsIgnoreCase(TotalAppIDscount)) {
			Reporter.log("Total APPID's count matches with the sum of successful and failed appid's ",
					MessageTypes.Pass);
		} else {
			Reporter.log("Total APPID's count Doesnot matches with the sum of successful and failed appid's",
					MessageTypes.Fail);
		}

	}

	/**
	 * Validate Sub Collection resource create for full success, 1) Validate
	 * both the Total App version passed matches with the response result, 2) No
	 * Error object should be present
	 */
	@QAFTestStep(description = "Validate the subcollection response for Full success")
	public void validateTheSubcollectionResponseForFullSuccess() {

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		String AppVersionID = successList.get(0).toString().replace("\"", "");
		String AppVersionIDs = successList.toString().replace("\"", "");
		getBundle().setProperty("AppVersionID", AppVersionID);
		getBundle().setProperty("AppVersionIDs", AppVersionIDs);
		getBundle().setProperty("common.appVersionId", AppVersionID);

		int Totalsuccess = successList.size();
		String TotalAppversioncount = getBundle().getString("TotalAppversioncount");

		if (TotalAppversioncount.equalsIgnoreCase(String.valueOf(Totalsuccess))) {

			Reporter.log("Response is fully successful ", MessageTypes.Pass);
		} else {
			Reporter.log("Response is Not fully successful ", MessageTypes.Fail);
		}

		try {
			JsonArray Error = (JsonArray) gson.getAsJsonObject().get("errors");
			if (Error.isJsonNull()) {
				Reporter.log("No Error response object ", MessageTypes.Pass);
			} else {
				Reporter.log("Error response object is present ", MessageTypes.Fail);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Validate Sub Collection resource create for partial success, 1) Validate
	 * both success and Error entries are present, 2) Validate both success list
	 * and Error list are present for Partial success 207, 3) Sum of total
	 * success and failure should match the request count
	 */
	@QAFTestStep(description = "Validate the subcollection response for Partial success")
	public void validateTheSubcollectionResponseForPartialSuccess() {

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray Error = (JsonArray) gson.getAsJsonObject().get("errors");

		String TotalAppversioncount = getBundle().getString("TotalAppversioncount");

		int Totalsuccess = successList.size();
		int TotalError = Error.size();

		int overAllcount = Totalsuccess + TotalError;

		String OverALLCount = String.valueOf(overAllcount);

		if (!successList.isJsonNull() && !Error.isJsonNull()) {
			Reporter.log("Only few App property is successful- parially successful ", MessageTypes.Pass);
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
		}

		if (OverALLCount.equalsIgnoreCase(TotalAppversioncount)) {
			Reporter.log("Total APPID's count matches with the sum of successful and failed appid's ",
					MessageTypes.Pass);
		} else {
			Reporter.log("Total App version count Doesnot matches with the sum of successful and failed App version's",
					MessageTypes.Fail);
		}

	}

	/**
	 * Validate Read Respnse of Sub collection expected App Version Id's with
	 * actual AppVersionId's in response
	 */
	@QAFTestStep(description = "I verify the Created subcollection details are available in the read response")
	public void iVerifyTheCreatedSubcollectionDetailsAreAvailableInTheReadResponse() {

		String exp_AppVersionID = getBundle().getString("AppVersionID");
		boolean isAppVersionIdAvailable = false;
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		JsonArray jArray = gson.getAsJsonArray();

		for (JsonElement jElement : jArray) {

			String AppVersionID = jElement.getAsJsonObject().get("appVersionId").toString().replace("\"", "");

			if (AppVersionID.equalsIgnoreCase(exp_AppVersionID)) {
				isAppVersionIdAvailable = true;
				break;
			}
		}

		if (isAppVersionIdAvailable) {
			Reporter.log("Created AppVersion Id available in the Read response.", MessageTypes.Pass);
			Reporter.log("AppID: " + getBundle().getString("AppID"));
			Reporter.log("AppVersionID: " + exp_AppVersionID);
		} else {
			Reporter.log("Created AppVersion Id not available in the Read response.", MessageTypes.Fail);
			Reporter.log("AppID: " + getBundle().getString("AppID"));
			Reporter.log("AppVersionID: " + exp_AppVersionID);
		}
	}

	/**
	 * Validate the created AppId is available in the read batch response,
	 * Validate response OK.
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I Validate the created AppId is available in the read batch response")
	public void iValidateTheCreatedAppIdIsAvailableInTheReadBatchResponse() throws IOException, ProcessingException {

		String RESPONSE = getBundle().getString("APIresponse");
		int totalAppIds = 0;

		JsonArray AppIDlist = (JsonArray) getBundle().getProperty("AppIDsJsonArray");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray gson1 = gson.getAsJsonArray();
		
		for (JsonElement ele : gson1) {
			String appId = ele.getAsJsonObject().get("appId").toString().replace("\"", "");
			for (int i = 0; i < AppIDlist.size(); i++) {
				if (appId.equalsIgnoreCase(AppIDlist.get(i).toString().replace("\"", ""))) {
					totalAppIds = totalAppIds + 1;
					Reporter.log("AppID: " + appId + " is Available!");
				}
			}
			if (totalAppIds == AppIDlist.size()) {
				break;
			}
		}

		if (totalAppIds == AppIDlist.size()) {
			Reporter.log("All " + totalAppIds + " Created AppID's are available in the Read batch response.",
					MessageTypes.Pass);
		} else {
			Reporter.log("Created AppID is not available in the Read batch response.", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the error message for Invalid apikey 1) code 400 2) API key
	 * not valid. Please pass a valid API key.
	 * 
	 * @param errorCode
	 *            Status code of Response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for Invalid apikey")
	public void iValidateTheResponse_ErrorForInValidApikey(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidKey");
		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}

	/**
	 * Validate error response for invalid appId
	 * 
	 * @param errorCode
	 *            Status code of Response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for in-valid appId")
	public static void iValidateTheResponse_ErrorForInValidAppId(int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidAppId");

		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
	}

	/**
	 * Validate error response for invalid appVersionId
	 * 
	 * @param errorCode
	 *            Status code of Response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for in-valid appVersionId")
	public void iValidateTheResponse_ErrorForInValidAppVersionId(int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidAppVersionId");

		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,
		// expErrorMsg);

	}
}
