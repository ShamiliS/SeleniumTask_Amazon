package com.heb.automation.steps.Adminservices.Appversion.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.JsonArray;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Delete_Appversion_BodyParameters {
	
	/**
	 * Create Body Parameter with valid array of app property details for DELETE request 
	 * @return BodyParameter
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of Property details")
	public static JsonArray theDeleteBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails()
			throws ProcessingException, IOException {

		System.out.println("AppID to be Deleted 	:" + (String) getBundle().getProperty("AppIDs"));

		getBundle().setProperty("AppIDbatchtoDelete", (String) getBundle().getProperty("AppIDs"));

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("AppIDsJsonArray");

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;

	}

	/**
	 * Create Body Parameter with valid array of app property details for DELETE request 
	 */
	@QAFTestStep(description = "the delete batch request Body parameter is having Valid set of all AppIds")
	public void theDeleteBatchRequestBodyParameterIsHavingValidSetOfAllAppIds() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("appIDListToDeleteAsJArray");

		getBundle().setProperty("BodyParametervalue", BodyParameter);

	}

	/**
	 * Create Body Parameter with valid array of app version details for DELETE request 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of appVersion details")
	public void theDeleteBatchRequestBodyParameterShouldContainValidArrayOfAppVersionDetails() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("AppVersionIDsJsonArray");

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		System.out.println(BodyParameter);
	}

}
