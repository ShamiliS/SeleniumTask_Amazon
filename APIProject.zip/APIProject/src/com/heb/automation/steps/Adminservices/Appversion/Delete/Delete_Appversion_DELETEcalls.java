package com.heb.automation.steps.Adminservices.Appversion.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.JsonArray;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Delete_Appversion_DELETEcalls {

	/**
	 * Delete batch resource for App Peroperty top collection with no body parameter 
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I  DELETE batch Resource for Top collection level with No BodyParamter")
	public void iDELETEBatchResourceForTopCollectionLevelWithNoBodyParamter() throws ProcessingException, IOException {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.deletebatch");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}

	}

	/**
	 * Delete batch resource for App Peroperty top collection 
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I DELETE batch Resource for Top collection level")
	public void iDELETEBatchResourceForTopCollectionLevel() throws ProcessingException, IOException {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.deletebatch");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}

	}

	/**
	 * Delete specific resource for App Peroperty top collection using App Id
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I DELETE Resource form Top collection level using appID")
	public void iDELETEResourceFormTopCollectionLevelUsingAppID() throws ProcessingException, IOException {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String appID = ((String) getBundle().getProperty("AppID")).replace("[,\",]", "");
		
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.deletebatch") + "/" + appID;
		getBundle().setProperty("env.baseurl", baseurl);
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * Delete specific resource for App Peroperty top collection without passing appId
	 */
	@QAFTestStep(description = "I DELETE Resource form Top collection level without passing appiD {0}")
	public void iDELETEResourceFormTopCollectionLevelWithoutPassingAppiD(String appID) {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		System.out.println(appID.replace("[,\",]", ""));
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.deletebatch") + "/" + appID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 *   Delete specific resource for App Peroperty top collection using appID as Bad url
	 */
	@QAFTestStep(description = "I DELETE Resource form Top collection level using appID as Bad url")
	public void iDELETEResourceFormTopCollectionLevelUsingAppIDAsBadUrl() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String appID = ((String) getBundle().getProperty("AppID")).replace("[,\",]", "");
		System.out.println(appID.replace("[,\",]", ""));
		String resource =getBundle().getString("MLapiURL.serviceName")+ getBundle().getString("AppProperty.deletebatch") + "/" + appID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 *  Delete specific resource having AppId and AppVersionId as URL Parameters
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I DELETE Resource for sub-collection level having AppId and AppVersionId as URL Parameters")
	public void iDELETEResourceForSubCollectionLevelHavingAppIdAndAppVersionIdAsURLParameters()
			throws ProcessingException, IOException {

		String appID = (String) getBundle().getProperty("AppID");
		String appVersionID = (String) getBundle().getProperty("AppVersionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete") + appID + "/appversion/" + appVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			Reporter.log("Delete Successful.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * Delete specific resource for App version sub level collection using appID as Bad url
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level using Bad url")
	public void iDELETEResourceFromSubCollectionLevelUsingBadUrl() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete");

		System.out.println(baseurl + ":" + resource);

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			Reporter.log("Delete processed with Bad url with \"http\".", MessageTypes.Fail);
			Reporter.log("Url: " + baseurl);
		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Pass);

			String errorMsg;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Delete specific resource for App version sub collection using invalid appVersion id
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level for invalid appVersionId")
	public void iDELETEResourceFromSubCollectionLevelForInvalidAppVersionId() {

		String appID = (String) getBundle().getProperty("AppID");
		String appVersionID = (String) getBundle().getProperty("AppVersionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete") + appID + "/appversion/" + appVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid AppId", MessageTypes.Pass);

			String errorMsg;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Delete specific resource for App version sub collection using invalid appID and valid appVersion Id
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level for invalid appId and valid AppversionID")
	public void iDELETEResourceFromSubCollectionLevelForInvalidAppIdAndValidAppversionID() {

		String appID = (String) getBundle().getProperty("AppID");
		String appVersionID = (String) getBundle().getProperty("AppVersionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete") + appID + "/appversion/" + appVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid AppId", MessageTypes.Pass);

			String errorMsg;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Delete specific resource for App version top collection using empty appVersion Id
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level for empty appVersionId")
	public void iDELETEResourceFromSubCollectionLevelForEmptyAppVersionId() {

		String appID = (String) getBundle().getProperty("AppID");
		String appVersionID = (String) getBundle().getProperty("AppVersionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete") + appID + "/appversion/" + appVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid AppId", MessageTypes.Pass);

			String errorMsg;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Delete specific resource for App version top collection using invalid api key
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level for invalid apikey")
	public void iDELETEResourceFromSubCollectionLevelForInvalidApikey() {

		String appID = (String) getBundle().getProperty("AppID");
		String appVersionID = (String) getBundle().getProperty("AppVersionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.delete") + appID + "/appversion/" + appVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			Reporter.log("Delete processed for Invalid apikey", MessageTypes.Fail);
			Reporter.log("AppVersionId: " + getBundle().getString("common.appVersionId"));
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid apikey", MessageTypes.Pass);

			String errorMsg;
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Read App Property top level collection and get deleted appId's
	 */
	@QAFTestStep(description = "I try to GET the deleted appId from Read Request")
	public void iTryToGETTheDeletedAppIdFromReadRequest() {

		String appID = getBundle().getString("common.validAppId");
		String appversionID = getBundle().getString("common.appVersionId");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.read");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		System.out.println(baseurl + ":" + resource);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Successful for Deleted Resource..", MessageTypes.Fail);
			Reporter.log("appID: " + appID);
			Reporter.log("appversionID: " + appversionID);

		} catch (Exception e) {
			Reporter.log("Read failed for the deleted resource as expected.", MessageTypes.Pass);
			Reporter.log("appID: " + appID);
			Reporter.log("appversionID: " + appversionID);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Delete specific resource for App version top collection using invalid appId in URL
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I DELETE Resource using valid apikey and invalid appId in the URL")
	public void iDELETEResourceUsingValidApikeyAndInvalidAppIdInTheURL() throws ProcessingException, IOException {

		String invalidAppId = getBundle().getString("appID.invalidAppId");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.delete") + invalidAppId;
		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("GivenAppId", invalidAppId);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			getBundle().setProperty("APIresponse", RESPONSE);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * Delete batch resource for App version sub collection using appVersion Ids in body parameters
	 */
	@QAFTestStep(description = "I DELETE batch Resource for sub-collection level having AppVersionId as Body Parameters")
	public void iDELETEBatchResourceForSubCollectionLevelHavingAppVersionIdAsBodyParameters() {
		String appID = (String) getBundle().getProperty("AppID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.DeleteBatch")+appID+"/appversion";

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			Reporter.log("Delete Successful.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error while Deleting Batch Resource.", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * Delete specific resource for App version sub collection using empty app Id
	 */
	@QAFTestStep(description = "I DELETE Resource from Sub collection level for empty appId")
	public void iDELETEResourceFromSubCollectionLevelForEmptyAppId() {
		String appID = (String) getBundle().getProperty("AppID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.DeleteBatch")+"/appversion";

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			Reporter.log("Delete Successful.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error while Deleting Batch Resource.", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

}
