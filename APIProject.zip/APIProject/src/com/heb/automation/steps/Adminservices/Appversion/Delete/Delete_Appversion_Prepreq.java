package com.heb.automation.steps.Adminservices.Appversion.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.Appversion.Create.Create_Appversion_BodyParameters;
import com.heb.automation.steps.Adminservices.Appversion.Create.Create_Appversion_POSTcalls;
import com.heb.automation.steps.Adminservices.Appversion.Read.Read_Appversion_validations;
import com.heb.automation.steps.Adminservices.Appversion.common.Maintenance;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Delete_Appversion_Prepreq {
	/**
	 * Create set of App Property - AppId's for performing delete request
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "Create an set of AppProperty to be deleted")
	public void createAnSetOfAppPropertyToBeDeleted() throws ProcessingException, IOException {
		Create_Appversion_BodyParameters.theCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails();
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		Create_Appversion_POSTcalls.iPostCreateResourceForAppPropertyCollection();
	}

	/**
	 * Create an App Property - AppId's for performing delete request
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I create an AppProperty to be deleted")
	public static void iCreateAnAppPropertyToBeDeleted() throws Exception {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(ReusableUtils.TopcollectionaddJSONObjectcompletedefinition(ReusableUtils.getAppId(),
				"valid data will full definition"));

		String AppIDlist = null;

		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {

			if (Jsonlist.isJsonObject()) {

				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {

					if (nestedgsonlist.getKey().equals("appId")) {

						AppIDlist = nestedgsonlist.getValue().toString();

					}

				}
			}

		}
		getBundle().setProperty("AppID", AppIDlist.replace("\"", ""));
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("AppProperty.CreateBatch");
		getBundle().setProperty("env.baseurl", baseurl);
	
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = CommonUtils.POST(resource, headers, BodyParameter);
		getBundle().setProperty("APIresponse", RESPONSE);

	}

	/**
	 * Create an App Version for given AppId's for performing delete request
	 */
	@QAFTestStep(description = "I create an Appversion for the AppID which I got")
	public static void iCreateAnAppversionForTheAppIDWhichIGot() {
		String appId = getBundle().getString("AppID");
		Create_Appversion_BodyParameters
				.theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAnSingleAppversionDetail();
		Create_Appversion_POSTcalls.iPostCreateResourceForAppVersionSubCollectionUnder(appId);
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		String appVersionId = null;
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successListArray = gson.getAsJsonObject().getAsJsonArray("success");

		for (JsonElement appVersionJson : successListArray) {
			appVersionId = appVersionJson.toString().replace("\"", "");
		}

		getBundle().setProperty("AppVersionID", appVersionId);

		System.out.println(getBundle().getProperty("AppVersionID"));

	}

	/**
	 * 1. Read Valid appId by executing Read top level collection, 2. Assign
	 * valid AppId and Invalid AppVersionId for Testing
	 * 
	 * @throws ProcessingException
	 * @throws Exception
	 */
	@QAFTestStep(description = "The user is having a valid appId and Invalid appVersionId")
	public void theUserIsHavingAValidAppIdAndInvalidAppVersionId() throws ProcessingException, Exception {

		// Calling the Read Batch request for getting the existing AppIDs and
		// APPVersionIds
		Read_Appversion_validations.readTheTopLevelCollectionResultsToFullSuccess();

		String invalidAppVersionId = getBundle().getString("appID.invalidAppVersionId");
		String validAppId = getBundle().getString("AppIdwithAppVersion");

		getBundle().setProperty("AppID", validAppId);
		getBundle().setProperty("AppVersionID", invalidAppVersionId);

		if (!invalidAppVersionId.isEmpty() && !validAppId.isEmpty()) {
			Reporter.log("Valid AppId: " + validAppId + ", Invalid AppVersionId: " + invalidAppVersionId,
					MessageTypes.Pass);
		} else {
			Reporter.log("Error occured while getting the Valid APPId and Invalid APPVersionId from the Read request.",
					MessageTypes.Fail);
		}
	}

	/**
	 * 1. Read Valid appVersion by executing Read top level collection, 2.
	 * Assign in-valid AppId and valid AppVersionId for Testing
	 * 
	 * @throws ProcessingException
	 * @throws Exception
	 */
	@QAFTestStep(description = "The user is having a Invalid appId and valid appVersionId")
	public void theUserIsHavingAInvalidAppIdAndValidAppVersionId() throws ProcessingException, Exception {

		// Calling the Read Batch request for getting the existing AppIDs and
		// APPVersionIds
		Read_Appversion_validations.readTheTopLevelCollectionResultsToFullSuccess();

		String validAppVersionId = getBundle().getString("AppVersionIDchoosen");
		String invalidAppId = getBundle().getString("appID.invalidAppId");
		getBundle().setProperty("AppID", invalidAppId);
		getBundle().setProperty("AppVersionID", validAppVersionId);
		System.out.println(validAppVersionId);
		System.out.println(invalidAppId);

		if (!validAppVersionId.isEmpty() && !invalidAppId.isEmpty()) {
			Reporter.log("Invalid AppId to be used : " + invalidAppId + ", Valid AppVersionId to be used : "
					+ validAppVersionId, MessageTypes.Pass);
		} else {
			Reporter.log("Error occured while getting the Invalid APPId and Valid APPVersionId from the Read request.",
					MessageTypes.Fail);
		}
	}

	/**
	 * 1. Read Valid appId by executing Read top level collection, 2. Assign
	 * valid AppId and empty AppVersionId for Testing
	 * 
	 * @throws ProcessingException
	 * @throws Exception
	 */
	@QAFTestStep(description = "The user is having a valid appId and empty appVersionId")
	public void theUserIsHavingAValidAppIdAndEmptyAppVersionId() throws ProcessingException, Exception {

		// Calling the Read Batch request for getting the existing AppIDs and
		// APPVersionIds
		Read_Appversion_validations.readTheTopLevelCollectionResultsToFullSuccess();

		String emptyAppVersionId = "";
		String validAppId = getBundle().getString("AppIdwithAppVersion");

		getBundle().setProperty("AppID", validAppId);
		getBundle().setProperty("AppVersionID", emptyAppVersionId);

		if (emptyAppVersionId.isEmpty() && !validAppId.isEmpty()) {
			Reporter.log("Valid AppId: " + validAppId + ", AppVersionId: <empty value>", MessageTypes.Pass);
		} else {
			Reporter.log("Error occured while getting the Valid APPId and empty APPVersionId from the Read request.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Create set of AppVersion Id's for the given AppId
	 */
	@QAFTestStep(description = "I create batch of Appversions for the AppID which I got")
	public void iCreateBatchOfAppversionsForTheAppIDWhichIGot() {
		String appId = getBundle().getString("AppID");
		Create_Appversion_BodyParameters
				.theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAValidArrayOfVersionDetails();
		Create_Appversion_POSTcalls.iPostCreateResourceForAppVersionSubCollectionUnder(appId);
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		JsonElement code = gson.getAsJsonObject().get("code");

		String AppVersionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("AppVersionID", AppVersionID);
		getBundle().setProperty("AppVersionIDsJsonArray", successList);
	}

	@QAFTestStep(description = "the user is having the Valid set of all AppIds")
	public void theUserIsHavingTheValidSetOfAllAppIds() {
		Maintenance.getAllTheRecordsUnderResources(getBundle().getString("AppProperty.ReadBatch"));
		Maintenance.storeTheInAnArrayListExceptDefault("appId");
	}

}
