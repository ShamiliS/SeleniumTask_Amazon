package com.heb.automation.steps.Adminservices.Appversion.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map.Entry;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Delete_Appversion_validations {

	/**
	 * Validate the DELETE batch response for Full success 1. Validate Response
	 * OK 2. Validate Json Schema 3. Compare the appId list of expected and
	 * actually deleted
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "Validate the DELETE batch response for Full success")
	public void validateTheDELETEBatchResponseForFullSuccess() throws Exception {

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		ReusableUtils.writeJSONreponse(ConfigurationManager.getBundle().getString("APIresponse"),
				"App_Property_DeleteBatch");

		ReusableUtils.validateJSONschema("App_property_DELETEBatch_Schema", "App_Property_DeleteBatch");

		System.out.println((String) getBundle().getProperty("AppIDbatchtoDelete"));
		System.out.println(successList.toString());

		if (successList.toString().equalsIgnoreCase((String) getBundle().getProperty("AppIDbatchtoDelete"))) {
			Reporter.log("Batch DELETE is Fully successfully" + successList, MessageTypes.Pass);
		} else {
			Reporter.log("Batch DELETE is Not fully successfully" + successList, MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validate the DELETE specific response for Full success 1. Validate
	 * Response OK 2. Validate Json Schema 3. validate response for deleted app
	 * id
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the delete response for full success")
	public void iValidateTheDeleteResponseForFullSuccess() throws Exception {

		String ExpectedKeyList = getBundle().getString("common.ExpectedDeleteAppPropBody");
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		ReusableUtils.writeJSONreponse(ConfigurationManager.getBundle().getString("APIresponse"),
				"App_Property_DeleteBatch");
		ReusableUtils.validateJSONschema("App_property_DELETEBatch_Schema", "App_Property_DeleteBatch");

		for (Entry<String, JsonElement> JsonErrorResponseObject : gson.getAsJsonObject().entrySet()) {
			if (JsonErrorResponseObject.getKey().equalsIgnoreCase("id")) {
				System.out.println(JsonErrorResponseObject.getValue().toString());
				System.out.println((String) getBundle().getProperty("AppID"));
				if ((JsonErrorResponseObject.getValue().toString()).replace("\"", "")
						.equalsIgnoreCase((String) getBundle().getProperty("AppID"))) {

					Reporter.log("Correct AppID for Deleted", MessageTypes.Pass);
				} else {
					Reporter.log("Correct AppID for Deleted", MessageTypes.Fail);
				}
			}

		}
		ReusableUtils.responseStatusforOK();

	}

	/**
	 * Validate the DELETE response for Full success of AppVersion sub
	 * collection 1. Validate Response OK 2. Validate Json Schema 3. Compare the
	 * appVersionId list of expected and actually deleted
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the App Version DELETE response for Full success")
	public void validateTheAppVersionDELETEResponseForFullSuccess() throws Exception {

		String appID = (String) getBundle().getProperty("AppID");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		String deletedAppVersionId = gson.getAsJsonObject().get("id").toString().replace("\"", "");
		ReusableUtils.writeJSONreponse(getBundle().getString("APIresponse"), "App_Version_DELETE");

		ReusableUtils.validateJSONschema("App_Version_DELETE_Schema", "App_Version_DELETE");

		if (deletedAppVersionId.toString().equalsIgnoreCase(getBundle().getString("AppVersionID"))) {
			Reporter.log("DELETE Appversion Id is Successfull for Id: " + deletedAppVersionId + "under APPID" + appID,
					MessageTypes.Pass);
		} else {
			Reporter.log("DELETE Appversion Id is not Successfull for Id: " + deletedAppVersionId, MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validate the Read response for not having deleted appId 1. Compare
	 * expected and actual OSname and OSversion
	 */
	@QAFTestStep(description = "I verify the deleted AppId is not available in the Read response")
	public void iVerifyTheDeletedAppIdIsNotAvailableInTheReadResponse() {

		String exp_OSName = getBundle().getString("updatedOsname");
		String exp_OSVersion = getBundle().getString("updatedOsversion");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		String osName = gson.getAsJsonObject().get("osName").toString().replace("\"", "");
		String osVersion = gson.getAsJsonObject().get("osVersion").toString().replace("\"", "");

		if (osName.equalsIgnoreCase(exp_OSName)) {
			Reporter.log("Validation successful.", MessageTypes.Pass);
			Reporter.log("Expected osName: " + exp_OSName);
			Reporter.log("Actual osName: " + osName);
		} else {
			Reporter.log("Updated \"osName\" value not updated in the Read response.", MessageTypes.Fail);
			Reporter.log("Expected osName: " + exp_OSName);
			Reporter.log("Actual osName: " + osName);
		}

		if (osVersion.equalsIgnoreCase(exp_OSVersion)) {
			Reporter.log("Validation successful.", MessageTypes.Pass);
			Reporter.log("Expected osVersion: " + exp_OSVersion);
			Reporter.log("Actual osVersion: " + osVersion);
		} else {
			Reporter.log("Updated \"osVersion\" value not updated in the Read response.", MessageTypes.Fail);
			Reporter.log("Expected osVersion: " + exp_OSVersion);
			Reporter.log("Actual osVersion: " + osVersion);
		}
	}

	/**
	 * Validate the DELETE batch response for Full success for Valid set of all
	 * AppIds 1. Validate Response OK 2. Validate Json Schema 3. Get deleted app
	 * ids
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the DELETE batch response for Full success for Valid set of all AppIds")
	public void validateTheDELETEBatchResponseForFullSuccessForValidSetOfAllAppIds() throws Exception {

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		JsonArray successList;

		try {
			successList = (JsonArray) gson.getAsJsonObject().get("success");

			if (successList.toString().equalsIgnoreCase((String) getBundle().getProperty("AppIDbatchtoDelete"))) {
				Reporter.log("Batch DELETE is Fully successfully" + successList, MessageTypes.Pass);
			} else {
				Reporter.log("Batch DELETE is Not fully successfull" + successList, MessageTypes.Fail);
			}

		} catch (Exception e) {

			try {
				Reporter.log("No AppIds available to delete.", MessageTypes.Pass);

				for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {

					if (JsonErrorObject.getKey().equalsIgnoreCase("code")) {
						Reporter.log("Code: " + JsonErrorObject.getValue().toString().replace("\"", ""));
						break;
					}
				}
			} catch (Exception e1) {
				Reporter.log("Error occured during response validation.", MessageTypes.Fail);
			}

		}

		ReusableUtils.writeJSONreponse(ConfigurationManager.getBundle().getString("APIresponse"),
				"App_Property_DeleteBatch");

		ReusableUtils.validateJSONschema("App_property_DELETEBatch_Schema", "App_Property_DeleteBatch");

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validate the DELETE batch response for Full success for Valid set of
	 * appVersionId's 1. Validate Response OK 2. Validate Json Schema 3. Get
	 * deleted app ids
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the App Version DELETE Batch response for Full success")
	public void validateTheAppVersionDELETEBatchResponseForFullSuccess() throws Exception {
		String appID = (String) getBundle().getProperty("AppID");
		JsonArray AppVersionIDsJsonArray = (JsonArray) getBundle().getProperty("AppVersionIDsJsonArray");
		int chkCount = 0;
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		JsonArray deletedAppVersionIdArray = gson.getAsJsonObject().getAsJsonArray("success");
		ReusableUtils.writeJSONreponse(ConfigurationManager.getBundle().getString("APIresponse"),
				"App_Version_DeleteBatch");

		ReusableUtils.validateJSONschema("App_Version_DELETEBatch_Schema", "App_Version_DeleteBatch");

		if (deletedAppVersionIdArray.size() == AppVersionIDsJsonArray.size()) {
			Reporter.log("Number of App Version Id's deleted are " + deletedAppVersionIdArray.size(),
					MessageTypes.Pass);
		} else {
			Reporter.log("Number of App Version Id's deleted mismatches ", MessageTypes.Fail);
		}

		for (int i = 0; i < deletedAppVersionIdArray.size(); i++) {
			String actualAppVersionId = deletedAppVersionIdArray.get(i).toString().replace("\"", "");
			for (int j = 0; j < AppVersionIDsJsonArray.size(); j++) {
				String expAppVersionId = AppVersionIDsJsonArray.get(j).toString().replace("\"", "");

				if (expAppVersionId.equalsIgnoreCase(actualAppVersionId)) {
					Reporter.log("Deleted AppVersion Id: " + expAppVersionId);
					chkCount++;
				}

				if (deletedAppVersionIdArray.size() == chkCount) {
					break;
				}
			}
		}

		if (deletedAppVersionIdArray.size() == chkCount) {
			Reporter.log("DELETE Appversion Id is Successfull for Id's: " + deletedAppVersionIdArray.toString()
					+ "under APPID" + appID, MessageTypes.Pass);
		} else {
			Reporter.log("DELETE Appversion Id is not Successfull for Id's: " + deletedAppVersionIdArray.toString(),
					MessageTypes.Fail);
		}
		ReusableUtils.responseStatusforOK();
	}

	/**
	 * <<<<<<< HEAD 1) Validate the response code 2) Message field is available
	 * in the response
	 * 
	 * @param errorCode
	 *            ======= Validate the error response for
	 *            "Resource not belong to Parent" error with errorcode
	 * @param errorCode
	 *            statusCode from response >>>>>>>
	 *            8caf87b2374c28f0c459991da5024f576bc3c1b9
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for resource not belong to parent")
	public void iValidateTheResponse_ErrorForResourceNotBelongToParent(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.resourceNotBelong");
		ErrorMessage.validateErrorResponse(errorCode);
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}

	/**
	 * Validate error response for empty appVersionId with error code
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for empty appVersionId")
	public void iValidateTheResponse_ErrorForEmptyAppVersionId(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.emptyAppId");
		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
	}

	/**
	 * Validate error resposnse for bad request
	 * 
	 * @param l0
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0} bad request")
	public void iValidateTheResponseBadRequest(long l0) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = "Not Found";
		int Errorcode = new RestTestBase().getResponse().getStatus().getStatusCode();
		ErrorMessage.validateErrorResponse(Errorcode);
		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
	}

	/**
	 * Error validation for invalid appVersion Id
	 */
	public void ValidateErrorForInvalidAppVersionId() {
		/*
		 * 
		 * String id = null; String appVersionId =
		 * getBundle().getString("AppVersionID");
		 * 
		 * // Actual values from the Response JsonElement gson = new
		 * Gson().fromJson(ConfigurationManager.getBundle().getString("errorMsg"
		 * ), JsonElement.class); try { JsonElement json =
		 * gson.getAsJsonObject().get("message"); } catch (Exception e) {
		 * Reporter.log("Message key is not available in the response.",
		 * MessageTypes.Fail); }
		 * 
		 * id = gson.getAsJsonObject().get("id").toString().replace("\"", "");
		 * 
		 * // Validating the Id value if (id.equalsIgnoreCase(appVersionId)) {
		 * Reporter.log("Id: " + id, MessageTypes.Pass); } else { Reporter.log(
		 * "Id value is incorrect.", MessageTypes.Fail); Reporter.log("Id: " +
		 * id); }
		 * 
		 */}

	/**
	 * Validate error response for invalid appVersion Id with error code
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for Updating in-valid appVersionId")
	public void iValidateTheResponse_ErrorForUpdatingInValidAppVersionId(int errorCode) {

		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.updateInvalidAppVersionId");
		ErrorMessage.validateErrorResponse(errorCode);
		ValidateErrorForInvalidAppVersionId();
	}

	/**
	 * Validate error response for updating invalid appId
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for Updating in-valid appId")
	public void iValidateTheResponse_ErrorForUpdatingInValidAppId(int errorCode) {

		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.updateInvalidAppId");
		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validate error response for updating invalid appId and valid appVersionId
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for in-valid appId and valid AppversionID")
	public void iValidateTheResponse_ErrorForInValidAppIdAndValidAppversionID(int errorCode) {

		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidAppIDValidAppversionID");
		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validate error response for updating valid appId and invalid appVersionId
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for valid appID and in-valid appVersionId")
	public void iValidateTheResponse_ErrorForValidAppIDAndInValidAppVersionId(int errorCode) {

		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.validAppIDandInValidAppversionID");
		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
	}

	/**
	 * Validate error response for Not found of appId or AppVersionId
	 * 
	 * @param errorCode
	 *            statusCode from response
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for Not Found")
	public void iValidateTheResponse_ErrorForNotFound(int errorCode) {

		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.notfound");
		ErrorMessage.validateErrorResponse(errorCode);
		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,
		// expErrorMsg);
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}

}
