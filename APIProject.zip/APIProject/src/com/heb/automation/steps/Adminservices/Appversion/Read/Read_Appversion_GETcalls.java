package com.heb.automation.steps.Adminservices.Appversion.Read;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Read_Appversion_GETcalls {

	/**
	 * Triggering the GET method and storing the response in variable
	 * 'APIresponse'
	 * 
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I GET or READ batch resources")
	public static void iGETBatchResourceUsingValidApikey() throws ProcessingException, IOException {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Batch Read Successful.", MessageTypes.Pass);

		} catch (Exception e) {

			Reporter.log("Error occured during batch Read.", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Call GET request and read batch using protocol
	 * @param protocol http or https protocol
	 */
	@QAFTestStep(description = "I GET batch resource using {0} protocol")
	public void iGETBatchResourceUsingProtocol(String protocol) {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", protocol);
		String resource =getBundle().getString("MLapiURL.serviceName")+ getBundle().getString("AppProperty.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Succesfully Read the Properties with " + protocol + " protocol!", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error in Reading the properties with " + protocol + " protocol!", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * GET request to read sub collection batch resource for appID and appversionID
	 * @param protocol http or https protocol
	 * @param appID
	 * @param appversionID
	 */
	@QAFTestStep(description = "I GET sub collection batch resource using {0} protocol for appID {1} and appversion {2}")
	public void iGETSubCollectionBatchResourceUsingProtocolForAppIDAndAppversion(String protocol, String appID,
			String appversionID) {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", protocol);
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.read") + appID + "/appversion/" + appversionID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Succesfully Read the Properties with " + protocol + " protocol!", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error in Reading the properties with " + protocol + " protocol!", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * GET request to read top collection batch resource for appID 
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I GET or READ resource for appID{0}")
	public static void iGETBatchResourceForAppIDUsingValidApikey(String appID) throws ProcessingException, IOException {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.read") + appID;
		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("AppId", appID);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Resource successful.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error in Reading the properties with invalid apikey!", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}

	}

	/**
	 * 1) GET the sub collection resource for specific appID 2) Storing the
	 * Success response in a variable 'APIresponse'
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I GET Batch sub collection resource for appID {0}")
	public void iGETBatchSubCollectionResourceForAppID(String appID) throws ProcessingException, IOException {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("AppID", appID);
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Batch Read for Subcollection successful.", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("Error occured while Subcollection Batch Read.", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * GET request to read sub collection batch resource for appID and appversionID
	 * @param appID appId
	 * @param appversionID appversionID
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I GET sub collection resource for appID {0} and appversionId {1}")
	public void iGETSubCollectionResourceForAppIDAndAppversion(String appID, String appversionID)
			throws ProcessingException, IOException {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("AppID", appID);
		getBundle().setProperty("AppVersionID", appversionID);
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.read");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		System.out.println(baseurl + ":" + resource);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Successful..", MessageTypes.Info);
			Reporter.log("appID: " + appID);
			Reporter.log("appversionID: " + appversionID);

			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error in Reading the properties!", MessageTypes.Info);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Get request to read top collection level and validate deleted appId's are present
	 */
	@QAFTestStep(description = "I try to GET the deleted appId from Top collection Read Request")
	public void iTryToGETTheDeletedAppIdFromTopCollectionReadRequest() {

		String appID = ((String) getBundle().getProperty("AppID")).replace("[,\",]", "");
		String appversionID = getBundle().getString("common.appVersionId");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.read") + appID;
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		System.out.println(baseurl + ":" + resource);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Successful for Deleted Resource..", MessageTypes.Fail);
			Reporter.log("appID: " + appID);
			Reporter.log("appversionID: " + appversionID);

		} catch (Exception e) {
			Reporter.log("Read failed for the deleted resource as expected.", MessageTypes.Pass);
			Reporter.log("appID: " + appID);
			Reporter.log("appversionID: " + appversionID);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Get request to read sub collection level resource
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I GET Batch sub collection resource")
	public void iGETBatchSubCollectionResource() throws ProcessingException, IOException {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("READ Batch successful.", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("READ Batch failed.", MessageTypes.Fail);
		}

	}

	/**
	 * 1) READ Batch resource with Invalid apikey 2) Storing the error response
	 * in a String variable 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I GET or READ batch resources with Invalid apikey")
	public void iGETOrREADBatchResourcesWithInvalidApikey() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			CommonUtils.GET(resource, headers);
			Reporter.log("Batch Read Successful with Invalid apikey.", MessageTypes.Fail);

		} catch (Exception e) {

			Reporter.log("Batch Read failed due to invalid apikey.", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Read a specific resource from appversion top collection level 2)
	 * Stores it in variable 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ a resource from appversion top collection level")
	public void iREADAResourceFromAppversionTopCollectionLevel() {

		String appID = getBundle().getString("AppID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.read") + appID;
		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("AppID", appID);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Resource successful.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error in Reading the properties with invalid apikey!", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}

	}

	/**
	 * 1) Read a resource with Invalid appId 2) Storing the error response in
	 * variable 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I READ a resource from appversion top collection level with Invalid appId")
	public void iREADAResourceFromAppversionTopCollectionLevelWithInvalidAppId() {

		String InvalidAppID = getBundle().getString("collection.wrongcollection");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.read") + InvalidAppID;
		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("AppId", InvalidAppID);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Read Resource successful with Invalid AppId.", MessageTypes.Fail);

		} catch (Exception e) {
			Reporter.log("Error in Reading the properties with invalid apikey!", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}

	}

}
