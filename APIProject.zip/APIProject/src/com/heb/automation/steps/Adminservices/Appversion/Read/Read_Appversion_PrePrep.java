package com.heb.automation.steps.Adminservices.Appversion.Read;

import java.io.IOException;

import com.heb.automation.steps.ML_CommonStepDef;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Read_Appversion_PrePrep {

	/**
	 * Getting a valid AppID and storing it in variable "AppID"
	 * 
	 * @throws Exception
	 * @throws IOException
	 */
	@QAFTestStep(description = "the user is having a valid appID")
	public void theUserIsHavingAValidAppID() throws Exception, IOException {
		
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		Read_Appversion_GETcalls.iGETBatchResourceUsingValidApikey();
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfREAD();
	}

}
