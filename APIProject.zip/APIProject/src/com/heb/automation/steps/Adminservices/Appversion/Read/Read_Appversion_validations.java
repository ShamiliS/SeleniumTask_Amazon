package com.heb.automation.steps.Adminservices.Appversion.Read;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.Appversion.Create.Create_Appversion_BodyParameters;
import com.heb.automation.steps.Adminservices.Appversion.Delete.Delete_Appversion_Prepreq;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Read_Appversion_validations {

	/**
	 * Validating the Success response for Batch Read
	 * 1. Schema Validation for Mandatory and Optional elements
	 * 
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "I Validate the response for Full success of batch READ")
	public static void iValidateTheResponseForFullSuccessOfREAD() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson1 = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray gson = gson1.getAsJsonArray();
		
		ReusableUtils.writeJSONreponse(gson, "App_Property_READ");
		ReusableUtils.validateJSONschema("App_Property_READ_Schema", "App_Property_READ");

		long size = gson.size();

		for (JsonElement ele : gson) {
			String appId = ele.getAsJsonObject().get("appId").toString().replace("\"", "");
			getBundle().setProperty("AppID", appId);
			break;
		}

		if (RESPONSE.equalsIgnoreCase("[]")) {

			Reporter.log("No App Properties available to Read.", MessageTypes.Pass);
			Reporter.log(RESPONSE);
		} else {

			if (size > 0) {
				Reporter.log("Successfully read the properties, Number of properties available: " + size,
						MessageTypes.Pass);
			} else {
				Reporter.log("Not successfully Read the properties", MessageTypes.Fail);
			}
		}

		ReusableUtils.responseStatusforOK();

	}

	/**
	 * Validating the response of full success for appversions specific Read 
	 * 1. Schema Validation for Mandatory and Optional elements
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I Validate the response for Full success of specific READ")
	public static void iValidateTheResponseForFullSuccessOfSpecificREAD() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		ReusableUtils.writeJSONreponse(RESPONSE, "App_Property_READ_Specific");
		ReusableUtils.validateJSONschema("App_Property_READ_Specific_Schema", "App_Property_READ_Specific");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		getBundle().setProperty("description", gson.getAsJsonObject().get("description").toString().replace("\"", ""));
		getBundle().setProperty("lastModifiedDate",
				gson.getAsJsonObject().get("lastModifiedDate").toString().replace("\"", ""));
		getBundle().setProperty("creationDate",
				gson.getAsJsonObject().get("creationDate").toString().replace("\"", ""));
		getBundle().setProperty("AppID", gson.getAsJsonObject().get("appId").toString().replace("\"", ""));
		getBundle().setProperty("appVersions", gson.getAsJsonObject().get("appVersions").toString().replace("\"", ""));

		Reporter.log(String.valueOf(new RestTestBase().getResponse().getStatus().getStatusCode()));
		ReusableUtils.responseStatusforOK();
	}

	/**
	 * 1) Validating the empty response []
	 * 2) Status as OK
	 */
	@QAFTestStep(description = "I Validate the response is empty with status OK")
	public void iValidateTheResponseIsEmptyWihtStatusOK() {
		String RESPONSE = getBundle().getString("APIresponse");
		System.out.println(RESPONSE);
		if (RESPONSE.equalsIgnoreCase("[]")) {
			Reporter.log("Response is Empty as Expected", MessageTypes.Pass);
		} else {
			Reporter.log("Response is Not Empty ", MessageTypes.Fail);
		}
		ReusableUtils.responseStatusforOK();

	}

	/**
	 *Validate the Read response of Sub collection AppVersion Id's for full success
	 * 1. Schema Validation for Mandatory and Optional elements
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */

	@QAFTestStep(description = "I Validate the Read subcollection response for Full success for an specific collectionID")
	public void iValidateTheReadSubcollectionResponseForFullSuccessForAnSpecificCollectionID()
			throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");
		String ExpectedKeyList = getBundle().getString("common.ExpectedAppVersionReadBody");

		ReusableUtils.writeJSONreponse(RESPONSE, "App_Version_READ_Specific");
		ReusableUtils.validateJSONschema("Appversion_READ_Specific_schema", "App_Version_READ_Specific");

		ArrayList<String> ActualKeyList = ReusableUtils.actualkeyList(RESPONSE);
		System.out.println(ExpectedKeyList);

		Reporter.log(String.valueOf(new RestTestBase().getResponse().getStatus().getStatusCode()));
		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the Success response for the APP Version batch Read
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I Validate the response for Full success of App version batch READ")
	public void iValidateTheResponseForFullSuccessOfAppVersionBatchREAD() throws Exception {
		
		String RESPONSE = getBundle().getString("APIresponse");
		
		ReusableUtils.writeJSONreponse(RESPONSE, "App_Version_READ");
		ReusableUtils.validateJSONschema("App_Version_READ_Schema", "App_Version_READ");

		JsonElement gson1 = new Gson().fromJson(getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray gson = gson1.getAsJsonArray();

		long size = gson.size();

		for (JsonElement ele : gson) {
			String appVersionId = ele.getAsJsonObject().get("appVersionId").toString().replace("\"", "");
			getBundle().setProperty("appVersionId", appVersionId);
			break;
		}

		if (RESPONSE.equalsIgnoreCase("[]")) {

		} else {

			if (size > 0) {
				Reporter.log("Successfully read the App version, Number of properties available: " + size,
						MessageTypes.Pass);
				Reporter.log("Response: " + RESPONSE);
			} else {
				Reporter.log("Error occured while validating the Read response.", MessageTypes.Fail);
				Reporter.log("Response: " + RESPONSE);
			}
		}

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * 1. GET request to read top level collection
	 * 2. Validate 200 status code
	 * 3. Validate the Read response of top level collection - App Property for full success
	 * 4. Storing the AppIds which is having AppVersion details
	 * 5. Storing All the APPIDs to an JSONArray - appIDListToDeleteAsJArray
	 * @throws ProcessingException
	 * @throws Exception
	 */
	public static void readTheTopLevelCollectionResultsToFullSuccess() throws ProcessingException, Exception {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.ReadBatch");

		Reporter.log("Resource :" + resource);

		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));

		String RESPONSE = null;

		RESPONSE = CommonUtils.GET(resource, headers);

		ErrorMessage.validateErrorResponse(200);

		try {
			JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray jArray = gson.getAsJsonArray();

			List<String> appIDList = new ArrayList<>();
			JsonArray appIDListToDeleteAsJArray = new JsonArray();

			Reporter.log(jArray.size() + " APP elements found.", MessageTypes.Info);

			if (jArray.size() > 0) {

				String firstappIDfromRead = jArray.get(0).getAsJsonObject().get("appId").toString().replace("\"", "");
				getBundle().setProperty("appIdfromRead", firstappIDfromRead);
				for (JsonElement jElement : jArray) {
					appIDList.add(jElement.getAsJsonObject().get("appId").toString().replace("\"", ""));
				}
				getBundle().setProperty("AppIDList", appIDList);
				boolean isAppVersioDataAvailable = getAppId_and_AppVersionId(jArray);
				for (JsonElement jElement : jArray) {
					appIDListToDeleteAsJArray.add(jElement.getAsJsonObject().get("appId"));
				}
				getBundle().setProperty("appIDListToDeleteAsJArray", appIDListToDeleteAsJArray);
				if (!isAppVersioDataAvailable) {
					Reporter.log("No APP Element found with AppVersion/ Subcollections data.");
					Reporter.log("Creating AppIDs and AppVersionIDs...");
					Create_Appversion_BodyParameters.iCreateAnAppProperty();
					Delete_Appversion_Prepreq.iCreateAnAppversionForTheAppIDWhichIGot();
				}

			} else {
				Reporter.log("No Elements found.", MessageTypes.Fail);
			}
		} catch (JsonSyntaxException e) {
			Reporter.log("Error occured while extracting the JSON response.", MessageTypes.Pass);
		}
	}

	/**
	 * Get AppId's without AppVersion 
	 * @param jArray deleted appId list
	 * @return
	 */
	public static JsonArray getAllAppIDsWithoutAppVersionDetails(JsonArray jArray) {

		JsonArray appIDListToDeleteAsJArray = new JsonArray();
		for (JsonElement jElement : jArray) {
			int size = jElement.getAsJsonObject().get("appVersions").getAsJsonArray().size();
			if (size == 0) {
				appIDListToDeleteAsJArray.add(jElement.getAsJsonObject().get("appId"));
			}
		}
		return appIDListToDeleteAsJArray;
	}

	/**
	 * Get AppId and AppVersion Id	
	 * 1. Storing the AppID and their AppVersionIds
	 * @param jArray
	 * @return
	 */
	public static boolean getAppId_and_AppVersionId(JsonArray jArray) {

		boolean isAppVersioDataAvailable = false;

		for (JsonElement jElement : jArray) {
			String appVersionId = null;
			String appID = jElement.getAsJsonObject().get("appId").toString().replace("\"", "");
			int size = jElement.getAsJsonObject().get("appVersions").getAsJsonArray().size();
			if (size > 0) {
				for (JsonElement jElement1 : jElement.getAsJsonObject().get("appVersions").getAsJsonArray()) {
					appVersionId = jElement1.getAsJsonObject().get("appVersionId").toString().replace("\"", "");
					break;
				}

				System.out.println(appID);
				System.out.println(appVersionId);

				getBundle().setProperty("AppIdwithAppVersion", appID);
				getBundle().setProperty("AppVersionIDchoosen", appVersionId);
				isAppVersioDataAvailable = true;
				break;
			}
		}
		return isAppVersioDataAvailable;
	}

	
}
