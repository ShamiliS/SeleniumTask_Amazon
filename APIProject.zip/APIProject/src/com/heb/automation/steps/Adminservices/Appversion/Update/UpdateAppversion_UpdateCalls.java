package com.heb.automation.steps.Adminservices.Appversion.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import com.google.gson.JsonObject;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;;

public class UpdateAppversion_UpdateCalls {
	/**
	 * PUT Request to update AppProperty collection 
	 * @throws UnsupportedEncodingException
	 */
	@QAFTestStep(description = "I PUT Update Resource for App Property collection")
	public void iPUTUpdateResourceForAppPropertyCollection() throws UnsupportedEncodingException {

		String errorMsg = null;
		String AppID = (String) getBundle().getProperty("AppID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.update")+AppID;
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");
		System.out.println(BodyParamter);
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * PUT Request to update sub level collection - App version over editable fields 
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level over editable fields")
	public void iUPDATEResourceOnSubCollectionLevelOverEditableFields() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid AppId and AppVersionId.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
				System.out.println(errorMsg);
				System.out.println(new RestTestBase().getResponse().toString());
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * PUT Request to update sub level collection - App version over editable fields with invalid Json Body
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level over editable fields for invalid Json body")
	public void iUPDATEResourceOnSubCollectionLevelOverEditableFieldsForInvalidJsonBody() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid AppId.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Got error response for Invalid AppId..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);

	}

	/**
	 * PUT Request to update sub level collection - App version with empty body parameter
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level for empty body parameter")
	public void iUPDATEResourceOnSubCollectionLevelForEmptyBodyParameter() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Empty Json Body.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Got Error response for Empty Json Body..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);

	}

	/**
	 * PUT Request to update sub level collection - App version with bad url http protocol
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection with bad url having http protocol")
	public void iUPDATEResourceOnSubCollectionWithBadUrlHavingHttpProtocol() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_UrlBadURl");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid AppId and AppVersionId.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);
	}

	/**
	 * PUT Request to update top level collection - App property with invalid body parameter
	 */
	@QAFTestStep(description = "I PUT Update Resource with invalid body parameter")
	public void iPUTUpdateResourceWithInvalidBodyParameter() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.update")+getBundle().getString("AppID");
		String errorMsg;
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);
		String BodyParamter = getBundle().getString("BodyParametervalue");
		System.out.println(BodyParamter);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("Succesfully updated the Collection with invalid body parameter!", MessageTypes.Fail);

		} catch (Exception e) {

			Reporter.log("Error in Updating the properties with invalid body parameter!", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * PUT Request to update sub level collection - App version for invalid apikey
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level for Invalid apikey")
	public void iUPDATEResourceOnSubCollectionLevelForInvalidApikey() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid Apikey.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Got Error response for Invalid apikey..", MessageTypes.Pass);
			Reporter.log("Apikey: " + getBundle().getString("common.invalidAPIkey"));

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);

	}

	/**
	 * PUT Request to update top level collection - App property for invalid apikey
	 */
	@QAFTestStep(description = "I PUT Update Resource with invalid apikey")
	public void iPUTUpdateResourceWithInvalidApikey() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.update") + getBundle().getString("appId");
		String errorMsg;
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("Update processed with Invalid apikey..", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Update failed due to Invalid apikey..", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);

	}

	/**
	 * PUT Request to update sub level collection - App version with invalid bosy structure
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level for Invalid Json Body Structure")
	public void iUPDATEResourceOnSubCollectionLevelForInvalidJsonBodyStructure() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid Json Body Structure", MessageTypes.Fail);
		} catch (Exception e) {

			Reporter.log("Update failed due to Invalid Json Body Structure..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);
	}

	/**
	 * PUT Request to update sub level collection - App version with bad url
	 */
	@QAFTestStep(description = "I PUT Update Resource with bad url having http protocol")
	public void iPUTUpdateResourceWithBadUrlHavingHttpProtocol() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_UrlBadURl");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.update") + getBundle().getString("appId");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Bad URL", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		getBundle().setProperty("APIresponse", RESPONSE);
	}

	/**
	 * PUT Request to update top level collection - App version with invalid app id
	 * @param appId
	 */
	@QAFTestStep(description = "I PUT Update Resource with invalid App id{0}")
	public void iPUTUpdateResourceWithInvalidAppId(String appId) {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppProperty.update")+appId;

		String errorMsg = null;
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("Succesfully Updated the Properties with invalid appId!", MessageTypes.Fail);

		} catch (Exception e) {
			Reporter.log("Error in updating the properties with invalid appId!", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * PUT Request to update sub level collection - App version with invalid appid
	 */
	@QAFTestStep(description = "I UPDATE resource on sub-collection level with Invalid AppID")
	public void iUPDATEResourceOnSubCollectionLevelWithInvalidAppID() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+getBundle().getString("AppVersion.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid AppId.", MessageTypes.Fail);
			
		} catch (Exception e) {
			Reporter.log("UPDATE Failed due to Invalid AppID..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

}
