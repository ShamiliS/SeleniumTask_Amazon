package com.heb.automation.steps.Adminservices.Appversion.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.Appversion.Read.Read_Appversion_GETcalls;
import com.heb.automation.steps.Adminservices.Appversion.Read.Read_Appversion_validations;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Update_Appversion_BodyParameters {

	/**
	 * Update Body parameter for UPDATE request with all editable fields
	 * @throws ProcessingException
	 * @throws IOException
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 */
	@QAFTestStep(description = "I UPDATE resource properties body parameter contains all valid editable fields")
	public void uPDATEResourcePropertiesBodyParameterContainsAllValidEditableFields()
			throws ProcessingException, IOException, NoSuchFieldException, SecurityException {

		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		JsonObject BodyParameter = ReusableUtils.TopcollectionUpdateJSONObjectWithoutAppVersion(updatedDescription);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
	}

	/**
	 * Update Body parameter for UPDATE request with valid array of editable fields
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the Update Request Body Parameter is having valid array of editable fields")
	public static JsonObject theUpdateRequestBodyParameterIsHavingValidArrayOfEditableFields() {

		String updatedOsversion = "OsVersion_" + ReusableUtils.getCurrentTime();
		String updatedOsname = "OSName" + ReusableUtils.getCurrentTime();
		getBundle().setProperty("updatedOsversion", updatedOsversion);
		getBundle().setProperty("updatedOsname", updatedOsname);

		JsonObject BodyParameter = ReusableUtils.SC_Update_AddJsonBodyObjects(updatedOsversion, updatedOsname);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;

	}

	/**
	 * Update Body parameter for UPDATE request with valid fields and outside definition fields
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the Update Request Body Parameter is having valid fields with new fields outside definition")
	public JsonObject theUpdateRequestBodyParameterIsHavingValidFieldsWithNewFieldsOutsideDefinition() {

		String updatedOsversion = "OsVersion_" + ReusableUtils.getCurrentTime();
		String updatedOsname = "OSName" + ReusableUtils.getCurrentTime();

		// Defining Property outside the definition
		String outsideDef = "Model_" + ReusableUtils.getCurrentTime();

		getBundle().setProperty("updatedOsversion", updatedOsversion);
		getBundle().setProperty("updatedOsname", updatedOsname);
		getBundle().setProperty("outsideDef", outsideDef);

		JsonObject BodyParameter = ReusableUtils.SC_Update_AddJsonBodyObjects_OutsideDefinition(updatedOsversion,
				updatedOsname, outsideDef);
		getBundle().setProperty("BodyParametervalue", BodyParameter);

		return BodyParameter;

	}

	/**
	 * Update Body parameter for UPDATE request with only one Valid Editable property field
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the Update Request Body Parameter with only one Valid Editable property field")
	public static JsonObject theUpdateRequestBodyParameterWithOnlyOneValidEditablePropertyField() {

		String updatedOsname = "OSName" + ReusableUtils.getCurrentTime();
		getBundle().setProperty("updatedOsname", updatedOsname);
		getBundle().setProperty("updatingEditableProperty", "osName");

		JsonObject BodyParameter = ReusableUtils.SC_Update_AddJsonBodyObjects_OnlyOneMandatoryfield(updatedOsname);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;

	}

	/**
	 * Update Body parameter for UPDATE request with only new fields outside definition
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties body parameter contains new fields outside definition")
	public void iUPDATEResourcePropertiesBodyParameterContainsNewFieldsOutsideDefinition()
			throws Exception {
		
		String appId = getBundle().getString("AppID");
		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();

		String newField1 = "new Additional field 1";
		String newField2 = "new Additional field 2";
		JsonObject BodyParameter = ReusableUtils.TopcollectionUpdateJSONObjectNewFields(newField1, newField2);

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("newField1", newField1);
		getBundle().setProperty("newField2", newField2);
		getBundle().setProperty("appId", appId);
	}

	/**
	 * Update Body parameter for UPDATE request contains editable fields with AppVersion
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties body parameter contains valid editable fields with appversion")
	public void iUPDATEResourcePropertiesBodyParameterContainsValidEditableFieldsWithAppversion()
			throws Exception {
		
		String appId = getBundle().getString("AppID");

		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();

		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		JsonArray updatedAppVersions = ReusableUtils.getUpdatedAppVersion(getBundle().getString("common.AppVersionId"));
		JsonObject BodyParameter = ReusableUtils.TopcollectionUpdateJSONObjectwithAppVersion(updatedDescription,
				updatedAppVersions);

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
		getBundle().setProperty("updatedAppVersions", updatedAppVersions.toString());
		getBundle().setProperty("appId", appId);
		System.out.println(updatedAppVersions.toString());
	}

	/**
	 * Update Body parameter for UPDATE request contains only one editable field
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties body parameter contains one editable field")
	public void iUPDATEResourcePropertiesBodyParameterContainsOneEditableField()
			throws Exception {

		String appId = getBundle().getString("AppID");

		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();
		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		JsonObject BodyParameter = ReusableUtils.TopcollectionUpdateJSONObjectDescriptionAlone(updatedDescription);

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
		getBundle().setProperty("appId", appId);
	}


	/**
	 * Update Body parameter for UPDATE request contains editable fields and non editable or mandatory fields
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties body parameter contains editable and mandatory fields")
	public void iUPDATEResourcePropertiesBodyParameterContainsEditableAndMandatoryFields()
			throws Exception {

		String appId = getBundle().getString("AppID");

		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();

		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		String updatedAppId = "AppId_Updated_" + ReusableUtils.getCurrentTime();

		JsonObject BodyParameter = ReusableUtils.TopcollectionUpdateJSONObjectDescriptionAndAppId(updatedDescription,
				updatedAppId);

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
		getBundle().setProperty("appId", appId);
		getBundle().setProperty("updatedAppId", updatedAppId);
	}

	/**
	 * Update Body parameter for UPDATE request contains invalid body parameter structure
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties with invalid body parameter structure")
	public void iUPDATEResourcePropertiesWithInvalidBodyParameterStructure() throws Exception {

		String appId = getBundle().getString("AppID");

		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();

		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		String BodyParameter = ReusableUtils.TopcollectionUpdateInvalidJSONObjectDescription(updatedDescription)
				.toString() + ",";

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
		getBundle().setProperty("appId", appId);
	}

	/**
	 * Update Body parameter for UPDATE request contains empty body parameter
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE resource properties with empty body parameter structure")
	public void iUPDATEResourcePropertiesWithEmptyBodyParameterStructure() throws Exception {
		
		String appId = getBundle().getString("AppID");
		Read_Appversion_GETcalls.iGETBatchResourceForAppIDUsingValidApikey(appId);
		Read_Appversion_validations.iValidateTheResponseForFullSuccessOfSpecificREAD();
		String updatedDescription = "Description_Updated_" + ReusableUtils.getCurrentTime();
		String BodyParameter = " ";
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", updatedDescription);
		getBundle().setProperty("appId", appId);
	}

	/**
	 * Update Body parameter for UPDATE request contains mandatory fields and new fields
	 * @return BodyParameter
	 */
	@QAFTestStep(description = "the Update Request Body Parameter with the mandatory field and a new value")
	public JsonObject theUpdateRequestBodyParameterWithTheMandatoryFieldAndANewValue() {

		String updated_appVersionId = getBundle().getString("common.appVersionId") + 1;
		getBundle().setProperty("updated_appVersionId", updated_appVersionId);

		String outsideDef = "Model_" + ReusableUtils.getCurrentTime();
		getBundle().setProperty("outsideDef", outsideDef);

		JsonObject BodyParameter = ReusableUtils
				.SC_Update_AddJsonBodyObjects_Mandatory_and_NewValue(updated_appVersionId, outsideDef);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		return BodyParameter;

	}

	/**
	 * Update Body parameter for UPDATE request contains invalid body parameter structure
	 * @throws Exception
	 */
	@QAFTestStep(description = "the Update Request Body Parameter with invalid body parameter structure")
	public void theUpdateRequestBodyParameterWithInvalidBodyParameterStructure()
			throws ProcessingException, IOException {

		String updatedOsname = "OSName" + ReusableUtils.getCurrentTime();
		getBundle().setProperty("updatedOsname", updatedOsname);
		getBundle().setProperty("updatingEditableProperty", "osName");

		String BodyParameter = ReusableUtils.SC_Update_AddJsonBodyObjects_OnlyOneMandatoryfield(updatedOsname)
				.toString() + "}";

		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Defining the body parameter with empty value
	 * 
	 * @throws ProcessingException
	 * @throws IOException
	 */
	@QAFTestStep(description = "the Update Request Body Parameter with empty body parameter")
	public void theUpdateRequestBodyParameterWithEmptyBodyParameter() throws ProcessingException, IOException {

		String BodyParameter = " ";
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}
}
