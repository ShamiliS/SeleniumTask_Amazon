package com.heb.automation.steps.Adminservices.Appversion.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.heb.automation.steps.Adminservices.Appversion.Read.Read_Appversion_validations;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Update_Appversion_Prereq {

	/**
	 *  Calling the Read Batch request for getting the existing AppIDs and APPVersionIds
	 * 1) Reads the top level collection resource
	 * 2) Storing the AppID and AppVersionID in a variable 
	 * 
	 * @throws ProcessingException
	 * @throws Exception
	 */
	@QAFTestStep(description = "The user is having a valid appId and appVersionId")
	public void theUserIsHavingAValidAppIdAndAppVersionId() throws ProcessingException, Exception {

		Read_Appversion_validations.readTheTopLevelCollectionResultsToFullSuccess();

		String validAppVersionId = getBundle().getString("AppVersionIDchoosen");
		String validAppId = getBundle().getString("AppIdwithAppVersion");
		
		getBundle().setProperty("AppID", validAppId);
		getBundle().setProperty("AppVersionID", validAppVersionId);

		if (!validAppVersionId.isEmpty() && !validAppId.isEmpty()) {
			Reporter.log("AppId: " + validAppId + ", Valid AppVersionId: " + validAppVersionId, MessageTypes.Pass);
		} else {
			Reporter.log("Error occured while getting the Valid APPId and APPVersionId from the Read request.",
					MessageTypes.Fail);
		}
	}
}
