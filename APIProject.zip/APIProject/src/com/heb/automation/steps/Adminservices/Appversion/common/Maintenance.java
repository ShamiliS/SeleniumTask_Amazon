package com.heb.automation.steps.Adminservices.Appversion.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Maintenance {

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "Get all the records under {0} resources")
	public static void getAllTheRecordsUnderResources(String apiCollectionBatch) {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+apiCollectionBatch;

		getBundle().setProperty("env.baseurl", baseurl);
		
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		String errorMsg = null;
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		try {
			String RESPONSE = CommonUtils.GET(resource, headers);

			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "I GET or READ batch resources for {0} resources")
	public void iGETOrREADBatchResourcesForResources(String str0) {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("AppProperty.ReadBatch");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg = null;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			// Reporter.log("Succesfully Read the Properties with invalid
			// apikey!", MessageTypes.Fail);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "Delete the complete List under {0} resources")
	public void deleteTheCompleteListUnderResources(String rsourceBatch) throws ProcessingException, IOException {
		String IDtoDelete = (String) getBundle().getProperty("IdListToDeleteAsJArray");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")+rsourceBatch;
		getBundle().setProperty("env.baseurl", baseurl);
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		String BodyParameter = IDtoDelete;
		String errorMsg = null;
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		Reporter.log("BodyParameter: "+BodyParameter);

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParameter);
			Reporter.log("Delete Successful.",MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during delete.",MessageTypes.Fail);
			errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			

		}
	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "Store the {0} in an Array List except default")
	public static void storeTheInAnArrayListExceptDefault(String IDname) {

		String RESPONSE = getBundle().getString("APIresponse");
		JsonElement jelement = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray gson = jelement.getAsJsonArray();
		int size = gson.size();

		ArrayList<String> MandatoryfieldList = new ArrayList<String>();

		System.out.println(size);

		for (JsonElement ele : gson) {
			String collID = ele.getAsJsonObject().get(IDname).toString().replace("\"", "");
			// getBundle().setProperty("appId", appId);

			if (!collID.equalsIgnoreCase("default")) {
				MandatoryfieldList.add(collID);
			}

		}

		System.out.println(MandatoryfieldList);
		getBundle().setProperty("IdListToDeleteAsJArray", MandatoryfieldList.toString());
	}

}
