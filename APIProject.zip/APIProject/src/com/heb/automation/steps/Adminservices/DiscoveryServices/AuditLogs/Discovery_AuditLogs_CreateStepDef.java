package com.heb.automation.steps.Adminservices.DiscoveryServices.AuditLogs;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;;

public class Discovery_AuditLogs_CreateStepDef {

	@QAFTestStep(description = "I validate the created CollectionID in audit log")
	public void iValidateTheCreatedCollectionIDInAuditLog() {

		String CollectionId = getBundle().getString("CollectionID");
		boolean flag = false;

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(CollectionId)) {
					flag = true;
					break;
				}
			}
		}

		if (!flag) {
			Reporter.log("The value of created batch" + CollectionId + "is not exist in Audit log", MessageTypes.Fail);
		} else {
			Reporter.log("The value of deleted batch" + CollectionId + "is exist in Audit log", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I validate the created ServiceDescriptionID in audit log")
	public void iValidateTheCreatedServiceDescriptionIDInAuditLog() {

		String ServiceDescriptionID = getBundle().getString("ServiceDescriptionID");
		boolean flag = false;

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(ServiceDescriptionID)) {
					flag = true;
					break;
				}
			}
		}

		if (!flag) {
			Reporter.log("The value of created batch" + ServiceDescriptionID + "is not exist in Audit log",
					MessageTypes.Fail);
		} else {
			Reporter.log("The value of deleted batch" + ServiceDescriptionID + "is exist in Audit log",
					MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I validate the created ServiceVersionID in audit log")
	public void iValidateTheCreatedServiceVersionIDInAuditLog() {

		String ServiceVersionID = getBundle().getString("ServiceVersionID");
		boolean flag = false;

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(ServiceVersionID)) {
					flag = true;
					break;
				}
			}
		}

		if (!flag) {
			Reporter.log("The value of created batch" + ServiceVersionID + "is not exist in Audit log",
					MessageTypes.Fail);
		} else {
			Reporter.log("The value of deleted batch" + ServiceVersionID + "is exist in Audit log", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I validate the created ResourcePathID in audit log")
	public void iValidateTheCreatedResourcePathIDInAuditLog() {

		String ResourcePathID = getBundle().getString("ResourcePathID");
		boolean flag = false;

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(ResourcePathID)) {
					flag = true;
					break;
				}
			}
		}

		if (!flag) {
			Reporter.log("The value of created batch" + ResourcePathID + "is not exist in Audit log",
					MessageTypes.Fail);
		} else {
			Reporter.log("The value of deleted batch" + ResourcePathID + "is exist in Audit log", MessageTypes.Pass);
		}

	}
}
