package com.heb.automation.steps.Adminservices.DiscoveryServices.AuditLogs;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;;

public class Discovery_AuditLogs_DeleteStepDef {

	@QAFTestStep(description = "I Verify the deleted api CollectionId from Auditlog")
	public void iVerifyTheDeletedApiCollectionIdFromAuditlog() {

		boolean isDeletedCollectionIDAvailable = false;
		String DeletedCollectionId = getBundle().getString("DeletedCollectionId");

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(DeletedCollectionId)) {
					isDeletedCollectionIDAvailable = true;
					break;
				}
			}
		}

		if (isDeletedCollectionIDAvailable) {
			Reporter.log("The value of deleted batch" + DeletedCollectionId + "is exist in Audit log",
					MessageTypes.Pass);
		} else {
			Reporter.log("The value of deleted batch" + DeletedCollectionId + "is not exist in Audit log",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Verify the deleted ServiceDesId from Auditlog")
	public void iVerifyTheDeletedServiceDesIdFromAuditlog() {

		boolean isDeletedServiceDesID = false;
		String DeletedServiceDesID = getBundle().getString("DeletedServiceDesID");

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(DeletedServiceDesID)) {
					isDeletedServiceDesID = true;
					break;
				}
			}
		}

		if (isDeletedServiceDesID) {
			Reporter.log("The value of deleted batch" + DeletedServiceDesID + "is exist in Audit log",
					MessageTypes.Pass);
		} else {
			Reporter.log("The value of deleted batch" + DeletedServiceDesID + "is not exist in Audit log",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Verify the deleted ServiceVersionId from Auditlog")
	public void iVerifyTheDeletedServiceVersionIdFromAuditlog() {

		boolean isDeletedServiceVersionIDAvailable = false;
		String DeletedServiceVersionID = getBundle().getString("DeletedServiceVersionID");

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(DeletedServiceVersionID)) {
					isDeletedServiceVersionIDAvailable = true;
					break;
				}
			}
		}

		if (isDeletedServiceVersionIDAvailable) {
			Reporter.log("The value of deleted batch" + DeletedServiceVersionID + "is exist in Audit log",
					MessageTypes.Pass);
		} else {
			Reporter.log("The value of deleted batch" + DeletedServiceVersionID + "is not exist in Audit log",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Verify the deleted ResourcePathId from Auditlog")
	public void iVerifyTheDeletedResourcePathIdFromAuditlog() {

		boolean isDeletedResourcePathIDAvailable = false;
		String DeletedResourcePathID = getBundle().getString("DeletedResourcePathID");

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("itemId").toString().replace("\"", "");
			if (getitemid.equals("BATCH")) {
				String val = element.getAsJsonObject().get("jsonResponse").toString();

				if (val.contains(DeletedResourcePathID)) {
					isDeletedResourcePathIDAvailable = true;
					break;
				}
			}
		}

		if (isDeletedResourcePathIDAvailable) {
			Reporter.log("The value of deleted batch" + DeletedResourcePathID + "is exist in Audit log",
					MessageTypes.Pass);
		} else {
			Reporter.log("The value of deleted batch" + DeletedResourcePathID + "is not exist in Audit log",
					MessageTypes.Fail);
		}

	}

}
