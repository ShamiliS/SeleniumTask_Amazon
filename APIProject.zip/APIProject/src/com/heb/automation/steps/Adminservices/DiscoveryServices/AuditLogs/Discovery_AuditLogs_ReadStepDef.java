package com.heb.automation.steps.Adminservices.DiscoveryServices.AuditLogs;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;;

public class Discovery_AuditLogs_ReadStepDef {
	
	
	
}
