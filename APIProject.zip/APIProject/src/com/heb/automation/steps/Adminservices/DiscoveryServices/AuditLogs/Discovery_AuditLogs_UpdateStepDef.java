package com.heb.automation.steps.Adminservices.DiscoveryServices.AuditLogs;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;;

public class Discovery_AuditLogs_UpdateStepDef {

	@QAFTestStep(description = "I Verify the updated api CollectionId from Auditlog")
	public void iVerifyTheUpdatedApiCollectionIdFromAuditlog() {

		String UpdatedCollectionId = getBundle().getString("CollectionID");
		boolean isAvailable = false;
		String val = null;
		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("operation").toString().replace("\"", "");
			if (getitemid.equals("update")) {
				String dataItemType = element.getAsJsonObject().get("dataItemType").toString().replace("\"", "");
				if (dataItemType.equals("apiCollection")) {
					val = element.getAsJsonObject().get("jsonResponse").toString();
					if (val.contains(UpdatedCollectionId)) {
						Reporter.log("Updated CollectionId " + UpdatedCollectionId + " is exist in Audit log",
								MessageTypes.Pass);
						isAvailable = true;
						break;
					} 
				}
			}
		}
		if(isAvailable){
			if (val.contains(getBundle().getString("updatedName"))) {
				Reporter.log("Editable field: Name is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: Name is not updated successfully!", MessageTypes.Fail);
			}
		}else {
			Reporter.log("Updated CollectionId " + UpdatedCollectionId + " is not exist in Audit log",
					MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "I Verify the updated service descriptionId from Auditlog")
	public void iVerifyTheUpdatedServiceDescriptionIdFromAuditlog() {
		String UpdatedServiceDescId = getBundle().getString("ServiceDesID");
		boolean isAvailable = false;
		String val = null;
		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("operation").toString().replace("\"", "");
			if (getitemid.equals("update")) {
				String dataItemType = element.getAsJsonObject().get("dataItemType").toString().replace("\"", "");
				if (dataItemType.equals("serviceDescription")) {

					val = element.getAsJsonObject().get("jsonResponse").toString();

					if (val.contains(UpdatedServiceDescId)) {
						Reporter.log("Updated Service description Id " + UpdatedServiceDescId + " is exist in Audit log",
								MessageTypes.Pass);
						isAvailable = true;
						break;
					} 
				}
			}
		}
		
		if(isAvailable){
			if (val.contains(getBundle().getString("name"))) {
				Reporter.log("Editable field: Name is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: Name is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("description"))) {
				Reporter.log("Editable field: description is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: description is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("labels"))) {
				Reporter.log("Editable field: labels is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: labels is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("openApiSpecUrl"))) {
				Reporter.log("Editable field: openApiSpecUrl is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: openApiSpecUrl is not updated successfully!",
						MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("documentationUrl"))) {
				Reporter.log("Editable field: documentationUrl is updated successfully!",
						MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: documentationUrl is not updated successfully!",
						MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("currentVersion"))) {
				Reporter.log("Editable field: currentVersion is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: currentVersion is not updated successfully!",
						MessageTypes.Fail);
			}
		}else {
			Reporter.log(
					"Updated Service description Id " + UpdatedServiceDescId + " is not exist in Audit log",
					MessageTypes.Fail);
		}
		
	}

	@QAFTestStep(description = "I Verify the updated service VersionId from Auditlog")
	public void iVerifyTheUpdatedServiceVersionIdFromAuditlog() {
		String UpdatedServiceVersionID = getBundle().getString("ServiceVersionID");
		boolean isAvailable = false;
		String val = null;
		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("operation").toString().replace("\"", "");
			if (getitemid.equals("update")) {
				String dataItemType = element.getAsJsonObject().get("dataItemType").toString().replace("\"", "");
				if (dataItemType.equals("serviceVersion")) {

					val = element.getAsJsonObject().get("jsonResponse").toString();

					if (val.contains(UpdatedServiceVersionID)) {
						Reporter.log("Updated Service Version Id " + UpdatedServiceVersionID + " is exist in Audit log",
								MessageTypes.Pass);
						isAvailable = true;
						break;
					} 
				}
			}
		}
		
		if(isAvailable){
			if (val.contains(getBundle().getString("versionNumber"))) {
				Reporter.log("Editable field: versionNumber is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: versionNumber is not updated successfully!",
						MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("hostName"))) {
				Reporter.log("Editable field: hostName is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: hostName is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("description"))) {
				Reporter.log("Editable field: description is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: description is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("basePath"))) {
				Reporter.log("Editable field: basePath is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: basePath is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("openApiSpecUrl"))) {
				Reporter.log("Editable field: openApiSpecUrl is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: openApiSpecUrl is not updated successfully!",
						MessageTypes.Fail);
			}
		}
		else {
			Reporter.log(
					"Updated Service Version Id " + UpdatedServiceVersionID + " is not exist in Audit log",
					MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I Verify the updated resource PathId from Auditlog")
	public void iVerifyTheUpdatedResourcePathIdFromAuditlog() {
		String UpdatedResourcePathId = getBundle().getString("ResourcePathId");
		String CollectionID = getBundle().getString("CollectionID");
		boolean isAvailable = false;
		String val = null;

		JsonElement json = new Gson().fromJson(ConfigurationManager.getBundle().getString("AuditLog_Reponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) json.getAsJsonArray();

		for (JsonElement element : successList) {

			String getitemid = element.getAsJsonObject().get("operation").toString().replace("\"", "");
			if (getitemid.equals("update")) {
				String dataItemType = element.getAsJsonObject().get("dataItemType").toString().replace("\"", "");
				if (dataItemType.equals("resourcePath")) {

					val = element.getAsJsonObject().get("jsonResponse").toString();

					if (val.contains(UpdatedResourcePathId)) {
						Reporter.log("Updated Resource Path Id " + UpdatedResourcePathId + " is exist in Audit log",
								MessageTypes.Pass);
						isAvailable = true;
						break;
					} 
				}
			}
		}
		
		if(isAvailable){
			if (val.contains(getBundle().getString("description"))) {
				Reporter.log("Editable field: description is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: description is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("path"))) {
				Reporter.log("Editable field: path is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: path is not updated successfully!", MessageTypes.Fail);
			}

			if (val.contains(getBundle().getString("name"))) {
				Reporter.log("Editable field: name is updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable field: name is not updated successfully!", MessageTypes.Fail);
			}
		}
		else {
			Reporter.log("Updated Resource Path " + UpdatedResourcePathId + " is not exist in Audit log",
					MessageTypes.Fail);
		}
	}

}
