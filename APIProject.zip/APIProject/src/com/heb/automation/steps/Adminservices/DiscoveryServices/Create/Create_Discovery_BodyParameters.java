package com.heb.automation.steps.Adminservices.DiscoveryServices.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map.Entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Discovery_ReusableUtils.Discovery_ReusableUtils;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Create_Discovery_BodyParameters {

	/**
	 * Passing valid input arrays body parameter to create batch for
	 * APICollection 1) With only mandatory fields 2) With Mandatory and
	 * optional fields 3) With Mandatory, Optional and a field outside
	 * definition
	 */

	@QAFTestStep(description = "the apiCollection create Batch Request Body Parameter should contain valid array of Property details")
	public static void theApiCollectionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_fields());
		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_and_Optional_fields());
		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_Optional_and_Outsidedef_fields());

		JsonArray collectionIdList = new JsonArray();

		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			if (Jsonlist.isJsonObject()) {
				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {
					if (nestedgsonlist.getKey().equals("name")) {
						collectionIdList.add(nestedgsonlist.getValue());
					}
				}
			}
		}
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("TotalcollectionIdsCount", String.valueOf(collectionIdList.size()));
	}

	/**
	 * Passing body parameter to create batch with one of the set not having the
	 * mandatory fields for APICollection 1) With only mandatory fields 2) With
	 * Mandatory and optional fields 3) Without having the mandatory field
	 */

	@QAFTestStep(description = "the apiCollection create Batch Request Body Parameter with one of the set not having the mandatory fields")
	public void theApiCollectionCreateBatchRequestBodyParameterWithOneOfTheSetNotHavingTheMandatoryFields() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_fields());
		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_and_Optional_fields());
		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Optional_and_MissingMandatory());

		JsonArray collectionIdList = new JsonArray();

		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			if (Jsonlist.isJsonObject()) {
				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {
					if (nestedgsonlist.getKey().equals("name")) {
						collectionIdList.add(nestedgsonlist.getValue());
					}
				}
			}
		}
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("collectionIdsAsString", collectionIdList.toString());
		getBundle().setProperty("collectionIdsAsJsonArray", collectionIdList);
		getBundle().setProperty("TotalcollectionIdsCount", BodyParameter.size());
	}

	/**
	 * Passing body parameter to create batch without mandatory fields for
	 * APICollection
	 */

	@QAFTestStep(description = "the apiCollection create Batch Request Body Parameter without having the mandatory fields")
	public void theApiCollectionCreateBatchRequestBodyParameterWithoutHavingTheMandatoryFields() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Optional_and_MissingMandatory());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("TotalcollectionIdsCount", BodyParameter.size());
	}

	/**
	 * Passing body parameter to create batch with Invalid JSON entry for
	 * APICollection
	 */

	@QAFTestStep(description = "the apiCollection create Batch Request Body Parameter with Invalid Json entry")
	public void theApiCollectionCreateBatchRequestBodyParameterWithInvalidJsonEntry() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Optional_and_MissingMandatory());

		getBundle().setProperty("BodyParametervalue", BodyParameter.toString() + ",");
		getBundle().setProperty("TotalcollectionIdsCount", BodyParameter.size());
	}

	/**
	 * Passing valid input array body parameter to create batch for Service
	 * Description 1) With only mandatory fields 2) With Mandatory and optional
	 * fields
	 * 
	 */
	@QAFTestStep(description = "the ServiceDescription create Batch Request Body Parameter should contain valid array of Property details")
	public static void theServiceDescriptionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.serviceDescription_add_Mandatory_fields());
		BodyParameter.add(Discovery_ReusableUtils.serviceDescription_add_Mandatory_and_Optional_fields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ServiceDescriptionIdsCountFromRequest", BodyParameter.size());
	}

	/**
	 * Passing body parameter to create batch with one of the set not having the
	 * mandatory fields for Service Description
	 */

	@QAFTestStep(description = "the ServiceDescription create Batch Request Body Parameter with one of the set not having the mandatory fields")
	public void theServiceDescriptionCreateBatchRequestBodyParameterWithOneOfTheSetNotHavingTheMandatoryFields() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.serviceDescription_add_Mandatory_fields());
		BodyParameter.add(Discovery_ReusableUtils.serviceDescription_add_Optional_and_Missing_Mandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ServiceDescriptionIdsCountFromRequest", BodyParameter.size());
	}

	/**
	 * Passing body parameter to create batch request without mandatory fields
	 * for Service Description
	 */

	@QAFTestStep(description = "the ServiceDescription create Batch Request Body Parameter without having the mandatory fields")
	public void theServiceDescriptionCreateBatchRequestBodyParameterWithoutHavingTheMandatoryFields() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.serviceDescription_add_Optional_and_Missing_Mandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);

		getBundle().setProperty("ServiceDescriptionIdsCountFromRequest", BodyParameter.size());

	}

	/**
	 * Defining the Body parameters 1) with mandatory and optional
	 * fields 2) with only mandatory fields
	 */
	@QAFTestStep(description = "the resourcePath create Batch request contains BodyParamter with valid array")
	public static void theResourcePathCreateBatchRequestContainsBodyParamterWithValidArray() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_Mandatoryfields_optionalfields());
		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_onlyMandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ResourcePathIDCountFromRequest", BodyParameter.size());
	}

	/**
	 * Defining the body parameters with one valid and one Invalid set of
	 * details 1) Object without having mandatory field- Invalid 2) Object with
	 * mandatory field- valid
	 */
	@QAFTestStep(description = "the resourcePath create Batch request contains BodyParamter with atleast one valid and one invalid array")
	public void theResourcePathCreateBatchRequestContainsBodyParamterWithAtleastOneValidAndOneInvalidArray() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_with_missing_Mandatoryfield());
		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_onlyMandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ResourcePathIDCountFromRequest", BodyParameter.size());
	}

	/**
	 * Defining the Body parameter with missing mandatory fields- Invalid
	 */
	@QAFTestStep(description = "the resourcePath create Batch request contains BodyParamter with all invalid array")
	public void theResourcePathCreateBatchRequestContainsBodyParamterWithAllInvalidArray() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_with_missing_Mandatoryfield());
		BodyParameter.add(Discovery_ReusableUtils.resourcePath_add_with_missing_Mandatoryfield());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ResourcePathIDCountFromRequest", BodyParameter.size());
	}

	/**
	 * Defining the body parameters with valid array of data 1) With only
	 * mandatory fields 2) With Mandatory and optional fields
	 * 
	 */
	@QAFTestStep(description = "the serviceversion create Batch request contains BodyParamter with valid array")
	public static void theServiceversionCreateBatchRequestContainsBodyParamterWithValidArray() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.seviceversion_add_Mandatoryfields());
		BodyParameter.add(Discovery_ReusableUtils.seviceversion_add_Mandatoryfields_optionalfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ResourcePathIDCountFromRequest", BodyParameter.size());
	}

	/**
	 * Defining the Body Parameters with one valid and one Invalid array of Data
	 * 
	 */
	@QAFTestStep(description = "the serviceversion create Batch request contains BodyParamter with atleast one valid and one invalid Versionnumber array")
	public void theServiceversionCreateBatchRequestContainsBodyParamterWithAtleastOneValidAndOneInvalidVersionnumberArray() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.seviceversion_Missing_MandatoryfieldsVersionNumber());
		BodyParameter.add(Discovery_ReusableUtils.seviceversion_add_Mandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ServiceVersionRequestCount", BodyParameter.size());

	}

	/**
	 * Defining the Body parameters having all sets of Invalid data 1) Missing
	 * mandatory field 'VersionNumber' 2) Missing mandatory field 'HostName'
	 * 
	 */
	@QAFTestStep(description = "the serviceversion create Batch request contains BodyParamter with all invalid array")
	public void theServiceversionCreateBatchRequestContainsBodyParamterWithAllInvalidArray() {

		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.seviceversion_Missing_MandatoryfieldsVersionNumber());
		BodyParameter.add(Discovery_ReusableUtils.seviceversion_Missing_MandatoryfieldsHostName());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ServiceVersionRequestCount", BodyParameter.size());
	}

	/**
	 * Defining the body parameter with Invalid Json structure
	 * 
	 * @param str1
	 */
	@QAFTestStep(description = "the create Batch Request Body Parameter with Invalid Json entry input {0}")
	public void theCreateBatchRequestBodyParameterWithInvalidJsonEntryInput(String str1) {

		String BodyParameter = str1 + ",";
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining the Body parameter having, at least one set of data which is
	 * missing the mandatory field 'Host name'
	 * 
	 */
	@QAFTestStep(description = "the serviceversion create Batch request contains BodyParamter with atleast one valid and one invalid hostname array")
	public void theServiceversionCreateBatchRequestContainsBodyParamterWithAtleastOneValidAndOneInvalidHostnameArray() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.seviceversion_Missing_MandatoryfieldsHostName());
		BodyParameter.add(Discovery_ReusableUtils.seviceversion_add_Mandatoryfields());

		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("ServiceVersionRequestCount", BodyParameter.size());
	}

	/**
	 * 1) ApiCollection- Defining the body parameters with only mandatory fields
	 * 2) Storing the Body parameter value in - BodyParametervalue 3) Storing
	 * the Objects count in- TotalcollectionIdsCount
	 * 
	 */
	@QAFTestStep(description = "the apiCollection create Batch Request with single valid Body Parameter")
	public void theApiCollectionCreateBatchRequestWithSingleValidBodyParameter() {
		JsonArray BodyParameter = new JsonArray();

		BodyParameter.add(Discovery_ReusableUtils.apiCollection_add_Mandatory_fields());

		JsonArray collectionIdList = new JsonArray();

		for (JsonElement Jsonlist : BodyParameter.getAsJsonArray()) {
			if (Jsonlist.isJsonObject()) {
				for (Entry<String, JsonElement> nestedgsonlist : Jsonlist.getAsJsonObject().entrySet()) {
					if (nestedgsonlist.getKey().equals("name")) {
						collectionIdList.add(nestedgsonlist.getValue());
					}
				}
			}
		}
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("TotalcollectionIdsCount", String.valueOf(collectionIdList.size()));
	}

}
