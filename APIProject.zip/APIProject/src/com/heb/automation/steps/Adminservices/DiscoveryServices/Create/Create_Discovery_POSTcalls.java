package com.heb.automation.steps.Adminservices.DiscoveryServices.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.steps.Adminservices.Appversion.Create.Create_Appversion_BodyParameters;
import com.heb.automation.steps.Adminservices.Appversion.Create.Create_Appversion_POSTcalls;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;;

public class Create_Discovery_POSTcalls {

	/**
	 * 1) POST Create Resource request for APICollection for Full Success 2)
	 * Storing the response in 'APIresponse'
	 */

	@QAFTestStep(description = "I Post Create Resource for apiCollection")
	public static void iPostCreateResourceForApiCollection() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with the valid set of body parameters.", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("Error occured during POST..", MessageTypes.Fail);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) POST Create Resource request for APICollection for Partial Success 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for apiCollection for Partial success")
	public void iPostCreateResourceForApiCollectionForPartialSuccess() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
		.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with the combination of valid and Invalid set of body parameters.",
					MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("Error occured during POST..", MessageTypes.Fail);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) POST Create Resource request for APICollection for missing mandatory
	 * field 2) Storing the error response in 'errorMsg'
	 */

	@QAFTestStep(description = "I Post Create Resource for apiCollection for missing mandatory field")
	public void iPostCreateResourceForApiCollectionForMissingMandatoryField() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful without having the mandatory body fields.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("POSt Failed due to the missing mandatory fields..", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) POST Create Resource request for APICollection for invalid apikey 2)
	 * Storing the error response in 'errorMsg'
	 */

	@QAFTestStep(description = "I Post Create Resource for apiCollection for invalid apikey")
	public void iPostCreateResourceForApiCollectionForInvalidApikey() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("Post successful with Invalid apikey..", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("POST Failed due to invalid apikey..", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			Reporter.log(errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) POST Create Resource request for APICollection for invalid JSON
	 * parameters 2) Storing the error response in 'errorMsg '
	 */
	@QAFTestStep(description = "I Post Create Resource for apiCollection for invalid Json Entry")
	public void iPostCreateResourceForApiCollectionForInvalidJsonEntry() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);
		String errorMsg;

		String BodyParamter = getBundle().getString("BodyParametervalue");
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("Post successful with Invalid Json Body parameter..", MessageTypes.Fail);
			Reporter.log(BodyParamter);
		} catch (Exception e) {
			Reporter.log("POST Failed due to invalid Json Body parameter..", MessageTypes.Pass);
			Reporter.log(BodyParamter);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception e1) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			Reporter.log(errorMsg);
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * POST Create Resource request for APICollection for Bad URL
	 */

	@QAFTestStep(description = "I Post Create Resource for apiCollection for bad url")
	public void iPostCreateResourceForApiCollectionForBadUrl() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("Post successful with Bad url.", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);

		} catch (Exception e) {

			Reporter.log("POST failed due to the bad url..", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/*
	 * @QAFTestStep(description = "I create an Api collection resource") public
	 * static void iCreateAnApiCollectionResource() {
	 * 
	 * Create_Discovery_BodyParameters
	 * .theApiCollectionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails
	 * (); iPostCreateResourceForApiCollection(); }
	 */

	/**
	 * Creation of Service description for created CollectionID
	 */

	@QAFTestStep(description = "I create a Service description for the CollectionID which I got")
	public static void iCreateAServiceDescriptionForTheCollectionidWhichIGot() {
		String appId = getBundle().getString("CollectionID");

		Create_Appversion_BodyParameters
				.theCreateBatchRequestBodyParameterForSubcollectionLevelContainingAnSingleAppversionDetail();
		Create_Appversion_POSTcalls.iPostCreateResourceForAppVersionSubCollectionUnder(appId);

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		String appVersionId = null;
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successListArray = gson.getAsJsonObject().getAsJsonArray("success");

		for (JsonElement appVersionJson : successListArray) {
			appVersionId = appVersionJson.toString().replace("\"", "");
		}

		getBundle().setProperty("AppVersionID", appVersionId);

		System.out.println(getBundle().getProperty("AppVersionID"));

	}

	/**
	 * 1) Posting Create Resource for Service Description for Full Success 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for Service description")
	public static void iPostCreateResourceForServiceDescription() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with the valid set of body parameters.", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("Error occured during POST..", MessageTypes.Fail);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * 1) Posting Create Resource for Service Description for Partial Success 2)
	 * Storing the response in 'APIresponse'
	 */

	@QAFTestStep(description = "I Post Create Resource for Service description for Partial success")
	public void iPostCreateResourceForServiceDescriptionForPartialSuccess() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with the combination of valid and Invalid set of body parameters.",
					MessageTypes.Pass);

		} catch (Exception e) {

			Reporter.log("Error occured during POST..", MessageTypes.Fail);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * Posting Create Resource for Service Description for Bad URL
	 */

	@QAFTestStep(description = "I Post Create Resource for Service description for bad url")
	public void iPostCreateResourceForServiceDescriptionForBadUrl() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Bad url.", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);

		} catch (Exception e) {

			Reporter.log("POST failed due to bad url..", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Posting Create Resource for Service Description for Invalid apikey 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for Service description for Invalid apikey")
	public void iPostCreateResourceForServiceDescriptionForInvalidApikey() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid apikey.", MessageTypes.Fail);
			Reporter.log(headers.toString());
		} catch (Exception e) {

			Reporter.log("POST failed due to Invalid apikey.", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * Posting Create Resource for Service Description for Invalid JSON entry
	 */

	@QAFTestStep(description = "I Post Create Resource for Service description for Invalid Json entry")
	public void iPostCreateResourceForServiceDescriptionForInvalidJsonEntry() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid apikey.", MessageTypes.Fail);
			Reporter.log(headers.toString());
		} catch (Exception e) {

			Reporter.log("POST failed due to Invalid apikey.", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Posting Create Resource for Service Description for missing mandatory
	 * fields 2) Storing the error response in 'errorMsg'
	 */

	@QAFTestStep(description = "I Post Create Resource for Service description for missing mandatory fields")
	public void iPostCreateResourceForServiceDescriptionForMissingMandatoryFields() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.createbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful without mandatory field in body.", MessageTypes.Fail);
			Reporter.log(headers.toString());
		} catch (Exception e) {

			Reporter.log("POST failed, since the mandatory field is not available in bosy parameters.",
					MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) POSTing the create batch request 2) Storing the response in a String
	 * variable - APIresponse
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path")
	public static void iPostCreateResourceForResourcePath() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful.", MessageTypes.Pass);

		} catch (Exception e) {

			Reporter.log("POST failed", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log(headers.toString());
			Reporter.log("BodyParamter: " + BodyParamter.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) POSTing create request for Service Version 2) Storing the response in
	 * 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Service Version")
	public static void iPostCreateResourceForServiceVersion() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		Reporter.log(BodyParamter.toString());

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("POST Successfull", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("POST Failed ", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Post Create Resource for Service Description with Invalid or empty
	 * body parameter 2) Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for Service description with Invalid or empty body parameter")
	public void iPostCreateResourceForServiceDescriptionWithInvalidOrEmptyBodyParameter() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);
		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log(headers.toString());
		} catch (Exception e) {
			Reporter.log("POST Failed ", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) POSTing with Invalid 'CollectionID' and 'ServiceDesID' 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for service version with Invalid collectionId and ServiceDescriptionID")
	public void iPostCreateResourceForServiceVersionWithInvalidCollectionIdAndServiceDescriptionID() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		Reporter.log(BodyParamter.toString());

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Create successful with Invalid collectionId and ServiceDescId.", MessageTypes.Fail);
			Reporter.log("CollectionId: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
		} catch (Exception e) {
			Reporter.log("POST Failed due to Invalid CollectionId and ServiceDescriptionId.", MessageTypes.Pass);
			Reporter.log("CollectionId: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Posting resourcePath resource with Invalid CollectionID. 2) Storing
	 * the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path with Invalid CollectionId")
	public void iPostCreateResourceForResourcePathWithInvalidCollectionId() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid CollectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);
		} catch (Exception e) {

			Reporter.log("POST failed due to Invalid CollectionId ", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Posting Create resource with Invalid Service Description Id 2) Storing
	 * the error response in variable 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path with Invalid serviceDescriptionId")
	public void iPostCreateResourceForResourcePathWithInvalidServiceDescriptionId() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid serviceDescriptionId", MessageTypes.Fail);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
		} catch (Exception e) {

			Reporter.log("POST failed due to Invalid serviceDescriptionId.", MessageTypes.Pass);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) POSTing the resource with Invalid CollectionID 2) Storing the error
	 * response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for service version with invalid collectionId")
	public void iPostCreateResourceForServiceVersionWithInvalidCollectionId() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		Reporter.log(BodyParamter.toString());

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("Create successful with invalid collectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);

		} catch (Exception e) {
			Reporter.log("Create failed due to invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);

			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) POSTing the resource with empty body parameters 2) Storing the error
	 * message in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post Create Resource for Service Version with Invalid or empty body parameter")
	public void iPostCreateResourceForServiceVersionWithInvalidOrEmptyBodyParameter() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);
		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log(headers.toString());
		} catch (Exception e) {
			Reporter.log("POST Failed ", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Posting create resource with Invalid apikey. 2) Storing the error
	 * response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path with Invalid apikey")
	public void iPostCreateResourceForResourcePathWithInvalidApikey() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid apikey.", MessageTypes.Fail);
			Reporter.log(headers.toString());

		} catch (Exception e) {

			Reporter.log("Post failed due to Invalid apikey.", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) POSTing the create request with missing mandatory fields 2) Storing
	 * the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path with missing mandatory field")
	public void iPostCreateResourceForResourcePathWithMissingMandatoryField() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("Post successful with missing mandatory field.", MessageTypes.Fail);
			Reporter.log("BodyParamter: " + BodyParamter.toString());

		} catch (Exception e) {

			Reporter.log("Post failed due to missing mandatory field.", MessageTypes.Pass);
			Reporter.log("BodyParamter: " + BodyParamter.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Posting resource path with Invalid collectionId an ServiceVersionId 2)
	 * Storing the error response in variable 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I Post create resource for Resource Path with invalid collectionId and ServiceVersionId")
	public void iPostCreateResourceForResourcePathWithInvalidCollectionIdAndServiceVersionId() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {

			RESPONSE = CommonUtils.POST(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Post successful with Invalid CollectionId and Service DescriptionId", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionID: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);

		} catch (Exception e) {

			Reporter.log("Post failed due to Invalid CollectionId and Service DescriptionId", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionID: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

}
