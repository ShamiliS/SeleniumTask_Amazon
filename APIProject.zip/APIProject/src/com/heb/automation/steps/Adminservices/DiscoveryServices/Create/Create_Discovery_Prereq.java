package com.heb.automation.steps.Adminservices.DiscoveryServices.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Create_Discovery_Prereq {

	/**
	 * 1) Reads the API collection resource 2) sets the value for valid Service
	 * versionID and ServiceDesID 3) Invalid value for CollectionID
	 */
	@QAFTestStep(description = "user have an in-valid CollectionID, valid ServiceDesc, valid ServiceVersion")
	public void userHaveAnInValidCollectionIDValidServiceDescValidServiceVersion() {

		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();

		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("ServiceDesID"));
		getBundle().setProperty("ServiceVersionID", getBundle().getString("ServiceVersionID"));

	}

	/**
	 * Reading API collection read batch and setting the below values 1) Valid
	 * CollectionID, ServiceVersionID 2) Invalid ServiceDesID
	 * 
	 */
	@QAFTestStep(description = "user have an valid CollectionID, in-valid ServiceDesc, valid ServiceVersion")
	public void userHaveAnValidCollectionIDInValidServiceDescValidServiceVersion() {
		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();

		getBundle().setProperty("CollectionID", getBundle().getString("CollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("invalidServiceDescriptionID"));
		getBundle().setProperty("ServiceVersionID", getBundle().getString("ServiceVersionID"));
	}

	/**
	 * Reading API collection read batch and setting the below values 1) Invalid
	 * CollectionID, ServiceVersionID 2) Valid ServiceDesID
	 * 
	 */
	@QAFTestStep(description = "user have an in-valid CollectionID, valid ServiceDesc, in-valid ServiceVersion")
	public void userHaveAnInValidCollectionIDValidServiceDescInValidServiceVersion() {
		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();

		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("ServiceDesID"));
		getBundle().setProperty("ServiceVersionID", getBundle().getString("invalidServiceVersionID"));
	}

	@QAFTestStep(description = "user have an in-valid CollectionID, in-valid ServiceDesc, valid ServiceVersion")
	public void userHaveAnInValidCollectionIDInValidServiceDescValidServiceVersion() {
		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();

		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("invalidServiceDescriptionID"));
		getBundle().setProperty("ServiceVersionID", getBundle().getString("ServiceVersionID"));
	}

}
