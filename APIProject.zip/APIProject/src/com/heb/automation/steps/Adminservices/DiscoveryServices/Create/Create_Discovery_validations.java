package com.heb.automation.steps.Adminservices.DiscoveryServices.Create;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.Map.Entry;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.common.endpoints.constants.ApiDiscovery_Client_Constants;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Create_Discovery_validations {

	/**
	 * Validate Created response of APICollection for Full Success 1) Response
	 * status 2) Schema validation 3) Validate the requires fields are available
	 * 4) Validating the count of objects are equal in request and response
	 * 
	 * @throws Exception
	 */

	@QAFTestStep(description = "Validate the apiCollection Create response for Full success")
	public static void validateTheApiCollectionCreateResponseForFullSuccess() throws Exception {
		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		getBundle().setProperty("collectionIdsAsJsonArray", successList);

		String CollectionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("CollectionID", CollectionID);

		int collectionIDsCoumtFromResponse = successList.size();
		int collectionIDsCoumtFromRequestBody = getBundle().getInt("TotalcollectionIdsCount");

		if (collectionIDsCoumtFromResponse == collectionIDsCoumtFromRequestBody) {
			Reporter.log("All the CollectionIds are validated successfully  ", MessageTypes.Pass);
		} else {
			Reporter.log(
					"Validation Failed for collectionIDsCoumtFromResponse:" + collectionIDsCoumtFromResponse
							+ "collectionIDsCoumtFromRequestBody: " + collectionIDsCoumtFromRequestBody,
					MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "APICollection_Create");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_FullSuccess_Schema", "APICollection_Create");

	}

	/**
	 * Validate Created response of APICollection for Partial Success 1)
	 * Response status 2) Schema validation 3) Validate the requires fields are
	 * available 4) Validating the count of objects are equal in request and
	 * response
	 * 
	 * 
	 * @throws Exception
	 */

	@QAFTestStep(description = "Validate the apiCollection Create response for partial success")
	public void validateTheApiCollectionCreateResponseForPartialSuccess() throws Exception {
		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");
		getBundle().setProperty("collectionIdsAsJsonArray", successList);

		String CollectionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("CollectionID", CollectionID);

		int collectionIDsCoumtFromResponse = successList.size() + errorsList.size();
		int collectionIDsCoumtFromRequestBody = getBundle().getInt("TotalcollectionIdsCount");

		if (collectionIDsCoumtFromResponse == collectionIDsCoumtFromRequestBody) {
			Reporter.log("All the CollectionIds are successful and valdiated ", MessageTypes.Pass);
			Reporter.log("Total CollectionIDs count: " + collectionIDsCoumtFromResponse);
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
			Reporter.log("collectionIDsCoumtFromResponse: " + collectionIDsCoumtFromResponse);
			Reporter.log("collectionIDsCoumtFromRequestBody: " + collectionIDsCoumtFromRequestBody);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "APICollection_Create");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_PartialSuccess_Schema", "APICollection_Create");
	}

	/**
	 * Validate error response of missing mandatory fields 1) Status code 2)
	 * Message section is available in the error response
	 * 
	 * @param errorCode
	 */

	@QAFTestStep(description = "I Validate the response {0}_Error for missing mandatory field")
	public void IValidateTheResponseErrorForMissingMandatoryField(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.missMandateNameField");
		JsonObject BodyParamter = ((JsonArray) getBundle().getProperty("BodyParametervalue")).get(0).getAsJsonObject();
		String collectionId = getBundle().getString("CollectionID");

		ErrorMessage.validateErrorResponse(errorCode);

		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);

		// ErrorMessage.validateErrorMessageOfJsonObjectTextUnderJsonObjectMessage(actErrorMsg,expErrorMsg);

		// ErrorMessage.validateObjectJsonObject(actErrorMsg, BodyParamter);

		// ErrorMessage.validateIdInErrorResponse(actErrorMsg, collectionId);

		// ErrorMessage.validateStatusInErrorResponse(actErrorMsg,Integer.toString(errorCode));
	}

	/**
	 * Validation of Service Description response for Full Success 1) Response
	 * status 2) Schema validation 3) Validate the requires fields are available
	 * 4) Validating the count of objects are equal in request and response
	 * 
	 * @throws Exception
	 */

	@QAFTestStep(description = "Validate the Service Description Create response for Full success")
	public void validateTheServiceDescriptionCreateResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		getBundle().setProperty("ServiceDescriptionIdsAsJsonArray", successList);

		String ServiceDescriptionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("ServiceDescriptionID", ServiceDescriptionID);

		int ServiceDescriptionIDsCountFromResponse = successList.size();
		int ServiceDescriptionIdsCountFromRequestBody = getBundle().getInt("ServiceDescriptionIdsCountFromRequest");

		if (ServiceDescriptionIDsCountFromResponse == ServiceDescriptionIdsCountFromRequestBody) {

			Reporter.log("All the ServiceDescriptionIds are successful and valdiated ", MessageTypes.Pass);
			Reporter.log("ServiceDescriptionIds count: " + ServiceDescriptionIDsCountFromResponse);
		} else {

			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
			Reporter.log("ServiceDescriptionIDsCountFromResponse: " + ServiceDescriptionIDsCountFromResponse);
			Reporter.log("ServiceDescriptionIdsCountFromRequestBody: " + ServiceDescriptionIdsCountFromRequestBody);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_Create");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_FullSuccess_Schema", "App_DS_Create");

	}

	/**
	 * Validation of Service Description response for Partial Success 1)
	 * Response status 2) Schema validation 3) Validate the requires fields are
	 * available 4) Validating the count of objects are equal in request and
	 * response
	 * 
	 * @throws Exception
	 */

	@QAFTestStep(description = "Validate the Service Description Create response for Partial success")
	public void validateTheServiceDescriptionCreateResponseForPartialSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		int ServiceDescriptionIdsCountFromResponse = successList.size() + errorsList.size();
		int ServiceDescriptionIdsCountFromRequest = getBundle().getInt("ServiceDescriptionIdsCountFromRequest");
		int successCount = successList.size();
		int errorsCount = errorsList.size();

		if (ServiceDescriptionIdsCountFromResponse == ServiceDescriptionIdsCountFromRequest) {
			Reporter.log("All the ServiceDesIds are successful and valdiated ", MessageTypes.Pass);
			Reporter.log("Total Service Description Ids count: " + ServiceDescriptionIdsCountFromResponse
					+ ",SuccessCount: " + successCount + ",ErrorsCount: " + errorsCount);
		} else {
			Reporter.log("Validation Failed with successCount: " + successCount, MessageTypes.Fail);
			Reporter.log("ServiceDescriptionIdsCountFromResponse: " + ServiceDescriptionIdsCountFromResponse
					+ "ServiceDescriptionIdsCountFromRequest: " + ServiceDescriptionIdsCountFromRequest);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		Reporter.log("Failed to create " + errorsList.size() + "service Description, due to error ", MessageTypes.Pass);

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "APICollection_Create");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_PartialSuccess_Schema", "APICollection_Create");
	}

	/**
	 * Validation of resourcePath response for full success 1) Response status
	 * 2) Schema validation 3) Validate the requires fields are available 4)
	 * Validating the count of objects are equal in request and response
	 * 
	 * @throws Exception
	 * @throws ProcessingException
	 */
	@QAFTestStep(description = "I validate the resourcePath response for full success")
	public static void iValidateTheResourcePathResponseForFullSuccess() throws ProcessingException, Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		getBundle().setProperty("ResourcePathIDsAsJsonArray", successList);

		String ResourcePathID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("ResourcePathID", ResourcePathID);

		int ResourcePathIDsCountFromResponse = successList.size();
		int ResourcePathIDCountFromRequest = getBundle().getInt("ResourcePathIDCountFromRequest");

		if (ResourcePathIDCountFromRequest == ResourcePathIDsCountFromResponse) {
			Reporter.log("All the ResourcePath are successful and valdiated ", MessageTypes.Pass);
			Reporter.log("ResourcePath count: " + ResourcePathIDsCountFromResponse);
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
			Reporter.log("ResourcePathIDsCountFromResponse: " + ResourcePathIDsCountFromResponse);
			Reporter.log("ResourcePathIDCountFromRequest: " + ResourcePathIDCountFromRequest);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_Create_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_FullSuccess_Schema", "RP_Create_FullSuccess");

	}

	/**
	 * Validating the Response for Partial Success 1) Response status 2) Schema
	 * validation 3) Validate the requires fields are available 4) Validating
	 * the count of objects are equal in request and response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the resourcePath response for partial success")
	public void iValidateTheResourcePathResponseForPartialSuccess() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		getBundle().setProperty("ResourcePathIDsAsJsonArray", successList);

		int ResourcePathIDCoumtFromResponse = successList.size() + errorsList.size();
		int ResourcePathIDCountFromRequest = getBundle().getInt("ResourcePathIDCountFromRequest");

		if (ResourcePathIDCoumtFromResponse == ResourcePathIDCountFromRequest) {
			Reporter.log("All the Resourcepath are successful and valdiated ", MessageTypes.Pass);
			Reporter.log("Total Resourcepath count: " + ResourcePathIDCoumtFromResponse);
			Reporter.log("successCount: " + successList.size());
			Reporter.log("errorsCount: " + errorsList.size());
		} else {
			Reporter.log("Not successfull and Validation Failed ", MessageTypes.Fail);
			Reporter.log("collectionIDsCoumtFromResponse: " + ResourcePathIDCoumtFromResponse);
			Reporter.log("collectionIDsCoumtFromRequestBody: " + ResourcePathIDCountFromRequest);
			Reporter.log("successCount: " + successList.size());
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_Create_PartialSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_PartialSuccess_Schema", "RP_Create_PartialSuccess");

	}

	/**
	 * Validating the serviceVersion response for full success 1) Response
	 * status 2) Schema validation 3) Validate the requires fields are available
	 * 4) Validating the count of objects are equal in request and response
	 * 
	 */
	@QAFTestStep(description = "I validate the serviceVersion response for full success")
	public void iValidateTheServiceVersionResponseForFullSuccess() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		getBundle().setProperty("ServiceVersionIdsAsJsonArray", successList);

		String ServiceVersionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("ServiceVersionID", ServiceVersionID);

		int ServiceVersionIDsCountFromResponse = successList.size();
		int ServiceVersionIDsCountFromRequest = ((JsonArray) getBundle().getProperty("BodyParametervalue")).size();

		if (ServiceVersionIDsCountFromRequest == ServiceVersionIDsCountFromResponse) {
			Reporter.log("Serviceversion request are validated successfully ", MessageTypes.Pass);
			Reporter.log("Service Version count: " + ServiceVersionIDsCountFromResponse);
		} else {
			Reporter.log("Service Version are not validated successfully", MessageTypes.Fail);
			Reporter.log("ServiceVersionIDsCountFromResponse: " + ServiceVersionIDsCountFromResponse
					+ ",ServiceVersionIDCountFromRequest" + ServiceVersionIDsCountFromRequest);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_Create_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_FullSuccess_Schema", "SV_Create_FullSuccess");

	}

	/**
	 * Validate Created response of APICollection for Partial Success 1)
	 * Response status 2) Schema validation 3) Validate the requires fields are
	 * available 4) Validating the count of objects are equal in request and
	 * response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I Validate the serviceVersion response for Partial success")
	public void iValidateTheServiceVersionResponseForPartialSuccess() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		getBundle().setProperty("ServiceVersionIdsAsJsonArray", successList);

		int collectionIDsCountFromResponse = successList.size() + errorsList.size();
		int collectionIDsCountFromRequestBody = getBundle().getInt("ServiceVersionRequestCount");

		if (collectionIDsCountFromResponse == collectionIDsCountFromRequestBody) {
			Reporter.log("All the CollectionIds are successfully valdiated and total request is:"
					+ collectionIDsCountFromResponse, MessageTypes.Pass);
			Reporter.log("successCount: " + successList.size() + ", errorsCount: " + errorsList.size());

		} else {
			Reporter.log("CollectionIDs are not validated successfully", MessageTypes.Fail);
			Reporter.log("CollectionIDs from Response is: " + collectionIDsCountFromResponse
					+ " CollectionIDs from RequestBody is:" + collectionIDsCountFromRequestBody);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Create_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_Create_PartialSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Create_PartialSuccess_Schema", "SV_Create_PartialSuccess");
	}

	public static void getServiceVersionFromResponse() {
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		String ServiceVersionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("ServiceVersionID", ServiceVersionID);
		getBundle().setProperty("ServiceVersionIDsArray", successList);
	}

	/**
	 * Getting list of Service Description Id's from response
	 */

	public static void getServiceDescriptionFromResponse() {
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");

		getBundle().setProperty("ServiceDescriptionIdsAsJsonArray", successList);

		/*
		 * Storing the success ServiceDescriptionID
		 */
		String ServiceDescriptionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("ServiceDesID", ServiceDescriptionID);
		Reporter.log("ServiceDescriptionID " + ServiceDescriptionID);
	}

	/*
	 * Getting list of Collection Id's from response
	 */

	@QAFTestStep(description = "Get CollectionId From Response")
	public static void getCollectionIdFromResponse() {
		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		getBundle().setProperty("collectionIdsAsJsonArray", successList);

		/*
		 * Storing the success collectionID
		 */
		String CollectionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("CollectionID", CollectionID);
	}

	/**
	 * 1) Setting the Invalid value for 'CollectionID' 2) Setting the Invalid
	 * value for 'ServiceDesID'
	 */

	@QAFTestStep(description = "the user is having Invalid collectionId and Invalid Service DescriptionID")
	public void theUserIsHavingInvalidCollectionIdAndInvalidServiceDescriptionID() {

		String InvalidCollectionID = getBundle().getString("serviceversion.invalidCollectionID");
		String InvalidServiceDescriptionID = getBundle().getString("serviceversion.invalidServiceDescriptionID");

		getBundle().setProperty("CollectionID", InvalidCollectionID);
		getBundle().setProperty("ServiceDesID", InvalidServiceDescriptionID);

		if (!InvalidCollectionID.isEmpty() && !InvalidServiceDescriptionID.isEmpty()) {
			Reporter.log("InvalidCollectionID: " + InvalidCollectionID, MessageTypes.Pass);
			Reporter.log("InvalidServiceDescriptionID: " + InvalidServiceDescriptionID, MessageTypes.Pass);
		} else {
			Reporter.log(
					"Error occured while getting the Valid CollectionID and ServiceDescriptionID from the Read request.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Validate created Collection ID's in Admin Portal READ Response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate created CollectionID's in Admin Portal READ")
	public void iValidateCreatedCollectionIDInAdminPortalREAD() throws Exception {

		String ExpCollectionId, ActCollectionID;

		JsonArray collectionIDarr = (JsonArray) getBundle().getProperty("collectionIdsAsJsonArray");
		for (JsonElement colId : collectionIDarr) {

			ExpCollectionId = colId.getAsString().toString().replace("\"", "");
			getBundle().setProperty("CollectionID", ExpCollectionId);

			Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();

			JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
			ActCollectionID = gson.getAsJsonObject().get("collectionId").toString().replace("\"", "");

			if (ExpCollectionId.equals(ActCollectionID)) {
				Reporter.log("Created Collection Id's are available in Admin Portal: " + ActCollectionID,
						MessageTypes.Pass);
			} else {
				Reporter.log("Created Collection Id's are not available in Admin Portal", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Validate created Collection ID in Customer Portal READ Response
	 * 
	 */
	@QAFTestStep(description = "I validate created CollectionID's in Customer Portal READ")
	public void iValidateCreatedCollectionIDInCustomerPortalREAD() {

		String resCollectionID, CollectionID;

		JsonArray ExpcollectionID = (JsonArray) getBundle().getProperty("collectionIdsAsJsonArray");

		for (JsonElement expCollID : ExpcollectionID) {
			CollectionID = expCollID.getAsString().toString().replace("\"", "");

			Read_Discovery_GETcalls
					.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal(CollectionID);

			JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
			resCollectionID = gson.getAsJsonObject().get(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID).toString().replace("\"", "");

			if (resCollectionID.equals(CollectionID)) {
				Reporter.log("Created CollectionID is available in Customer Portal: " + CollectionID,
						MessageTypes.Pass);
			} else {
				Reporter.log("Created CollectionID is not available in Customer Portal", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Validating the created ServiceVersionIDs are available in Client portal
	 * Read
	 * 
	 */
	@QAFTestStep(description = "I Verify the Created Service Version fields in Discovery Services Customer Portal READ")
	public void iVerifyTheCreatedServiceVersionFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> expectedServiceVersionIds = new ArrayList<String>();
		ArrayList<String> actualServiceVersionIds = new ArrayList<String>();

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ServiceVersionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			expectedServiceVersionIds.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {
				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {
								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVer : serviceVersionsArray) {
										String serviceVersionId = singleServiceVer.getAsJsonObject().get(ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)
												.toString().replace("\"", "");
										actualServiceVersionIds.add(serviceVersionId);
									}
								}
							}
						}
					}
				}
			}
		}

		if (actualServiceVersionIds.containsAll(expectedServiceVersionIds)) {
			Reporter.log("Created Service Version Id's are available in Customer Portal: " + expectedServiceVersionIds,
					MessageTypes.Pass);
		} else {
			Reporter.log("Created Service Version Id's are not available in Customer Portal", MessageTypes.Fail);
		}
	}

	/**
	 * Validating the created ServiceVersionIDs are available in ADMIN portal
	 * Read
	 * 
	 */
	@QAFTestStep(description = "I Verify the Created Service Version fields in Discovery Services Admin Portal READ")
	public void iVerifyTheCreatedServiceVersionFieldsInDiscoveryServicesAdminPortalREAD() {

		String ExpServiceVersionId, ActServiceVersionId;

		JsonArray ServiceVersionIDarr = (JsonArray) getBundle().getProperty("ServiceVersionIdsAsJsonArray");
		for (JsonElement serviceVerId : ServiceVersionIDarr) {

			ExpServiceVersionId = serviceVerId.getAsString().toString().replace("\"", "");
			ConfigurationManager.getBundle().setProperty("ServiceVersionID", ExpServiceVersionId);

			Read_Discovery_GETcalls.iReadSpecificResourceFieldsServiceVersionDiscoveryServices();

			JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
			ActServiceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");

			if (ExpServiceVersionId.equals(ActServiceVersionId)) {
				Reporter.log("Created ServiceVersionID is available in Admin Portal: " + ActServiceVersionId,
						MessageTypes.Pass);
			} else {
				Reporter.log("Created ServiceVersionID is not available in Admin Portal: " + ActServiceVersionId,
						MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying the Created ResourcePathIDs in Discovery Services ADMIN Portal
	 * READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the Created ResourcePath fields in Discovery Services Admin Portal READ")
	public void iVerifyTheCreatedResourcePathFieldsInDiscoveryServicesAdminPortalREAD() {

		String ExpResourcePathID, ActExpResourcePathID;

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonArray ResourcePathIDarr = (JsonArray) getBundle().getProperty("ResourcePathIDsAsJsonArray");
		for (JsonElement resourcePathId : ResourcePathIDarr) {

			ExpResourcePathID = resourcePathId.getAsString().toString().replace("\"", "");
			getBundle().setProperty("ResourcePathID", ExpResourcePathID);

			Read_Discovery_GETcalls.iREADResourcePathResourceForCollectionIDServiceDesServVersionResourcePath(
					CollectionID, ServiceDesID, ServiceVersionID, ExpResourcePathID);

			JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
			ActExpResourcePathID = gson.getAsJsonObject().get("resourcePathId").toString().replace("\"", "");

			if (ExpResourcePathID.equals(ActExpResourcePathID)) {
				Reporter.log("Created ResourcePathID is available in Admin Portal: " + ActExpResourcePathID,
						MessageTypes.Pass);
			} else {
				Reporter.log("Created ResourcePathID is not available in Admin Portal: " + ActExpResourcePathID,
						MessageTypes.Fail);
			}
		}

	}

	/**
	 * Verifying the Created ResourcePathIDs in Discovery Services Customer
	 * Portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the Created ResourcePath fields in Discovery Services Customer Portal READ")
	public void iVerifyTheCreatedResourcePathFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> expectedResourcePathIds = new ArrayList<String>();
		ArrayList<String> actualResourcePathIds = new ArrayList<String>();

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ResourcePathIDsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			expectedResourcePathIds.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {
				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {
								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVersion : serviceVersionsArray) {

										for (Entry<String, JsonElement> JsonObject2 : singleServiceVersion
												.getAsJsonObject().entrySet()) {

											if (JsonObject2.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)) {

												if (JsonObject2.getValue().toString().replace("\"", "")
														.equalsIgnoreCase(ServiceVersionID)) {

													JsonArray ResourcePathsArray = (JsonArray) singleServiceVersion
															.getAsJsonObject().get("resourcePaths");

													for (JsonElement singleResourcePath : ResourcePathsArray) {
														for (Entry<String, JsonElement> JsonObject3 : singleResourcePath
																.getAsJsonObject().entrySet()) {

															if (JsonObject3.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.RESOURCE_PATH_PROPERTY_ID)) {
																String ResourcePathId = JsonObject3.getValue()
																		.toString().replace("\"", "");
																actualResourcePathIds.add(ResourcePathId);
															}
														}
													}
												}
											}
										}
									}

								}
							}

						}
					}
				}
			}
		}

		if (actualResourcePathIds.containsAll(expectedResourcePathIds)) {
			Reporter.log("Created ReourcePath Id's are available in Customer Portal: " + expectedResourcePathIds,
					MessageTypes.Pass);
		} else {
			Reporter.log("Created ReourcePath Id's are not available in Customer Portal", MessageTypes.Fail);
		}
	}

}
