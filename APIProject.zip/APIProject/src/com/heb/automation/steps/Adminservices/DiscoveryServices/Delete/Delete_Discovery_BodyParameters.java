package com.heb.automation.steps.Adminservices.DiscoveryServices.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Discovery_ReusableUtils.Discovery_ReusableUtils;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Delete_Discovery_BodyParameters {

	/**
	 * Defining body parameter with array of valid Collection ID's to Delete
	 * Batch
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of collectionIds")
	public void theDeleteBatchRequestBodyParameterShouldContainValidArrayOfCollectionIds() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("collectionIdsAsJsonArray");
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining body parameter with array of valid serviceDescription ID's to
	 * Delete Batch
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of serviceDescriptionIds")
	public void theDeleteBatchRequestBodyParameterShouldContainValidArrayOfServiceDescriptionIds() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("ServiceDescriptionIdsAsJsonArray");
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining body parameter with array of Invalid serviceDescription ID's
	 * to Delete Batch
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter with valid and invalid serviceDescriptionIds")
	public void theDeleteBatchRequestBodyParameterWithValidAndInvalidServiceDescriptionIds() {

		String invalidServiceDescriptionId = "abcd123";

		String temp = getBundle().getProperty("ServiceDescriptionIdsAsJsonArray").toString().replace("[", "")
				.replace("]", "");
		String strData = "[" + temp + ",\"" + invalidServiceDescriptionId + "\"]";

		Object object = null;
		JsonArray BodyParameter = null;
		JsonParser jsonParser = new JsonParser();
		object = jsonParser.parse(strData);
		BodyParameter = (JsonArray) object;

		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Update Body Parameter with Invalid JSON entry
	 */

	@QAFTestStep(description = "I Update the Request Body Parameter with Invalid Json entry")
	public void iUpdateTheRequestBodyParameterWithInvalidJsonEntry() {

		String BodyParameter = Discovery_ReusableUtils.serviceDescription_add_Mandatory_fields().toString() + ",";
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining the Body section with valid array of ResourcepathIDs
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of resourcePathIDs")
	public void theDeleteBatchRequestBodyParameterShouldContainValidArrayOfResourcePathIDs() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("ResourcePathIDsAsJsonArray");
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Defining the Body parameter with valid and Invalid set of ResourcePathIDs
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter is having a set of valid and invalid set of resourcePathIDs")
	public void theDeleteBatchRequestBodyParameterIsHavingASetOfValidAndInvalidSetOfResourcePathIDs() {

		String invalidResourcePathId = getBundle().getString("invalidResourcePathId");

		String temp = getBundle().getProperty("ResourcePathIDsAsJsonArray").toString().replace("[", "").replace("]",
				"");
		String strData = "[" + temp + ",\"" + invalidResourcePathId + "\"]";

		Object object = null;
		JsonArray BodyParameter = null;
		JsonParser jsonParser = new JsonParser();
		object = jsonParser.parse(strData);
		BodyParameter = (JsonArray) object;

		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining the body parameters with valid array of ServiceVersionIDs
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain valid array of serviceVersionIds")
	public void theDeleteBatchRequestBodyParameterShouldContainValidArrayOfServiceVersionIds() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("ServiceVersionIDsArray");
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining the Body Parameter with an array of Invalid ServiceVersionIDs
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain array of valid and invalid serviceVersionIds")
	public void theDeleteBatchRequestBodyParameterShouldContainArrayOfValidAndInvalidServiceVersionIds() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("ServiceVersionIDsArray");

		JsonParser parser = new JsonParser();
		JsonElement invalid_SerVersion = (JsonElement) parser.parse(getBundle().getString("invalidServiceVersionID"));

		BodyParameter.add(invalid_SerVersion);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * 1) Defining the Body parameters with Invalid JSON structure
	 * 
	 */
	@QAFTestStep(description = "the delete Batch Request Body Parameter should contain invalid body parameter")
	public void theDeleteBatchRequestBodyParameterShouldContainInvalidBodyParameter() {

		JsonArray BodyParameter = (JsonArray) getBundle().getProperty("ServiceVersionIDsArray");
		String strBody = BodyParameter.toString().replace("]", "],");
		getBundle().setProperty("BodyParametervalue", strBody);
	}

}
