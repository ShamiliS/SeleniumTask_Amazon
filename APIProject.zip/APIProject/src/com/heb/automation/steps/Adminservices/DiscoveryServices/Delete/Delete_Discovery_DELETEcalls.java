package com.heb.automation.steps.Adminservices.DiscoveryServices.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.JsonArray;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Delete_Discovery_DELETEcalls {

	/**
	 * 1) DELETE batch resource with valid set of data 2) Storing the response
	 * in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for apiCollection Discovery services")
	public void iDELETEBatchResourceForApiCollectionDiscoveryServices() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!");
		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!");
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) DELETing the batch resource with empty Body parameter 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for apiCollection Discovery services with empty body parameters")
	public void iDELETEBatchResourceForApiCollectionDiscoveryServicesWithEmptyBodyParameters() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!");
		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!");
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) DELETing a specific API collection resource 2) Storing the response in
	 * 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE specific Resource for apiCollection Discovery services")
	public void iDELETESpecificResourceForApiCollectionDiscoveryServices() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.delete");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!");
		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!");
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) Deleting specific resource with empty collectonID in URL 2) Storing
	 * the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE specific Resource for apiCollection Discovery services with empty collectionId")
	public void iDELETESpecificResourceForApiCollectionDiscoveryServicesWithEmptyCollectionId() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.delete")
				.replace("/" + getBundle().getString("CollectionID"), "");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with empty collectionId.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Delete batch Failed due to empty collectionId.", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	@QAFTestStep(description = "I DELETE specific Resource for apiCollection Discovery services with invalid collectionId")
	public void iDELETESpecificResourceForApiCollectionDiscoveryServicesWithInvalidCollectionId() {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.delete");
		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Invalid collectionId", MessageTypes.Fail);
			Reporter.log("CollectionID: " + getBundle().getString("CollectionID"));
		} catch (Exception e) {
			Reporter.log("Delete Batch failed due to Invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + getBundle().getString("CollectionID"));
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	@QAFTestStep(description = "I DELETE specific Resource for apiCollection Discovery services with Bad URL")
	public void iDELETESpecificResourceForApiCollectionDiscoveryServicesWithBadURL() {
		String baseurl = getBundle().getString("MLapiURL.Admin_UrlBadURl").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.delete");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Bad url.", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Delete batch Failed due to bad url.", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource with valid data 2) Storing the response in
	 * 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for serviceDescription Discovery services")
	public void iDELETEBatchResourceForServiceDescriptionDiscoveryServices() {

		String CollectionID = getBundle().getString("CollectionID");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions";

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!", MessageTypes.Info);
		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) Deleting the batch resource with empty or invalid value 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for serviceDescription with empty or invalid body parameters")
	public void iDELETEBatchResourceForServiceDescriptionWithEmptyOrInvalidBodyParameters() {

		String CollectionID = getBundle().getString("CollectionID");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions";

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with empty/invalid body parameters", MessageTypes.Fail);
			Reporter.log("BodyParamter: " + BodyParamter);

		} catch (Exception e) {
			Reporter.log("Delete Batch failed due to empty/invalid body parameters", MessageTypes.Pass);
			Reporter.log("BodyParamter: " + BodyParamter);

			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I DELETE Batch Resource for serviceDescription with bad url")
	public void iDELETEBatchResourceForServiceDescriptionWithBadUrl() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.deletebatch");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with bad url", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);
		} catch (Exception e) {
			Reporter.log("Delete Batch failed due to bad url", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}

	}

	/**
	 * 1) Deleting specific resource for service description 2) Storing the
	 * response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE specific Resource for serviceDescription")
	public void iDELETESpecificResourceForServiceDescription() {

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDesID;

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull.", MessageTypes.Info);
		} catch (Exception e) {
			Reporter.log("Error occurred while Delete request.", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I DELETE specific Resource for serviceDescription with bad url")
	public void iDELETESpecificResourceForServiceDescriptionWithBadUrl() {
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("\"", "");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.delete");

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with Bad url..", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);
		} catch (Exception e) {
			Reporter.log("Delete Failed due to bad url..", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource with valid set of data 2) Storing the
	 * response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services")
	public void iDELETEBatchResourceForResourcePathDiscoveryServices() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!", MessageTypes.Pass);

		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!", MessageTypes.Fail);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * 1) Deleting with Invalid collectionID 2) Storing the error response in
	 * 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with Invalid collectionId")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithInvalidCollectionId() {

		String invalidCollectionID = (String) getBundle().getProperty("invalidCollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + invalidCollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Invalid CollectionId!", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionId: " + invalidCollectionID);

		} catch (Exception e) {
			Reporter.log("Delete batch failed due to Invalid collectionId..", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionId: " + invalidCollectionID);

			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource without body parameters 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services without body parameters")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithoutBodyParameters() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with empty body parameters.", MessageTypes.Fail);
			Reporter.log("BodyParametervalue: " + BodyParamter);

		} catch (Exception e) {
			Reporter.log("Delete batch failed due to empty body parameters.", MessageTypes.Pass);
			Reporter.log("BodyParametervalue: " + BodyParamter);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource with Invalid body parameters 2) Storing
	 * the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with Invalid body parameters")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithInvalidBodyParameters() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Invalid body parameters.", MessageTypes.Fail);
			Reporter.log("BodyParametervalue: " + BodyParamter);

		} catch (Exception e) {
			Reporter.log("Delete batch failed due to Invalid body parameters.", MessageTypes.Pass);
			Reporter.log("BodyParametervalue: " + BodyParamter);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource with Invalid apikey 2) Storing the error
	 * response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with Invalid apikey")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithInvalidApikey() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Invalid apikey.", MessageTypes.Fail);
			Reporter.log(headers.toString());

		} catch (Exception e) {
			Reporter.log("Delete batch failed due to Invalid apikey.", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}
	}

	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with bad url")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithBadUrl() {

		String CollectionID = (String) getBundle().getProperty("collectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with bad url.", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);
		} catch (Exception e) {
			Reporter.log("Delete batch failed due to bad url.", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);

		}

	}

	/**
	 * 1) Deleting specific resource for ResourcePath 2) Storing the response in
	 * 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services")
	public void iDELETEResourceForResourcePathDiscoveryServices() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null, errorMsg = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull!", MessageTypes.Pass);

		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting request!", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();

			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting specific resource with Invalid ResourcePath 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with Invalid ResourcePathID")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithInvalidResourcePathID() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String invalidResourcePathId = getBundle().getString("invalidResourcePathId");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/"
				+ invalidResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with Invalid ResourcepathId..", MessageTypes.Fail);
			Reporter.log("Resource: " + resource);
			Reporter.log("InvalidResourcePathId: " + invalidResourcePathId);
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid ResourcePathId..", MessageTypes.Pass);
			Reporter.log("Resource: " + resource);
			Reporter.log("InvalidResourcePathId: " + invalidResourcePathId);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting specific resource with Invalid CollectionID 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with Invalid CollectionId")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithInvalidCollectionId() {

		String invalidCollectionID = getBundle().getString("invalidCollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + invalidCollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with Invalid CollectionID..", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidCollectionID: " + invalidCollectionID);
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid CollectionID..", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidCollectionID: " + invalidCollectionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
			
		}
	}

	/**
	 * 1) Deleting specific resource with Invalid ServiceDesID 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with Invalid ServiceDescriptionId")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithInvalidServiceDescriptionId() {

		String CollectionID = getBundle().getString("CollectionID");
		String invalidServiceDescriptionID = getBundle().getString("invalidServiceDescriptionID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ invalidServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/"
				+ ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with invalidServiceDescriptionID ", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidServiceDescriptionID: " + invalidServiceDescriptionID);
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to invalidServiceDescriptionID..", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidServiceDescriptionID: " + invalidServiceDescriptionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting specific resource with Invalid ServiceVersionID 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with Invalid ServiceVersionID")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithInvalidServiceVersionID() {

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String invalidServiceVersionID = getBundle().getString("invalidServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + invalidServiceVersionID + "/resourcePaths/"
				+ ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with invalidServiceVersionID..", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidServiceVersionID: " + invalidServiceVersionID);
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to invalidServiceVersionID..", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("invalidServiceVersionID: " + invalidServiceVersionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting specific resource with Invalid apikey 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with Invalid apikey")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithInvalidApikey() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with Invalid apikey..", MessageTypes.Fail);
			Reporter.log(headers.toString());
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to Invalid apikey..", MessageTypes.Pass);
			Reporter.log(headers.toString());
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting specific resource with Bad URL 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Resource for ResourcePath Discovery services with bad url")
	public void iDELETEResourceForResourcePathDiscoveryServicesWithBadUrl() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + ResourcePathId;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete successfull with Bad url..", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);
			
		} catch (Exception e) {
			Reporter.log("Delete failed due to bad url..", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting the batch resource with Invalid ServiceDesID 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with Invalid ServiceDescriptionId")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithInvalidServiceDescriptionId() {

		String CollectionID = getBundle().getString("CollectionID");
		String invalidServiceDescriptionID = getBundle().getString("invalidServiceDescriptionID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ invalidServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch successfull with invalidServiceDescriptionID..", MessageTypes.Fail);
			Reporter.log("invalidServiceDescriptionID: " + invalidServiceDescriptionID);
			Reporter.log("resource: " + resource);
		} catch (Exception e) {
			Reporter.log("Delete batch failed due to invalidServiceDescriptionID..", MessageTypes.Pass);
			Reporter.log("invalidServiceDescriptionID: " + invalidServiceDescriptionID);
			Reporter.log("resource: " + resource);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}

	}

	/**
	 * 1) Deleting the batch resource with Invalid ServiceVersionID 2) Storing
	 * the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for ResourcePath Discovery services with Invalid ServiceVersionId")
	public void iDELETEBatchResourceForResourcePathDiscoveryServicesWithInvalidServiceVersionId() {

		String CollectionID = getBundle().getString("collectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String invalidServiceVersionID = getBundle().getString("invalidServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + invalidServiceVersionID + "/resourcePaths";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch successfull with invalidServiceVersionID..", MessageTypes.Fail);
			Reporter.log("invalidServiceVersionID: " + invalidServiceVersionID);
			Reporter.log("resource: " + resource);

		} catch (Exception e) {
			Reporter.log("Delete batch failed due to invalidServiceVersionID..", MessageTypes.Pass);
			Reporter.log("invalidServiceVersionID: " + invalidServiceVersionID);
			Reporter.log("resource: " + resource);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting batch resource with valid array of data 2) Storing the
	 * response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for serviceVersion Discovery services")
	public void iDELETEBatchResourceForServiceVersionDiscoveryServices() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!", MessageTypes.Info);
		} catch (Exception e) {
			Reporter.log("Error occurred while Deleting Batch request!", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting batch resource with empty or Invalid body parameters 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for serviceVersion Discovery services with empty or invalid body parameter")
	public void iDELETEBatchResourceForServiceVersionDiscoveryServicesWithEmptyOrinvalidBodyParameter() {

		String CollectionID = (String) getBundle().getProperty("collectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!", MessageTypes.Info);

		} catch (Exception e) {

			Reporter.log("Error occurred while Deleting Batch request!", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Delete Specific resource with valid set of data 2) Storing the
	 * response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I DELETE specific Resource for serviceVersion Discovery services")
	public void iDELETESpecificResourceForServiceVersionDiscoveryServices() {
		String CollectionID = (String) getBundle().getProperty("collectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull!", MessageTypes.Info);

		} catch (Exception e) {

			Reporter.log("Error occurred while Deleting Batch request!", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting batch resource with invalid collectionID 2) Storing the error
	 * response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE Batch Resource for serviceVersion Discovery services with Invalid collectionId")
	public void iDELETEBatchResourceForServiceVersionDiscoveryServicesWithInvalidCollectionId() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers, BodyParamter.toString());
			Reporter.log("Delete Batch is successfull with Invalid collectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);
			
		} catch (Exception e) {
			Reporter.log("Delete Batch failed due to Invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) Deleting Specific resource with Invalid CollectionID 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I DELETE specific Resource for serviceVersion Discovery services with Invalid collectionId")
	public void iDELETESpecificResourceForServiceVersionDiscoveryServicesWithInvalidCollectionId() {
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.DELETE(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Delete Batch is successfull with Invalid collectionId", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);

		} catch (Exception e) {
			Reporter.log("Delete Batch failed due to Invalid collectionId", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

}
