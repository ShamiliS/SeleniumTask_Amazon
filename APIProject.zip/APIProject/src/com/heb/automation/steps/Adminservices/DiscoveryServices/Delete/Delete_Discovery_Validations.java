package com.heb.automation.steps.Adminservices.DiscoveryServices.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.common.endpoints.constants.ApiDiscovery_Client_Constants;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Delete_Discovery_Validations {

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED IDs are available in the
	 * response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of apiCollection Discovery services delete")
	public void validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesDelete() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		String DeletedCollectionId = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("DeletedCollectionId", DeletedCollectionId);

		if (successList.equals(BodyParamter)) {
			Reporter.log("Success List have all Collection Id's mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted Collection Id's:" + successList);
		} else {
			Reporter.log("Success List does not have all Collection Id's mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_Delete");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_FullSuccess_Schema", "App_DS_Delete");

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Success", RESPONSE);

	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED ID is available in the response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of specific apiCollection Discovery services delete")
	public void validateTheResponseForFullSuccessOfSpecificApiCollectionDiscoveryServicesDelete() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		String DeletedCollectionId;

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		DeletedCollectionId = gson.getAsJsonObject().get("id").toString().replace("\"", "");

		getBundle().setProperty("CollectionID", DeletedCollectionId);

		JsonArray collectionIdsAsJsonArray = new JsonArray();
		collectionIdsAsJsonArray.add(gson.getAsJsonObject().get("id"));
		getBundle().setProperty("collectionIdsAsJsonArray", collectionIdsAsJsonArray);

		if (DeletedCollectionId.equals(getBundle().getString("CollectionID"))) {
			Reporter.log("Deleted the Collection Id: " + DeletedCollectionId, MessageTypes.Pass);
		} else {
			Reporter.log("Collection Id is not deleted! ", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_Delete_Specific");
		ReusableUtils.validateJSONschema_ApiDiscovery("Delete_Specific_Schema", "App_DS_Delete_Specific");

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Specific_Success", RESPONSE);

	}

	/**
	 * Validate the error response 1) Status code: 400 2) Invalid Request
	 * 
	 * @param errorCode
	 */
	@QAFTestStep(description = "I Validate the response {0}_Error for not passing collection ID in URL")
	public void IValidateTheResponse_ErrorForNotPassingCollectionIDInURL(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.NoBodyParam");
		ErrorMessage.validateErrorResponse(errorCode);
	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED IDs are available in the
	 * response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the serviceDescription delete batch response for Full success")
	public void validateTheServiceDescriptionDeleteBatchResponseForFullSuccess() throws IOException, Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		getBundle().setProperty("ServiceDescriptionIdsAsJsonArray", successList);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		String DeletedServiceDesID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("DeletedServiceDesID", DeletedServiceDesID);

		if (successList.equals(BodyParamter)) {
			Reporter.log("Success List have all serviceDescription Id's mentioned in Body Parameter!",
					MessageTypes.Pass);
			Reporter.log("Deleted serviceDescription Id's:" + successList);
		} else {
			Reporter.log("Success List does not have all serviceDescription Id's mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_Delete");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_FullSuccess_Schema", "App_DS_Delete");
	}

	/**
	 * Validating the DELETE response for Partial success 1) Response status 2)
	 * Schema validation 3) Validate the count of IDs are equal in request and
	 * response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the serviceDescription delete batch response for Partial success")
	public void validateTheServiceDescriptionDeleteBatchResponseForPartialSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		int sizeFromResponse = successList.size() + errorsList.size();

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		if (sizeFromResponse == BodyParamter.size()) {
			Reporter.log("Response is having serviceDescription Id's mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted serviceDescription Id's:" + successList);
			Reporter.log("Delete failed serviceDescription Id's:" + errorsList);
		} else {
			Reporter.log("Response is not having all serviceDescription Id's mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SD_DeleteBatch_PartialSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_PartialSuccess_Schema",
				"SD_DeleteBatch_PartialSuccess");
	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED ID is available in the response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I Validate the serviceDescription delete response for Full success")
	public void iValidateTheServiceDescriptionDeleteResponseForFullSuccess() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		String DeletedServiceDesID = gson.getAsJsonObject().get("id").toString().replace("\"", "");

		getBundle().setProperty("DeletedServiceDesID", DeletedServiceDesID);

		if (DeletedServiceDesID.equals(getBundle().getString("ServiceDesID"))) {
			Reporter.log("Deleted the ServiceDescription Id: " + DeletedServiceDesID, MessageTypes.Pass);
		} else {
			Reporter.log("ServiceDescription Id is not deleted! ", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_Delete_Specific");
		ReusableUtils.validateJSONschema_ApiDiscovery("Delete_Specific_Schema", "App_DS_Delete_Specific");

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Specific_Success", RESPONSE);
	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED IDs are available in the
	 * response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the ResourcePath delete batch response for Full success")
	public void validateTheResourcePathDeleteBatchResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		getBundle().setProperty("DeletedResourcePathIDsAsJsonArray", successList);

		String DeletedResourcePathID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("DeletedResourcePathID", DeletedResourcePathID);

		if (successList.equals(BodyParamter)) {
			Reporter.log("Success List have all ResourcepathIDs mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted ResourcepathIDs:" + successList);
		} else {
			Reporter.log("Success List does not have all ResourcepathIDs mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_DeleteBatch_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_FullSuccess_Schema", "RP_DeleteBatch_FullSuccess");

	}

	/**
	 * Validating the DELETE response for Partial success 1) Response status 2)
	 * Schema validation 3) Required fields 4) Validate the Objects count from
	 * request and response are equal
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the ResourcePath delete batch response for Partial success")
	public void validateTheResourcePathDeleteBatchResponseForPartialSuccess() throws Exception, Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		getBundle().setProperty("DeletedResourcePathIDsAsJsonArray", successList);

		int sizeFromResponse = successList.size() + errorsList.size();

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		if (sizeFromResponse == BodyParamter.size()) {
			Reporter.log("Response is having ResourcePathIDs mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted ResourcePathIDs:" + successList);
			Reporter.log("Delete failed ResourcePathIDs:" + errorsList);
		} else {
			Reporter.log("Response is not having all ResourcePathIDs mentioned in Body Parameter!", MessageTypes.Fail);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_DeleteBatch_PartialSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_PartialSuccess_Schema",
				"RP_DeleteBatch_PartialSuccess");

	}

	/**
	 * Validating the specific DELETE response for full success 1) Response
	 * status 2) Schema validation 3) Required fields 4) Validate the DELETED ID
	 * is available in the response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the ResourcePath delete response for Full success")
	public void validateTheResourcePathDeleteResponseForFullSuccess() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String DeletedResourcePathID = gson.getAsJsonObject().get("id").toString().replace("\"", "");

		getBundle().setProperty("DeletedResourcePathID", DeletedResourcePathID);

		if (DeletedResourcePathID.equals(getBundle().getString("ResourcePathID"))) {
			Reporter.log("Deleted the ResourcePathID: " + DeletedResourcePathID, MessageTypes.Pass);
		} else {
			Reporter.log("ResourcePathID not deleted! ", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Specific_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_DeleteSpecific_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Delete_Specific_Schema", "RP_DeleteSpecific_FullSuccess");

	}

	/**
	 * 1) Validating the delete specific response for full success 1) Response
	 * status 2) Schema validation 3) Validate the DELETED id is available in
	 * the response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the serviceVersion delete specific resource response for Full success")
	public void validateTheServiceVersionDeleteSpecificResourceResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String DeletedServiceVersionID = gson.getAsJsonObject().get("id").toString().replace("\"", "");

		getBundle().setProperty("DeletedServiceVersionId", DeletedServiceVersionID);

		if (DeletedServiceVersionID.equals(getBundle().getString("ServiceVersionID"))) {
			Reporter.log("Deleted the ServiceVersion Id: " + DeletedServiceVersionID, MessageTypes.Pass);
		} else {
			Reporter.log("ServiceVersion Id is not deleted! ", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Specific_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_DeleteSpecific_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("Delete_Specific_Schema", "SV_DeleteSpecific_FullSuccess");
	}

	@QAFTestStep(description = "I Validate the response {0}_Error for invalid collectionId, invalid serviceDescriptonID, valid serviceVersionId")
	public void iValidateTheResponse_ErrorForInvalidCollectionIdInvalidServiceDescriptonIDValidServiceVersionId(
			int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidserviceVersionId");
		System.out.println(expErrorMsg);
		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the DELETED IDs are available in the
	 * response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the serviceVersion delete batch response for Full success")
	public void validateTheServiceVersionDeleteBatchResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		getBundle().setProperty("DeletedServiceVersionIdsAsJsonArray", successList);

		String DeletedServiceVersionID = successList.get(0).toString().replace("\"", "");
		getBundle().setProperty("DeletedServiceVersionID", DeletedServiceVersionID);

		if (successList.equals(BodyParamter)) {
			Reporter.log("Success List have all serviceVersion Id's mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted serviceDescription Id's:" + successList);
		} else {
			Reporter.log("Success List does not have all serviceVersion Id's mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_DeleteBatch_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_FullSuccess_Schema", "SV_DeleteBatch_FullSuccess");
	}

	/**
	 * Validating the DELETE response for full success 1) Response status 2)
	 * Schema validation 3) Validate the Object counts are equal from request
	 * and response
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the serviceVersion delete batch response for partial success")
	public void validateTheServiceVersionDeleteBatchResponseForPartialSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray successList = (JsonArray) gson.getAsJsonObject().get("success");
		JsonArray errorsList = (JsonArray) gson.getAsJsonObject().get("errors");

		getBundle().setProperty("DeletedServiceVersionIdsAsJsonArray", successList);

		int sizeFromResponse = successList.size() + errorsList.size();

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		if (sizeFromResponse == BodyParamter.size()) {
			Reporter.log("Response is having serviceVersion Id's mentioned in Body Parameter!", MessageTypes.Pass);
			Reporter.log("Deleted serviceVersion Id's:" + successList);
			Reporter.log("Delete failed serviceVersion Id's:" + errorsList);
		} else {
			Reporter.log("Response is not having all serviceVersion Id's mentioned in Body Parameter!",
					MessageTypes.Fail);
		}

		// ReusableUtils.verifyResponseStatusfor207();

		ReusableUtils.validateRequiredFieldsInResponse("Delete_Batch_Partial_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_DeleteBatch_PartialSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("DeleteBatch_PartialSuccess_Schema",
				"SV_DeleteBatch_PartialSuccess");
	}

	/**
	 * 1) Validating the deleted ServiceDesID is not available in ADMIN portal
	 * READ
	 * 
	 */
	@QAFTestStep(description = "I Verify deleted description Ids in Discovery Services Admin Portal READ")
	public void iVerifyDeletedDescriptionIdsInDiscoveryServicesAdminPortalREAD() {
		String CollectionID = getBundle().getString("CollectionID");

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ServiceDescriptionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String expServiceDescIds = expServiceDesc.getAsString().toString().replace("\"", "");

			Read_Discovery_GETcalls.iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(CollectionID,
					expServiceDescIds);

			ErrorMessage.validateErrorResponse(404);
			Reporter.log("Deleted Service Description Id's are not available in Admin Portal: " + expServiceDescIds,
					MessageTypes.Pass);

		}

	}

	/**
	 * 1) Validating the deleted ServiceDesIDs are not available in Client
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify deleted description Ids in Discovery Services Customer Portal READ")
	public void iVerifyDeletedDescriptionIdsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> expectedServiceDesc = new ArrayList<String>();
		ArrayList<String> actualServiceDesc = new ArrayList<String>();

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ServiceDescriptionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			expectedServiceDesc.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (JsonObject.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> singleServiceDescObj : singleServiceDesc.getAsJsonObject()
								.entrySet()) {

							if (singleServiceDescObj.getKey()
									.equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {
								String serviceDescId = singleServiceDesc.getAsJsonObject()
										.get(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID).toString()
										.replace("\"", "");
								actualServiceDesc.add(serviceDescId);
							}
						}
					}
				}
			}
		}

		if (actualServiceDesc.containsAll(expectedServiceDesc)) {
			Reporter.log("Deleted Service Description Id's are available in Customer Portal", MessageTypes.Fail);
		} else {
			Reporter.log(
					"Deleted Service Description Id's are not available in Customer Portal: " + expectedServiceDesc,
					MessageTypes.Pass);
		}
	}

	/**
	 * 1) Validating the deleted ServiceDesID not available in ADMIN portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify specific deleted description Id in Discovery Services Admin Portal READ")
	public void iVerifySpecificDeletedDescriptionIdInDiscoveryServicesAdminPortalREAD() {

		String expectedServiceDesc = getBundle().getString("ServiceDesID");
		String CollectionID = getBundle().getString("CollectionID");

		Read_Discovery_GETcalls.iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(CollectionID,
				expectedServiceDesc);

		ErrorMessage.validateErrorResponse(404);
		Reporter.log("Deleted Service Description Id's are not available in Admin Portal: " + expectedServiceDesc,
				MessageTypes.Pass);

	}

	/**
	 * 1) Validating the deleted ServiceDesID not available in Client portal
	 * READ
	 * 
	 */
	@QAFTestStep(description = "I Verify specific deleted description Id in Discovery Services Customer Portal READ")
	public void iVerifySpecificDeletedDescriptionIdInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		String expectedServiceDesc = getBundle().getString("ServiceDesID");
		ArrayList<String> actualServiceDesc = new ArrayList<String>();

		String CollectionID = getBundle().getString("CollectionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equalsIgnoreCase("id")) {

				if (JsonObject.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {
					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> singleServiceDescObj : singleServiceDesc.getAsJsonObject()
								.entrySet()) {

							if (singleServiceDescObj.getKey().equalsIgnoreCase("id")) {

								String serviceDescId = singleServiceDesc.getAsJsonObject().get("id").toString()
										.replace("\"", "");
								actualServiceDesc.add(serviceDescId);
							}
						}
					}
				}
			}
		}

		if (actualServiceDesc.contains(expectedServiceDesc)) {
			Reporter.log("Deleted Service Description Id is available in Customer Portal", MessageTypes.Fail);
		} else {
			Reporter.log("Deleted Service Description Id is not available in Customer Portal: " + expectedServiceDesc,
					MessageTypes.Pass);
		}
	}

	/**
	 * 1) Validating the deleted ServiceVersionIDs are not available in ADMIN
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the deleted Service Version fields in Discovery Services Admin Portal READ")
	public void iVerifyTheDeletedServiceVersionFieldsInDiscoveryServicesAdminPortalREAD() {

		JsonArray ExpServiceVerArr = (JsonArray) getBundle().getProperty("DeletedServiceVersionIdsAsJsonArray");

		for (JsonElement json : ExpServiceVerArr) {

			getBundle().setProperty("ServiceVersionID", json.toString());

			Read_Discovery_GETcalls.iReadSpecificResourceFieldsServiceVersionDiscoveryServices();

			ErrorMessage.validateErrorResponse(404);
			ErrorMessage.validErrorMessageOfJSONObjectMessage();
		}
	}

	/**
	 * 1) Validating the deleted ServiceVersionIDs are not available in Client
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the deleted Service Version fields in Discovery Services Customer Portal READ")
	public void iVerifyTheDeletedServiceVersionFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> deletedServiceVersions = new ArrayList<String>();
		ArrayList<String> availableServiceVersions = new ArrayList<String>();

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("DeletedServiceVersionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			deletedServiceVersions.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey()
									.equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {

								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVer : serviceVersionsArray) {

										String serviceVersionId = singleServiceVer.getAsJsonObject()
												.get(ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)
												.toString().replace("\"", "");
										availableServiceVersions.add(serviceVersionId);
									}
								}
							}
						}
					}
				}
			}
		}

		if (availableServiceVersions.containsAll(deletedServiceVersions)) {
			Reporter.log("Deeleted Service Version Id's are still available in Admin Portal: ", MessageTypes.Fail);
			Reporter.log("deletedServiceVersion Ids: " + deletedServiceVersions);
			Reporter.log("availableServiceVersion Ids: " + availableServiceVersions);
		} else {
			Reporter.log("Deleted Service Version Id's are not available in Admin Portal", MessageTypes.Pass);
			Reporter.log("deletedServiceVersion Ids: " + deletedServiceVersions);
			Reporter.log("availableServiceVersion Ids: " + availableServiceVersions);
		}
	}

	/**
	 * 1) Validating the deleted ResourcePathIDs are not available in ADMIN
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the deleted ResourcePath fields in Discovery Services Admin Portal READ")
	public void iVerifyTheDeletedResourcePathFieldsInDiscoveryServicesAdminPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonArray ExpResourcePathsArr = (JsonArray) getBundle().getProperty("DeletedResourcePathIDsAsJsonArray");

		for (JsonElement json : ExpResourcePathsArr) {

			getBundle().setProperty("ResourcePathID", json.toString());

			Read_Discovery_GETcalls.iREADResourcePathResourceForCollectionIDServiceDesServVersionResourcePath(
					CollectionID, ServiceDesID, ServiceVersionID, json.toString());

			ErrorMessage.validateErrorResponse(404);
			ErrorMessage.validErrorMessageOfJSONObjectMessage();
		}

	}

	/**
	 * 1) Validating the deleted ResourcePathIDs are not available in Client
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the deleted ResourcePath fields in Discovery Services Customer Portal READ")
	public void iVerifyTheDeletedResourcePathFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> deletedResourcePaths = new ArrayList<String>();
		ArrayList<String> availableResourcePaths = new ArrayList<String>();

		JsonArray ExpResourcePathArr = (JsonArray) getBundle().getProperty("DeletedResourcePathIDsAsJsonArray");
		for (JsonElement expServiceDesc : ExpResourcePathArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			deletedResourcePaths.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey()
									.equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {

								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVer : serviceVersionsArray) {

										for (Entry<String, JsonElement> ServiceVer : singleServiceVer.getAsJsonObject()
												.entrySet()) {

											if (ServiceVer.getKey().equalsIgnoreCase(
													ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)) {

												if (ServiceVer.getValue().toString().replace("\"", "")
														.equalsIgnoreCase(ServiceVersionID)) {

													JsonArray resourcePathsArray = (JsonArray) singleServiceVer
															.getAsJsonObject().get("resourcePaths");

													for (JsonElement singleResoucePath : resourcePathsArray) {

														String resourcePathId = singleResoucePath.getAsJsonObject()
																.get(ApiDiscovery_Client_Constants.RESOURCE_PATH_PROPERTY_ID)
																.toString().replace("\"", "");
														availableResourcePaths.add(resourcePathId);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (availableResourcePaths.containsAll(deletedResourcePaths)) {
			Reporter.log("Deeleted Resource Path Id's are still available in Admin Portal: ", MessageTypes.Fail);
			Reporter.log("deleted Resource Path Ids: " + deletedResourcePaths);
			Reporter.log("available Resource Path Ids: " + availableResourcePaths);
		} else {
			Reporter.log("Deleted  Resource Path Id's are not available in Admin Portal", MessageTypes.Pass);
			Reporter.log("deleted Resource Path Ids: " + deletedResourcePaths);
			Reporter.log("available Resource Path Ids: " + availableResourcePaths);
		}

	}

	/**
	 * 1) Validating the deleted ServiceVersionID is not available in ADMIN
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the specific deleted ServiceVersionId in Discovery Services Admin Portal READ")
	public void iVerifyTheSpecificDeletedServiceVersionIdInDiscoveryServicesAdminPortalREAD() {

		String ExpServiceVerArr = getBundle().getString("DeletedServiceVersionId");

		getBundle().setProperty("ServiceVersionID", ExpServiceVerArr);

		Read_Discovery_GETcalls.iReadSpecificResourceFieldsServiceVersionDiscoveryServices();

		ErrorMessage.validateErrorResponse(404);
		ErrorMessage.validErrorMessageOfJSONObjectMessage();
	}

	/**
	 * 1) Validating the deleted ServiceVersionID is not available in Client
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the specific deleted ServiceVersionId in Discovery Services Customer Portal READ")
	public void iVerifyTheSpecificDeletedServiceVersionIdInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> availableServiceVersions = new ArrayList<String>();

		String DeletedServiceVersionId = getBundle().getString("DeletedServiceVersionId");

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase("id")) {

				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase("id")) {
								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVer : serviceVersionsArray) {

										String serviceVersionId = singleServiceVer.getAsJsonObject().get("id")
												.toString().replace("\"", "");
										availableServiceVersions.add(serviceVersionId);
									}
								}
							}
						}
					}
				}
			}
		}

		if (availableServiceVersions.contains(DeletedServiceVersionId)) {
			Reporter.log("Deeleted Service Version Id is still available in Admin Portal: ", MessageTypes.Fail);
			Reporter.log("deletedServiceVersion Id: " + DeletedServiceVersionId);
			Reporter.log("availableServiceVersion Ids: " + availableServiceVersions);

		} else {
			Reporter.log("Deleted Service Version Id is not available in Admin Portal", MessageTypes.Pass);
			Reporter.log("deletedServiceVersion Id: " + DeletedServiceVersionId);
			Reporter.log("availableServiceVersion Ids: " + availableServiceVersions);

		}
	}

	/**
	 * Validating the Deleted ResourcePathIDs are not available in the Admin
	 * Portal Read
	 * 
	 */
	@QAFTestStep(description = "I Verify the specific deleted ResourcePathId in Discovery Services Admin Portal READ")
	public void iVerifyTheSpecificDeletedResourcePathIdInDiscoveryServicesAdminPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String ResourcePathID = getBundle().getString("DeletedResourcePathID");

		getBundle().setProperty("ResourcePathID", ResourcePathID);

		Read_Discovery_GETcalls.iREADResourcePathResourceForCollectionIDServiceDesServVersionResourcePath(CollectionID,
				ServiceDesID, ServiceVersionID, ResourcePathID);

		ErrorMessage.validateErrorResponse(404);
		ErrorMessage.validErrorMessageOfJSONObjectMessage();

	}

	/**
	 * Validating the Deleted ResourcePathIDs are not available in the Client
	 * Portal Read
	 * 
	 */
	@QAFTestStep(description = "I Verify the specific deleted ResourcePathId in Discovery Services Customer Portal READ")
	public void iVerifyTheSpecificDeletedResourcePathIdInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> AvailableResourcePathIds = new ArrayList<String>();

		String DeletedResourcePathID = getBundle().getString("DeletedResourcePathID");

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase("id")) {

				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase("id")) {

								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVersion : serviceVersionsArray) {

										for (Entry<String, JsonElement> JsonObject2 : singleServiceVersion
												.getAsJsonObject().entrySet()) {

											if (JsonObject2.getKey().equalsIgnoreCase("id")) {

												if (JsonObject2.getValue().toString().replace("\"", "")
														.equalsIgnoreCase(ServiceVersionID)) {

													JsonArray ResourcePathsArray = (JsonArray) singleServiceVersion
															.getAsJsonObject().get("resourcePaths");

													for (JsonElement singleResourcePath : ResourcePathsArray) {

														for (Entry<String, JsonElement> JsonObject3 : singleResourcePath
																.getAsJsonObject().entrySet()) {

															if (JsonObject3.getKey().equalsIgnoreCase("id")) {

																String ResourcePathId = JsonObject3.getValue()
																		.toString().replace("\"", "");
																AvailableResourcePathIds.add(ResourcePathId);
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (AvailableResourcePathIds.contains(DeletedResourcePathID)) {
			Reporter.log("Deleted ReourcePath Id is still available in Admin Portal: ", MessageTypes.Fail);
			Reporter.log("DeletedResourcePathId: " + DeletedResourcePathID);
			Reporter.log("AvailableResourcePathIds: " + AvailableResourcePathIds);

		} else {
			Reporter.log("Deleted ReourcePath Id is not available in Admin Portal", MessageTypes.Pass);
			Reporter.log("DeletedResourcePathId: " + DeletedResourcePathID);
			Reporter.log("AvailableResourcePathIds: " + AvailableResourcePathIds);

		}
	}

	/**
	 * 1) Validating the deleted CollectionIDs not available in Client portal
	 * READ
	 * 
	 */
	@QAFTestStep(description = "I validate deleted CollectionID not available in Customer Portal READ")
	public void iValidateDeletedCollectionIDNotAvailableInCustomerPortalREAD() {

		JsonArray collectionIDarr = (JsonArray) getBundle().getProperty("collectionIdsAsJsonArray");

		for (JsonElement expCollID : collectionIDarr) {
			String Ids = expCollID.getAsString().toString().replace("\"", "");
			getBundle().setProperty("CollectionID", Ids);

			Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

			ErrorMessage.validateErrorResponse(404);
			// ErrorMessage.validErrorMessageOfJSONObjectMessage();
		}
	}

	/**
	 * 1) Validating the deleted CollectionID not available in ADMIN portal READ
	 * 
	 */
	@QAFTestStep(description = "I validate deleted CollectionID not available in Admin Portal READ")
	public void iValidateDeletedCollectionIDNotAvailableInAdminPortalREAD() {

		String ExpCollectionId;

		JsonArray collectionIDarr = (JsonArray) getBundle().getProperty("collectionIdsAsJsonArray");
		for (JsonElement expCollID : collectionIDarr) {
			ExpCollectionId = expCollID.getAsString().toString().replace("\"", "");

			getBundle().setProperty("CollectionID", ExpCollectionId);
			Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();

			ErrorMessage.validateErrorResponse(404);
			// ErrorMessage.validErrorMessageOfJSONObjectMessage();
		}
	}

	/**
	 * Validate the error response 1) Status code 2) Message section is
	 * available in the response
	 * 
	 * @param errorCode
	 */
	@QAFTestStep(description = "I Validate the response for {0}_Error for Not Found with Id and Status")
	public void iValidateTheResponseFor_ErrorForNotFoundWithIdAndStatus(int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");

		ErrorMessage.validateErrorResponse(errorCode);
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}

	/**
	 * 1) Validating the deleted CollectionID not available in Client portal
	 * READ
	 * 
	 */
	@QAFTestStep(description = "I validate specific deleted CollectionID not available in Customer Portal READ")
	public void iValidateSpecificDeletedCollectionIDNotAvailableInCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ErrorMessage.validateErrorResponse(404);
		// ErrorMessage.validErrorMessageOfJSONObjectMessage();
	}
}
