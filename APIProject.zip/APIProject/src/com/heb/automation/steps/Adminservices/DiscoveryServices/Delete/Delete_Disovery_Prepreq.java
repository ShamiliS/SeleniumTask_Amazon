package com.heb.automation.steps.Adminservices.DiscoveryServices.Delete;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_BodyParameters;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_POSTcalls;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_validations;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_Preprep;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Delete_Disovery_Prepreq {
	
	/**
	 * Create Set of Collection ID's to Delete in APICollection 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I create set of api collections to be deleted")
	public void iCreateSetOfApiCollectionsToBeDeleted() throws Exception {

		Create_Discovery_BodyParameters
				.theApiCollectionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails();
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		Create_Discovery_POSTcalls.iPostCreateResourceForApiCollection();
		Create_Discovery_validations.validateTheApiCollectionCreateResponseForFullSuccess();
	}
	
	/**
	 * Sending request with Invalid collectionId and Valid ServiceDescriptionID
	 */

	@QAFTestStep(description = "the user is having Invalid collectionId and Valid ServiceDescriptionID")
	public void theUserIsHavingInvalidCollectionIdAndValidServiceDescriptionID() {

		String validApikey = ConfigurationManager.getBundle().getString("common.apikey");
		ML_CommonStepDef.iHaveAValidApikey(validApikey);
		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServices();

		String InvalidCollectionID = getBundle().getString("invalidCollectionID");
		String validServiceDescriptionID = getBundle().getString("ServiceDescriptionID");

		getBundle().setProperty("CollectionID", InvalidCollectionID);
		getBundle().setProperty("ServiceDescriptionID", validServiceDescriptionID);

		if (!InvalidCollectionID.isEmpty() && !validServiceDescriptionID.isEmpty()) {
			Reporter.log("InvalidCollectionID: " + InvalidCollectionID, MessageTypes.Pass);
			Reporter.log("ServiceDescriptionID: " + validServiceDescriptionID, MessageTypes.Pass);
		} else {
			Reporter.log(
					"Error occured while getting the Valid CollectionID and ServiceDescriptionID from the Read request.",
					MessageTypes.Fail);
		}

	}
	
	/**
	 * Sending request with valid collectionId and invalid ServiceDescriptionID
	 */

	@QAFTestStep(description = "the user is having valid collectionId and invalid ServiceDescriptionID")
	public void theUserIsHavingValidCollectionIdAndInvalidServiceDescriptionID() {

		String validApikey = ConfigurationManager.getBundle().getString("common.apikey");
		ML_CommonStepDef.iHaveAValidApikey(validApikey);
		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServices();

		String validCollectionID = getBundle().getString("CollectionID");
		String invalidServiceDescriptionID = getBundle().getString("invalidServiceDescriptionID");

		getBundle().setProperty("CollectionID", validCollectionID);
		getBundle().setProperty("ServiceDescriptionID", invalidServiceDescriptionID);

		if (!validCollectionID.isEmpty() && !invalidServiceDescriptionID.isEmpty()) {
			Reporter.log("validCollectionID: " + validCollectionID, MessageTypes.Pass);
			Reporter.log("invalidServiceDescriptionID: " + invalidServiceDescriptionID, MessageTypes.Pass);
		} else {
			Reporter.log(
					"Error occured while getting the Valid CollectionID and invalidServiceDescriptionID from the Read request.",
					MessageTypes.Fail);
		}

	}

	/**
	 * 1) Creating a set of resourcepathIds
	 * 2) And storing it as JSON array- ResourcePathIDsAsJsonArray
	 * 
	 * @throws Exception
	 * @throws Exception
	 */
	@QAFTestStep(description = "I create a set of resourcePathIDs")
	public static void iCreateASetOfResourcePathIDs() throws Exception, Exception {

		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();
		Create_Discovery_BodyParameters.theResourcePathCreateBatchRequestContainsBodyParamterWithValidArray();
		Create_Discovery_POSTcalls.iPostCreateResourceForResourcePath();
		Create_Discovery_validations.iValidateTheResourcePathResponseForFullSuccess();
	}
	
	/**
	 * 1) Creating a set of service Descriptions
	 * 
	 */
	@QAFTestStep(description = "I create a set of service Descriptions")
	public void iCreateASetOfServiceDescriptions() {

		Read_Discovery_Preprep.theUserIsHavingValidCollectionId();
		Read_Discovery_GETcalls.DiscoveryServices_Create("Create_ServiceDescriptionId");
	}

}
