package com.heb.automation.steps.Adminservices.DiscoveryServices.Discovery_ReusableUtils;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map.Entry;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Discovery_ReusableUtils {

	public static JsonObject apiCollection_add_Mandatory_fields() {

		String collectionId = getCollectionId();
		String name = getName();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("collectionId", collectionId);
		objTestBody.addProperty("name", name);
		return objTestBody;
	}

	public static JsonObject apiCollection_add_Mandatory_and_Optional_fields() {

		String collectionId = getCollectionId();
		String name = getName();
		String description = getDescription();
		String contactInfo = getContactInfo();
		
		JsonObject serDesc = new JsonObject();
		serDesc.addProperty("serviceDescriptionId", "Test123");
		serDesc.addProperty("name", "TestSham");
		
		JsonArray serDecvalues = new JsonArray();
		serDecvalues.add(serDesc);;
		
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("collectionId", collectionId);
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("contactInfo", contactInfo);
		objTestBody.add("serviceDescriptions", serDecvalues);
		return objTestBody;
	}

	public static JsonObject apiCollection_add_Mandatory_Optional_and_Outsidedef_fields() {

		String collectionId = getCollectionId();
		String name = getName();
		String description = getDescription();
		String contactInfo = getContactInfo();
		String outsidedef = getBundle().getString("apicollections.create.outsidedefvalue");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("collectionId", collectionId);
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("contactInfo", contactInfo);
		objTestBody.addProperty("outsidedef", outsidedef);
		return objTestBody;
	}

	public static String getCollectionId() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "CollectionId_" + appId.substring(3, appId.length());

	}

	public static String getName() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Name_" + appId.substring(3, appId.length());

	}

	public static String getDescription() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Desc_" + appId.substring(3, appId.length());

	}

	public static String getContactInfo() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return appId.substring(3, appId.length()) + "@mailnator.com";

	}

	public static String getPath() {

		String Path = "/catalog/category/product/{productId}";
		return Path;

	}

	public static JsonObject apiCollection_add_Optional_and_MissingMandatory() {

		String description = getDescription();
		String contactInfo = getContactInfo();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("contactInfo", contactInfo);

		return objTestBody;

	}

	public static boolean getCollectionId_ServiceDescriptionId(JsonArray jArray) {

		boolean isServiceDescriptionAvailable = false;

		for (JsonElement jElement : jArray) {

			String ServiceDescriptionId = null;
			String CollectionId = jElement.getAsJsonObject().get("collectionId").toString().replace("\"", "");
			int size = jElement.getAsJsonObject().get("serviceDescriptions").getAsJsonArray().size();

			if (size > 0) {
				/**
				 * Storing the AppID and their AppVersionIds
				 */
				for (JsonElement jElement1 : jElement.getAsJsonObject().get("serviceDescriptions").getAsJsonArray()) {
					ServiceDescriptionId = jElement1.getAsJsonObject().get("serviceDescriptionId").toString()
							.replace("\"", "");
					/**
					 * Validate Updated fields
					 */
					String name = jElement1.getAsJsonObject().get("name").toString().replace("\"", "");
					getBundle().setProperty("name", name);

					for (Entry<String, JsonElement> gsonlist : jElement1.getAsJsonObject().entrySet()) {

						if (gsonlist.getKey().equalsIgnoreCase("description")) {
							getBundle().setProperty("description", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("creationDate")) {
							getBundle().setProperty("creationDate", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("lastModifiedDate")) {
							getBundle().setProperty("lastModifiedDate", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("serviceVersions")) {
							getBundle().setProperty("serviceVersions", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("labels")) {
							getBundle().setProperty("labels", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("currentVersion")) {
							getBundle().setProperty("currentVersion", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("openApiSpecURL")) {
							getBundle().setProperty("openApiSpecURL", gsonlist.getValue().toString());
						}
						if (gsonlist.getKey().equalsIgnoreCase("documentation")) {
							getBundle().setProperty("documentation", gsonlist.getValue().toString());
						}
					}
					break;
				}

				System.out.println(CollectionId);
				System.out.println(ServiceDescriptionId);

				getBundle().setProperty("CollectionID", CollectionId);
				getBundle().setProperty("ServiceDescriptionID", ServiceDescriptionId);
				isServiceDescriptionAvailable = true;
				break;

			}
		}
		return isServiceDescriptionAvailable;
	}

	public static JsonObject serviceDescription_add_Mandatory_fields() {
		String name = getName();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);
		return objTestBody;
	}

	public static JsonObject serviceDescription_add_Mandatory_and_Optional_fields() {

		String name = getName();
		String description = getDescription();
		String labels = getLabels();
		String openApiSpecURL = getOpenApiSpecURL();
		String documentation = getDocumentation();
		String currentVersion = getCurrentVersion();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("labels", labels);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecURL);
		objTestBody.addProperty("documentationUrl", documentation);
		objTestBody.addProperty("currentVersion", currentVersion);

		getBundle().setProperty("name", name);
		getBundle().setProperty("description", description);
		getBundle().setProperty("labels", labels);
		getBundle().setProperty("openApiSpecUrl", openApiSpecURL);
		getBundle().setProperty("documentationUrl", documentation);
		getBundle().setProperty("currentVersion", currentVersion);

		return objTestBody;

	}

	public static JsonObject serviceDescription_add_Mandatory_Optional_and_Outsidedef_fields() {

		String name = getName();
		String description = getDescription();
		String labels = getLabels();
		String openApiSpecURL = getOpenApiSpecURL();
		String documentation = getDocumentation();
		String currentVersion = getCurrentVersion();
		String outsidedef = getBundle().getString("apicollections.create.outsidedefvalue");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("labels", labels);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecURL);
		objTestBody.addProperty("documentationUrl", documentation);
		objTestBody.addProperty("currentVersion", currentVersion);
		objTestBody.addProperty("outsidedef", outsidedef);

		return objTestBody;

	}

	public static String getLabels() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Label_" + appId.substring(3, appId.length());

	}

	public static String getOpenApiSpecURL() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "OpenApiSpecURL_" + appId.substring(3, appId.length());

	}

	public static String getDocumentation() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "Doc" + appId.substring(3, appId.length());

	}

	public static String getCurrentVersion() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");

		return "CV_" + appId.substring(7, appId.length());

	}

	public static JsonObject serviceDescription_add_Optional_and_Missing_Mandatoryfields() {

		String description = getDescription();
		String labels = getLabels();
		String openApiSpecURL = getOpenApiSpecURL();
		String documentation = getDocumentation();
		String currentVersion = getCurrentVersion();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("labels", labels);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecURL);
		objTestBody.addProperty("documentationUrl", documentation);
		objTestBody.addProperty("currentVersion", currentVersion);

		return objTestBody;

	}

	public static JsonObject serviceDescription_update_serviceDescriptionId(String serviceDescriptionId) {

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("serviceDescriptionId", serviceDescriptionId);

		return objTestBody;

	}

	public static JsonObject resourcePath_add_onlyMandatoryfields() {

		String name = getName();
		String path = getPath();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("path", path);
		return objTestBody;

	}

	public static JsonObject resourcePath_add_Mandatoryfields_optionalfields() {

		String name = getName();
		String path = getPath();
		String description = getDescription();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("path", path);
		objTestBody.addProperty("description", description);
		return objTestBody;

	}

	public static JsonObject resourcePath_add_with_missing_Mandatoryfield() {

		String name = getName();
		String description = getDescription();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("name", name);

		objTestBody.addProperty("description", description);
		return objTestBody;

	}

	public static JsonObject seviceversion_add_Mandatoryfields() {

		String versionNumber = getBundle().getString("serviceversion.versionNumber");
		String hostName = getBundle().getString("serviceversion.hostName");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("versionNumber", versionNumber);
		objTestBody.addProperty("hostName", hostName);
		return objTestBody;
	}

	public static JsonObject seviceversion_add_Mandatoryfields_optionalfields() {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String appId = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		
		String versionNumber = "vn_" + appId.substring(8, appId.length());
		String hostName = "hn_" + appId.substring(3, appId.length());
		String description = getDescription();
		String basePath = "Path_"+getBundle().getString("serviceversion.basePath");
		String openApiSpecUrl = "Url_"+getBundle().getString("serviceversion.openApiSpecUrl");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("versionNumber", versionNumber);
		objTestBody.addProperty("hostName", hostName);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("basePath", basePath);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecUrl);
		
		getBundle().setProperty("versionNumber", versionNumber);
		getBundle().setProperty("hostName", hostName);
		getBundle().setProperty("description", description);
		getBundle().setProperty("basePath", basePath);
		getBundle().setProperty("openApiSpecUrl", openApiSpecUrl);
		
		return objTestBody;
	}
	
	public static JsonObject seviceversion_add_ousidedef() {
		
		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("outsidedef", "Testing");
		
		return objTestBody;
	}

	public static JsonObject seviceversion_Missing_MandatoryfieldsVersionNumber() {

		String hostName = getBundle().getString("serviceversion.hostName");
		String description = getDescription();
		String basePath = getBundle().getString("serviceversion.basePath");
		String openApiSpecUrl = getBundle().getString("serviceversion.openApiSpecUrl");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("hostName", hostName);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("basePath", basePath);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecUrl);
		return objTestBody;
	}

	public static JsonObject seviceversion_Missing_MandatoryfieldsHostName() {

		String versionNumber = getBundle().getString("serviceversion.versionNumber");
		String description = getDescription();
		String basePath = getBundle().getString("serviceversion.basePath");
		String openApiSpecUrl = getBundle().getString("serviceversion.openApiSpecUrl");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("versionNumber", versionNumber);
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("basePath", basePath);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecUrl);
		return objTestBody;
	}

	public static JsonObject seviceversion_Missing_AllMandatoryfields() {

		String description = getDescription();
		String basePath = getBundle().getString("serviceversion.basePath");
		String openApiSpecUrl = getBundle().getString("serviceversion.openApiSpecUrl");

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("basePath", basePath);
		objTestBody.addProperty("openApiSpecUrl", openApiSpecUrl);
		return objTestBody;
	}

	public static JsonObject resourcepath_editablefields() {

		String description = getDescription();
		String path = getPath();
		String name = getName();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("path", path);
		objTestBody.addProperty("name", name);
		
		getBundle().setProperty("description", description);
		getBundle().setProperty("path", path);
		getBundle().setProperty("name", name);
		return objTestBody;
	}
	
	public static JsonObject resourcepath_editableandoptionalfields() {

		String description = getDescription();
		String path = getPath();
		String name = getName();
		String batchPath = getPath();

		JsonObject objTestBody = new JsonObject();
		objTestBody.addProperty("description", description);
		objTestBody.addProperty("path", path);
		objTestBody.addProperty("name", name);
		objTestBody.addProperty("batchPath", batchPath);
		return objTestBody;
	}	
	
	public static JsonObject resourcepath_onlyoptionalfields() {

		
		String batchPath = getPath();

		JsonObject objTestBody = new JsonObject();
		
		objTestBody.addProperty("batchPath", batchPath);
		return objTestBody;
	}	
}