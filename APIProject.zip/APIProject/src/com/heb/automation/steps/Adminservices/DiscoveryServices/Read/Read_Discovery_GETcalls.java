package com.heb.automation.steps.Adminservices.DiscoveryServices.Read;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_BodyParameters;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_POSTcalls;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Create.Create_Discovery_validations;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Delete.Delete_Disovery_Prepreq;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Read_Discovery_GETcalls {

	/**
	 * 1) READ specific resource for API collection discovery services 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ Resource fields for apiCollection Discovery services")
	public static void iREADResourceFieldsForApiCollectionDiscoveryServices() {

		String errorMsg = null;
		String CollectionID = getBundle().getString("CollectionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("READ is successfull", MessageTypes.Info);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Read..", MessageTypes.Info);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) READ batch resource for API collection discovery services 2) Storing
	 * the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ Batch Resources for apiCollection Discovery services")
	public static void iREADBatchResourcesForApiCollectionDiscoveryServices() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	/**
	 * 1) READ batch resource with Invalid apikey 2) Storing the error response
	 * in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I READ Batch Resources for apiCollection Discovery services for Invalid apikey")
	public void iREADBatchResourcesForApiCollectionDiscoveryServicesForInvalidApikey() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid apikey..", MessageTypes.Fail);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid apikey.", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I READ Batch Resources for apiCollection Discovery services using bad url")
	public void iREADBatchResourcesForApiCollectionDiscoveryServicesUsingBadUrl() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with bad url..", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to bad url.", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ batch resource for API collection with Invalid CollectionID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I READ Resources for apiCollection Discovery services with Invalid collectionId")
	public void iREADResourcesForApiCollectionDiscoveryServicesWithInvalidCollectionId() {

		String errorMsg = null;
		getBundle().setProperty("CollectionID", getBundle().getString("apicollections.read.invalidcollectionid"));

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.read");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid CollectionId..", MessageTypes.Fail);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid CollectionId.", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ Specific resource for API collection with Invalid CollectionID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I READ Resources for apiCollection Discovery services with Invalid apikey")
	public void iREADResourcesForApiCollectionDiscoveryServicesWithInvalidApikey() {
		String errorMsg = null;

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.read");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid CollectionId..", MessageTypes.Fail);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid CollectionId.", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I READ Resources for apiCollection Discovery services with bad url")
	public void iREADResourcesForApiCollectionDiscoveryServicesWithBadUrl() {

		String errorMsg = null;

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.read");
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Bad url..", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to bad url.", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ specific resource for ServiceDescription with valid data 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ service Description resource for CollectionID{0}and ServiceDescriptionID{1}")
	public static void iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(String CollectionID,
			String ServiceDesID) {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDesID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("READ is successfull", MessageTypes.Info);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I read Resource fields Service description Discovery services for invalid a bad URL")
	public void IReadResourceFieldsServiceDescriptionDiscoveryServicesForInvalidABadURL() {

		String baseurl = getBundle().getString("MLDiscoveryAPI.DiscoveryBadURl");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("servicedescription.read");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("READ is successfull with bad url.", MessageTypes.Fail);
			Reporter.log("baseurl: " + baseurl);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {

			Reporter.log("READ failed with bad url..", MessageTypes.Pass);
			Reporter.log("baseurl: " + baseurl);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 * 1) READ batch resource for Service Description with valid data 2) Storing
	 * the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I read Resource fields Service description Discovery services")
	public void IReadResourceFieldsServiceDescriptionDiscoveryServices() {

		String CollectionID = (String) getBundle().getProperty("CollectionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions";

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("READ is successfull", MessageTypes.Info);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {

			Reporter.log("Error occured during POST..", MessageTypes.Info);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	@QAFTestStep(description = "I READ/GET a valid collectionID")
	public void iREADGETAValidCollectionID() {
		// String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);
		ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			getavalidCollectionID((String) getBundle().getProperty("APIresponse"));

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);

		}
	}

	// Get a collectionID which has Service Description element in it
	public static void getavalidCollectionID(String RESPONSE) {
		JsonElement gson = new Gson().fromJson((String) getBundle().getProperty("APIresponse"), JsonElement.class);
		// JsonArray jArray = gson.getAsJsonArray();
		JsonArray collArray = gson.getAsJsonArray();

		Reporter.log(collArray.size() + " Collections found.", MessageTypes.Pass);

		for (JsonElement jElement : collArray) {

			// String collectionID = null;
			String collectionID = jElement.getAsJsonObject().get("collectionId").toString().replace("\"", "");
			int size = jElement.getAsJsonObject().get("serviceDescriptions").getAsJsonArray().size();

			if (size > 0) {

				System.out.println(collectionID);
				getBundle().setProperty("CollectionID", collectionID);
				break;
			}

		}
	}

	// Get teh Json Objects from Array

	public static void getavalidCollectionIDwithServDesandSerVersions(String RESPONSE) {
		boolean svAvailable = false, sdAvailable = false, collAvailable = false;
		String validCollId = null, validSerDescId = null;
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		// JsonArray jArray = gson.getAsJsonArray();
		JsonArray collArray = gson.getAsJsonArray();
		Reporter.log(collArray.size() + " Collections found.", MessageTypes.Pass);
		if (collArray.size() > 0) {
			collAvailable = true;
			for (JsonElement jObject : collArray) {

				System.out.println(jObject);

				String collectionID = jObject.getAsJsonObject().get("collectionId").toString().replace("\"", "");

				getBundle().setProperty("CollectionID", collectionID);

				int SDsize = jObject.getAsJsonObject().get("serviceDescriptions").getAsJsonArray().size();

				if (SDsize > 0) {
					sdAvailable = true;
					JsonArray SDArray = (JsonArray) jObject.getAsJsonObject().get("serviceDescriptions");
					System.out.println(collectionID);
					System.out.println(SDArray);

					for (JsonElement SDlist : SDArray.getAsJsonArray()) {

						String ServiceDesID = SDlist.getAsJsonObject().get("serviceDescriptionId").toString()
								.replace("\"", "");

						validCollId = collectionID;
						validSerDescId = ServiceDesID;
						getBundle().setProperty("CollectionID", collectionID);
						getBundle().setProperty("ServiceDesID", ServiceDesID);

						JsonArray SVArray = (JsonArray) SDlist.getAsJsonObject().get("serviceVersions");
						int SVsize = SDlist.getAsJsonObject().get("serviceVersions").getAsJsonArray().size();
						if (SVsize > 0) {
							svAvailable = true;

							System.out.println(ServiceDesID);
							System.out.println(SVArray);
							JsonArray serviceVersionIDs = new JsonArray();

							for (JsonElement SVlist : SVArray.getAsJsonArray()) {

								String ServiceVersionID = SVlist.getAsJsonObject().get("serviceVersionId").toString()
										.replace("\"", "");
								getBundle().setProperty("CollectionID", collectionID);
								getBundle().setProperty("ServiceDesID", ServiceDesID);
								getBundle().setProperty("ServiceVersionID", ServiceVersionID);
								serviceVersionIDs.add(SVlist.getAsJsonObject().get("serviceVersionId"));

								JsonArray ResourcePathArray = (JsonArray) SVlist.getAsJsonObject().get("resourcePaths");
								int resPathsize = SVlist.getAsJsonObject().get("resourcePaths").getAsJsonArray().size();

								if (resPathsize > 0) {
									getBundle().setProperty("ServiceVersionID", ServiceVersionID);
								}
							}
							getBundle().setProperty("ServiceVersionIDsArray", serviceVersionIDs);
							break;

						}

					}
					if (svAvailable) {
						break;
					}

				}

			}

		}

		if (!collAvailable && !sdAvailable && !svAvailable) {
			// Create coll Id, Service desc Id, Service Version Id
			DiscoveryServices_Create("Create_CollectionId");
			DiscoveryServices_Create("Create_ServiceDescriptionId");
			DiscoveryServices_Create("Create_ServiceVersionId");

		} else if (!sdAvailable && !svAvailable) {
			// Create Service desc Id, Service Version Id
			String collectionID = getBundle().getString("collectionID");
			getBundle().setProperty("CollectionID", collectionID);
			DiscoveryServices_Create("Create_ServiceDescriptionId");
			DiscoveryServices_Create("Create_ServiceVersionId");

		} else if (!svAvailable) {
			// Create Service Version Id
			String collectionID = validCollId;
			String ServiceDesID = validSerDescId;
			getBundle().setProperty("CollectionID", collectionID);
			getBundle().setProperty("ServiceDesID", ServiceDesID);
			DiscoveryServices_Create("Create_ServiceVersionId");
		}

	}

	private static void getavalidCollectionIDwithServDesSerVersionsandresourcePath(String rESPONSE) throws Exception {

		boolean isResourcePathIdAvailable = false;

		JsonElement gson = new Gson().fromJson(rESPONSE, JsonElement.class);
		JsonArray collArray = gson.getAsJsonArray();
		Reporter.log(collArray.size() + " Collections found.", MessageTypes.Pass);

		for (JsonElement jObject : collArray) {

			String collectionID = jObject.getAsJsonObject().get("collectionId").toString().replace("\"", "");
			int SDsize = jObject.getAsJsonObject().get("serviceDescriptions").getAsJsonArray().size();

			getBundle().setProperty("CollectionID", collectionID);

			if (SDsize > 0) {

				JsonArray SDArray = (JsonArray) jObject.getAsJsonObject().get("serviceDescriptions");

				for (JsonElement SDlist : SDArray.getAsJsonArray()) {

					String ServiceDesID = SDlist.getAsJsonObject().get("serviceDescriptionId").toString().replace("\"",
							"");
					JsonArray SVArray = (JsonArray) SDlist.getAsJsonObject().get("serviceVersions");
					int SVsize = SDlist.getAsJsonObject().get("serviceVersions").getAsJsonArray().size();

					getBundle().setProperty("CollectionID", collectionID);
					getBundle().setProperty("ServiceDesID", ServiceDesID);

					if (SVsize > 0) {

						for (JsonElement SVlist : SVArray.getAsJsonArray()) {

							String ServiceVersionID = SVlist.getAsJsonObject().get("serviceVersionId").toString()
									.replace("\"", "");
							JsonArray ResourcePathArray = (JsonArray) SVlist.getAsJsonObject().get("resourcePaths");
							int resPathsize = SVlist.getAsJsonObject().get("resourcePaths").getAsJsonArray().size();

							getBundle().setProperty("CollectionID", collectionID);
							getBundle().setProperty("ServiceDesID", ServiceDesID);
							getBundle().setProperty("ServiceVersionID", ServiceVersionID);

							if (resPathsize > 0) {

								for (JsonElement ResPathlist : ResourcePathArray.getAsJsonArray()) {

									String resourcePathId = ResPathlist.getAsJsonObject().get("resourcePathId")
											.toString().replace("\"", "");

									getBundle().setProperty("CollectionID", collectionID);
									getBundle().setProperty("ServiceDesID", ServiceDesID);
									getBundle().setProperty("ServiceVersionID", ServiceVersionID);
									getBundle().setProperty("ResourcePathID", resourcePathId);

									break;
								}

								isResourcePathIdAvailable = true;
							}
							if (isResourcePathIdAvailable) {
								break;
							}
						}

					}
					if (isResourcePathIdAvailable) {
						break;
					}
				}
			}
			if (isResourcePathIdAvailable) {
				break;
			}
		}

		if (!isResourcePathIdAvailable) {
			Reporter.log("No Records found with resourcepathIds. Creating ResourcePathIDs... ", MessageTypes.Info);

			Delete_Disovery_Prepreq.iCreateASetOfResourcePathIDs();

		}
	}

	/**
	 * Reads API collection resource and sets the value for the below parameters
	 * 1) CollectionID 2) ServiceDesID 3) ServiceVersionID
	 */
	@QAFTestStep(description = "I READ a valid CollectionID ServiceDesc ServiceVersion")
	public static void iREADAValidCollectionIDServiceDescServiceVersion() {
		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		getBundle().setProperty("headers", headers);

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			getavalidCollectionIDwithServDesandSerVersions(RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Read API batch read resource 2) Set valid values for 'CollectionID',
	 * 'ServiceDesID', 'ServiceVersionID' and 'ResourcePathID'
	 */
	@QAFTestStep(description = "I READ a valid CollectionID ServiceDesc ServiceVersion resourcePathID")
	public static void iREADAValidCollectionIDServiceDescServiceVersionResourcePathID() {
		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		getBundle().setProperty("headers", headers);

		String RESPONSE = null;

		try {

			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			getavalidCollectionIDwithServDesSerVersionsandresourcePath(RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "I READ Batch Resources for ResourcePath Discovery services")
	public void iREADBatchResourcesForResourcePathDiscoveryServices() {
		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);

		} catch (Exception e) {
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
		}

	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "I READ ResourcePath resource for valid CollectionID {0} ServiceDes {1} ServVersion {2}")
	public void iREADResourcePathResourceForValidCollectionIDServiceDesServVersion(String collectionID,
			String ServDescID, String ServVersID) {
		collectionID = (String) getBundle().getProperty("collectionID");
		ServDescID = (String) getBundle().getProperty("ServiceDesID");
		ServVersID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch") + "/" + collectionID + "/serviceDescriptions/"
				+ ServDescID + "/serviceVersions/" + ServVersID + "/resourcePaths";

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		getBundle().setProperty("env.baseurl", baseurl);

		String RESPONSE = null;
		String errorMsg = null;
		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);

		} catch (Exception e) {
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			Reporter.log(errorMsg);
		}
	}


	/**
	 * 1) READ batch resource for ResourcePath with valid set of data
	 * 2) Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ ResourcePath resource for CollectionID {0} ServiceDes {1} ServVersion {2}")
	public void iREADResourcePathResourceForCollectionIDServiceDesServVersion(String collectionID, String ServDescID,
			String ServVersID) {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);
		
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + collectionID + "/serviceDescriptions/"
				+ ServDescID + "/serviceVersions/" + ServVersID + "/resourcePaths";
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;
		String errorMsg = null;
		
		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);

		} catch (Exception e) {
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();

			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ specific resource for ResourcePath with valid set of data
	 * 2) Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I READ ResourcePath resource for CollectionID {0} ServiceDes {1} ServVersion {2} resourcePath {3}")
	public static void iREADResourcePathResourceForCollectionIDServiceDesServVersionResourcePath(String collectionID,
			String ServDescID, String ServVersID, String resourcePathID) {

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);
		
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch") + "/" + collectionID + "/serviceDescriptions/"
				+ ServDescID + "/serviceVersions/" + ServVersID + "/resourcePaths/" + resourcePathID;
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");
		
		String RESPONSE = null;
		String errorMsg = null;
		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			
		} catch (Exception e) {
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();

			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ batch resource for Service Version discovery services 2) Storing
	 * the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I read Resource fields Service Version Discovery services")
	public static void iReadResourceFieldsServiceVersionDiscoveryServices() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Info);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ specific resource for Service Version discovery services
	 * 2) Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I read specific Resource fields Service Version Discovery services")
	public static void iReadSpecificResourceFieldsServiceVersionDiscoveryServices() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		getBundle().setProperty("env.baseurl", baseurl);
		
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Pass);
			Reporter.log("resource: " + resource);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	public static void DiscoveryServices_Create(String resource) {

		switch (resource) {

		case "Create_CollectionId":
			Create_Discovery_BodyParameters
					.theApiCollectionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails();
			Create_Discovery_POSTcalls.iPostCreateResourceForApiCollection();
			Create_Discovery_validations.getCollectionIdFromResponse();
			break;

		case "Create_ServiceDescriptionId":
			Create_Discovery_BodyParameters
					.theServiceDescriptionCreateBatchRequestBodyParameterShouldContainValidArrayOfPropertyDetails();
			Create_Discovery_POSTcalls.iPostCreateResourceForServiceDescription();
			Create_Discovery_validations.getServiceDescriptionFromResponse();
			break;

		case "Create_ServiceVersionId":
			Create_Discovery_BodyParameters.theServiceversionCreateBatchRequestContainsBodyParamterWithValidArray();
			Create_Discovery_POSTcalls.iPostCreateResourceForServiceVersion();
			Create_Discovery_validations.getServiceVersionFromResponse();
			break;

		default:
			break;
		}

	}

	public static void getavalidCollectionIDwithServDes(String RESPONSE) {

		boolean sdAvailable = false, collAvailable = false;
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray collArray = gson.getAsJsonArray();
		Reporter.log(collArray.size() + " Collections found.", MessageTypes.Pass);
		if (collArray.size() > 0) {
			collAvailable = true;
			for (JsonElement jObject : collArray) {

				System.out.println(jObject);

				String collectionID = jObject.getAsJsonObject().get("collectionId").toString().replace("\"", "");

				getBundle().setProperty("CollectionID", collectionID);

				int SDsize = jObject.getAsJsonObject().get("serviceDescriptions").getAsJsonArray().size();

				if (SDsize > 0) {
					sdAvailable = true;
					JsonArray SDArray = (JsonArray) jObject.getAsJsonObject().get("serviceDescriptions");
					JsonArray serviceDescriptionIDs = new JsonArray();
					System.out.println(collectionID);
					System.out.println(SDArray);

					for (JsonElement SDlist : SDArray.getAsJsonArray()) {

						String ServiceDesID = SDlist.getAsJsonObject().get("serviceDescriptionId").toString()
								.replace("\"", "");
						getBundle().setProperty("CollectionID", collectionID);
						serviceDescriptionIDs.add(SDlist.getAsJsonObject().get("serviceDescriptionId"));
						getBundle().setProperty("ServiceDesID", ServiceDesID);
						break;
					}
					getBundle().setProperty("ServiceDescriptionIdsAsJsonArray", serviceDescriptionIDs);
				}
				if (sdAvailable) {
					break;
				}
			}
		}

		System.out.println(getBundle().getString("CollectionID"));
		System.out.println(getBundle().getString("ServiceDesID"));

		if (!collAvailable && !sdAvailable) {
			// Create coll Id, Service desc Id,
			DiscoveryServices_Create("Create_CollectionId");
			DiscoveryServices_Create("Create_ServiceDescriptionId");

		} else if (!sdAvailable) {
			// Create Service desc Id
			DiscoveryServices_Create("Create_ServiceDescriptionId");
		}
	}

	/**
	 * 1) READ batch resource for Service Version with Invalid CollectionID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I read Resource fields Service Version Discovery services with Invalid collectionId")
	public void iReadResourceFieldsServiceVersionDiscoveryServicesWithInvalidCollectionId() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions";

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid collectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);

		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}


	/**
	 * 1) READ specific resource for Service Version with Invalid CollectionID
	 * 2) Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I read specific Resource fields Service Version Discovery services with Invalid collectionId")
	public void iReadSpecificResourceFieldsServiceVersionDiscoveryServicesWithInvalidCollectionId() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid collectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);
			
		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ specific resource for Service Version with Invalid ServiceDescId
	 * 2) Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I read specific Resource fields Service Version Discovery services with Invalid ServiceDescId")
	public void iReadSpecificResourceFieldsServiceVersionDiscoveryServicesWithInvalidServiceDescId() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull with Invalid serviceDescriptionId.", MessageTypes.Fail);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			
		} catch (Exception e) {
			Reporter.log("Batch Read failed due to Invalid Service Description ID.", MessageTypes.Info);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);

		}
	}

	public static void iREADBatchResourcesForApiCollectionDiscoveryServicesCreateIfNotAvailable() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.readbatch");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

		/**
		 * Extracting the JSON response
		 */
		try {
			JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
			JsonArray collArray = gson.getAsJsonArray();
			Reporter.log(collArray.size() + " Collections found.", MessageTypes.Pass);
			if (collArray.size() > 0) {
				JsonElement jObject = collArray.get(0);
				String collectionID = jObject.getAsJsonObject().get("collectionId").toString().replace("\"", "");
				getBundle().setProperty("CollectionID", collectionID);
			} else {
				Reporter.log("No Elements found.. adding collections..", MessageTypes.Pass);
				DiscoveryServices_Create("Create_CollectionId");
			}
		} catch (JsonSyntaxException e) {
			Reporter.log("Error occured while extracting the JSON response.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I READ Batch Resources for apiCollection Discovery services from customer portal")
	public static void iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal(String CollectionID) {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLDiscoveryAPI.DiscoveryURL");
		String resource = getBundle().getString("MLDiscoveryAPI.serviceName")
				+ getBundle().getString("MLDiscoveryAPI.resource") + "/" + CollectionID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Info);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I READ Batch Resources for apiCollection Discovery services from customer portal")
	public static void iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal() {

		String errorMsg = null;
		String CollectionID = getBundle().getString("CollectionID");
		String baseurl = getBundle().getString("MLDiscoveryAPI.DiscoveryURL");
		String resource = getBundle().getString("MLDiscoveryAPI.serviceName")
				+ getBundle().getString("MLDiscoveryAPI.resource") + "/" + CollectionID;
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Info);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I READ Specific Resource for Service Version Discovery services from customer portal")
	public static void iREADResourceForServiceVersionDiscoveryServicesFromCustomerPortal() {

		String errorMsg = null;
		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLDiscoveryAPI.DiscoveryURL");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("MLDiscoveryAPI.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

}