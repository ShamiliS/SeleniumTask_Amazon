package com.heb.automation.steps.Adminservices.DiscoveryServices.Read;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Update.Update_Disovery_Prepreq;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Read_Discovery_Preprep {

	/**
	 * 1) Read apiCollection batch read resource 2) Storing the valid
	 * collectionId in 'CollectionID' parameter
	 * 
	 */
	@QAFTestStep(description = "the user is having valid collectionId")
	public static void theUserIsHavingValidCollectionId() {

		String validCollectionID;
		String validApikey = getBundle().getString("common.apikey");
		ML_CommonStepDef.iHaveAValidApikey(validApikey);
		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesCreateIfNotAvailable();

		validCollectionID = getBundle().getString("CollectionID");

		if (!validCollectionID.isEmpty()) {
			Reporter.log("CollectionID:" + validCollectionID, MessageTypes.Pass);
		} else {
			Reporter.log("Error occured while getting the Valid CollectionIDfrom the Read request.", MessageTypes.Fail);
		}
	}

	/**
	 * Defining the 'CollectionID' with Invalid value
	 * 
	 * @param str1
	 */
	@QAFTestStep(description = "the user is having invalid collectionId{0}")
	public void theUserIsHavingInvalidCollectionId(String str1) {
		getBundle().setProperty("CollectionID", str1);
	}

	/**
	 * Defining Invalid values for 'CollectionID', 'ServiceDesID' and
	 * 'ServiceVersionID'
	 * 
	 */
	@QAFTestStep(description = "I READ a in-valid CollectionID ,in-validServiceDesc, in-valid ServiceVersion")
	public void iREADAInValidCollectionIDInValidServiceDescInValidServiceVersion() {

		Read_Discovery_GETcalls.iREADAValidCollectionIDServiceDescServiceVersion();

		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("invalidServiceDescriptionID"));
		getBundle().setProperty("ServiceVersionID", getBundle().getString("invalidServiceVersionID"));
	}

	/**
	 * 1) Set invalid value for 'CollectionID' 2) valid value for 'ServiceDesID'
	 * 
	 */
	@QAFTestStep(description = "User have an in-valid CollectionID and valid ServiceDescID")
	public void userHaveAnInValidCollectionIDAndValidServiceDescID() {

		Update_Disovery_Prepreq.iREADAValidCollectionIDServiceDescID();
		getBundle().setProperty("CollectionID", getBundle().getString("invalidCollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("ServiceDesID"));
	}

	/**
	 * 1) Set valid value for 'CollectionID' 2) Invalid value for 'ServiceDesID'
	 * 
	 */
	@QAFTestStep(description = "User have a valid CollectionID and in-valid ServiceDescID")
	public void userHaveAValidCollectionIDAndInValidServiceDescID() {

		Update_Disovery_Prepreq.iREADAValidCollectionIDServiceDescID();
		getBundle().setProperty("CollectionID", getBundle().getString("CollectionID"));
		getBundle().setProperty("ServiceDesID", getBundle().getString("invalidServiceDescriptionID"));
	}

}
