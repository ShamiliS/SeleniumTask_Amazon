package com.heb.automation.steps.Adminservices.DiscoveryServices.Read;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.snakeyaml.Yaml;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.common.endpoints.constants.ApiDiscovery_Client_Constants;
import com.heb.automation.common.yaml.ReadApiDiscoveryFields;
import com.heb.automation.common.yaml.resourcePathFields;
import com.heb.automation.common.yaml.serviceDescriptionsFields;
import com.heb.automation.common.yaml.serviceVersionFields;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

public class Read_Discovery_Validations {

	/**
	 * Validating the Specific READ response for full success 1) Response status
	 * 2) Schema validation 3) Required fields
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of apiCollection Discovery services Read")
	public static void validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesRead() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("apiCollection_Read_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ApiCollections_Read");
		ReusableUtils.validateJSONschema_ApiDiscovery("ApiCollections_Read_Schema", "ApiCollections_Read");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String creationDate = gson.getAsJsonObject().get("creationDate").toString().replace("\"", "");
		String lastModifiedDate = gson.getAsJsonObject().get("lastModifiedDate").toString().replace("\"", "");
		String serviceDescriptions = gson.getAsJsonObject().get("serviceDescriptions").toString().replace("\"", "");

		getBundle().setProperty("name", name);
		getBundle().setProperty("creationDate", creationDate);
		getBundle().setProperty("lastModifiedDate", lastModifiedDate);
		getBundle().setProperty("serviceDescriptions", serviceDescriptions);

	}

	/**
	 * Validating the READ batch response for full success 1) Response status 2)
	 * Schema validation 3) Required fields
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the apicollection batch read response for full success")
	public void iValidateTheApicollectionBatchReadResponseForFullSuccess() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(ConfigurationManager.getBundle().getString("APIresponse"),
				JsonElement.class);
		JsonArray gson1 = gson.getAsJsonArray();

		long size = gson1.size();

		if (RESPONSE.equalsIgnoreCase("[]")) {
			Reporter.log("No Collections available to Read.", MessageTypes.Pass);
			Reporter.log(RESPONSE);
		} else {
			if (size > 0) {
				Reporter.log("Successfully read the properties, Number of properties available: " + size,
						MessageTypes.Pass);
			} else {
				Reporter.log("Not successfully Read the properties", MessageTypes.Fail);

			}
		}

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("apiCollection_BatchRead_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ApiCollections_ReadBatch");
		ReusableUtils.validateJSONschema_ApiDiscovery("ApiCollections_ReadBatch_Schema", "ApiCollections_ReadBatch");

	}

	@QAFTestStep(description = "I Validate the response {0}_Error for in-valid CollectionId")
	public void iValidateTheResponse_ErrorForInValidCollectionId(int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidCollId");

		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validating the READ specific response for full success 1) Response status
	 * 2) Schema validation 3) Required fields
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I Validate the response for Full success of Service Description specific READ")
	public static void iValidateTheResponseForFullSuccessOfServiceDescriptionSpecificREAD() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("serviceDescription_ReadSpecific_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "App_DS_ServiceDescription_Read");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceDescription_Read_Schema",
				"App_DS_ServiceDescription_Read");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String serviceDescriptionId = gson.getAsJsonObject().get("serviceDescriptionId").toString().replace("\"", "");
		String creationDate = gson.getAsJsonObject().get("creationDate").toString().replace("\"", "");
		String lastModifiedDate = gson.getAsJsonObject().get("lastModifiedDate").toString().replace("\"", "");
		String serviceVersions = gson.getAsJsonObject().get("serviceVersions").toString().replace("\"", "");

		getBundle().setProperty("name", name);
		getBundle().setProperty("creationDate", creationDate);
		getBundle().setProperty("lastModifiedDate", lastModifiedDate);
		getBundle().setProperty("serviceVersions", serviceVersions);

	}

	@QAFTestStep(description = "I Validate the response {404}_Error for Updating in-valid Collection ID")
	public void iValidateTheResponse_ErrorForUpdatingInValidCollectionID(int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.updateInvalidAppId");
		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validating the READ batch response for full success 1) Response status 2)
	 * Schema validation 3) Required fields
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of Service description Discovery services Read")
	public void ValidateTheResponseForFullSuccessOfServiceDescriptionDiscoveryServicesRead() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("serviceDescription_Read_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ServiceDescription_ReadBatch");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceDescription_ReadBatch_Schema",
				"ServiceDescription_ReadBatch");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		JsonArray jarray = gson.getAsJsonArray();

		int ArraySize = jarray.size();

		if (ArraySize > 0) {
			Reporter.log(ArraySize + "ServiceDescription Elements found.", MessageTypes.Pass);
		} else {
			Reporter.log("ServiceDescription Elements not found.", MessageTypes.Fail);
		}
	}

	/**
	 * Validating the READ batch response for full success 1) Response status 2)
	 * Schema validation 3) Required fields
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of Service Version Discovery services Read")
	public void validateTheResponseForFullSuccessOfServiceVersionDiscoveryServicesRead() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_Read_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_ReadBatch_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceVersion_ReadBatch_Schema", "SV_ReadBatch_FullSuccess");

	}

	@QAFTestStep(description = "I validate the Service Version Specific Read response for Full success")
	public void IValidateTheResponseForFullSuccessOfServiceVersionDiscoveryServicesSpecificRead() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		// Validate Required fields in Response
		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_ReadSpecific_Success", RESPONSE);

		// Validate Updated fields
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");
		String versionNumber = gson.getAsJsonObject().get("versionNumber").toString().replace("\"", "");
		String hostName = gson.getAsJsonObject().get("hostName").toString().replace("\"", "");

		getBundle().setProperty("hostName", hostName);
		getBundle().setProperty("versionNumber", versionNumber);
		getBundle().setProperty("ServiceVersionID", serviceVersionId);

		/*
		 * // JSON validation
		 * ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE,
		 * "SV_Update_FullSuccess");
		 * ReusableUtils.validateJSONschema_ApiDiscovery(
		 * "ServiceVersion_Read_Schema", "SV_Update_FullSuccess");
		 */
		// Validate Response code
		ReusableUtils.responseStatusforOK();

	}

	/**
	 * Validating the READ batch response for full success 1) Response status 2)
	 * Schema validation 3) Required fields
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the ResourcePath batch read response for full success")
	public void iValidateTheResourcePathBatchReadResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Resourcepath_BatchRead_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_ReadBatch_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ResourcePath_ReadBatch_Schema", "RP_ReadBatch_FullSuccess");

	}

	/**
	 * Validating the READ specific response for full success 1) Response status
	 * 2) Schema validation 3) Required fields
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the ResourcePath specific read response for full success")
	public void iValidateTheResourcePathSpecificReadResponseForFullSuccess() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("Resourcepath_Read_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "RP_ReadSpecific_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ResourcePath_Read_Schema", "RP_ReadSpecific_FullSuccess");

	}

	@QAFTestStep(description = "I Validate the response {0}_Error for valid collectionId, serviceVersionId and in-valid serviceDescriptonID")
	public void iValidateTheResponse_ErrorForValidCollectionIdServiceVersionIdAndInValidServiceDescriptonID(
			int errorCode) {
		String actErrorMsg = getBundle().getString("errorMsg");
		String expErrorMsg = getBundle().getString("errorMsg.invalidServiceDescriptionID");
		System.out.println(expErrorMsg);
		ErrorMessage.validateErrorResponse(errorCode);

	}

	/**
	 * Validating the READ specific response for full success 1) Response status
	 * 2) Schema validation 3) Required fields
	 * 
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of Service Version Discovery services Specific Read")
	public void validateTheResponseForFullSuccessOfServiceVersionDiscoveryServicesSpecificRead() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_ReadSpecific_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_ReadSpecific_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceVersion_Read_Schema", "SV_ReadSpecific_FullSuccess");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");
		String versionNumber = gson.getAsJsonObject().get("versionNumber").toString().replace("\"", "");
		String hostName = gson.getAsJsonObject().get("hostName").toString().replace("\"", "");

		getBundle().setProperty("hostName", hostName);
		getBundle().setProperty("versionNumber", versionNumber);
		getBundle().setProperty("ServiceVersionID", serviceVersionId);

	}

	/**
	 * Validate the created Service Description IDs in ADMIN portal read.
	 * 
	 */
	@QAFTestStep(description = "I Verify created description Ids in Discovery Services Admin Portal READ")
	public void iVerifyCreatedDescriptionIdsInDiscoveryServicesAdminPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ServiceDescriptionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String expServiceDescIds = expServiceDesc.getAsString().toString().replace("\"", "");

			Read_Discovery_GETcalls.iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(CollectionID,
					expServiceDescIds);

			JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

			for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {
				System.out.println(JsonObject.getKey());
				if (JsonObject.getKey().equalsIgnoreCase("serviceDescriptionId")) {
					if (JsonObject.getValue().toString().replace("\"", "").equalsIgnoreCase(expServiceDescIds)) {
						Reporter.log(
								"Created Service Description Id is available in Admin Portal: " + expServiceDescIds,
								MessageTypes.Pass);
					} else {
						Reporter.log(
								"Created Service Description Id is not available in Admin Portal: " + expServiceDescIds,
								MessageTypes.Fail);
					}
				}
			}
		}
	}

	/**
	 * Validate the created Service Description IDs in Client portal read.
	 * 
	 */
	@QAFTestStep(description = "I Verify created description Ids in Discovery Services Customer Portal READ")
	public void iVerifyCreatedDescriptionIdsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> expectedServiceDesc = new ArrayList<String>();
		ArrayList<String> actualServiceDesc = new ArrayList<String>();

		JsonArray ExpServiceDescArr = (JsonArray) getBundle().getProperty("ServiceDescriptionIdsAsJsonArray");
		for (JsonElement expServiceDesc : ExpServiceDescArr) {
			String Ids = expServiceDesc.getAsString().toString().replace("\"", "");
			expectedServiceDesc.add(Ids);
		}

		String CollectionID = getBundle().getString("CollectionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {
				if (JsonObject.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {
					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
					for (JsonElement singleServiceDesc : serviceDescArray) {
						String serviceDescId = singleServiceDesc.getAsJsonObject()
								.get(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID).toString()
								.replace("\"", "");
						actualServiceDesc.add(serviceDescId);
					}
				}
			}
		}

		if (actualServiceDesc.containsAll(expectedServiceDesc)) {
			Reporter.log("Created Service Description Id's are available in Customer Portal: " + expectedServiceDesc,
					MessageTypes.Pass);
		} else {
			Reporter.log("Created Service Description Id's are not available in Customer Portal", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I get values from response using YAML approach")
	public void iGetValuesFromResponseUsingYAMLApproach() throws JsonParseException, JsonMappingException, IOException {

		String RESPONSE = getBundle().getString("APIresponse");
		String collectionId = null, serviceDescriptionId = null, serviceVersionId = null, resourcePathId = null;

		Yaml yaml = new Yaml();
		ArrayList<Object> arrayListResponse = (ArrayList<Object>) yaml.load(RESPONSE);

		for (Object key : arrayListResponse) {
			ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			ReadApiDiscoveryFields ReadFields = mapper.readValue(yaml.dump(key), ReadApiDiscoveryFields.class);
			collectionId = ReadFields.getCollectionId();
			
			for (serviceDescriptionsFields serviceDescriptions : ReadFields.getServiceDescriptions()) {
				serviceDescriptionId = serviceDescriptions.getServiceDescriptionId();
			
				for(serviceVersionFields serviceVersions: serviceDescriptions.getServiceVersions()){
					serviceVersionId = serviceVersions.getServiceVersionId();
					
					for(resourcePathFields resourcePaths : serviceVersions.getResourcePaths()){
						resourcePathId = resourcePaths.getResourcePathId();
						break;
					}
				}
			}
		}
		
		System.out.println(collectionId);
		System.out.println(serviceDescriptionId);
		System.out.println(serviceVersionId);
		System.out.println(resourcePathId);
		
		Reporter.log("CollectionId: "+ collectionId);
		Reporter.log("serviceDescriptionId: "+ serviceDescriptionId);
		Reporter.log("serviceVersionId: "+ serviceVersionId);
		Reporter.log("resourcePathId: "+ resourcePathId);

	}

}
