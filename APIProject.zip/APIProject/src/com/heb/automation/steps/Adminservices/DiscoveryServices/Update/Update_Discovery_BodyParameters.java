package com.heb.automation.steps.Adminservices.DiscoveryServices.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Discovery_ReusableUtils.Discovery_ReusableUtils;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_Validations;
import com.qmetry.qaf.automation.step.QAFTestStep;

public class Update_Discovery_BodyParameters {

	/**
	 * Defining the Body parameter with the list of elements to be updated.
	 * 
	 */
	@QAFTestStep(description = "I UPDATE apiCollection resource body parameter contains all valid editable fields")
	public void iUPDATEApiCollectionResourceBodyParameterContainsAllValidEditableFields() {

		String name = "Name_Updated_" + ReusableUtils.getCurrentTime();
		String contactInfo = "contactinfoMail_" + ReusableUtils.getCurrentTime() + "@heb.com";
		String description = "Description_Updated_" + ReusableUtils.getCurrentTime();

		JsonObject BodyParameter = ReusableUtils.APIcollectionUpdateEditableFields(name, contactInfo, description);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedName", name);
		getBundle().setProperty("updatedContactInfo", contactInfo);
		getBundle().setProperty("updatedDescription", description);
	}

	/**
	 * Defining the Body parameters with values outside the definition
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE apiCollection resource body parameter contains outside definition fields")
	public void iUPDATEApiCollectionResourceBodyParameterContainsOutsideDefinitionFields() throws Exception {

		Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();
		Read_Discovery_Validations.validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesRead();

		String outsideDef1 = "Name_Updated_" + ReusableUtils.getCurrentTime();
		String outsideDef2 = "contactinfoMail_" + ReusableUtils.getCurrentTime() + "@heb.com";

		JsonObject BodyParameter = ReusableUtils.APIcollectionUpdateOutsideDinition(outsideDef1, outsideDef2);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Define Body parameter with Values containing Service Description field
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE apiCollection resource body parameter contains Service Description field")
	public void iUPDATEApiCollectionResourceBodyParameterContainsServiceDescriptionField() throws Exception {

		Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();
		Read_Discovery_Validations.validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesRead();

		String serviceDescriptionId = "Id_" + ReusableUtils.getCurrentTime();
		String name = "Name_" + ReusableUtils.getCurrentTime();

		JsonArray BodySubParameter = new JsonArray();
		BodySubParameter.add(ReusableUtils.APIcollectionUpdateServiceDescription(serviceDescriptionId, name));

		JsonObject BodyParameter = new JsonObject();
		BodyParameter.add("serviceDescriptions", BodySubParameter);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Define Body parameters with the Editable field values
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE apiCollection resource body parameter contains few valid editable fields")
	public void iUPDATEApiCollectionResourceBodyParameterContainsFewValidEditableFields() throws Exception {

		Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();
		Read_Discovery_Validations.validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesRead();

		String name = "Name_Updated_" + ReusableUtils.getCurrentTime();
		String contactInfo = "contactinfoMail_" + ReusableUtils.getCurrentTime() + "@heb.com";

		JsonObject BodyParameter = ReusableUtils.APIcollectionUpdateFewEditableFields(name, contactInfo);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedName", name);
		getBundle().setProperty("updatedContactInfo", contactInfo);
		getBundle().setProperty("updatedDescription", getBundle().getString("description"));
	}

	/**
	 * Defining the Body parameter with the mandatory/ Non-editable field
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I UPDATE apiCollection resource body parameter contains mandatory field-CollectionId")
	public void iUPDATEApiCollectionResourceBodyParameterContainsMandatoryFieldCollectionId() throws Exception {

		Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();
		Read_Discovery_Validations.validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesRead();

		String collectionId = "collectionId_Updated_" + ReusableUtils.getCurrentTime();

		JsonObject BodyParameter = ReusableUtils.APIcollectionAddMandatoryFields(collectionId);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedDescription", getBundle().getString("description"));

	}

	/**
	 * Defining the Body parameter with the Editable fields of Service
	 * Description
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceDescription resource body parameter contains all valid editable fields")
	public void iUPDATEServiceDescriptionResourceBodyParameterContainsAllValidEditableFields() {

		JsonObject BodyParameter = Discovery_ReusableUtils.serviceDescription_add_Mandatory_and_Optional_fields();
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Updating the Body parameter with the Non-editable field values
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceDescription resource body parameter contains non editable fields")
	public void iUPDATEServiceDescriptionResourceBodyParameterContainsNonEditableFields() {

		String serviceDescriptionId = "Id_" + ReusableUtils.getCurrentTime();

		JsonObject BodyParameter = Discovery_ReusableUtils
				.serviceDescription_update_serviceDescriptionId(serviceDescriptionId);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
		getBundle().setProperty("updatedServiceDescriptionID", serviceDescriptionId);
	}

	/**
	 * Update the Body Parameter with the values of editable fields
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceversion resource body parameter contains all valid editable fields")
	public void iUPDATEServiceversionResourceBodyParameterContainsAllValidEditableFields() {

		JsonObject BodyParameter = Discovery_ReusableUtils.seviceversion_add_Mandatoryfields_optionalfields();
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Update the ResourcePath Body Parameter with the values of editable fields
	 * 
	 */
	@QAFTestStep(description = "I UPDATE resourcePath resource body parameter contains all valid editable fields")
	public void iUPDATEResourcePathResourceBodyParameterContainsAllValidEditableFields() {

		JsonObject BodyParameter = Discovery_ReusableUtils.resourcepath_editablefields();
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Update the ResourcePath Body Parameter with the values outside the
	 * definition
	 * 
	 */
	@QAFTestStep(description = "I UPDATE resourcePath resource body parameter contains outside definition fields")
	public void iUPDATEResourcePathResourceBodyParameterContainsOutsideDefinitionFields() {

		JsonObject BodyParameter = Discovery_ReusableUtils.resourcepath_onlyoptionalfields();
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Updating the Body parameter with values outside the definition
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceDescription resource body parameter contains outside definition fields")
	public void iUPDATEServiceDescriptionResourceBodyParameterContainsOutsideDefinitionFields() {

		String outsideDef1 = "Name_Updated_" + ReusableUtils.getCurrentTime();
		String outsideDef2 = "contactinfoMail_" + ReusableUtils.getCurrentTime() + "@heb.com";

		JsonObject BodyParameter = ReusableUtils.APIcollectionUpdateOutsideDinition(outsideDef1, outsideDef2);
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}

	/**
	 * Defining the ServiceDescription resource Body parameter with invalid JSON
	 * body parameter
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceDescription resource body parameter contains invalid Json body parameter")
	public void iUPDATEServiceDescriptionResourceBodyParameterContainsInvalidJsonBodyParameter() {

		JsonObject BodyParameter = Discovery_ReusableUtils.serviceDescription_add_Mandatory_and_Optional_fields();
		String strBody = BodyParameter.toString().replace("}", "},");
		getBundle().setProperty("BodyParametervalue", strBody);
	}

	/**
	 * Update the Body Parameter with the values Outside the definition
	 * 
	 */
	@QAFTestStep(description = "I UPDATE serviceversion body parameter contains outside definition fields")
	public void iUPDATEServiceVersionBodyParameterContainsOutsideDefinitionFields() {

		JsonObject BodyParameter = Discovery_ReusableUtils.seviceversion_add_ousidedef();
		getBundle().setProperty("BodyParametervalue", BodyParameter);
	}
}
