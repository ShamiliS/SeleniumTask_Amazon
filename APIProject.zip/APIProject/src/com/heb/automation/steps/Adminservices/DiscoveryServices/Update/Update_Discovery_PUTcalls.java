package com.heb.automation.steps.Adminservices.DiscoveryServices.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.JsonObject;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Update_Discovery_PUTcalls {

	/**
	 * 1) Update the resource fields for API Collection' 2) Store the response
	 * in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for apiCollection Discovery services")
	public void iPUTUpdatedResourceFieldsForApiCollectionDiscoveryServices() {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating with Invalid collectionID for API Collection 2) Storing the
	 * error response in 'errorMsg'
	 * 
	 * @param collectionId
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for apiCollection Discovery services for invalid collectionID {0}")
	public void iPUTUpdatedResourceFieldsForApiCollectionDiscoveryServicesForInvalidCollectionID(String collectionId) {

		String errorMsg = null;
		getBundle().setProperty("CollectionID", collectionId);

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.update");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Fail);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I PUT Updated Resource fields for apiCollection Discovery services with bad url")
	public void iPUTUpdatedResourceFieldsForApiCollectionDiscoveryServicesWithBadUrl() {
		// Get Valid App Id
		String errorMsg = null;
		String AppID = (String) getBundle().getProperty("CollectionID");
		String baseurl = getBundle().getString("MLapiURL.Admin_UrlBadURl");
		String resource = getBundle().getString("MLapiURL.serviceName") + getBundle().getString("apicollection.update");
		System.out.println("resource: " + resource);
		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");
		System.out.println(BodyParamter);
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) UPDATE Service description resource with valid editable fields 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for serviceDescription Discovery services")
	public void iPUTUpdatedResourceFieldsForServiceDescriptionDiscoveryServices() {

		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID;

		getBundle().setProperty("env.baseurl", baseurl);

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the service version resource with all valid editable fields
	 * 2) Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for serviceversion")
	public void iPUTUpdatedResourceFieldsForServiceversion() {

		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the ResourcePath resources with all valid editable fields 2)
	 * Storing the response in 'APIresponse'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for resourcePath")
	public void iPUTUpdatedResourceFieldsForResourcePath() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String resourcePathID = (String) getBundle().getProperty("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + resourcePathID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 */
	@QAFTestStep(description = "I PUT Updated resourcePath using {0} collectionID {1} serviceDesc {1} servVersion and {1}resourceID")
	public void iPUTUpdatedResourcePathUsingCollectionIDServiceDescServVersionAndResourceID(String CollectionID,
			String ServiceDescriptionID, String ServiceVersionID, String resourcePathID) {

	}

	/**
	 * 1) Updating the ResourcePath resources with Invalid CollectionID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated resourcePath using invalid collectionID valid serviceDesc ,servVersion & resourceID")
	public void iPUTUpdatedResourcePathUsingInvalidCollectionIDValidServiceDescServVersionResourceID() {
		String errorMsg = null;
		String CollectionID = "abc1234";
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String resourcePathID = (String) getBundle().getProperty("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + resourcePathID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid collectionId.", MessageTypes.Fail);
			Reporter.log("CollectionID: " + CollectionID);

		} catch (Exception e) {
			Reporter.log("UPDATE failed due to Invalid collectionId.", MessageTypes.Pass);
			Reporter.log("CollectionID: " + CollectionID);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the ResourcePath resources with Invalid ServiceDesID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated resourcePath using valid collectionID invalid serviceDesc , valid servVersion & valid resourceID")
	public void iPUTUpdatedResourcePathUsingValidCollectionIDInvalidServiceDescValidServVersionValidResourceID() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = getBundle().getString("invalidServiceDescriptionID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String resourcePathID = (String) getBundle().getProperty("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + resourcePathID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid ServiceDescriptionID.", MessageTypes.Fail);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);

		} catch (Exception e) {
			Reporter.log("UPDATE failed due to Invalid ServiceDescriptionID.", MessageTypes.Pass);
			Reporter.log("ServiceDescriptionID: " + ServiceDescriptionID);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) UPDATE ServiceDescription resource with empty or invalid body
	 * parameter 2) Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for serviceDescription Discovery services with empty or invalid body")
	public void iPUTUpdatedResourceFieldsForServiceDescriptionDiscoveryServicesWithEmptyOrInvalidBody() {

		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID;

		getBundle().setProperty("env.baseurl", baseurl);

		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	/**
	 * 1) Updating the service version resource with Invalid CollectionID or
	 * ServiceDesID or ServiceVersionID 2) Storing the error response in
	 * 'errorMsg'
	 * 
	 * @param key
	 * @param value
	 */
	@QAFTestStep(description = "I PUT Updated serviceversion using invalid {0} and {1}")
	public void iPUTUpdatedServiceversionUsingInvalidAnd(String key, String value) {

		String errorMsg = null, CollectionID = null, ServiceDescriptionID, ServiceVersionID;

		CollectionID = getBundle().getString("CollectionID");
		ServiceDescriptionID = getBundle().getString("ServiceDesID");
		ServiceVersionID = getBundle().getString("ServiceVersionID");

		if (key.equals("CollectionID")) {
			CollectionID = value;
		} else if (key.equals("ServiceDescriptionID")) {
			ServiceDescriptionID = value;
		} else if (key.equals("ServiceVersionID")) {
			ServiceVersionID = value;
			getBundle().setProperty("ServiceVersionID", value);
		}

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

	@QAFTestStep(description = "I PUT Updated serviceversion using invalid collectionID&ServiceDescID")
	public void iPUTUpdatedServiceversionUsingInvalidCollectionIDServiceDescID() {

		String errorMsg = null, CollectionID = null, ServiceDescriptionID, ServiceVersionID;

		CollectionID = "Testing";
		ServiceDescriptionID = "Testing";
		ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;
		System.out.println(baseurl);
		System.out.println(resource);

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Valid Parameters.", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Update..", MessageTypes.Info);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the service version resource with empty Body parameter 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT update Resource for Invalid input")
	public void iPUTUpdateResourceForInvalidInput() {

		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);
		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with empty body Parameters.", MessageTypes.Fail);
			Reporter.log("BodyParamter:" + BodyParamter);

		} catch (Exception e) {
			Reporter.log("UPDATE failed due to empty body parameter.", MessageTypes.Pass);
			Reporter.log("BodyParamter:" + BodyParamter);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the service version resource with Invalid collectionID 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated serviceversion using invalid collectionID valid serviceDesc ,servVersion & resourceID")
	public void iPUTUpdatedServiceversionUsingInvalidCollectionIDValidServiceDescServVersionResourceID() {
		String errorMsg = null;
		String CollectionID = getBundle().getString("invalidCollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with Invalid CollectionID.", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionID: " + CollectionID);

		} catch (Exception e) {
			Reporter.log("UPDATE Failed due to Invalid CollectionID.", MessageTypes.Pass);
			Reporter.log("resource: " + resource);
			Reporter.log("CollectionID: " + CollectionID);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) Updating the ResourcePath resources with empty body parameters 2)
	 * Storing the error response in 'errorMsg'
	 * 
	 */
	@QAFTestStep(description = "I PUT Updated Resource fields for resourcePath with empty body parameters")
	public void iPUTUpdatedResourceFieldsForResourcePathWithEmptyBodyParameters() {
		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("CollectionID");
		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String ServiceVersionID = (String) getBundle().getProperty("ServiceVersionID");
		String resourcePathID = (String) getBundle().getProperty("ResourcePathID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID + "/resourcePaths/" + resourcePathID;

		getBundle().setProperty("env.baseurl", baseurl);
		String BodyParamter = getBundle().getString("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with empty body parameters.", MessageTypes.Fail);
			Reporter.log("resource: " + resource);
			Reporter.log("BodyParamter: " + BodyParamter.toString());

		} catch (Exception e) {
			Reporter.log("UPDATE failed due to empty body parameters.", MessageTypes.Pass);
			Reporter.log("resource: " + resource);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	@QAFTestStep(description = "I PUT Updated Resource fields for serviceversion with bad URL")
	public void iPUTUpdatedResourceFieldsForServiceversionWithBadURL() {

		String errorMsg = null;
		String CollectionID = (String) getBundle().getProperty("collectionID");
		String ServiceDescriptionID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		String baseurl = getBundle().getString("MLapiURL.Admin_Url").replace("https", "http");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource") + "/" + CollectionID + "/serviceDescriptions/"
				+ ServiceDescriptionID + "/serviceVersions/" + ServiceVersionID;
		System.out.println(baseurl);
		System.out.println(resource);

		getBundle().setProperty("env.baseurl", baseurl);
		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		String RESPONSE = null;
		try {
			RESPONSE = CommonUtils.PUT(resource, headers, BodyParamter);
			Reporter.log("UPDATE Processed with bad URL.", MessageTypes.Fail);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("Update Fail due to bad URL", MessageTypes.Pass);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}

	}

}
