package com.heb.automation.steps.Adminservices.DiscoveryServices.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.common.endpoints.constants.ApiDiscovery_Client_Constants;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Update_Discovery_Validations {

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the colectionID in the
	 * response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of apiCollection Discovery services update")
	public void validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesUpdate() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.validateRequiredFieldsInResponse("apiCollection_Update_Success", RESPONSE);

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String collectionId = gson.getAsJsonObject().get("collectionId").toString().replace("\"", "");

		if (collectionId.equalsIgnoreCase(getBundle().getString("CollectionID"))) {
			if (name.equalsIgnoreCase(getBundle().getString("updatedName"))) {
				Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable fields are not updated successfully!", MessageTypes.Fail);
			}
		} else {
			Reporter.log("Wrong Collection Id !", MessageTypes.Fail);
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ApiCollections_Update");
		ReusableUtils.validateJSONschema_ApiDiscovery("ApiCollections_Update_Schema", "ApiCollections_Update");

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) Fields are not Updated
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of apiCollection Discovery services for no update")
	public void validateTheResponseForFullSuccessOfApiCollectionDiscoveryServicesForNoUpdate() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.validateRequiredFieldsInResponse("apiCollection_Update_Success", RESPONSE);

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String collectionId = gson.getAsJsonObject().get("collectionId").toString().replace("\"", "");
		String serviceDescriptions = gson.getAsJsonObject().get("serviceDescriptions").toString().replace("\"", "");

		if (collectionId.equalsIgnoreCase(getBundle().getString("CollectionID"))) {
			if (name.equalsIgnoreCase(getBundle().getString("name"))
					&& serviceDescriptions.equalsIgnoreCase(getBundle().getString("serviceDescriptions"))) {
				Reporter.log("Fields are not updated while updating outside definition fields!", MessageTypes.Pass);
			} else {
				Reporter.log("Fields are updated while updating outside definition fields!", MessageTypes.Fail);
			}
		} else {
			Reporter.log("Wrong Collection Id!", MessageTypes.Fail);
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ApiCollections_Update");
		ReusableUtils.validateJSONschema_ApiDiscovery("ApiCollections_Update_Schema", "ApiCollections_Update");

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the ServiceDesID in
	 * the response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of serviceDescription Discovery services update")
	public void validateTheResponseForFullSuccessOfServiceDescriptionDiscoveryServicesUpdate() throws Exception {

		String ServiceDescriptionID = (String) getBundle().getProperty("ServiceDesID");
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		String serviceDescriptionId = gson.getAsJsonObject().get("serviceDescriptionId").toString().replace("\"", "");
		if (serviceDescriptionId.equalsIgnoreCase(ServiceDescriptionID)) {
			Reporter.log("Service Description Id is available!", MessageTypes.Pass);
		} else {
			Reporter.log("Wrong Service Description Id !", MessageTypes.Fail);
		}

		validateServiceDescriptionUpdate(gson, ServiceDescriptionID);

		ReusableUtils.responseStatusforOK();

		ReusableUtils.validateRequiredFieldsInResponse("serviceDescription_ReadSpecific_Success", RESPONSE);

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ServiceDescription_Update");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceDescription_Read_Schema", "ServiceDescription_Update");
	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the Non-editable field
	 * is not updated
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate the response for Full success of serviceDescription Discovery services for no update")
	public void validateTheResponseForFullSuccessOfServiceDescriptionDiscoveryServicesForNoUpdate() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "ServiceDescription_Update");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceDescription_Read_Schema", "ServiceDescription_Update");

		ReusableUtils.validateRequiredFieldsInResponse("serviceDescription_ReadSpecific_Success", RESPONSE);

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String labels = gson.getAsJsonObject().get("labels").toString().replace("\"", "");
		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String openApiSpecURL = gson.getAsJsonObject().get("openApiSpecUrl").toString().replace("\"", "");
		String documentation = gson.getAsJsonObject().get("documentationUrl").toString().replace("\"", "");
		String currentVersion = gson.getAsJsonObject().get("currentVersion").toString().replace("\"", "");
		String serviceDescriptionId = gson.getAsJsonObject().get("serviceDescriptionId").toString().replace("\"", "");

		if (serviceDescriptionId.equalsIgnoreCase(getBundle().getString("ServiceDesID"))) {
			Reporter.log("Mandatory field is not updated!", MessageTypes.Pass);
		} else {
			Reporter.log("Wrong Service Description Id !", MessageTypes.Fail);
		}

		if (description.equalsIgnoreCase(getBundle().getString("description"))
				&& labels.equalsIgnoreCase(getBundle().getString("labels"))
				&& name.equalsIgnoreCase(getBundle().getString("name"))
				&& openApiSpecURL.equalsIgnoreCase(getBundle().getString("openApiSpecUrl"))
				&& documentation.equalsIgnoreCase(getBundle().getString("documentationUrl"))
				&& currentVersion.equalsIgnoreCase(getBundle().getString("currentVersion"))) {
			Reporter.log("Editable fields are not updated while trying to update Mandatory field!", MessageTypes.Pass);
		} else {
			Reporter.log("Editable fields are updated while trying to update Mandatory field!", MessageTypes.Fail);
		}

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the mandatory field is
	 * not updated
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the mandatory field of ServiceVersionID is not updated")
	public void iValidateTheMandatoryFieldOfServiceVersionIDIsNotUpdated() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");
		String RequestSVID = getBundle().getString("ServiceVersionID");

		if (serviceVersionId.equals(RequestSVID)) {
			Reporter.log("Mandatory field of ServiceVersionID is not updated as expected", MessageTypes.Pass);
		} else {
			Reporter.log("Mandatory field of ServiceVersionID is updated", MessageTypes.Fail);
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_Update_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceVersion_Read_Schema", "SV_Update_FullSuccess");

		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_ReadSpecific_Success", RESPONSE);

		ReusableUtils.responseStatusforOK();

	}

	/**
	 * 1) Validating the Service Description Updated fields are available in
	 * ADMIN portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify updated Service description fields in Discovery Services Admin Portal READ")
	public void iVerifyUpdatedServiceDescriptionFieldsInDiscoveryServicesAdminPortalREAD() {

		String expectedServiceDesc = getBundle().getString("ServiceDesID");
		String CollectionID = getBundle().getString("CollectionID");

		Read_Discovery_GETcalls.iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(CollectionID,
				expectedServiceDesc);

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		if (gson.getAsJsonObject().get("serviceDescriptionId").toString().replace("\"", "")
				.equalsIgnoreCase(expectedServiceDesc)) {
			Reporter.log("Updated Service Description Id is available in Admin Portal: " + expectedServiceDesc,
					MessageTypes.Pass);
			validateServiceDescriptionUpdate(gson, expectedServiceDesc);
		} else {
			Reporter.log("Updated Service Description Id is not available in Admin Portal", MessageTypes.Fail);
		}

	}

	public static void validateServiceDescriptionUpdate(JsonElement gson, String ServiceDescriptionID) {

		String description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String labels = gson.getAsJsonObject().get("labels").toString().replace("\"", "");
		String name = gson.getAsJsonObject().get("name").toString().replace("\"", "");
		String openApiSpecURL = gson.getAsJsonObject().get("openApiSpecUrl").toString().replace("\"", "");
		String documentationUrl = gson.getAsJsonObject().get("documentationUrl").toString().replace("\"", "");
		String currentVersion = gson.getAsJsonObject().get("currentVersion").toString().replace("\"", "");

		if (description.equalsIgnoreCase(getBundle().getString("description"))
				&& labels.equalsIgnoreCase(getBundle().getString("labels"))
				&& name.equalsIgnoreCase(getBundle().getString("name"))
				&& openApiSpecURL.equalsIgnoreCase(getBundle().getString("openApiSpecUrl"))
				&& documentationUrl.equalsIgnoreCase(getBundle().getString("documentationUrl"))
				&& currentVersion.equalsIgnoreCase(getBundle().getString("currentVersion"))) {
			Reporter.log("Editable fields are updated successfully!", MessageTypes.Pass);
		} else {
			Reporter.log("Editable fields are not updated successfully!", MessageTypes.Fail);
		}
	}

	/**
	 * 1) Validating the Service Description Updated fields are available in
	 * Client portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify updated Service description fields in Discovery Services Customer Portal READ")
	public void iVerifyUpdatedServiceDescriptionFieldsInDiscoveryServicesCustomerPortalREAD() {

		String expectedServiceDesc = getBundle().getString("ServiceDesID");
		String CollectionID = getBundle().getString("CollectionID");
		ArrayList<String> actualServiceDesc = new ArrayList<String>();

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (JsonObject.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

					for (JsonElement singleServiceDesc : serviceDescArray) {

						String serviceDescId = singleServiceDesc.getAsJsonObject().get(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID).toString().replace("\"",
								"");
						if (serviceDescId.equalsIgnoreCase(expectedServiceDesc)) {

							validateServiceDescriptionUpdate(singleServiceDesc, serviceDescId);
						}
						actualServiceDesc.add(serviceDescId);
					}

					System.out.println(actualServiceDesc);
				}
			}
		}

		if (actualServiceDesc.contains(expectedServiceDesc)) {
			Reporter.log("Updated Service Description Id is available in Customer Portal: " + expectedServiceDesc,
					MessageTypes.Pass);
		} else {
			Reporter.log("Updated Service Description Id is not available in Customer Portal", MessageTypes.Fail);
		}
	}

	/**
	 * 1) Validating the Service Version Updated fields are available in ADMIN
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify updated ServiceVersion fields in Discovery Services Admin Portal READ")
	public void iVerifyUpdatedServiceVersionFieldsInDiscoveryServicesAdminPortalREAD() {

		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		Read_Discovery_GETcalls.iReadSpecificResourceFieldsServiceVersionDiscoveryServices();

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");

		if (serviceVersionId.equalsIgnoreCase(ServiceVersionID)) {
			Reporter.log("Updated Service Version Id is available in Admin Portal.", MessageTypes.Pass);
			validateServiceVersionnUpdate(gson);
		} else {
			Reporter.log("Updated Service Version Id is not available in Admin Portal.", MessageTypes.Fail);
		}
	}

	private void validateServiceVersionnUpdate(JsonElement gson) {

		String hostName = gson.getAsJsonObject().get("hostName").toString().replace("\"", "");
		String basePath = gson.getAsJsonObject().get("basePath").toString().replace("\"", "");
		String description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String versionNumber = gson.getAsJsonObject().get("versionNumber").toString().replace("\"", "");
		String openApiSpecUrl = gson.getAsJsonObject().get("openApiSpecUrl").toString().replace("\"", "");

		if (hostName.equalsIgnoreCase(getBundle().getString("hostName"))
				&& basePath.equalsIgnoreCase(getBundle().getString("basePath"))
				&& description.equalsIgnoreCase(getBundle().getString("description"))
				&& versionNumber.equalsIgnoreCase(getBundle().getString("versionNumber"))
				&& openApiSpecUrl.equalsIgnoreCase(getBundle().getString("openApiSpecUrl"))) {
			Reporter.log("Updated values are available in the given Portal read.", MessageTypes.Pass);
		} else {
			Reporter.log("Updated values are not available in the given Portal read.", MessageTypes.Fail);
		}
	}

	/**
	 * 1) Validating the Service Description Updated fields are available in
	 * Client portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify updated ServiceVersion fields in Discovery Services Customer Portal READ")
	public void iVerifyUpdatedServiceVersionFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> actualServiceVersionIds = new ArrayList<String>();

		String UpdatedServiceVerID = getBundle().getString("ServiceVersionID");

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {
								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVer : serviceVersionsArray) {
										String serviceVersionId = singleServiceVer.getAsJsonObject().get(ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)
												.toString().replace("\"", "");

										if (serviceVersionId.equalsIgnoreCase(ServiceVersionID)) {
											validateServiceVersionnUpdate(singleServiceVer);
										}

										actualServiceVersionIds.add(serviceVersionId);
									}

								}
							}
						}
					}
				}
			}
		}

		if (actualServiceVersionIds.contains(UpdatedServiceVerID)) {
			Reporter.log("Updated ServiceVersionId is available in Customer Portal: " + UpdatedServiceVerID,
					MessageTypes.Pass);
		} else {
			Reporter.log("Updated ServiceVersionId is not available in Customer Portal", MessageTypes.Fail);
		}
	}

	/**
	 * 1) Validating the ResourcePath Updated fields are available in ADMIN
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the Updated ResourcePath fields in Discovery Services Admin Portal READ")
	public void iVerifyTheUpdatedResourcePathFieldsInDiscoveryServicesAdminPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionId = getBundle().getString("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathID");

		Read_Discovery_GETcalls.iREADResourcePathResourceForCollectionIDServiceDesServVersionResourcePath(CollectionID,
				ServiceDesID, ServiceVersionId, ResourcePathId);

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);
		String actResourcePathId = gson.getAsJsonObject().get("resourcePathId").toString().replace("\"", "");

		if (actResourcePathId.equalsIgnoreCase(ResourcePathId)) {
			Reporter.log("Updated ReourcePath Id is available in Admin Portal: " + actResourcePathId,
					MessageTypes.Pass);
			validateResourcePathUpdate(gson);
		} else {
			Reporter.log("Updated ReourcePath Id is not available in Admin Portal", MessageTypes.Fail);
		}

	}

	private void validateResourcePathUpdate(JsonElement singleResourcePath) {

		String name = singleResourcePath.getAsJsonObject().get("name").toString().replace("\"", "");
		String path = singleResourcePath.getAsJsonObject().get("path").toString().replace("\"", "");

		String description;

		try {
			description = singleResourcePath.getAsJsonObject().get("description").toString().replace("\"", "");

			vaidateTheUpdatedResourcePathFields(name, path, description);

		} catch (Exception e) {

			Reporter.log("description field not available.");
			vaidateTheUpdatedResourcePathFields(name, path);
		}

	}

	void vaidateTheUpdatedResourcePathFields(String name, String path, String description) {

		if (name.equalsIgnoreCase(getBundle().getString("name"))
				&& path.equalsIgnoreCase(getBundle().getString("path"))) {
			Reporter.log("Updated values are available in the Admin Portal read.", MessageTypes.Pass);
			Reporter.log("name: " + name);
			Reporter.log("path: " + path);
			Reporter.log("description: " + description);
		} else {
			Reporter.log("Updated values are available in the Admin Portal read.", MessageTypes.Fail);
			Reporter.log("name: " + name);
			Reporter.log("path: " + path);
			Reporter.log("description: " + description);
		}

	}

	void vaidateTheUpdatedResourcePathFields(String name, String path) {

		if (name.equalsIgnoreCase(getBundle().getString("name"))
				&& path.equalsIgnoreCase(getBundle().getString("path"))) {
			Reporter.log("Updated values are available in the Admin Portal read.", MessageTypes.Pass);
			Reporter.log("name: " + name);
			Reporter.log("path: " + path);
		} else {
			Reporter.log("Updated values are available in the Admin Portal read.", MessageTypes.Fail);
			Reporter.log("name: " + name);
			Reporter.log("path: " + path);
		}
	}

	/**
	 * 1) Validating the ResourcePath Updated fields are available in Client
	 * portal READ
	 * 
	 */
	@QAFTestStep(description = "I Verify the Updated ResourcePath fields in Discovery Services Customer Portal READ")
	public void iVerifyTheUpdatedResourcePathFieldsInDiscoveryServicesCustomerPortalREAD() {

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		ArrayList<String> actualResourcePathIds = new ArrayList<String>();

		String UpdatedResourcePathId = getBundle().getString("ResourcePathId");

		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");
		String ServiceVersionID = getBundle().getString("ServiceVersionID");
		String ResourcePathId = getBundle().getString("ResourcePathId");

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> col : gson.getAsJsonObject().entrySet()) {

			if (col.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {
				if (col.getValue().toString().replace("\"", "").equalsIgnoreCase(CollectionID)) {

					JsonArray serviceDescArray = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
					for (JsonElement singleServiceDesc : serviceDescArray) {

						for (Entry<String, JsonElement> serviceDes : singleServiceDesc.getAsJsonObject().entrySet()) {

							if (serviceDes.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID)) {
								if (serviceDes.getValue().toString().replace("\"", "").equalsIgnoreCase(ServiceDesID)) {

									JsonArray serviceVersionsArray = (JsonArray) singleServiceDesc.getAsJsonObject()
											.get("serviceVersions");

									for (JsonElement singleServiceVersion : serviceVersionsArray) {

										for (Entry<String, JsonElement> JsonObject2 : singleServiceVersion
												.getAsJsonObject().entrySet()) {

											if (JsonObject2.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.SERVICE_VERSION_PROPERTY_ID)) {

												if (JsonObject2.getValue().toString().replace("\"", "")
														.equalsIgnoreCase(ServiceVersionID)) {

													JsonArray ResourcePathsArray = (JsonArray) singleServiceVersion
															.getAsJsonObject().get("resourcePaths");

													for (JsonElement singleResourcePath : ResourcePathsArray) {
														for (Entry<String, JsonElement> JsonObject3 : singleResourcePath
																.getAsJsonObject().entrySet()) {

															if (JsonObject3.getKey().equalsIgnoreCase(ApiDiscovery_Client_Constants.RESOURCE_PATH_PROPERTY_ID)) {
																String singleResourcePathId = JsonObject3.getValue()
																		.toString().replace("\"", "");

																if (singleResourcePathId
																		.equalsIgnoreCase(ResourcePathId)) {
																	validateResourcePathUpdate(singleResourcePath);
																}

																actualResourcePathIds.add(ResourcePathId);
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (actualResourcePathIds.contains(UpdatedResourcePathId)) {
			Reporter.log("Updated ReourcePath Id is available in Customer Portal: " + UpdatedResourcePathId,
					MessageTypes.Pass);
		} else {
			Reporter.log("Updated ReourcePath Id is not available in Customer Portal", MessageTypes.Fail);
		}
	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the ServiceVersionID
	 * in the response
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the Service Version Specific Update response for Full success")
	public void iValidateTheServiceVersionSpecificUpdateResponseForFullSuccess() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_ReadSpecific_Success", RESPONSE);

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");
		String versionNumber = gson.getAsJsonObject().get("versionNumber").toString().replace("\"", "");
		String hostName = gson.getAsJsonObject().get("hostName").toString().replace("\"", "");
		String description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String basePath = gson.getAsJsonObject().get("basePath").toString().replace("\"", "");
		String openApiSpecUrl = gson.getAsJsonObject().get("openApiSpecUrl").toString().replace("\"", "");

		if (serviceVersionId.equalsIgnoreCase(getBundle().getString("ServiceVersionID"))) {
			Reporter.log("Service Version Id is displayed correctly!", MessageTypes.Pass);

			if (versionNumber.equalsIgnoreCase(getBundle().getString("versionNumber"))
					&& hostName.equalsIgnoreCase(getBundle().getString("hostName"))
					&& description.equalsIgnoreCase(getBundle().getString("description"))
					&& basePath.equalsIgnoreCase(getBundle().getString("basePath"))
					&& openApiSpecUrl.equalsIgnoreCase(getBundle().getString("openApiSpecUrl"))) {

				Reporter.log("Editable Fields are updated correctly!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable Fields are not updated correctly!", MessageTypes.Fail);
			}
		} else {
			Reporter.log("Service Version Id is not displayed correctly!", MessageTypes.Fail);
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_Update_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceVersion_Read_Schema", "SV_Update_FullSuccess");

		ReusableUtils.responseStatusforOK();

	}

	/**
	 * Validating the UPDATE response for full success 1) Response status 2)
	 * Schema validation 3) Required fields 4) validating the fields are not
	 * updated
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate the Service Version Specific Update response for Full success with no update")
	public void iValidateTheServiceVersionSpecificUpdateResponseForFullSuccessWithNoUpdate() throws Exception {

		String RESPONSE = getBundle().getString("APIresponse");

		ReusableUtils.validateRequiredFieldsInResponse("serviceVersion_ReadSpecific_Success", RESPONSE);

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String serviceVersionId = gson.getAsJsonObject().get("serviceVersionId").toString().replace("\"", "");
		String versionNumber = gson.getAsJsonObject().get("versionNumber").toString().replace("\"", "");
		String hostName = gson.getAsJsonObject().get("hostName").toString().replace("\"", "");
		String description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String basePath = gson.getAsJsonObject().get("basePath").toString().replace("\"", "");
		String openApiSpecUrl = gson.getAsJsonObject().get("openApiSpecUrl").toString().replace("\"", "");

		if (serviceVersionId.equalsIgnoreCase(getBundle().getString("ServiceVersionID"))) {
			Reporter.log("Service Version Id is displayed correctly!", MessageTypes.Pass);

			if (versionNumber.equalsIgnoreCase(getBundle().getString("versionNumber"))
					&& hostName.equalsIgnoreCase(getBundle().getString("hostName"))
					&& description.equalsIgnoreCase(getBundle().getString("description"))
					&& basePath.equalsIgnoreCase(getBundle().getString("basePath"))
					&& openApiSpecUrl.equalsIgnoreCase(getBundle().getString("openApiSpecUrl"))) {

				Reporter.log("Editable Fields are not updated while updating outside definition!", MessageTypes.Pass);
			} else {
				Reporter.log("Editable Fields are updated while updating outside definition!", MessageTypes.Fail);
			}
		} else {
			Reporter.log("Service Version Id is not displayed correctly!", MessageTypes.Fail);
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "SV_Update_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("ServiceVersion_Read_Schema", "SV_Update_FullSuccess");

		ReusableUtils.responseStatusforOK();

	}

	/**
	 * 1) Validating the Updated fields are available in ADMIN portal READ
	 * 
	 */
	@QAFTestStep(description = "I validate update fields of collectionID in Admin Portal READ")
	public void iValidateUpdateFieldsOfCollectionIDInAdminPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");
		String updName = getBundle().getString("updatedName");
		String updContactInfo = getBundle().getString("updatedContactInfo");
		String updDescrip = getBundle().getString("updatedDescription");

		Read_Discovery_GETcalls.iREADResourceFieldsForApiCollectionDiscoveryServices();

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equals("collectionId")) {

				if (JsonObject.getValue().toString().replace("\"", "").equals(CollectionID)) {

					if (JsonObject.getKey().equals("name")) {
						if (JsonObject.getValue().toString().replace("\"", "").equals(updName)) {
							Reporter.log("Name is Updated successfully as:" + updName, MessageTypes.Pass);
						} else {
							Reporter.log("Name is not Updated", MessageTypes.Fail);
						}
					}

					if (JsonObject.getKey().equals("contactInfo")) {
						if (JsonObject.getValue().toString().replace("\"", "").equals(updContactInfo)) {
							Reporter.log("ContactInfo is Updated successfully as:" + updContactInfo, MessageTypes.Pass);
						} else {
							Reporter.log("ContactInfo is not Updated", MessageTypes.Fail);
						}
					}

					if (JsonObject.getKey().equals("description")) {
						if (JsonObject.getValue().toString().replace("\"", "").equals(updDescrip)) {
							Reporter.log("Description is Updated successfully as:" + updDescrip, MessageTypes.Pass);
						} else {
							Reporter.log("Description is not Updated", MessageTypes.Fail);
						}
					}
				}
			}
		}

	}

	/**
	 * 1) Validating the Updated fields are available in Client portal READ
	 * 
	 */
	@QAFTestStep(description = "I validate update fields of CollectionID in Customer Portal READ")
	public void iValidateUpdateFieldsOfCollectionIDInCustomerPortalREAD() {

		String CollectionID = getBundle().getString("CollectionID");
		String updName = getBundle().getString("updatedName");
		String updContactInfo = getBundle().getString("updatedContactInfo");
		String updDescrip = getBundle().getString("updatedDescription");

		Read_Discovery_GETcalls.iREADBatchResourcesForApiCollectionDiscoveryServicesFromCustomerPortal();

		JsonElement gson = new Gson().fromJson(getBundle().getString("APIresponse"), JsonElement.class);

		for (Entry<String, JsonElement> JsonObject : gson.getAsJsonObject().entrySet()) {

			if (JsonObject.getKey().equals(ApiDiscovery_Client_Constants.API_COLLECTION_PROPERTY_ID)) {

				if (JsonObject.getValue().toString().replace("\"", "").equals(CollectionID)) {

					if (JsonObject.getKey().equals("name")) {

						if (JsonObject.getValue().toString().replace("\"", "").equals(updName)) {
							Reporter.log("Name is Updated successfully as:" + updName, MessageTypes.Pass);

						} else {
							Reporter.log("Name is not Updated", MessageTypes.Fail);
						}
					}

					if (JsonObject.getKey().equals("contactInfo")) {

						if (JsonObject.getValue().toString().replace("\"", "").equals(updContactInfo)) {
							Reporter.log("ContactInfo is Updated successfully as:" + updContactInfo, MessageTypes.Pass);
						} else {
							Reporter.log("ContactInfo is not Updated", MessageTypes.Fail);
						}
					}

					if (JsonObject.getKey().equals("description")) {

						if (JsonObject.getValue().toString().replace("\"", "").equals(updDescrip)) {
							Reporter.log("Description is Updated successfully as:" + updDescrip, MessageTypes.Pass);
						} else {
							Reporter.log("Description is not Updated", MessageTypes.Fail);
						}
					}
				}
			}
		}
	}

	/**
	 * 1) Validating the Error code 2) Message- Resource with 'ID' not found
	 * 
	 */
	@QAFTestStep(description = "I validate the response {0}_Resource with Id Not Found Error for Invalid {1}")
	public void iValidateTheResponse_ResourceWithIdNotFoundErrorForInvalid(int errorCode, String InValidValue) {
		String actErrorMsg = getBundle().getString("errorMsg");

		String expErrorMsg = null;

		switch (InValidValue) {

		case "CollectionID":
			expErrorMsg = "Resource with id " + getBundle().getString("CollectionID") + " not found.";
			break;

		case "ServiceDesID":
			expErrorMsg = "Resource with id " + getBundle().getString("ServiceDesID") + " not found.";
			break;

		case "ServiceVersionID":
			expErrorMsg = "Resource with id " + getBundle().getString("ServiceVersionID") + " not found.";
			break;

		case "ResourcePathID":
			expErrorMsg = "Resource with id " + getBundle().getString("ResourcePathID") + " not found.";
			break;

		default:
			break;
		}

		JsonObject BodyParamter = (JsonObject) getBundle().getProperty("BodyParametervalue");
		String collectionId = getBundle().getString("CollectionID");

		// Validate status code
		ErrorMessage.validateErrorResponse(errorCode);

		// validating the Message field is not empty
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}
}
