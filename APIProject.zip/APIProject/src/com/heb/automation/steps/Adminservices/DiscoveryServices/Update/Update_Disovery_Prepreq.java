package com.heb.automation.steps.Adminservices.DiscoveryServices.Update;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.steps.ML_CommonStepDef;
import com.heb.automation.steps.Adminservices.DiscoveryServices.Read.Read_Discovery_GETcalls;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;

public class Update_Disovery_Prepreq {

	/**
	 * 1) READ Service Description resource before update 2) Setting the
	 * properties values for the available keys
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I READ ServiceDescription Resource details before update")
	public void iREADServiceDescriptionResourceDetailsBeforeUpdate() throws Exception {
		String CollectionID = getBundle().getString("CollectionID");
		String ServiceDesID = getBundle().getString("ServiceDesID");

		String description = null, name = null, serviceDescriptionId = null, creationDate = null,
				lastModifiedDate = null, serviceVersions = null, labels = null, openApiSpecUrl = null,
				documentationUrl = null, currentVersion = null;

		Read_Discovery_GETcalls.iREADServiceDescriptionResourceForCollectionIDandServiceDescriptionID(CollectionID,
				ServiceDesID);

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {

			if (JsonErrorObject.getKey().equalsIgnoreCase("description")) {
				description = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("name")) {
				name = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("serviceDescriptionId")) {
				serviceDescriptionId = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("creationDate")) {
				creationDate = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("lastModifiedDate")) {
				lastModifiedDate = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("serviceVersions")) {
				serviceVersions = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("labels")) {
				labels = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("openApiSpecUrl")) {
				openApiSpecUrl = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("documentationUrl")) {
				documentationUrl = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("currentVersion")) {
				currentVersion = JsonErrorObject.getValue().toString().replace("\"", "");
			}
		}

		getBundle().setProperty("description", description);
		getBundle().setProperty("name", name);
		getBundle().setProperty("creationDate", creationDate);
		getBundle().setProperty("lastModifiedDate", lastModifiedDate);
		getBundle().setProperty("serviceVersions", serviceVersions);
		getBundle().setProperty("labels", labels);
		getBundle().setProperty("openApiSpecUrl", openApiSpecUrl);
		getBundle().setProperty("documentationUrl", documentationUrl);
		getBundle().setProperty("currentVersion", currentVersion);
	}

	/**
	 * 1) READ an ApiCollection batch read resource 2) Storing the valid values
	 * for 'CollectionID' and 'ServiceDesID'
	 * 
	 */
	@QAFTestStep(description = "I READ a valid CollectionID ServiceDescID")
	public static void iREADAValidCollectionIDServiceDescID() {
		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));
		getBundle().setProperty("headers", headers);
		
		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);
			Read_Discovery_GETcalls.getavalidCollectionIDwithServDes(RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ API COllecton batch resource 2) Set the invalid value for
	 * 'CollectionID' 3) valid value for 'ServiceDesID'
	 * 
	 */
	@QAFTestStep(description = "I READ an Invalid CollectionID and valid ServiceDescID")
	public static void iREADAnInvalidCollectionIDAndValidServiceDescID() {
		String errorMsg = null;
		String baseurl = getBundle().getString("MLapiURL.Admin_Url");
		String resource = getBundle().getString("MLapiURL.serviceName")
				+ getBundle().getString("apicollection.resource");
		getBundle().setProperty("env.baseurl", baseurl);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = ML_CommonStepDef.iHaveAValidApikey(getBundle().getString("common.apikey"));;

		String RESPONSE = null;

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("Batch READ successfull..", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

			Read_Discovery_GETcalls.getavalidCollectionIDwithServDes(RESPONSE);
			getBundle().setProperty("ServiceDesID", getBundle().getString("invalidServiceDescriptionID"));
		} catch (Exception e) {
			Reporter.log("Error occured during Batch Read..", MessageTypes.Fail);

			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}

			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * 1) READ ServiceVersion resource before Update 2) Setting the properties
	 * for the available key values
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I READ ServiceVersion Resource details before update")
	public void iREADServiceVersionResourceDetailsBeforeUpdate() throws Exception {

		String description = null, hostName = null, serviceVersionId = null, creationDate = null,
				lastModifiedDate = null, resourcePaths = null, versionNumber = null, openApiSpecUrl = null,
				basePath = null;

		Read_Discovery_GETcalls.iReadSpecificResourceFieldsServiceVersionDiscoveryServices();

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		for (Entry<String, JsonElement> JsonErrorObject : gson.getAsJsonObject().entrySet()) {

			if (JsonErrorObject.getKey().equalsIgnoreCase("description")) {
				description = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("hostName")) {
				hostName = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("serviceVersionId")) {
				serviceVersionId = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("creationDate")) {
				creationDate = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("lastModifiedDate")) {
				lastModifiedDate = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("resourcePaths")) {
				resourcePaths = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("versionNumber")) {
				versionNumber = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("openApiSpecUrl")) {
				openApiSpecUrl = JsonErrorObject.getValue().toString().replace("\"", "");
			}

			if (JsonErrorObject.getKey().equalsIgnoreCase("basePath")) {
				basePath = JsonErrorObject.getValue().toString().replace("\"", "");
			}

		}

		getBundle().setProperty("description", description);
		getBundle().setProperty("hostName", hostName);
		getBundle().setProperty("creationDate", creationDate);
		getBundle().setProperty("lastModifiedDate", lastModifiedDate);
		getBundle().setProperty("resourcePaths", resourcePaths);
		getBundle().setProperty("versionNumber", versionNumber);
		getBundle().setProperty("openApiSpecUrl", openApiSpecUrl);
		getBundle().setProperty("basePath", basePath);
	}

}
