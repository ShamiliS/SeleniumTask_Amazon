package com.heb.automation.steps.Appversion;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.http.HttpStatus;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ReusableUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.core.util.MultivaluedMapImpl;
//import com.heb.automation.common.ValidationUtils;

public class ML_CommonStepDef extends RestWSTestCase {

	/**
	 * Read request for sub collection level App version
	 * 1. Retrieving Data from the response using GSON iOS App version Android 
	 * AppID value Description value Total appversion available
	 * 2. Get the Platform versions
	 * 
	 * @throws IOException
	 * @throws ProcessingException
	 */

	@QAFTestStep(description = "I get the App version with appID {0}")
	public void iGetTheAppVersionWithAppID(String appid) throws Exception {

		String resource = getBundle().getString("appversion.resource") + "/" + appid;
		String baseurl = getBundle().getString("MLapiURL.AppversionFlex");

		Reporter.log("API call" + baseurl + resource);

		getBundle().setProperty("env.baseurl", baseurl);

		String iOSVersion = null, AndroidVersion = null, WindowsMobileVersion = null;

		MultivaluedMap queryParams = new MultivaluedMapImpl();
		queryParams.add("key", getBundle().getString("common.apikey"));
		queryParams.add("Content-Type", getBundle().getString("common.Content-Type.JSON"));
		queryParams.add("appid", appid);

		String Response = CommonUtils.GET(resource, queryParams);

		ReusableUtils.writeJSONreponse(Response, appid);
		ReusableUtils.validateJSONschema("AppversionSchema", appid);

		JsonElement gson = new Gson().fromJson(Response, JsonElement.class);
		String appIDvalue = gson.getAsJsonObject().get("appId").toString().replace("\"", "");
		String Description = gson.getAsJsonObject().get("description").toString().replace("\"", "");
		String appversionslist = gson.getAsJsonObject().get("appVersions").toString().replace("\"", "");

		Reporter.log("APPID		:" + appIDvalue, MessageTypes.Info);
		Reporter.log("Description	:" + Description, MessageTypes.Info);
		Reporter.log("appversionslist :" + appversionslist, MessageTypes.Info);

		JsonArray jArray = gson.getAsJsonObject().getAsJsonArray("appVersions");

		Reporter.log("No of Platforms: " + jArray.size(), MessageTypes.Pass);

		for (JsonElement listIterator : jArray) {

			if (listIterator.getAsJsonObject().get("osName").toString().replace("\"", "").equals("iOs")) {

				iOSVersion = listIterator.getAsJsonObject().get("osVersion").toString().replace("\"", "");
				Reporter.log("iOS App Version number: " + iOSVersion, MessageTypes.Info);
				System.out.println("iOS App Version" + iOSVersion);
			} else if (listIterator.getAsJsonObject().get("osName").toString().replace("\"", "").equals("Android")) {
				AndroidVersion = listIterator.getAsJsonObject().get("osVersion").toString().replace("\"", "");
				Reporter.log("Version number: " + AndroidVersion, MessageTypes.Info);
				System.out.println("Android version Number :" + AndroidVersion);
			} else if (listIterator.getAsJsonObject().get("osName").toString().replace("\"", "")
					.equals("Windows 10 Mobile")) {

				WindowsMobileVersion = listIterator.getAsJsonObject().get("osVersion").toString().replace("\"", "");
				Reporter.log("Version number: " + WindowsMobileVersion, MessageTypes.Info);
				System.out.println("WindowsMobileVersion  Number :" + WindowsMobileVersion);
			}
		}
	}

	/**
	 * Retrieving Data from the response using GSON iOS App version Android
	 * AppID value Description value Total Appversion available
	 * 1. Get the Platform versions
	 * 2. JSON Schema Validation
	 */
	@QAFTestStep(description = "I validate the Appversion read response")
	public void iValidateTheAppversionReadResponse() throws Exception {
		String RESPONSE = getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);

		String appIDvalue = gson.getAsJsonObject().get("appId").toString().replace("\"", "");
		String appversionslist = gson.getAsJsonObject().get("appVersions").toString().replace("\"", "");

		Reporter.log("APPID		:" + appIDvalue, MessageTypes.Info);
		Reporter.log("appversionslist :" + appversionslist, MessageTypes.Info);

		JsonArray jArray = gson.getAsJsonObject().getAsJsonArray("appVersions");
		Reporter.log("No of Platforms: " + jArray.size(), MessageTypes.Pass);

		if (jArray.isJsonNull()) {
			Reporter.log("App Version details are not available for the App Id: " + appIDvalue, MessageTypes.Info);
		} else {
			for (JsonElement listIterator : jArray) {
				String osName = listIterator.getAsJsonObject().get("osName").toString().replace("\"", "");
				String osVersion = listIterator.getAsJsonObject().get("osVersion").toString().replace("\"", "");
				Reporter.log("OS Name: " + osName + ", OS Version: " + osVersion, MessageTypes.Info);
			}
		}

		ReusableUtils.writeJSONreponse_ApiDiscovery(RESPONSE, "CP_AppVersion_FullSuccess");
		ReusableUtils.validateJSONschema_ApiDiscovery("CP_AppVersion_Schema", "CP_AppVersion_FullSuccess");

	}


	/**
	 * Read request for sub collection resource with invalid appId
	 * @param appid
	 */
	@QAFTestStep(description = "I READ Appversion from with Invalid appID {0}")
	public void iREADAppversionFromWithInvalidAppID(String appid) {

		String RESPONSE = null;
		String resource = getBundle().getString("MLapiURL.versionServiceName")
				+ getBundle().getString("MLapiURL.resource") + "/" + appid;
		String baseurl = getBundle().getString("MLapiURL.AppversionFlex");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");
		
		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Successfully Read new App Id!", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error while reading new App Id!", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}

	/**
	 *
	 */
	@QAFTestStep(description = "Check for Access-Control-Allow-Origin header using origin {0} on domain {1} and resource {2}")
	public void checkAccessControlAllowOriginHeader(String origin, String domain, String resource) {
		ClientResponse response = corsResponse(origin, domain, resource);
		int status = response.getStatus();
		if(status == HttpStatus.SC_OK && response.getHeaders().containsKey("Access-Control-Allow-Origin")) {
			Reporter.log("Request from " + origin + " to " +  domain + " was successful", MessageTypes.Pass);
		} else {
			Reporter.log("Request from " + origin + " to " +  domain + " was rejected", MessageTypes.Fail);
		}
	}
	
	/**
	 *
	 */
	@QAFTestStep(description = "Check for CORS error using origin {0} on domain {1} and resource {2}")
	public void checkCorsError(String origin, String domain, String resource) {
		ClientResponse response = corsResponse(origin, domain, resource);
		int status = response.getStatus();
		if(status == HttpStatus.SC_FORBIDDEN) {
			Reporter.log("Request from " + origin + " to " +  domain + " was rejected", MessageTypes.Pass);
		} else {
			Reporter.log("Request from " + origin + " to " +  domain + " should have been rejected", MessageTypes.Fail);
		}
	}
	
	private ClientResponse corsResponse(String origin, String domain, String resource) {
		// origin is a restricted header
		System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
		Reporter.log("API call" + domain + resource);
		getBundle().setProperty("env.baseurl", domain);

		Map<String, String> headers = new HashMap<String,String>();
		headers.put("origin", origin);
		headers.put("x-api-key", getBundle().getString("common.apikey"));
		
		JsonObject obj = new JsonObject();
		obj.addProperty("value", "test");
		ClientResponse response = CommonUtils.POST(resource, new MultivaluedMapImpl(), headers, obj);

		Reporter.log(response.toString());
		return response;
	}
}
