package com.heb.automation.steps.Discoveryservices;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.io.IOException;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.heb.automation.common.CommonUtils;
import com.heb.automation.common.ErrorMessage;
import com.heb.automation.common.ReusableUtils;
import com.heb.automation.common.endpoints.constants.ApiDiscovery_Client_Constants;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class ML_DiscoveryserviceStepDef {

	/**
	 * 1) GET the discovery services resource with valid or Invalid CollectionID
	 * 2) If success, Store the response in 'APIresponse' 3) If failure, Store
	 * the error response in 'errorMsg'
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "launch the Discover service API with collectionID as {0}")
	public void launchTheDiscoverServiceAPIWithCollectionIDAs(String CollectionID) throws Exception {

		String errorMsg = null;
		String baseurl = getBundle().getString("MLDiscoveryAPI.DiscoveryURL");
		String resource = getBundle().getString("MLDiscoveryAPI.serviceName")
				+ getBundle().getString("MLDiscoveryAPI.resource") + "/" + CollectionID;

		getBundle().setProperty("env.baseurl", baseurl);
		getBundle().setProperty("CollectionID", CollectionID);

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.GET(resource, headers);
			Reporter.log("READ is successfull", MessageTypes.Pass);
			getBundle().setProperty("APIresponse", RESPONSE);

		} catch (Exception e) {
			Reporter.log("Error occured during Read..", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
			Reporter.log(errorMsg);
		}
	}

	/**
	 * Auto-generated code snippet by QMetry Automation Framework.
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "Validate Discovery serviceDescription Object")
	public void validateDiscoveryServiceDescriptionObject() throws Exception {

		ReusableUtils.writeJSONreponse(ConfigurationManager.getBundle().getString("APIresponse"), "acol_test1");
		ReusableUtils.validateJSONschema("DS_Apicollection_Schema", "acol_test1");

	}

	@QAFTestStep(description = "check for BAD API request with collectionID as {0}")
	public void checkForBADAPIRequestWithCollectionIDAs(String collectionID) throws ProcessingException, IOException {
		String resource = getBundle().getString("apicollection.resource") + "/" + collectionID;
		/*
		 * API specific parameters QUERY PARAMETER
		 */

		MultivaluedMap queryParams = new MultivaluedMapImpl();
		queryParams.add("key", getBundle().getString("common.apikey"));

		String Response = CommonUtils.GET(resource, queryParams);

	}

	/**
	 * Validating the READ response for full success 1) Response status 2)
	 * Schema validation 3) Required fields
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I Validate the response for Full success of Discovery services Customer Portal Read")
	public static void IvalidateTheResponseForFullSuccessOfDiscoveryServicesCustomerPortalRead() throws Exception {
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		ReusableUtils.writeJSONreponse(RESPONSE, "Discovery_Read");
		ReusableUtils.validateJSONschema("DS_Apicollection_Schema", "Discovery_Read");
		
		ReusableUtils.validateRequiredFieldsInResponse("Discovery_Customer_Read_Success", RESPONSE);

		ReusableUtils.responseStatusforOK();
	}

	/**
	 * Validating the Error response 1) Error code 2) Message section is
	 * available in the response
	 * 
	 * @param errorCode
	 */

	@QAFTestStep(description = "I Validate the Discovery_Customer portal response {0}_Error for invalid collection Id")
	public void iValidateTheDiscovery_CustomerPortalResponse_ErrorForInvalidCollectionId(int errorCode) {

		String actErrorMsg = (String) getBundle().getProperty("errorMsg");

		ErrorMessage.validateErrorResponse(errorCode);
		ErrorMessage.validateMessageFieldFromErrorResponse(actErrorMsg);
	}

	/**
	 * Validate the service description fields available 1) Response code 2)
	 * Schema validation 3) Required fields are available in the response
	 * 
	 * @throws Exception
	 * @throws IOException
	 */
	@QAFTestStep(description = "I validate Discovery Service customer portal_service Description fields")
	public void iValidateDiscoveryServiceCustomerPortal_serviceDescriptionFields() throws Exception, IOException {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray SD_Array = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");
		String CollectionID = getBundle().getString("CollectionID");

		if (SD_Array.toString().equalsIgnoreCase("[]")) {
			Reporter.log("No AppVersions available for the Collection Id " + CollectionID, MessageTypes.Info);
		} else {
			ReusableUtils.writeJSONreponse(SD_Array.toString(), "Discovery_SD_Read");
			ReusableUtils.validateJSONschema_ApiDiscovery("ServiceDescription_ReadBatch_Schema", "Discovery_SD_Read");
			ReusableUtils.validateRequiredFieldsInResponse("Discovery_Customer_SD_Read_Success", SD_Array.toString());
			ReusableUtils.responseStatusforOK();
		}
	}

	/**
	 * Validate the service version fields available 1) Response code 2)
	 * Schema validation 3) Required fields are available in the response
	 * 
	 * @throws Exception
	 * @throws IOException
	 */
	
	@QAFTestStep(description = "I validate Discovery Service customer portal_service Version fields")
	public void iValidateDiscoveryServiceCustomerPortal_serviceVersionFields() throws Exception {

		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");
		// String CollectionID = getBundle().getString("CollectionID");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray SD_Array = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

		for (JsonElement currentJsonItem : SD_Array) {

			JsonArray SV_Array = (JsonArray) currentJsonItem.getAsJsonObject().get("serviceVersions");
			String ServiceDesc = currentJsonItem.getAsJsonObject().get(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID).toString().replace("\"", "");

			if (SV_Array.isJsonNull()) {
				Reporter.log("No Service Versions available for Service Description Id " + ServiceDesc,
						MessageTypes.Info);
			} else {
				Reporter.log(SV_Array.toString());
				ReusableUtils.validateRequiredFieldsInResponse("Discovery_Customer_SV_Read_Success",
						SV_Array.toString());
			}
		}
		ReusableUtils.responseStatusforOK();
	}

	
	/**
	 * Validate the ResourcePath fields available 1) Response code 2)
	 * Schema validation 3) Required fields are available in the response
	 * 
	 * @throws Exception
	 * @throws IOException
	 */
	@QAFTestStep(description = "I validate Discovery Service customer portal_Resource Path fields")
	public void iValidateDiscoveryServiceCustomerPortal_ResourcePathFields() throws Exception {
		
		String RESPONSE = ConfigurationManager.getBundle().getString("APIresponse");

		JsonElement gson = new Gson().fromJson(RESPONSE, JsonElement.class);
		JsonArray SD_Array = (JsonArray) gson.getAsJsonObject().get("serviceDescriptions");

		for (JsonElement SD_Ele : SD_Array) {

			JsonArray SV_Array = (JsonArray) SD_Ele.getAsJsonObject().get("serviceVersions");
			String ServiceDesc = SD_Ele.getAsJsonObject().get(ApiDiscovery_Client_Constants.SERVICE_DESCRIPTION_PROPERTY_ID).toString().replace("\"", "");

			for (JsonElement SV_Ele : SV_Array) {

				JsonArray RP_Array = (JsonArray) SV_Ele.getAsJsonObject().get("resourcePaths");

				if (RP_Array.isJsonNull()) {
					Reporter.log("No Service Versions available for Service Description Id " + ServiceDesc,
							MessageTypes.Info);
				} else {
					Reporter.log(RP_Array.toString());
					ReusableUtils.validateRequiredFieldsInResponse("Discovery_Customer_RP_Read_Success",
							RP_Array.toString());
				}
			}
		}
		ReusableUtils.responseStatusforOK();
	}
}