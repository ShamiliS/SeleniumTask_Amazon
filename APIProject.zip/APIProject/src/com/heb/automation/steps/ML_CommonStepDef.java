package com.heb.automation.steps;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.google.gson.JsonArray;
import com.heb.automation.common.CommonUtils;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.qmetry.qaf.automation.ws.rest.RestWSTestCase;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class ML_CommonStepDef extends RestWSTestCase {

	/**
	 * Setting the queryparams value with valid apikey
	 * 
	 * @return queryParams apikey
	 */
	@QAFTestStep(description = "i have a valid apikey {0}")
	public static Map<String, String> iHaveAValidApikey(String apikey) {

		Map<String, String> headers = new HashMap<String, String>();

		headers.put("x-api-key", apikey);
		headers.put("Referer", getBundle().getString("common.Referer"));
		
		getBundle().setProperty("headers", headers);

		return headers;
	}

	/**
	 * Setting the queryparams value with invalid apikey
	 * 
	 * @return queryParams apikey
	 */
	@QAFTestStep(description = "i have a In-valid apikey {0}")
	public Map<String, String> iHaveAInValidApikey(String apikey) {

		Map<String, String> headers = new HashMap<String, String>();

		headers.put("x-api-key", apikey);
		headers.put("Referer", getBundle().getString("common.Referer"));
		
		getBundle().setProperty("headers", headers);

		return headers;
	}

	/**
	 * POST request for creating resource with non-SSL url "http"
	 */
	@QAFTestStep(description = "I POST create Resource using non-SSL url http")
	public void iPOSTCreateResourceUsingNonSSLUrlHttp() {
		String baseurl = getBundle().getString("http://adminportal-dot-heb-javaapptest.appspot.com");
		String resource = getBundle().getString("AppProperty.CreateBatch");
		String errorMsg = null;
		getBundle().setProperty("env.baseurl", baseurl);
		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		@SuppressWarnings("unchecked")
		Map<String, String> headers = (Map<String, String>) getBundle()
				.getProperty("headers");

		try {
			String RESPONSE = CommonUtils.POST(resource, headers, BodyParamter);
			Reporter.log("non- SSL Error", MessageTypes.Fail);
			getBundle().setProperty("APIresponse", RESPONSE);
		} catch (Exception e) {
			Reporter.log("non- SSL Error as expected ", MessageTypes.Pass);
			try {
				errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			} catch (Exception f) {
				errorMsg = new RestTestBase().getResponse().toString();
			}
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * Read and validate AppVersion information for given APPID
	 * 
	 * @param appid
	 *            appId of AppVersion
	 * @throws Exception
	 */
	@QAFTestStep(description = "I READ Appversion from with appID {0}")
	public void iREADAppversionFromWithAppID(String appid) throws Exception {

		String RESPONSE = null;
		String resource = getBundle().getString("MLapiURL.versionServiceName")
				+ getBundle().getString("MLapiURL.resource") + "/" + appid;
		String baseurl = getBundle().getString("MLapiURL.AppversionFlex");

		getBundle().setProperty("env.baseurl", baseurl);

		
		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Successfully created new App Id!", MessageTypes.Pass);
		} catch (Exception e) {
			Reporter.log("Error while creating new App Id!", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}

	}

	/**
	 * Read and validate AppVersion information for given invalid APPID
	 * 
	 * @param appid
	 *            appId of AppVersion
	 * @throws Exception
	 */
	@QAFTestStep(description = "I READ Appversion from with appID {0} with Invalid APIKey")
	public void iREADAppversionFromWithAppIDWithInvalidAPIKey(String appid) throws Exception {

		String RESPONSE = null;
		String resource = getBundle().getString("MLapiURL.versionServiceName")
				+ getBundle().getString("MLapiURL.resource") + "/" + appid;
		String baseurl = getBundle().getString("MLapiURL.AppversionFlex");

		getBundle().setProperty("env.baseurl", baseurl);

		JsonArray BodyParamter = (JsonArray) getBundle().getProperty("BodyParametervalue");

		Map<String, String> headers = (Map<String, String>) getBundle().getProperty("headers");

		try {
			RESPONSE = CommonUtils.GET(resource, headers);
			getBundle().setProperty("APIresponse", RESPONSE);
			Reporter.log("Successfully created new App Id!", MessageTypes.Fail);
		} catch (Exception e) {
			Reporter.log("Error while creating new App Id!", MessageTypes.Pass);
			String errorMsg = new RestTestBase().getResponse().getMessageBody().toString();
			getBundle().setProperty("errorMsg", errorMsg);
		}
	}
}
