package test.java.com.Amazon_SeleniumTask.Pages;

import org.openqa.selenium.By;

public class EditBasketTestPage {

	public static final By btnEditBasket = By.id("hlb-view-cart-announce");

	public static final By lblProductTitle = By
			.xpath("//span[contains(@class,'product-title')]");

	public static final By lblType = By
			.xpath("//span[contains(@class,'product-binding')]");

	public static final By lblPrice = By
			.xpath("//span[contains(@class,'product-price')]");

	public static final By lblQuantity = By
			.xpath("//*[@id='a-autoid-2-announce']/span[@class='a-dropdown-prompt']");

	public static final By lblTotalPrice = By
			.xpath("//*[@id='sc-subtotal-amount-activecart']/span");

	public static By getBtneditbasket() {
		return btnEditBasket;
	}

	public static By getLblproducttitle() {
		return lblProductTitle;
	}

	public static By getLbltype() {
		return lblType;
	}

	public static By getLblprice() {
		return lblPrice;
	}

	public static By getLblquantity() {
		return lblQuantity;
	}

	public static By getLbltotalprice() {
		return lblTotalPrice;
	}

}
