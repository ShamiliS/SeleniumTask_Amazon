package test.java.com.Amazon_SeleniumTask.Pages;

import org.openqa.selenium.By;

public class HomeTestPage {
	
	public static final By lblHelloSignIn = By.xpath("//span[.=\'Hello. Sign in\']");

    public static final By lblHello = By.xpath("//span[contains(.,\'Hello,\')]");

    public static final By btnSignInFromMouseHover = By
            .xpath("//div[@id=\'nav-flyout-ya-signin\']//span[.=\'Sign in\']");

    public static final By txtSearch = By.xpath("//input[@type=\'text\']");

    public static final By btnSearch = By.xpath("//input[@type=\'submit\']");

    public static By getTxtsearch() {
        return txtSearch;
    }

    public static By getBtnsearch() {
        return btnSearch;
    }

    public static By getLblhellosignin() {
        return lblHelloSignIn;
    }

    public static By getLblhello() {
        return lblHello;
    }

    public static By getBtnsigninfrommousehover() {
        return btnSignInFromMouseHover;
    }

}
