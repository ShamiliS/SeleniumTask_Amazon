package test.java.com.Amazon_SeleniumTask.Pages;

import org.openqa.selenium.By;

public class LoginTestPage {

	public static final By txtEmail = By.xpath("//input[@type=\'email\']");

	public static final By txtPassword = By
			.xpath("//input[@type=\'password\']");

	public static final By btnSignInSubmit = By
			.xpath("//input[@id=\'signInSubmit\']");

	public static By getTxtemail() {
		return txtEmail;
	}

	public static By getTxtpassword() {
		return txtPassword;
	}

	public static By getBtnsigninsubmit() {
		return btnSignInSubmit;
	}

}
