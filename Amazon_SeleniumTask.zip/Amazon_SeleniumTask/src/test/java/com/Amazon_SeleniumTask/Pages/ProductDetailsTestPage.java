package test.java.com.Amazon_SeleniumTask.Pages;

import org.openqa.selenium.By;

public class ProductDetailsTestPage {

	public static final By lblBookTitle = By.id("ebooksProductTitle");

	public static final By lblBadge = By.xpath("//*[text(),'Best Seller']");

	public static final By lstSwatches = By
			.xpath("//*[@id='tmmSwatches']/ul/li");

	public static final By btnAddtoCart = By
			.xpath("//input[@id=\'add-to-cart-button\']");

	public static final By btnProceedtoCheckout = By
			.xpath("//a[@id=\'hlb-ptc-btn-native\']");

	public static final By AddToCartTitle = By
			.xpath("//*[@id='a-popover-header-3']//div[@class='a-color-base']");

	public static By getBtnaddtocart() {
		return btnAddtoCart;
	}

	public static By getBtnproceedtocheckout() {
		return btnProceedtoCheckout;
	}

	public static By lblBooktype(int val) throws Exception {
		By annouce = null;
		annouce = By.xpath("//*[@id='tmmSwatches']/ul/li['" + val
				+ "']//*[contains(@id,'announce')]/span[1]");
		return annouce;
	}

	public static By lblBookprice(int val) throws Exception {
		By price = null;
		price = By.xpath("//*[@id='tmmSwatches']/ul/li['" + val
				+ "']//*[contains(@id,'announce')]/span/span");
		return price;
	}

	public static By getLblbooktitle() {
		return lblBookTitle;
	}

	public static By getLblbadge() {
		return lblBadge;
	}

	public static By getLstswatches() {
		return lstSwatches;
	}

	public static By getAddtocarttitle() {
		return AddToCartTitle;
	}
}
