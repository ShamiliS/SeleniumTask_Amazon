package test.java.com.Amazon_SeleniumTask.Pages;

import org.openqa.selenium.By;

public class SearchResultsTestPage {

	public static final By lblyourstore = By
			.xpath("//*[@id='nav-link-yourAccount']/span[contains(text(),'Hello,')]");

	public static final By lblBookslist = By
			.xpath("//*[@id='s-results-list-atf']/li[contains(@id,result)]");

	public static final By lblbadge = By.xpath("//span[@class='a-badge-text']");

	public static By getLblbadge() {
		return lblbadge;
	}

	public static By getLblbookslist() {
		return lblBookslist;
	}

	public static By getLblyourstore() {
		return lblyourstore;
	}

	public static By lblBookNName(int val) throws Exception {
		By bookname = null;
		try {
			bookname = By.xpath("//*[@id='result_" + val + "']//h2");
		} catch (AssertionError Ae) {
			Ae.printStackTrace();
		}
		return bookname;
	}

	public static By lblselectedType(int val) throws Exception {
		By selectedType = null;
		selectedType = By.xpath("//*[@id='result_" + val + "']//h3");
		return selectedType;
	}

	public static By lblPrice(int val, String SelectedType) throws Exception {
		By price = null;
		price = By
				.xpath("//*[@id='result_"
						+ val
						+ "']//a[@title='"
						+ SelectedType
						+ "']/../following-sibling::div/a/span[contains(@class,'s-price')]");
		return price;
	}

	public static By lblBookName(String BookName) throws Exception {
		By book = null;
		book = By.xpath("//a[@title='" + BookName + "']");
		return book;
	}

}
