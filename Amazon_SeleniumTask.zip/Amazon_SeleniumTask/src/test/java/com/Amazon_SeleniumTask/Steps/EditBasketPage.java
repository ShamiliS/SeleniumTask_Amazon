package test.java.com.Amazon_SeleniumTask.Steps;

import java.util.Map;

import org.openqa.selenium.By;
import org.testng.Reporter;

import test.java.com.Amazon_SeleniumTask.Pages.EditBasketTestPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class EditBasketPage extends CommonUtils {

	@Then("^I click on Edit the basket$")
	public void I_click_on_Edit_the_basket() throws Throwable {
		By editBasket = EditBasketTestPage.getBtneditbasket();

		if (driver.findElement(editBasket).isDisplayed()) {
			driver.findElement(editBasket).click();
		}
	}

	@And("^I Verify that the book is shown on the list$")
	public void I_Verify_that_the_book_is_shown_on_the_list() throws Throwable {

		By lblTitle = EditBasketTestPage.getLblproducttitle();
		By lblType = EditBasketTestPage.getLbltype();
		By lblPrice = EditBasketTestPage.getLblprice();
		By lblQuantity = EditBasketTestPage.getLblquantity();
		By lblTotalPrice = EditBasketTestPage.getLbltotalprice();

		Map<String, String> userDetails = CommonUtils.readDatafromXMLFile();

		String strBookTitle = userDetails.get("Title");
		String strprice = userDetails.get("SelectedType");
		String strType = userDetails.get("Price");
		String intQuantity = userDetails.get("Quantity");

		// Validate the Title
		String title = driver.findElement(lblTitle).getText();
		if (title.equals(strBookTitle)) {
			Reporter.log("The Book Title " + title
					+ " is displayed as expected");
		} else {
			Reporter.log("The Book Title is not displayed as expected");
		}

		// Validate the Book Price
		String price = driver.findElement(lblPrice).getText();
		if (price.equals(strprice)) {
			Reporter.log("The Book Price " + price
					+ " is displayed as expected");
		} else {
			Reporter.log("The Book Price is not displayed as expected");
		}

		// Validate the Type
		String Type = driver.findElement(lblType).getText();
		if (Type.equals(strType)) {
			Reporter.log("The Book Type " + Type + " is displayed as expected");
		} else {
			Reporter.log("The Book Type is not displayed as expected");
		}

		// Validate the Quantity
		String Quantity = driver.findElement(lblQuantity).getText();
		int quan = Integer.parseInt(Quantity);
		
		if(quan==1){
			Reporter.log("The Quantity is displayed as 1");
		} else {
			Reporter.log("The Quantity is not displayed correctly");
		}
		
		// Validate the TotalPrice
		String totalprice = driver.findElement(lblTotalPrice).getText();
		if (totalprice.equals(strprice)) {
			Reporter.log("The Book Price " + price
					+ " is displayed as expected");
		} else {
			Reporter.log("The Book Price is not displayed as expected");
		}
	}
}
