package test.java.com.Amazon_SeleniumTask.Steps;

import java.util.List;
import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;

public class HomePage extends CommonUtils {

	List<Map<String, String>> data;

	@Given("^launch application URL$")
	public void launch_application_URL(DataTable launchDetails)
			throws Throwable {
		data = launchDetails.asMaps(String.class, String.class);

		String browserType = data.get(0).get("BrowserType");
		String appURL = data.get(0).get("AppURL");

		CommonUtils.setDriver(browserType, appURL);
	}
	
	@After
	public void teardown() {
		driver.close();
		driver.quit();
	}
}
