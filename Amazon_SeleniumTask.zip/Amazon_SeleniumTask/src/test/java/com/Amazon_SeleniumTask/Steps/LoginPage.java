package test.java.com.Amazon_SeleniumTask.Steps;

import java.util.List;
import java.util.Map;

import org.testng.Reporter;

import test.java.com.Amazon_SeleniumTask.Pages.HomeTestPage;
import test.java.com.Amazon_SeleniumTask.Pages.LoginTestPage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;

public class LoginPage extends CommonUtils {

	List<Map<String, String>> data;

	@Given("^login into the application using valid credentials$")
	public void login_into_the_application_using_valid_credentials(
			DataTable UserCredentials) throws Throwable {

		data = UserCredentials.asMaps(String.class, String.class);

		String Email = data.get(0).get("EmailAddress");
		String Password = data.get(0).get("Password");
		System.out.println(driver);
		CommonUtils.mousehover(driver,
				driver.findElement(HomeTestPage.getLblhellosignin()));
		driver.findElement(HomeTestPage.getBtnsigninfrommousehover()).click();

		if (driver.findElement(LoginTestPage.getTxtemail()).isDisplayed()) {
			Reporter.log("Navigated to Login Page.");

			driver.findElement(LoginTestPage.getTxtemail()).sendKeys(Email);
			driver.findElement(LoginTestPage.getTxtpassword()).sendKeys(
					Password);
			Reporter.log("Entered Username and Password..");

			driver.findElement(LoginTestPage.getBtnsigninsubmit()).click();
			Reporter.log("Clicked on Submit button..");

		} else {
			Reporter.log("Not navigated to Login page.");
		}

	}

}

