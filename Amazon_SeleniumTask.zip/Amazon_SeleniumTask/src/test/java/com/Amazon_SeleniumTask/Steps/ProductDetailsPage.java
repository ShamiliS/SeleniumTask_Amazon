package test.java.com.Amazon_SeleniumTask.Steps;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import test.java.com.Amazon_SeleniumTask.Pages.ProductDetailsTestPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ProductDetailsPage extends CommonUtils {

	@Then("^I validate the book details page of \"([^\"]*)\"$")
	public void I_validate_the_book_details_page_of(String TitleName)
			throws Throwable {

		By byTitle = ProductDetailsTestPage.getLblbooktitle();
		By byBadge = ProductDetailsTestPage.getLblbadge();
		By bySwatches = ProductDetailsTestPage.getLstswatches();
		Map<String, String> userDetails = CommonUtils.readDatafromXMLFile();

		String strbadge = userDetails.get("Badge");
		String strprice = userDetails.get("SelectedType");
		String strType = userDetails.get("Price");

		Reporter.log("Selected Book is " + TitleName);

		// Verify the Title
		String bookTitle = driver.findElement(byTitle).getText();
		if (bookTitle.equals(TitleName)) {
			Reporter.log("The Page Title " + bookTitle
					+ " is displayed as expected");
		} else {
			Reporter.log("The Page Title " + bookTitle
					+ " is not displayed as expected");
		}

		// Verify the Badge
		String badge = driver.findElement(byBadge).getText();
		if (badge.equals(strbadge)) {
			Reporter.log("The Badge " + badge + " is displayed as expected");
		} else {
			Reporter.log("The badge " + badge + " is not displayed as expected");
		}

		// Get the list Size
		List<WebElement> lstEle = driver.findElements(bySwatches);
		int cnt = lstEle.size();

		for (int i = 0; i < cnt; i++) {
			By byprice = ProductDetailsTestPage.lblBookprice(i);
			String price = driver.findElement(byprice).getText();
			// Verify the Price
			if (price.equals(strprice)) {
				Reporter.log("The price is dispalyed as expected");
				By byType = ProductDetailsTestPage.lblBooktype(i);
				String type = driver.findElement(byType).getText();
				if (type.equals(strType)) {
					Reporter.log("The type of book is dispalyed as expected");
				} else {
					Reporter.log("The type of book is not dispalyed as expected");
				}
			}
		}
	}

	@And("^I Add book to the Basket$")
	public void I_Add_book_to_the_Basket() throws Throwable {
		By byaddtocart = ProductDetailsTestPage.getBtnaddtocart();
		By AddtoBasketTitle = ProductDetailsTestPage.getAddtocarttitle();
		Map<String, String> userDetails = CommonUtils.readDatafromXMLFile();

		String strBookTitle = userDetails.get("Title");

		driver.findElement(byaddtocart).click();
		String getTitle = driver.findElement(AddtoBasketTitle).getText();

		if (getTitle.contains(strBookTitle)) {
			Reporter.log("The book is displayed with title as " + getTitle);
		} else {
			Reporter.log("Error in adding into the Cart..");
		}

		driver.switchTo().alert().dismiss();
	}
}
