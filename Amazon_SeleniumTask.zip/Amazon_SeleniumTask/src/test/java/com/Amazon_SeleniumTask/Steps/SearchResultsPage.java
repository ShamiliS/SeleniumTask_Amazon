package test.java.com.Amazon_SeleniumTask.Steps;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

import test.java.com.Amazon_SeleniumTask.Pages.HomeTestPage;
import test.java.com.Amazon_SeleniumTask.Pages.SearchResultsTestPage;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchResultsPage extends CommonUtils {

	@Given("^Enter search term \"(.*)\"$")
	public void Enter_search_term_Book(String searchTerm) throws Throwable {

		driver.findElement(HomeTestPage.getTxtsearch()).sendKeys(searchTerm);
		Reporter.log("Entered search term..");
	}

	@When("^I click search$")
	public void I_click_search() throws Throwable {

		driver.findElement(HomeTestPage.btnSearch).click();
		Reporter.log("Clicked on Search button..");
	}

	@Then("^I verify the page is correct and opened$")
	public void I_verify_the_page_is_correct_and_opened() throws Throwable {

		try {
			driver.findElement(HomeTestPage.getLblhellosignin());
			Reporter.log("The page is not opened correctly..");
		} catch (org.openqa.selenium.NoSuchElementException e) {
			Reporter.log("The page is opened correctly..");
			if (driver.findElement(HomeTestPage.getLblhello()).isDisplayed()) {
				Reporter.log("Login successful..");
			} else {
				Reporter.log("Error occured during login..");
			}
		}

	}

	@Then("^I Verify that the first items has the title \"([^\"]*)\"$")
	public void I_Verify_that_the_first_items_has_the_title(String TitleName)
			throws Throwable {
		String titleofbook, selType, bookprice;
		By bybadge = SearchResultsTestPage.getLblbadge();

		Map<String, String> BookDetails = CommonUtils.readDatafromXMLFile();

		String strType = BookDetails.get("Type");
		String strprice = BookDetails.get("Price");

		List<WebElement> lblbookname = driver
				.findElements(SearchResultsTestPage.getLblbookslist());

		int count = lblbookname.size();

		if (count > 0) {
			for (int i = 0; i <= count; i++) {
				WebElement bookname = driver.findElement(SearchResultsTestPage
						.lblBookNName(i));
				titleofbook = bookname.getText();
				if (titleofbook.equals(TitleName)) {

					Reporter.log("The items is titleed as " + TitleName);

					// Verify it has a badge "Best Seller
					WebElement lblbadge = driver.findElement(bybadge);
					Assert.assertTrue(
							lblbadge.isDisplayed(),
							"The page is displayed with badge as "
									+ lblbadge.getText());

					// Verify Selected type is Paperback
					List<WebElement> SelectedTypelist = driver
							.findElements(SearchResultsTestPage
									.lblselectedType(i));
					int cnt = SelectedTypelist.size();

					for (int j = 0; j <= cnt; j++) {
						List<WebElement> selectedtype = driver
								.findElements(SearchResultsTestPage
										.lblselectedType(i));
						selType = selectedtype.get(j).getText();

						if (selType.equals("Paperback")) {
							Reporter.log("The selected type is " + selType
									+ " as expected");

							// Verify the price of the book
							By price = SearchResultsTestPage.lblPrice(i,
									selType);
							bookprice = driver.findElement(price).getText();
							if (bookprice.equals(strType)) {
								selectedtype.get(j).click();
								Reporter.log("The price " + selectedtype
										+ " is displayed as expected");
								break;
							} else {
								Reporter.log("The price is not displayed as expected");
							}
						} else {
							Reporter.log("The selected type is not present as expected");
						}
					}
				}

			}
		}

	}

}
