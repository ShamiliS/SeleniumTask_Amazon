package test.java.com.Amazon_SeleniumTask.runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "feature", glue = { "test.java.com.Amazon_SeleniumTask.Steps" })
public class TestRun extends AbstractTestNGCucumberTests {

}