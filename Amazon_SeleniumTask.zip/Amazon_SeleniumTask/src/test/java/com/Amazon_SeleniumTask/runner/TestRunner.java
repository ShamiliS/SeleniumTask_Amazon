package test.java.com.Amazon_SeleniumTask.runner;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "feature", glue = "test.java.com.Amazon_SeleniumTask.Steps")
public class TestRunner {

}
