'''
ConvertToXLSX.py written by Garrett Griffin

Usage:
        > python3 ConvertToXLSX.py inputFile.txt
Purpose:
        Convert the given file from text to a .loc format
        Assumes the three items given (Value, Location, Description)
        are separated by commas.
Input:
        Expected input is as follows:
        footer.txt.emailbox, id=signup-email-address, EditTextView for email address
        Note: Spaces will be okay around all items as they will be trimmed before being
        entered into the Excel table
Output:
        Expected output for the inputline above:
            footer.txt.emailbox = {"locator":" id=signup-email-address","desc":" EditTextView for email address"\}

Notes:
        1) When using this, you are able to specify the new Filename, but don't include
        the file extension. Just makes it easier down the line
        2) This program can create or append files, no issues.
'''

import os
import re
import sys

if(len(sys.argv) != 2):
    print("Incorrect number of arguements.")
    print("Usage: <inputFileName.txt>")
    sys.exit(1)

# Create and open new files
inputFileName = sys.argv[1]
inputF = open(inputFileName, 'r')

locationFP = inputF.readline()
filePathGrab = re.search(r'^(.*)\n$', locationFP)
locationOutF = open(filePathGrab.group(1), 'w')

def generateLoc(inputLine, locationOutF):
    # Regex to capture the three groups.
    # .split() has a chance to make it nasty
    outline = re.search(r'^(.*);(.*);(.*)$', inputLine)
    if outline is None:
        return
    valueName = outline.group(1)
    locationName = outline.group(2)
    desName = outline.group(3)
    var = str("%s = {\"locator\":\"%s\",\"desc\":\"%s\"}\n" % (valueName, locationName, desName))
    print(var)
    locationOutF.write(var)


# Iterate through the given file, parse the line, and add
# it to the worksheet
for line in inputF:
    generateLoc(line, locationOutF)


# Close the files
inputF.close()
locationOutF.close()
