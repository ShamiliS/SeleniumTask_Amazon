'''
GenerateScenariosCheatSheet.py written by Garrett Griffin

Usage:
    >python GenerateScenariosCheatSheet.py

Purpose:
    Generates a list of all Scenarios in the given .BDD files, with their ID Number
    as well as their description

Input:
    Only expected input is the absolute path to the directory containing all the page files.
    Will search the files for the lines beginning with SCENARIO or META, and grab relevant information
    Sample input:
        SCENARIO: User Successfully Registers New Account
        META-DATA: {"TC_ID":"REG_TC_01","enabled":true,"description":"Starting at home page..."}
Output:
    Produces a new Excel file with all scenarios on a single sheet as such:
    ID Number   Scenario                                Description
    REG_TC_01   User Successfully Registers New Account Starting at home page...

'''
import xlsxwriter as xl
import os
import sys
import re
from tkinter import filedialog
from tkinter import *

root = Tk()
root.filename =  filedialog.askdirectory(initialdir = "~\HEBToYouWebAutomation",title = "Select Scenarios Directory")
javaDirPt = root.filename.replace('\\', '/')

root = Tk()
root.filename =  filedialog.asksaveasfilename(initialdir = "~\HEBToYouWebAutomation",title = "Create output file",filetypes = (("Excel File","*.xlsx"),("all files","*.*")))
bddOutPath = root.filename.replace('\\', '/')

bddOutPath += '.xlsx'

if(os.path.isfile(bddOutPath)):
    os.remove(bddOutPath)

IDCOL = 0
SCENCOL = 1
DESCCOL = 2

# Current row sizing
sColLen = 0
iColLen = 0
dColLen = 0

currentRow = 0

# Create new workbook, and format
workbook = xl.Workbook(bddOutPath)
wbFormat = workbook.add_format({'border': True})
worksheet = workbook.add_worksheet("Scenarios")

# In beginning row, enter headers
worksheet.write(currentRow, IDCOL, "ID Number")
worksheet.write(currentRow, SCENCOL, "Scenario Name")
worksheet.write(currentRow, DESCCOL, "Description")

# Compile regex to find QAF steps.
# Sample match: 'META-DATA:{..., "TC_ID":"ACC_01", ...}'
tc_idMatch = re.compile(r'^META.*\{.*\"TC_ID\"\s*:\s*\"([\w]+.*[\d]+)\"\s*,\s*')
# Sample match: 'META-DATA:{..., "TC_ID":"ACC_01", ...}'
descriptionMatch = re.compile(r'^META.*\{.*\"description\"\s*:\s*\"(.*)\"\s*[,\}]')
# Sample match: SCENARIO: User logs into Account
scenarioMatch = re.compile(r'^SCENARIO:(.*)$')

def createCheatSheet(filename, fileInput, currentRow, sColLen, iColLen, dColLen):

    # Iterate through current java file
    for line in fileInput:
        idFound = tc_idMatch.match(line.strip())
        desFound = descriptionMatch.match(line.strip())
        scenFound = scenarioMatch.match(line.strip())

        if(idFound is not None):
            # Set column width for readability
            if(len(idFound.group(1)) > iColLen):
                iColLen = len(idFound.group(1))
                worksheet.set_column(IDCOL, IDCOL, iColLen)
            if(len(desFound.group(1)) > dColLen):
                dColLen = len(desFound.group(1))
                worksheet.set_column(DESCCOL, DESCCOL, dColLen)

            worksheet.write(currentRow, IDCOL, idFound.group(1))
            worksheet.write(currentRow, DESCCOL, desFound.group(1))
        elif(scenFound is not None):
            currentRow += 1
            if(len(scenFound.group(1)) > sColLen):
                sColLen = len(scenFound.group(1))
                worksheet.set_column(SCENCOL, SCENCOL, sColLen)
            worksheet.write(currentRow, SCENCOL, scenFound.group(1))
    return currentRow, sColLen, iColLen, dColLen

# Recursively walk through each directory and work with each file
def grabFiles():
    sColLen = 0
    iColLen = 0
    dColLen = 0
    currentRow = 1
    for root, directories, filenames in os.walk(javaDirPt):
        for filename in filenames:
            javaFileIn = open(os.path.join(root,filename), 'r')
            currentRow, sColLen, iColLen, dColLen = createCheatSheet( \
            filename, javaFileIn, currentRow, sColLen, iColLen, dColLen)
            javaFileIn.close()
            currentRow += 1

grabFiles()
workbook.close()
