'''
GenerateBDDCheatSheet.py written by Garrett Griffin

Usage:
    >python GenerateStepsCheatSheet.py

Purpose:
    Generates a list of all BDD steps, as well as a short description of what they do if they
    are not self explanatory.

Input:
    Only expected input is the absolute path to the directory containing all the page files.
    Will search through the files looking for anything beginning with '@QAFTestStep(....)', and
    grab the description. If there are comments after the @QAFTestStep, then they will also be grabbed

Output:
    Produces a new Excel file with each sheet being the page type. So, if you're looking for steps
    that involve searching, the "Search" sheet will be the place to go! Column A will contain the step,
    column B will the method name, and column C will be any comments of the method

Notes:
    1) For this to work, the method must be written as such:
    @QAFTestStep(description = "I test the website")
    /**
     * Optional Comments
    */
    public void methodName(String optionalArgs){

'''
import xlsxwriter as xl
import os
import sys
import re
from tkinter import filedialog
from tkinter import *

root = Tk()
root.filename =  filedialog.askdirectory(initialdir = "~\HEBToYouWebAutomation",title = "Select Steps Directory")
javaDirPt = root.filename.replace('\\', '/')

root = Tk()
root.filename =  filedialog.asksaveasfilename(initialdir = "~\HEBToYouWebAutomation",title = "Create output file",filetypes = (("Excel File","*.xlsx"),("all files","*.*")))
bddOutPath = root.filename.replace('\\', '/')

bddOutPath += '.xlsx'

if(os.path.isfile(bddOutPath)):
    os.remove(bddOutPath)

STEPCOL = 1
METHCOL = 2
DESCCOL = 3

# Current row sizing
sColLen = 0
mColLen = 0
dColLen = 0

# Create new workbook, and format
#workbook = xl.Workbook(bddOutPath)
workbook = xl.Workbook(bddOutPath)
wbFormat = workbook.add_format({'border': True})

# Compile regex to find QAF steps.
# Sample match: 'QAFTestStep testStep(description = 'Description')
qafMatch = re.compile(r'^\@QAFT.*\=.*\"(.*)\"\)')
# Sample match: 'public void isTestStep(String sample){'
methodMatch = re.compile(r'.*\s(.*)\((.*)\)')

def populateCheatSheet(worksheet, row, bddStep, method, description):
    worksheet.write(row, STEPCOL, bddStep, wbFormat)
    worksheet.write(row, METHCOL, method, wbFormat)
    if description:
        worksheet.write(row, DESCCOL, description, wbFormat)

# Iterates through the comment array, removing beginning and ending of the
# Javadoc. Also removes asterisks and converts the array into a String
def cleanComments(commentArray):
    tempM = []
    descLine = ""
    for line in commentArray:
        if("/**" in line or "*/" in line or line is None):
            continue
        line = line.replace("*", "")
        line = line.strip()
        tempM.append(line)
    for line in tempM:
        descLine += (line + " ")
    return descLine

def createCheatSheet(filename, fileInput):
    sColLen = 0
    mColLen = 0
    dColLen = 0
    row = 0

    # Generate current worksheet and set header
    worksheet = workbook.add_worksheet(filename)
    worksheet.write(row,0, filename.replace('.java', ''))
    row += 1
    worksheet.write(row, STEPCOL, "Steps")
    worksheet.write(row, METHCOL, "Method Name")
    worksheet.write(row, DESCCOL, "Description")
    commArray = []
    # Iterate through current java file
    for line in fileInput:
        foundStep = qafMatch.match(line.strip())
        if(foundStep is not None):
            row += 1

            # Check for comments
            while(True):
                nextLine = fileInput.readline()
                methodName = methodMatch.match(nextLine.strip())
                # Break out when method name found
                if(methodName is not None):
                    break
                else:
                    commArray.append(nextLine)
            # Convert array into a string, and clean out asterisks
            commLine = cleanComments(commArray)

            # Set column width for readability
            if(len(foundStep.group(1)) > sColLen):
                sColLen = len(foundStep.group(1))
                worksheet.set_column(STEPCOL, STEPCOL, sColLen)
            if(len(methodName.group(1)) > mColLen):
                mColLen = len(methodName.group(1))
                worksheet.set_column(METHCOL, METHCOL, mColLen)
            if(len(commLine) > dColLen):
                dColLen = len(commLine)
                worksheet.set_column(DESCCOL, DESCCOL, dColLen)
            populateCheatSheet(worksheet, row, foundStep.group(1), methodName.group(1), commLine)
            commArray = []

# Recursively walk through each directory and work with each file
def grabFiles():
    for root, directories, filenames in os.walk(javaDirPt):
        for filename in filenames:
            javaFileIn = open(os.path.join(root,filename), 'r')
            createCheatSheet(filename, javaFileIn)
            javaFileIn.close()

grabFiles()
workbook.close()
