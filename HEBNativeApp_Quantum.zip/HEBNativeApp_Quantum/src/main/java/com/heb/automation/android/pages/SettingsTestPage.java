package com.heb.automation.android.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SettingsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "settings.lbl.pagetitle")
	private QAFWebElement settingsLblPagetitle;
	@FindBy(locator = "settings.lbl.privacypolicy")
	private QAFWebElement settingsLblPrivacypolicy;
	@FindBy(locator = "settings.lbl.termsconditions")
	private QAFWebElement settingsLblTermsconditions;
	@FindBy(locator = "settings.lbl.faqs")
	private QAFWebElement settingsLblFaqs;
	@FindBy(locator = "faq.lbl.product")
	private QAFWebElement faqLblProduct;
	@FindBy(locator = "faq.lbl.general")
	private QAFWebElement faqLblGeneral;
	@FindBy(locator = "faq.lbl.shoppinglist")
	private QAFWebElement faqLblShoppinglist;
	@FindBy(locator = "faq.lbl.digitalcoupons")
	private QAFWebElement faqLblDigitalcoupons;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getSettingsLblPagetitle() {
		return settingsLblPagetitle;
	}

	public QAFWebElement getSettingsLblPrivacypolicy() {
		return settingsLblPrivacypolicy;
	}

	public QAFWebElement getSettingsLblTermsconditions() {
		return settingsLblTermsconditions;
	}

	public QAFWebElement getSettingsLblFaqs() {
		return settingsLblFaqs;
	}

	public QAFWebElement getFaqLblProduct() {
		return faqLblProduct;
	}

	public QAFWebElement getFaqLblGeneral() {
		return faqLblGeneral;
	}

	public QAFWebElement getFaqLblShoppinglist() {
		return faqLblShoppinglist;
	}

	public QAFWebElement getFaqLblDigitalcoupons() {
		return faqLblDigitalcoupons;
	}

}
