package com.heb.automation.android.steps.cartncheckout;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.cartncheckout.CartTestPage;
import com.heb.automation.common.pages.cartncheckout.CheckoutTestPage;
import com.heb.automation.common.pages.cartncheckout.ShippingaddTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in CartAndCheckOut

	I naviagte to cart page
	I see updated quantity and price
    I enter as guest checkout from Login Splash page
    I enter as guest checkout from Login Splash page
	I see checkout page
	I enter shipping address*/


public class AndroidStepDefcartncheckout{
	
	@QAFTestStep(description = "I naviagte to cart page")
	public void iNaviagteToCartPage() {
		CartTestPage cartpage = new CartTestPage();

		cartpage.getCartpageLinkCart().waitForPresent(5000);
		cartpage.getCartpageLinkCart().verifyPresent();
		cartpage.getCartpageLinkCart().click();
		cartpage.getCartpageLblEstimatedtotal().waitForPresent(5000);
		boolean isCartDisplayed = cartpage.getCartpageLblEstimatedtotal().isPresent();

		if (isCartDisplayed) {
			PerfectoUtils.reportMessage("Cart Page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cart Page is not displayed",MessageTypes.Fail);
		}
	}

	/*@QAFTestStep(description = "I modify the product quantity")
	public void iModifyTheProductQuantity() throws InterruptedException {
		CartTestPage cartpage = new CartTestPage();
		ShippingaddTestPage shippingaddress = new ShippingaddTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		String actualprice = cartpage.getCartpageLblEstimatedprice().getText();
		System.out.println(actualprice);
		String actualqty = cartpage.getCartpageLblQuantitynumber().getText();
		System.out.println(actualqty);

		PerfectoUtils.reportMessage("actualprice:" + actualprice);
		getBundle().setProperty("actualprice", actualprice);
		PerfectoUtils.reportMessage("actual:" + actualqty);
		getBundle().setProperty("actual", actualqty);

		cartpage.getCartpageLblQuantitynumber().click();
		String displayedqty = cartpage.getCartpageLblQtypickervisiblerow().getText();

		androidcommon.getAddtolistTxtPickerbottom().waitForPresent(4000);
		String changeqty = androidcommon.getAddtolistTxtPickerbottom().getText();
		System.out.println(changeqty);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", changeqty);
		Object result1 = androidcommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);

		try {
			shippingaddress.getShippingBtnSave().waitForPresent(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		shippingaddress.getShippingBtnSave().verifyPresent();
		shippingaddress.getShippingBtnSave().click();
	}*/

	@QAFTestStep(description = "I see updated quantity and price")
	public void iSeeUpdatedQuantityAndPrice() {
		CartTestPage cartpage = new CartTestPage();

		// Changed price after updating qty
		String strchangeprice = cartpage.getCartpageLblEstimatedprice().getText().replace("$", "").trim();
		Double dblchangeprice = Double.parseDouble(strchangeprice);

		// Updated qty
		String changeqty = cartpage.getCartpageLblQuantitynumber().getText();
		Double dblupdatedqty = Double.parseDouble(changeqty);

		// Actual price before change qty
		String beforechangqty = getBundle().getString("actualprice");

		// Price of single product
		String priceofproduct = cartpage.getCartpageLblProductprice().getText().replace("$", "").trim();
		Double dblpriceofproduct = Double.parseDouble(priceofproduct);
		Double costofnoofprod = (dblpriceofproduct * dblupdatedqty);

		// Comparison of updated price with cost of number of product
		if (dblchangeprice.equals(costofnoofprod)) {
			PerfectoUtils.reportMessage("Correct price updated",MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Correct price not updated",MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I enter as guest checkout from Login Splash page")
	public void iEnterAsGuestCheckoutFromLoginSplashPage() {
		CheckoutTestPage chekoutpage = new CheckoutTestPage();

		chekoutpage.getCheckoutLblPgtitleguestcheckout().verifyPresent();
		chekoutpage.getCheckoutLinkContinue().click();
		PerfectoUtils.reportMessage("Clicked: on continue as guest user", MessageTypes.Pass);
	}

	/*@QAFTestStep(description = "I enter shipping address")
	public void iEnterShippingAddress() {
		CheckoutTestPage chekoutpage = new CheckoutTestPage();
		ShippingaddTestPage shippingaddress = new ShippingaddTestPage();

		chekoutpage.getCheckoutImgHomeicon().click();
		String firstname = ConfigurationManager.getBundle().getString("shippingaddress.firstname");
		shippingaddress.getShippingTxtFirstname().sendKeys(firstname);

		String lastname = ConfigurationManager.getBundle().getString("shippingaddress.lastname");
		shippingaddress.getShippingTxtLastname().sendKeys(lastname);

		String phonenumber = ConfigurationManager.getBundle().getString("shippingaddress.phonenumber");
		shippingaddress.getShippingTxtPhnumber().sendKeys(phonenumber);

		String address = ConfigurationManager.getBundle().getString("shippingaddress.address");
		shippingaddress.getShippingTxtAddress1().sendKeys(address);

		PerfectoUtils.verticalswipe();
		String city = ConfigurationManager.getBundle().getString("shippingaddress.city");
		shippingaddress.getShippingTxtCity().sendKeys(city);

		PerfectoUtils.verticalswipe();
		String zipcode = ConfigurationManager.getBundle().getString("shippingaddress.zipcode");
		shippingaddress.getShippingTxtZipcode().sendKeys(zipcode);
		shippingaddress.getShippingBtnSave().click();

		// Verifying the save confirmation pop-up
		shippingaddress.getShippingLblPopupshipadd().verifyPresent();
		shippingaddress.getShippingBtnNo().verifyPresent();
		shippingaddress.getShippingBtnYes().click();
		PerfectoUtils.reportMessage("Clicked: on yes button", MessageTypes.Pass);

		// If same address already present then select the existing one
		if (shippingaddress.getShippingLblShippgtiltle().isPresent()) {

			shippingaddress.getShippingLblExistingadd().waitForPresent(3000);
			shippingaddress.getShippingLblExistingadd().click();
			shippingaddress.getShippingBtnSelect().click();
			PerfectoUtils.reportMessage("Entered new address", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("you entered a new address", MessageTypes.Info);
		}
	}*/

	@QAFTestStep(description = "I see checkout page")
	public void iSeeCheckoutPage() {
		CartTestPage cartpage = new CartTestPage();

		cartpage.getCartpageLblPgtitlecartwithitem().verifyPresent();
	}
	
	@QAFTestStep(description = "I enter shipping address")
	public void iEnterShippingAddress() {
		CheckoutTestPage chekoutpage = new CheckoutTestPage();
		CartTestPage cartpage = new CartTestPage();
		ShippingaddTestPage shippingaddress = new ShippingaddTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		chekoutpage.getCheckoutImgHomeicon().click();

		String firstname = ConfigurationManager.getBundle().getString("shippingaddress.firstname");
		shippingaddress.getShippingTxtFirstname().sendKeys(firstname);

		String lastname = ConfigurationManager.getBundle().getString("shippingaddress.lastname");
		shippingaddress.getShippingTxtLastname().sendKeys(lastname);

		String phonenumber = ConfigurationManager.getBundle().getString("shippingaddress.phonenumber");
		shippingaddress.getShippingTxtPhnumber().sendKeys(phonenumber);

		String address = ConfigurationManager.getBundle().getString("shippingaddress.address");
		shippingaddress.getShippingTxtAddress1().sendKeys(address);

		PerfectoUtils.verticalswipe();
		String city = ConfigurationManager.getBundle().getString("shippingaddress.city");
		shippingaddress.getShippingTxtCity().sendKeys(city);

		PerfectoUtils.verticalswipe();
		String zipcode = ConfigurationManager.getBundle().getString("shippingaddress.zipcode");
		shippingaddress.getShippingTxtZipcode().sendKeys(zipcode);

		shippingaddress.getShippingBtnSave().click();

		// Verifung the save confirmation pop-up
		shippingaddress.getShippingLblPopupshipadd().verifyPresent();
		shippingaddress.getShippingBtnNo().verifyPresent();
		shippingaddress.getShippingBtnYes().click();
		PerfectoUtils.reportMessage("Clicked: on yes button", MessageTypes.Pass);

		// If same address already present then select the existing one
		if (shippingaddress.getShippingLblShippgtiltle().isPresent()) {

			shippingaddress.getShippingLblExistingadd().waitForPresent(3000);
			shippingaddress.getShippingLblExistingadd().click();
			shippingaddress.getShippingBtnSelect().click();
			PerfectoUtils.reportMessage("Entered new address", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("you entered a new address", MessageTypes.Info);
		}

	}
}
