package com.heb.automation.android.steps.recipes;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.Dimension;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.recipes.QuickrecipefinderTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxTestPage;
import com.heb.automation.common.pages.recipes.RecipeboxresultTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.recipes.ReciperesultTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.recipes.RefineTestPage;
import com.heb.automation.common.pages.registeration.CancelregistrationTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Recipes

	I navigate to Recipes
	I should be able to see the added recipe in my recipe Box
	I see scrolling selector appears with users available shopping lists
	I navigate back to recipe detail page
	I delete newly created folder from My Recipe Box
	I should not see the deleted folder name
	I click on edit folder option
	I select the recipe box to rename
	I enter the new recipe box name
	I should see the renamed recipe box
	I revert back the recipe box name
	I click on rename button from the pop-up
	I validate recipe refine page
	I select a recipe box
	I delete a recipe from the recipe box
	I should not see the deleted recipe
	I create a new folder in My Recipe Box
	I see no results error message for search text
	I see no results error message for advance search
	I choose the recipe options {0}{1} in Advanced option
	I Change/Sort the result order of recipe search result page
	I delete all the recipe boxes
	I verify the user is having atleast two recipe boxes
	I verify the selected recipe box is not empty
	I should able to add the recipe in the recipe Box
	I select the move button from the popup
	I verify the moved recipe is present in the recipe box
	I navigate to the selected recipe box page
	I verify the user is having atleast one recipe box
	I verify If added recipe is present in the shopping list
	I enter the existing recipe box name
	I see toast error message
	I select a recipe row from recipe box page
	I should see no result error message
	I navigate back to the recipes page
	I select Add to List button from recipe detail page
	I click share button from recipe detail page
	I see the selected ingredient on selecting single ingredient within corresponding check field
	I see My Recipebox page
	I navigate back to recipe page from login page
	I see registration page by clicking on Create an account
	I should see scrolling selector appears with weekly grocery shopping lists
	I verify that recipe is added to All recipe box
	I navigate to my recipe Box page from recipe detail screen
	I navigate to registration page by clicking login and Register buttons
	I register new user and land in Recipe detail page*/

public class AndroidStepdefRecipes {

	/**
	 * Navigating to Recipes from Aisle
	 */

	@QAFTestStep(description = "I navigate to Recipes")
	public void iNavigateToRecipes() {
		HomeTestPage homepage = new HomeTestPage();
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		homepage.waitForPageToLoad();
		PerfectoUtils.verticalswipe();
		try {
			homepage.getHomeLblRecipes().waitForPresent(10000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		homepage.getHomeLblRecipes().verifyPresent();
		homepage.getHomeLblRecipes().click();
		PerfectoUtils.reportMessage("Clicked on Recipes from homepage.", MessageTypes.Pass);
		PerfectoUtils.getReportiumClient().reportiumAssert("Clicked on Recipes", true);

		if (recipelanding.getRecipesRecipeboxname().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Recipes landing page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage(
					"Not Navigated to recipe landing page. Selecting the Recipes option from hamburger menu.",
					MessageTypes.Pass);
			PerfectoUtils.horizontalswipe();
			androidcommon.getAppHamburger().waitForPresent(1000);
			androidcommon.getAppHamburger().click();

			if (androidcommon.getAppSliderRecipes().isPresent()) {
				PerfectoUtils.reportMessage("Clicking on Recipes..", MessageTypes.Pass);
				androidcommon.getAppSliderRecipes().click();
				PerfectoUtils.reportMessage("Clicked on Recipes.", MessageTypes.Pass);
			} else {
				PerfectoUtils.verticalswipe(80, 75, 2);
				PerfectoUtils.reportMessage("Clicking on Recipes..", MessageTypes.Pass);
				androidcommon.getAppSliderRecipes().click();
				PerfectoUtils.reportMessage("Clicked on Recipes.", MessageTypes.Pass);
			}
		}

	}

	/**
	 * Opening My Recipe Box. Clicking on selected Recipe box. Verifying the
	 * selected recipe box.
	 * 
	 * @param strAddedRecipebox
	 */
	@QAFTestStep(description = "I should be able to see the added recipe in my recipe Box")
	public void iShouldBeAbleToSeeTheAddedRecipeInMyRecipeBox() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		WeeklygroceriesTestPage wGroceries = new WeeklygroceriesTestPage();

		/* Clicking on open box icon */
		recipebox.getRecipeboxOpenbox().waitForPresent(3000);
		recipebox.getRecipeboxOpenbox().click();

		/* Clicking on selected recipe box */
		String strAddedRecipebox = getBundle().getString("AddingRecipebox");
		wGroceries.getShopingListEntryByLable(strAddedRecipebox).waitForPresent(5000);
		wGroceries.getShopingListEntryByLable(strAddedRecipebox).click();

		try {
			if (appcrash.getAppExceptionMsgTitle().isPresent()) {
				String MessageBody = appcrash.getAppExceptionMsg().getText();
				System.out.println("Inside receipe exception");
				System.out.println(MessageBody);
				if (MessageBody.contains("Unable to load Recipe Box")) {
					System.out.println("Unable to load Recipe Box at this time. Please try again.");
					PerfectoUtils.reportMessage("Unable to Load Receipe BOX Error Occured", MessageTypes.TestStepFail);
					appcrash.getExceptionBtnOk().click();
				}
			} else {
				try {
					/* Verify if selected recipe is available */
					if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
						PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
								+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
					} else {
						PerfectoUtils.verticalswipe();
						if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
							if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName"))
									.isPresent()) {
								PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
										+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
							}
						}
					}
				} catch (Exception e) {
					PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("recipeName"));
					if (wGroceries.getShopingListEntryByLable(getBundle().getString("recipeName")).isPresent()) {
						PerfectoUtils.reportMessage("Added recipe: " + getBundle().getString("recipeName")
								+ ": is present in the box: " + strAddedRecipebox, MessageTypes.Pass);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifying add to list pop up title. Comparing the list by clicking on
	 * bottom list
	 * 
	 * @param strNewlistName
	 */

	@QAFTestStep(description = "I see scrolling selector appears with users available shopping lists")
	public void iSeeScrollingSelectorAppearsWithUsersAvailableShoppingLists() throws InterruptedException {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Verify add to list pop up title */
		recipedetail.getRecipedetailpageLstpopupTitle().verifyText("Add to List");

		/* Verify list name is present */
		recipedetail.getRecipedetailpageLstpopupListname().verifyPresent();

		/* Click on bottom list and compare */
		String strNewlistName = getBundle().getString("NewListName");
		recipedetail.getRecipedetailpageLstpopupListname().sendKeys(strNewlistName);
		boolean listSelect = false;
		int i = 0;

		/*
		 * do { String listName =
		 * androidcommon.getAddtolistTxtNumberpicker().getText(); if
		 * (listName.equals(strNewlistName)) { break; } else { int getSize =
		 * androidcommon.getAddtolistTxtNextpicker().size(); if (getSize > 0) {
		 * int actualSize = getSize - 1;
		 * androidcommon.getAddtolistTxtNextpicker().get(actualSize).getText();
		 * androidcommon.getAddtolistTxtNextpicker().get(actualSize).click(); }
		 * } i++; } while (!listSelect && i < 10);
		 */

		String swipe = "Up";
		int count = 0;
		do {
			String listName = androidcommon.getAddtolistTxtNumberpicker().getText();
			if (listName.equals(strNewlistName)) {
				break;
			} else {
				if (swipe.contains("Up")) {
					Dimension size = getAppiumDriver().manage().window().getSize();
					int intStartX = Integer.parseInt(androidcommon.getAddtolistTxtNumberpicker().getAttribute("X"));
					int intStartY = Integer.parseInt(androidcommon.getAddtolistTxtNumberpicker().getAttribute("Y"));
					int intEndY = intStartY - 200;
					getAppiumDriver().swipe(intStartX, intStartY, intStartX, intEndY, 2);
				}

				while (count < 1) {
					String newName = androidcommon.getAddtolistTxtNumberpicker().getText();
					if (listName == newName)
						swipe = "Down";
					count++;
				}

				if (swipe.contains("Down")) {
					Dimension size = getAppiumDriver().manage().window().getSize();
					int intStartX = Integer.parseInt(androidcommon.getAddtolistTxtNumberpicker().getAttribute("X"));
					int intStartY = Integer.parseInt(androidcommon.getAddtolistTxtNumberpicker().getAttribute("Y"));
					int intEndY = intStartY + 200;
					getAppiumDriver().swipe(intStartX, intStartY, intStartX, intEndY, 2);
				}
			}

		} while (!listSelect && i < 10);

		String strListName = recipedetail.getRecipedetailpageLstpopupListname().getText();
		getBundle().setProperty("listName", strListName);
		PerfectoUtils.reportMessage("Selected list: " + strListName, MessageTypes.Pass);
	}

	/**
	 * Clicking on device back button. Navigating back to recipe detail page.
	 */

	@QAFTestStep(description = "I navigate back to recipe detail page")
	public void iNavigateBackToRecipeDetailPage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Click on device back button */
		PerfectoUtils.androiddeviceback();
		if (recipebox.getRecipeboxSelectbox().isPresent()) {
			PerfectoUtils.androiddeviceback();
		}
	}

	/**
	 * Deleting the newly created recipe box
	 * 
	 * @param newFolder
	 * @param intStartX
	 * @param intEndX
	 * @param intStartY
	 */

	@QAFTestStep(description = "I delete newly created folder from My Recipe Box")
	public void iDeleteNewlyCreatedFolderFromMyRecipeBox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String newFolder = getBundle().getString("NewRecipeboxname");
		Dimension size = getAppiumDriver().manage().window().getSize();

		int intStartX = (int) (size.width * 0.90);
		int intEndX = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("X"));

		int intStartY = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("Y"));

		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the folder name: " + newFolder + " to delete", MessageTypes.Pass);
	}

	/**
	 * Verifying whether the deleted folder is present or not
	 * 
	 * @param newFolder
	 */

	@QAFTestStep(description = "I should not see the deleted folder name")
	public void iShouldNotSeeTheDeletedFolderName() throws InterruptedException {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String newFolder = getBundle().getString("NewRecipeboxname");
		weeklygrocery.getShopingListEntryByLable(newFolder).waitForNotPresent(5000);

		/* Forming the dynamic object */
		boolean isListDisplayed = weeklygrocery.getShopingListEntryByLable(newFolder).verifyNotVisible();
		if (isListDisplayed) {
			PerfectoUtils.reportMessage("Deleted Folder in My Recipe Box: " + newFolder + " is not displayed",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Deleted Folder in My Recipe Box: " + newFolder + " is displayed",
					MessageTypes.Fail);
		}
	}

	/**
	 * Checking if no recipe boxes are available, except ALL folder. If no
	 * folder is there, crating a new one. Clicking on edit option.
	 */
	@QAFTestStep(description = "I click on edit folder option")
	public void iClickOnEditFolderOption() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		/* Checking if no recipe boxes are available, except ALL folder */
		if (listsize <= 1) {
			/* Creating new recipe box */
			iCreateANewFolderInMyRecipeBox();
		}
		/* Clicking on edit folder option */
		recipebox.getBtnEditfolder().waitForPresent(5000);
		recipebox.getBtnEditfolder().verifyPresent();
		recipebox.getBtnEditfolder().click();
	}

	/**
	 * Selecting a recipe box to rename
	 */

	@QAFTestStep(description = "I select the recipe box to rename")
	public void iSelectTheRecipeBoxToRename() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		String strRecipeboxname = null;

		/* Clicking on Recipe box */
		List<QAFWebElement> items = recipebox.getLblRecipenameslist();
		strRecipeboxname = items.get(1).getText();
		items.get(1).click();
		getBundle().setProperty("Recipeboxname", strRecipeboxname);

		PerfectoUtils.reportMessage("Selected the folder: " + getBundle().getString("Recipeboxname") + " for renaming.",
				MessageTypes.Pass);
	}

	/**
	 * Entering the new recipe box name
	 */

	@QAFTestStep(description = "I enter the new recipe box name")
	public void iEnterTheNewRecipeBoxName() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		String strNewRecipeboxname = null, strOldRecipeboxname = null;
		strOldRecipeboxname = getBundle().getString("Recipeboxname");

		/* Creating new recipe box name to rename */
		if (strOldRecipeboxname.contains("1")) {
			strNewRecipeboxname = strOldRecipeboxname.replaceAll("1", "");
		} else {
			strNewRecipeboxname = strOldRecipeboxname + 1;
		}

		/* Entering the new value in the text box */
		getBundle().setProperty("NewRecipeboxname", strNewRecipeboxname);
		recipebox.getTxtRenamepopup().click();
		recipebox.getTxtRenamepopup().clear();
		recipebox.getTxtRenamepopup().sendKeys(strNewRecipeboxname);
	}

	/**
	 * Verifying the new folder in my recipe box page
	 * 
	 * @param strNewRecipeboxname
	 */

	@QAFTestStep(description = "I should see the renamed recipe box")
	public void iShouldSeeTheRenamedRecipeBox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Verify new folder in My Recipe Box page */
		String strNewRecipeboxname = getBundle().getString("NewRecipeboxname");
		weeklygrocery.getShopingListEntryByLable(strNewRecipeboxname).waitForPresent(1000);
		weeklygrocery.getShopingListEntryByLable(strNewRecipeboxname).verifyPresent();
	}

	/**
	 * CLicking on Edit folder for reverting back recipe box name. Updating the
	 * previous recipe box name
	 */

	@QAFTestStep(description = "I revert back the recipe box name")
	public void iRevertBackTheRecipeBoxName() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Clicking on edit folder option */
		iClickOnEditFolderOption();

		/* Clicking on Recipe box */
		List<QAFWebElement> items = recipebox.getLblRecipenameslist();
		int sizeItems = items.size();
		System.out.println(sizeItems + " lists found.");
		items.get(1).click();

		/* Updating the previous Recipe box name */
		recipebox.getTxtRenamepopup().click();
		recipebox.getTxtRenamepopup().clear();
		recipebox.getTxtRenamepopup().sendKeys(getBundle().getString("Recipeboxname"));
		iClickOnRenameButtonFromThePopUp();

		PerfectoUtils.reportMessage("Renamed the folder back to: " + getBundle().getString("Recipeboxname") + ".",
				MessageTypes.Pass);
	}

	/**
	 * Clicking on done button from pop up for renaming the recipe box
	 */

	@QAFTestStep(description = "I click on rename button from the pop-up")
	public void iClickOnRenameButtonFromThePopUp() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxBtnLoginpopupLogin().waitForPresent(5000);
		recipebox.getRecipeboxBtnLoginpopupLogin().click();

		/* Clicking on done button */
		recipebox.getBtnDone().waitForPresent(3000);
		recipebox.getBtnDone().click();
		recipebox.getBtnEditfolder().waitForPresent(5000);
		recipebox.getBtnEditfolder().verifyPresent();

		PerfectoUtils.reportMessage("Renamed the folder as: " + getBundle().getString("NewRecipeboxname") + ".",
				MessageTypes.Pass);
	}

	/**
	 * Verifying the recipe refine page
	 */

	@QAFTestStep(description = "I validate recipe refine page")
	public void iValidateRecipeRefinePage() {
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		reciperesult.getRefineBtnDone().verifyPresent();

		if (reciperesult.getRefineLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Able to see refine page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see refine page", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting the first recipe box
	 */

	@QAFTestStep(description = "I select a recipe box")
	public void iSelectARecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Clicking on 1st Recipe box */
		String strRecipeboxname = recipebox.getLblRecipenameslist().get(1).getText();
		getBundle().setProperty("Recipeboxname", strRecipeboxname);
		recipebox.getLblRecipenameslist().get(1).click();
		PerfectoUtils.reportMessage("Selected recipe box: " + strRecipeboxname, MessageTypes.Pass);
	}

	/**
	 * Selecting a recipe from recipe box to delete
	 */

	@QAFTestStep(description = "I delete a recipe from the recipe box")
	public void iDeleteARecipeFromTheRecipeBox() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();

		String recipeName = "";

		try {
			/* Deleting first recipe in the box */
			PerfectoUtils.reportMessage("Deleting recipe " + recipeName + " from the recipe box..", MessageTypes.Pass);
			String strDeletingRecipename = recipeboxresult.getRecipeboxresultBtnDeleterecipe().get(0).getText();
			getBundle().setProperty("DeletingRecipename", strDeletingRecipename);
			recipeboxresult.getRecipeboxresultBtnDeleterecipe().get(0).click();
			recipeboxresult.getPopupBtndelete().waitForPresent(5000);
			recipeboxresult.getPopupBtndelete().click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifying whether the deleted recipe is present in the recipe box or not
	 */

	@QAFTestStep(description = "I should not see the deleted recipe")
	public void iShouldNotSeeTheDeletedRecipe() {
		RecipeboxresultTestPage recipebox = new RecipeboxresultTestPage();
		String strDeletedRecipe = getBundle().getString("DeletingRecipename");
		String strRecipeboxname = getBundle().getString("Recipeboxname");

		try {
			recipebox.getRecipeboxresultLblRecipename().get(0).waitForNotPresent(30000);
		} catch (Exception e) {
			// ignore
		}
		int listsize = recipebox.getRecipeboxresultLblRecipename().size();

		/* Checking if no items are available */
		if (listsize != 0) {

			/* Comparing the name of the first recipe with the deleted recipe */
			if (!recipebox.getRecipeboxresultLblRecipename().get(0).getText().equalsIgnoreCase(strDeletedRecipe)) {
				PerfectoUtils.reportMessage(
						"Deleted the recipe: " + strDeletedRecipe + "from recipe box: " + strRecipeboxname,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Delete not successful!", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage(
					"Deleted the recipe: " + strDeletedRecipe + "from recipe box: " + strRecipeboxname,
					MessageTypes.Pass);
		}
	}

	/**
	 * Clicking on a plus icon for creating a new folder. Getting the current
	 * time to form the unique recipe box name. Entering the new recipe box name
	 */

	@QAFTestStep(description = "I create a new folder in My Recipe Box")
	public void iCreateANewFolderInMyRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Click on + icon */
		recipebox.getRecipeboxBtnPlusicon().waitForPresent(7000);
		recipebox.getRecipeboxBtnPlusicon().click();

		/* Enter new Recipe box folder */
		recipebox.getRecipeboxFolderpopupTitle().waitForPresent(2000);
		recipebox.getRecipeboxFolderpopupTxtFoldername().verifyPresent();

		/* Getting the current time to form the unique recipe box name */
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();
		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strRecipeboxname = "RB" + strTimeStmp;
		getBundle().setProperty("NewRecipeboxname", strRecipeboxname);

		/* Entering the new recipe box name in the text box */
		recipebox.getRecipeboxFolderpopupTxtFoldername().sendKeys(strRecipeboxname);

		recipebox.getRecipeboxBtnLoginpopupLogin().click();
		PerfectoUtils.reportMessage("Created a recipe box " + strRecipeboxname + ".", MessageTypes.Pass);
	}

	/**
	 * Verifying the no result error message
	 */

	@QAFTestStep(description = "I see no results error message for search text")
	public void iSeeNoResultsErrorMessageForSearchText() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Verify the landing page */
		if (recipelanding.getRecipesFeatured().isPresent()) {
			PerfectoUtils.reportMessage("No Results found for the entered search text", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Results found for the entered search text", MessageTypes.Fail);
		}
		if (androidcommon.getAppBtnCollapse().isPresent()) {
			androidcommon.getAppBtnCollapse().click();
		}
	}

	/**
	 * Verifying Recipe not found pop up is coming or not
	 */

	@QAFTestStep(description = "I see no results error message for advance search")
	public void iSeeNoResultsErrorMessageForAdvanceSearch() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		androidcommon.waitForPageToLoad();
		if (androidcommon.getAddtolistLblAlerttitle().verifyText("Recipe Not Found")) {
			PerfectoUtils.reportMessage("Recipe not Found pop up is displayed for selected options", MessageTypes.Pass);
			appcrash.getExceptionBtnOk().click();
		} else {
			PerfectoUtils.reportMessage("Recipe not Found pop up is not displayed for selected options",
					MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Quick Recipe Finder button. Selecting a recipe by Meal and by
	 * Ingredients. Clicking on Find button.
	 * 
	 * @param strRecipeByMeal
	 * @param strRecipeByIng
	 */

	@QAFTestStep(description = "I choose the recipe options {0}{1} in Advanced option")
	public void iChooseTheRecipeOptionsInAdvancedOption(String strRecipeByMeal, String strRecipeByIng) {
		QuickrecipefinderTestPage recipefinder = new QuickrecipefinderTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		recipefinder.getQuickfinderBtnAdvancedtab().waitForPresent(3000);
		recipefinder.getQuickfinderBtnAdvancedtab().click();
		recipefinder.waitForPageToLoad();

		/* Select Recipes in Advance search */
		weeklygrocery.getShopingListEntryByLable(strRecipeByMeal).click();
		PerfectoUtils.reportMessage("Recipe by Meal has selected");
		PerfectoUtils.getAppiumDriver().scrollToExact(strRecipeByIng).click();
		PerfectoUtils.reportMessage("Recipe by Ingredient has selected");

		/* Click on Find button */
		recipefinder.getQuickfinderFind().click();
	}

	/**
	 * Selecting the sort option for the recipes. Clicking on done button.
	 */

	@QAFTestStep(description = "I Change/Sort the result order of recipe search result page")
	public void iChangeSortTheResultOrderOfRecipeSearchResultPage() {
		RefineTestPage refinepage = new RefineTestPage();
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		refinepage.getRefineLblPagetitle().verifyPresent();
		refinepage.getRefineLblBymeal().verifyPresent();
		refinepage.getLblFilterbymeal().click();
		PerfectoUtils.getAppiumDriver().scrollToExact("BY NUTRITION");
		refinepage.getLblFilterbynutrition().click();
		reciperesult.getRefineBtnDone().click();
	}

	/**
	 * Swiping across the folder names to delete all the recipe boxes.
	 */

	@QAFTestStep(description = "I delete all the recipe boxes")
	public void iDeleteAllTheRecipeBoxes() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		/* Checking if no recipe boxes are available, except ALL folder */
		if (listsize > 1) {

			while (listsize > 1) {

				/* Deleting the recipe boxes using swipe action */
				String newFolder = recipebox.getLblRecipenameslist().get(1).getText();
				Dimension size = getAppiumDriver().manage().window().getSize();

				int intStartX = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("X"));
				int intEndX = (int) (size.width * 0.90);
				int intStartY = Integer.parseInt(weeklygrocery.getShopingListEntryByLable(newFolder).getAttribute("Y"));

				getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
				PerfectoUtils.reportMessage("Swiping across the folder name: " + newFolder + " to delete",
						MessageTypes.Pass);

				listsize = recipebox.getLblRecipenameslist().size();

			}
			PerfectoUtils.reportMessage("Deleted the recipe boxes.", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("No recipe boxes available.", MessageTypes.Pass);
		}
	}

	/**
	 * Verifying whether two recipe box are there or not. If not, then creating
	 * new folder.
	 */

	@QAFTestStep(description = "I verify the user is having atleast two recipe boxes")
	public void iVerifyTheUserIsHavingAtleastTwoRecipeBoxes() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();
		int count = 0;

		/*
		 * Checking if user is having less than two recipe boxes, except ALL
		 * folder
		 */
		if (listsize < 3) {

			while (listsize != 3) {
				/* Creating a new recipe box */
				iCreateANewFolderInMyRecipeBox();

				/*
				 * Navigating back to My recipe box page to get the refreshed
				 * size
				 */
				PerfectoUtils.androiddeviceback();
				recipelandingpage.getRecipesRecipeboxname().waitForPresent(5000);
				recipelandingpage.getRecipesRecipeboxname().click();

				count++;
				listsize = recipebox.getLblRecipenameslist().size();
			}
			PerfectoUtils.reportMessage("Created" + count + " recipe boxes.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is having" + (listsize - 1) + " recipe boxes", MessageTypes.Pass);
		}

	}

	/**
	 * Navigating to recipe box. Getting the recipe name. Clicking on first
	 * recipe.
	 */

	@QAFTestStep(description = "I verify the selected recipe box is not empty")
	public void iVerifyTheSelectedRecipeBoxIsNotEmpty() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();
		RecipeslandingTestPage recipelandingpage = new RecipeslandingTestPage();
		ReciperesultTestPage reciperesult = new ReciperesultTestPage();

		String strRecipeboxname = "";
		int listsize = recipeboxresult.getRecipeboxresultLblRecipename().size();

		try {
			if (listsize == 0) {

				PerfectoUtils.reportMessage("No recipes found! adding recipes to the recipe box.", MessageTypes.Pass);

				/* Navigating to recipes landing page */
				PerfectoUtils.androiddeviceback();
				recipebox.getRecipeboxLblPagetitle().waitForPresent(5000);
				PerfectoUtils.androiddeviceback();

				/* Adding the recipes to recipe box */
				recipelandingpage.getRecipesFeatured().waitForPresent(5000);
				recipelandingpage.getRecipesFeatured().click();

				/* Getting recipe name */
				reciperesult.waitForPageToLoad();
				String recipeName = reciperesult.getReciperesultRecipename().getText();
				getBundle().setProperty("recipeName", recipeName);

				/* Click on first recipe */
				reciperesult.getReciperesultItem1().waitForPresent(null);
				reciperesult.getReciperesultItem1().click();

				iShouldAbleToAddTheRecipeInTheRecipeBox();

				/* Navigating back to My Recipe box page */
				recipedetails.getRecipedetailpageHeaderRecipeboxbutton().click();

				/* Clicking on first recipe box */
				strRecipeboxname = recipebox.getLblRecipenameslist().get(1).getText();
				getBundle().setProperty("Recipeboxname", strRecipeboxname);
				recipebox.getLblRecipenameslist().get(1).click();

				PerfectoUtils.reportMessage(
						"Added the recipe " + recipeName + " in to the recipe box " + strRecipeboxname,
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The recipe box " + strRecipeboxname + " is not empty.", MessageTypes.Pass);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * CLicking on Add to Box button. Clicking add in choose folder pop up.
	 */

	@QAFTestStep(description = "I should able to add the recipe in the recipe Box")
	public void iShouldAbleToAddTheRecipeInTheRecipeBox() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Click on Add to Box button */
		recipedetail.getRecipedetailpageAddtoBox().waitForPresent(1000);
		recipedetail.getRecipedetailpageAddtoBox().click();

		/* Click add in choose folder pop up with default folder */
		recipebox.getRecipeboxAddtobox().waitForPresent(3000);
		String strAddingRecipebox = recipedetail.getRecipedetailpageLstpopupListname().getText();
		getBundle().setProperty("AddingRecipebox", strAddingRecipebox);
		recipebox.getRecipeboxAddtobox().click();
	}

	/**
	 * Selecting move button form pop up
	 */

	@QAFTestStep(description = "I select the move button from the popup")
	public void iSelectTheMoveButtonFromThePopup() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		String strMovedRecipename = getBundle().getString("recipeName");

		if (recipebox.getRecipeboxFolderpopupTitle().isPresent()) {

			/* Click add in choose folder pop up with default folder */
			String strAddingRecipebox = recipedetail.getRecipedetailpageLstpopupListname().getText();
			getBundle().setProperty("AddingRecipebox", strAddingRecipebox);

			recipeboxresult.getBtnPopupmove().click();
			PerfectoUtils.reportMessage("Moved the recipe: " + strMovedRecipename + " to the box " + strAddingRecipebox,
					MessageTypes.Pass);
		}
	}

	/**
	 * Verifying whether the moved recipe is present in the recipe box or not.
	 */
	@QAFTestStep(description = "I verify the moved recipe is present in the recipe box")
	public void iVerifyTheMovedRecipeIsPresentInTheRecipeBox() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strMovedRecipename = getBundle().getString("recipeName");

		if (weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent()) {
			PerfectoUtils.reportMessage("The moved recipe: " + strMovedRecipename + " is present in the recipe box.",
					MessageTypes.Pass);
			/* Deleting the added recipe */
			deleteRecipeFromRecipeBox();
		} else if (!weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent()) {
			int i = 0;
			while ((!weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent()) && i < 10) {
				/* Deleting the recipes other than the required one */
				deleteRecipeFromRecipeBox();
				i++;
			}
			if (weeklygrocery.getShopingListEntryByLable(strMovedRecipename).isPresent())
				PerfectoUtils.reportMessage(
						"The moved recipe: " + strMovedRecipename + " is not present in the recipe box.",
						MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage(
						"The moved recipe: " + strMovedRecipename + " is not present in the recipe box.",
						MessageTypes.Fail);
		} else
			PerfectoUtils.reportMessage(
					"The moved recipe: " + strMovedRecipename + " is not present in the recipe box.",
					MessageTypes.Fail);

	}

	/**
	 * Navigating to the selected recipe box.
	 * 
	 * @param selectedBox
	 */

	@QAFTestStep(description = "I navigate to the selected recipe box page")
	public void iNavigateToTheSelectedRecipeBoxPage() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		WeeklygroceriesTestPage wgroceries = new WeeklygroceriesTestPage();

		String selectedBox = "";
		recipeboxresult.getRecipeboxresultBtnRecipebox().click();
		selectedBox = getBundle().getString("AddingRecipebox");

		try {
			if (wgroceries.getShopingListEntryByLable(selectedBox).isPresent()) {
				wgroceries.getShopingListEntryByLable(selectedBox).click();
				PerfectoUtils.reportMessage("Navigated to box: " + selectedBox, MessageTypes.Pass);
			} else {
				PerfectoUtils.verticalswipe();
				wgroceries.getShopingListEntryByLable(selectedBox).waitForPresent(3000);
				wgroceries.getShopingListEntryByLable(selectedBox).click();
				PerfectoUtils.reportMessage("Navigated to box: " + selectedBox, MessageTypes.Pass);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Verifying atleast one recipe box is present or not If not, then creating
	 * the new folder
	 */
	@QAFTestStep(description = "I verify the user is having atleast one recipe box")
	public void iVerifyTheUserIsHavingAtleastOneRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		int listsize = recipebox.getLblRecipenameslist().size();

		/* Checking if no recipe boxes are available, except ALL folder */
		if (listsize <= 1) {
			iCreateANewFolderInMyRecipeBox();
		}
	}

	/**
	 * Clicking the selected shopping List. Verifying whether the added recipe
	 * is present in the shopping list or not.
	 */

	@QAFTestStep(description = "I verify If added recipe is present in the shopping list")
	public void iVerifyIfAddedRecipeIsPresentInTheShoppingList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int flag = 0;

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		} catch (Exception e) {
			PerfectoUtils.getAppiumDriver().scrollToExact(getBundle().getString("listName"));
			weeklygrocery.getShopingListEntryByLable(getBundle().getString("listName")).click();
		}
		weeklygrocery.getWgListItemlist().get(0).waitForPresent(5000);

		String productName = "";

		/* Verify if selected recipe is available */
		PerfectoUtils.verticalswipe();
		int size = weeklygrocery.getListRecipename().size();
		if (size == 0) {
			PerfectoUtils.verticalswipe();
		}

		for (QAFWebElement product : weeklygrocery.getListRecipename()) {
			productName = product.getText();

			if (productName.equalsIgnoreCase(getBundle().getString("IngredientName"))) {
				flag = 1;
				break;
			}
		}
		if (flag == 1)
			PerfectoUtils.reportMessage("Added ingredient is available in shopping list", MessageTypes.Pass);
		else {
			PerfectoUtils.reportMessage("Added ingredient is not available in shopping list, Swiping",
					MessageTypes.Info);
			PerfectoUtils.verticalswipe();
		}

	}

	/**
	 * Entering the existing name in the rename pop up
	 */
	@QAFTestStep(description = "I enter the existing recipe box name")
	public void iEnterTheExistingRecipeBoxName() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		String strOldRecipeboxname = null;
		strOldRecipeboxname = getBundle().getString("Recipeboxname");

		recipebox.getTxtRenamepopup().click();
		recipebox.getTxtRenamepopup().clear();
		recipebox.getTxtRenamepopup().sendKeys(strOldRecipeboxname);
	}

	/**
	 * Verifying the error toast message.
	 */
	@QAFTestStep(description = "I see toast error message")
	public void iSeeToastErrorMessage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		PerfectoUtils.reportMessage("Toast message is yet to be implemented", MessageTypes.Pass);

		if (recipebox.getRecipeboxCancel().isPresent()) {
			recipebox.getRecipeboxCancel().click();
			PerfectoUtils.reportMessage("clicked on Cancel button", MessageTypes.Pass);
		}
	}

	/**
	 * Getting the recipe name. Selecting the first recipe row.
	 */
	@QAFTestStep(description = "I select a recipe row from recipe box page")
	public void iSelectARecipeRowFromRecipeBoxPage() {
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();

		/* Getting recipe name */
		String recipeName = recipeboxresult.getRecipeboxresultLblRecipename().get(0).getText();
		getBundle().setProperty("recipeName", recipeName);

		/* Click on first recipe */
		recipeboxresult.getImgRecipeimage().get(0).click();
	}

	/**
	 * Verifying the error message of no result.
	 */
	@QAFTestStep(description = "I should see no result error message")
	public void iShouldSeeNoResultErrorMessage() {
		QuickrecipefinderTestPage quickfinder = new QuickrecipefinderTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		if (quickfinder.getQuickfinderLblRecipenotfound().isPresent()) {
			PerfectoUtils.reportMessage("Able to see no result error message", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see no result error message", MessageTypes.Fail);
		}
		appcrash.getExceptionBtnOk().click();
	}

	/**
	 * Navigating back to recipes landing page.
	 */
	@QAFTestStep(description = "I navigate back to the recipes page")
	public void iNavigateBackToTheRecipesPage() {
		RecipeslandingTestPage recipelanding = new RecipeslandingTestPage();

		/* Navigating to recipes landing page */
		PerfectoUtils.androiddeviceback();

		if (recipelanding.getRecipesPagename().isPresent()) {
			PerfectoUtils.reportMessage("Able to see recipes page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see recipes page", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Add to List button from recipe detail page.
	 */

	@QAFTestStep(description = "I select Add to List button from recipe detail page")
	public void iSelectAddToListButtonFromRecipeDetailPage() {

		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		if (recipedetail.getRecipedetailpageAddtolist().isPresent()) {
			recipedetail.getRecipedetailpageAddtolist().click();
			PerfectoUtils.reportMessage("Clicked Add to list button.", MessageTypes.Pass);
		} else {
			AndroidStepDef.scrollToString("Add to List", 80, 65, 2);
			try {
				if (recipedetail.getRecipedetailpageAddtolist().isPresent()) {
					recipedetail.getRecipedetailpageAddtolist().click();
					PerfectoUtils.reportMessage("Clicked on Add to List button.", MessageTypes.Pass);
				}
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Add to List button not found.", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying the share button. Clicking on share button.
	 */

	@QAFTestStep(description = "I click share button from recipe detail page")
	public void iClickShareButtonFromRecipeDetailPage() {
		RecipedetailTestPage recipedetailpage = new RecipedetailTestPage();

		/* Click on share icon in the left hand side of recipe detail page */
		recipedetailpage.getRecipedetailpageHeaderSharebutton().waitForPresent(3000);
		recipedetailpage.getRecipedetailpageHeaderSharebutton().verifyPresent();
		recipedetailpage.getRecipedetailpageHeaderSharebutton().click();
		PerfectoUtils.reportMessage("Clicked Share icon.", MessageTypes.Pass);
	}

	/**
	 * Getting name of ingredient Clicking on ingredient check box
	 */
	@QAFTestStep(description = "I see the selected ingredient on selecting single ingredient within corresponding check field")
	public void iSeeTheSelectedIngredientOnSelectingSingleIngredientWithinCorrespondingCheckField() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();
		String strIngredient = null;

		int getsize = recipedetail.getRecipedetailpageChkbox().size();

		/* Click on ingredient check box */
		if (getsize < 1) {
			PerfectoUtils.verticalswipeSlow();
		}

		strIngredient = recipedetail.getRecipedetailpageChkbox().get(0).getText();
		getBundle().setProperty("IngredientName", strIngredient);
		getBundle().setProperty("ingSize", 1);
		recipedetail.getRecipedetailpageChkbox().get(0).click();
		PerfectoUtils.reportMessage("Selected the checkbox of Single ingredient.", MessageTypes.Pass);
	}

	/**
	 * Injecting image to scan. Clicking on Scan Product option If error pop up
	 * is there, handling it.
	 *//*
		 * @QAFTestStep(description =
		 * "I navigate and scan the item by clicking scanner button from Recipes landing page"
		 * ) public void
		 * iNavigateAndScanTheItemByClickingScannerButtonFromRecipesLandingPage(
		 * ) { AndroidcommonTestPage androidcommon = new
		 * AndroidcommonTestPage(); ScannerTestPage scanner = new
		 * ScannerTestPage(); RecipeslandingTestPage recipelanding = new
		 * RecipeslandingTestPage();
		 * 
		 * Setting the image to "Scan" String repositoryFile =
		 * ConfigurationManager.getBundle().getString(
		 * "scanner.reporitoryimage.scanproducts1"); String appName =
		 * ConfigurationManager.getBundle().getString("app.name");
		 * 
		 * PerfectoUtils.imageInjection(repositoryFile, appName);
		 * 
		 * Clicking on "Scan Products" option if
		 * (recipelanding.getBtnScannerbutton().isPresent()) {
		 * recipelanding.getBtnScannerbutton().click();
		 * PerfectoUtils.reportMessage( "Navigated to Scan Products page",
		 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
		 * "Not navigated to Scan Receipts page", MessageTypes.Fail); }
		 * 
		 * Handling the error pop-ups if
		 * (androidcommon.getAppPopupAllowPermission().isPresent()) {
		 * androidcommon.getAppPopupBtnAllowPermission().click(); }
		 * 
		 * if (scanner.getLblProductnotfound().isPresent()) {
		 * PerfectoUtils.reportMessage( "Product not found!",
		 * MessageTypes.Info); if
		 * (scanner.getBtnCancelproductnotfound().isPresent()) {
		 * scanner.getBtnCancelproductnotfound().click(); } else if
		 * (scanner.getBtnOkproductnotfound().isPresent()) {
		 * scanner.getBtnOkproductnotfound().click(); } } else if
		 * (scanner.getLblNorecipesfound().isPresent()) {
		 * PerfectoUtils.reportMessage( "No Recipes found!", MessageTypes.Fail);
		 * scanner.getBtnOknorecipesfound().click(); }
		 * 
		 * Stopping Image Injection PerfectoUtils.stopimageinjection(); }
		 */
	/**
	 * Verifying the My Recipebox page title
	 */
	@QAFTestStep(description = "I see My Recipebox page")
	public void iSeeMyRecipeboxPage() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		recipebox.getRecipeboxLblPagetitle().waitForPresent(1000);
		recipebox.getRecipeboxLblPagetitle().verifyPresent("My Recipe Box");
		PerfectoUtils.reportMessage("Navigated to my recipe box page", MessageTypes.Info);
	}

	/**
	 * Navigating back to recipe page from login page
	 */
	@QAFTestStep(description = "I navigate back to recipe page from login page")
	public void iNavigateBackToRecipePageFromLoginPage() {
		CancelregistrationTestPage cancelregistration = new CancelregistrationTestPage();

		PerfectoUtils.hidekeyboard();
		PerfectoUtils.androiddeviceback();
		cancelregistration.waitForPageToLoad();

	}

	/**
	 * Deleting the other recipes if the required recipes not found. Click on
	 * delete from the pop up.
	 */
	public void deleteRecipeFromRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		/* Deleting the other recipes if the required recipes not found */
		if (recipebox.getRecipeboxOptionsDeleterecipe().isPresent()) {
			recipebox.getRecipeboxOptionsDeleterecipe().click();
			PerfectoUtils.reportMessage("Deleting a recipe from recipe box..");

			if (recipebox.getRecipeboxDelete().isPresent()) {
				PerfectoUtils.reportMessage("Clicking on Delete option from the popup..");
				recipebox.getRecipeboxDelete().click();
			} else {
				PerfectoUtils.reportMessage("Delete popup not found.");
			}
		} else {
			PerfectoUtils.reportMessage("Delete option not found.");
		}
	}

	/**
	 * Clicking on create account. Verifying the registration page.
	 */
	@QAFTestStep(description = "I see registration page by clicking on Create an account")
	public void iSeeRegistrationPageByClickingOnCreateAnAccount() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RegistrastionTestPage registration = new RegistrastionTestPage();

		recipebox.getMyrecipeboxBtnCreateanaccount().verifyPresent();
		recipebox.getMyrecipeboxBtnCreateanaccount().click();

		PerfectoUtils.hidekeyboard();

		if (registration.getRegistrationTxtFirstname().isPresent()) {
			PerfectoUtils.reportMessage("Able to see registration page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see registration page", MessageTypes.Fail);
		}

	}

	/**
	 * Verifying the pop up title. Verifying the list name in add to list pop
	 * up.
	 */

	@QAFTestStep(description = "I should see scrolling selector appears with weekly grocery shopping lists")
	public void iShouldSeeScrollingSelectorAppearsWithWeekyGroceryShoppingLists() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		/* Verify add to list pop up title */
		recipedetail.getRecipedetailpageLstpopupTitle().verifyText("Add to List");

		/* Verify list name is present */
		recipedetail.getRecipedetailpageLstpopupListname().verifyPresent();
		String strListName = recipedetail.getRecipedetailpageLstpopupListname().getText();
		getBundle().setProperty("listName", strListName);
	}

	/**
	 * Verifying Added recipe in All recipe box.
	 */

	@QAFTestStep(description = "I verify that recipe is added to All recipe box")
	public void iVerifyThatRecipeIsAddedToAllRecipeBox() {
		RecipeboxTestPage recipebox = new RecipeboxTestPage();
		RecipeboxresultTestPage recipeboxresult = new RecipeboxresultTestPage();
		RecipedetailTestPage recipedetails = new RecipedetailTestPage();

		// Click on My Recipe Box
		recipedetails.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetails.getRecipedetailpageHeaderRecipeboxbutton().click();
		recipebox.getRecipeboxLblPagetitle().waitForPresent(1000);

		String selectedrecipe = getBundle().getString("recipeName");
		System.out.println(selectedrecipe);
		int count = Integer.parseInt(recipebox.getLblAllCount().getText());

		// Click on All recipe box and verify the added recipe
		if (recipebox.getLblAll().isPresent()) {
			recipebox.getLblAll().click();

			int i = 0;
			while (i < count) {
				String addedrecipe = recipeboxresult.getRecipeboxresultLblRecipename().get(i).getText();
				System.out.println(addedrecipe);

				if (addedrecipe.equalsIgnoreCase(selectedrecipe)) {
					PerfectoUtils.reportMessage("Selected Recipe is present in All recipe box", MessageTypes.Pass);
				} else {
					PerfectoUtils.verticalswipe();
				}
				i++;
			}

		} else {
			PerfectoUtils.reportMessage("Selected Recipe is not present in All recipe box", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking and Validating My Recipe box page.
	 */
	@QAFTestStep(description = "I navigate to my recipe Box page from recipe detail screen")
	public void iNavigateToMyRecipeBoxPageFromRecipeDetailScreen() {
		RecipedetailTestPage recipedetailspage = new RecipedetailTestPage();
		RecipeboxTestPage recipebox = new RecipeboxTestPage();

		// Click on My Recipe Box
		recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().verifyPresent();
		recipedetailspage.getRecipedetailpageHeaderRecipeboxbutton().click();
		// Validate My Recipe Box page
		recipebox.getRecipeboxLblPagetitle().waitForPresent(3000);
		recipebox.getRecipeboxLblPagetitle().verifyPresent();
	}

	/**
	 * Clicking and Validating My Recipe box page.
	 */
	@QAFTestStep(description = "I navigate to registration page by clicking login and Register buttons")
	public void iNavigateToRegistrationPageByClickingLoginAndRegisterButtons() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}

	/**
	 * I register new user and land in Recipe detail page
	 */
	@QAFTestStep(description = "I register new user and land in Recipe detail page")
	public void iRegisterNewUserAndLandInRecipeDetailPage() {
		PerfectoUtils.reportMessage("This is NA for Android", MessageTypes.Info);
	}
}
