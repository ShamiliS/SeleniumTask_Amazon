package com.heb.automation.android.steps.weeklyad;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;
import static com.qmetry.qaf.automation.step.CommonStep.waitForPresent;

import java.util.ArrayList;
import java.util.List;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.shoppinglist.AndroidStepDefShoppingList;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.ShoppinglistResult;
import com.heb.automation.common.components.StoreResult;
import com.heb.automation.common.components.WeeklyadResult;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.shoppinglist.AddtolistTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyaddealdetailTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadslandingTestPage;
import com.heb.automation.common.pages.weeklyad.WeeklyadsresultlistTestPage;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.selenium.AssertionService;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in WeeklyAds

	I click on view another store option
	I should see the featured deals page with the selected store
	I navigate to Weekly ad from homepage as a cold user
	I choose an store from the store list for getting weeklyads
	I search an deal {0}
	I choose an another store from the store list for getting weeklyads
	I select an Weekly Ad from the result
	I add the weekly Ad deal to list from featured deals
	I add the weeklyad deal to shoppingList from Item details page
	I navigate to Weekly ad by cliking on Hamburger icon
	I see shopping list after selecting plus/Add from action bar
	I select multiple Weekly Ad from the result
	I click on plus/Add to list from featured deals page
	I verify Item details page
	I should see deal page
	I add the weekly Ad deal from featured deals to list and cancel it
	I select a Weekly Ad by clicking on deal check box from the result
	I delete all items from the added list
	I select an Weekly Ad from changed category result page
	I add the weeklyad deal to shoppingList from Item details page for cold user
	I see Search field by clcking on search icon from featured deals page
	I verify the user not able to add the weekly ad to list without selecting
	I add the weekly Ads to list from featured deals page
	I verify if the added items are available in the selected list
	I choose the another category for weeklyAds
	I verify the changed weekly ad
	I validate the Search Field is empty on clicking X icon
	Verify no result found for invalid search
	I click on plus/Add to list
	I click on cancel from add to list pop up
	I verify that add to list modal is not displayed
	I choose a category for weeklyAds dropdown
	search and select multiple deals
	I validate blue checkmark for selected deal in Features deal page
	navigate into each deal details page and back to deals page
	the added items should available in the list
	I see the weekly grocery list after selecting plus/Add from action bar
	I choose the category for weeklyAds*/



public class AndroidStepDefWeeklyAds {
	/**
	 * verify that user is able to change store from view another store option
	 */
	@QAFTestStep(description = "I click on view another store option")
	public void iClickOnViewAnotherStoreOption() {
		WeeklyadslandingTestPage weeklyadlandingpage = new WeeklyadslandingTestPage();

		weeklyadlandingpage.getWeeklyadBtnViewanotherstore().waitForPresent();
		weeklyadlandingpage.getWeeklyadBtnViewanotherstore().click();
	}

	@QAFTestStep(description = "I should see the featured deals page with the selected store")
	public void iShouldSeeTheFeaturedDealsPageWithTheSelectedStore() {
		WeeklyadslandingTestPage weeklyadlandingpage = new WeeklyadslandingTestPage();
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();

		weeklyadlandingpage.getWeeklyadLblDisplaystorename().waitForPresent(10000);
		weeklyadlandingpage.getWeeklyadLblPageTitle().waitForPresent(30000);

		weeklyadlanding.waitForPageToLoad();

		String strStorename = weeklyadlandingpage.getWeeklyadLblDisplaystorename().getText();
		String strStorenameFromStorelocatorPage = getBundle().getString("strStoreAddress");
		weeklyadlandingpage.getWeeklyadLblDisplaystorename().waitForText(strStorenameFromStorelocatorPage, 10000);

		if (strStorenameFromStorelocatorPage.equalsIgnoreCase(strStorename)) {
			PerfectoUtils.reportMessage("Pass: The store has been changed successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Fail: The store has not been changed successfully. Expected: "
					+ strStorenameFromStorelocatorPage + " Actual: " + strStorename + "", MessageTypes.Fail);
		}
	}

	/**
	 * cold user is able to navigate to weekly add from home page
	 */
	@QAFTestStep(description = "I navigate to Weekly ad from homepage as a cold user")
	public void iNavigateToWeeklyAdFromHomepageAsAColdUser() {
		HomeTestPage homepage = new HomeTestPage();
		String Stepname = new Object() {
		}.getClass().getEnclosingMethod().getName();

		System.out.println("Executing : " + Stepname);
		homepage.getHomeLblWeeklyAd().verifyPresent();

		if (homepage.getHomeLblWeeklyAd().isPresent()) {
			homepage.getHomeLblWeeklyAd().click();
		} else {
			System.out.println("Swiping to find weekly Ads");
			do {
				PerfectoUtils.verticalswipe();
				homepage.getHomeLblWeeklyAd().verifyPresent();
			} while (!homepage.getHomeLblWeeklyAd().isPresent());
		}
	}

	/**
	 * user selects a store from store list and on choosing store name and
	 * address of the store is verified
	 */
	@QAFTestStep(description = "I choose an store from the store list for getting weeklyads")
	public void iChooseAnStoreFromTheStoreListForGettingWeeklyads() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();

		// Clicking the allow button from the pop-up to access the device
		// location
		if (storepage.getStorelocatorBtnAllow().isPresent()) {
			storepage.getStorelocatorBtnAllow().click();
		}

		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);
		System.out.println(storelistresult.getStorelocatorLblStoreresults().size());
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(2);
		String StoreName = store.getStorelocatorLblStorename().getText();
		String strStoreAddress = store.getStorelocatorLblStoreaddress().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
		getBundle().setProperty("strStoreAddress", strStoreAddress);
		store.click();

		weeklyadresults.getWeeklyadSearchresult().get(0).waitForPresent(50000);
	}

	/**
	 * user search for a deal and if same deal is found user select the deal
	 */
	@QAFTestStep(description = "I search an deal {0}")
	public static String iSearchAnDeal(String searchproduct) {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();

		searchproduct(searchproduct);
		WeeklyadResult result = weeklyadresults.getWeeklyadSearchresult().get(0);

		/* Get deal name and click */
		String DealName = result.getWeeklyadLblDealname().getText();
		PerfectoUtils.reportMessage("Deal Name:" + DealName);
		getBundle().setProperty("ChoosenProduct", DealName);
		result.getWeeklyadCheckboxSelectdeal().click();
		return DealName;
	}

	/**
	 * User selects a different store from the store list
	 */
	@QAFTestStep(description = "I choose an another store from the store list for getting weeklyads")
	public void iChooseAnAnotherStoreFromTheStoreListForGettingWeeklyads() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		/* Handling allow Heb location popup */
		try {
			weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access").waitForPresent(5000);
			if (weeklygrocery.getShopingListEntryByLable("Allow H-E-B to access").isPresent()) {
				PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Info);
				androidcommon.getAppPopupBtnAllowPermission().verifyPresent();
				androidcommon.getAppPopupBtnAllowPermission().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		storepage.getStorelocatorImgListswitch().waitForPresent(8000);
		storepage.getStorelocatorImgListswitch().click();
		storelistresult.launchPage(null);
		StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
		String StoreName = store.getStorelocatorLblStorename().getText();
		String strStoreAddress = store.getStorelocatorLblStoreaddress().getText();
		PerfectoUtils.reportMessage("Store Name:" + StoreName);
		getBundle().setProperty("strStoreAddress", strStoreAddress);
		System.out.println("strStoreAddress: " + strStoreAddress);
		store.click();
	}

	/**
	 * user select a weekly add from the from the result and click on the
	 * selected product
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select an Weekly Ad from the result")
	public void iSelectAnWeeklyAdFromTheResult() throws InterruptedException {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();

		weeklyadresults.waitForPageToLoad();
		weeklyadresults.getWeeklyadLstDealname().get(0).waitForPresent(5000);

		/* Getting the second weekly add name */
		WeeklyadResult strWeeklyAddname = weeklyadresults.getWeeklyadLstDealname().get(0);
		getBundle().setProperty("ChoosenProduct", strWeeklyAddname.getText());

		/* Clicking the selected product */
		weeklyadresults.getWeeklyadLstDealname().get(0).click();
		PerfectoUtils.reportMessage("Selected: " + strWeeklyAddname + " weekly add", MessageTypes.Info);
	}

	/**
	 * user add the weekly Ad deal to list from featured deals
	 */
	@QAFTestStep(description = "I add the weekly Ad deal to list from featured deals")
	public void iAddTheWeeklyadDealToShoppingList() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		addtolist.waitForPageToLoad();
		addtolist.getAddtoList().click();
		PerfectoUtils.reportMessage("cliked on plus icon from bottom of page", MessageTypes.Pass);
		String SListName = addtolist.getAddtolistChoosenlist().getText();
		getBundle().setProperty("NewListName", SListName);
		getBundle().setProperty("SelectedList", SListName);
		PerfectoUtils.reportMessage("List name(Shoping List ) Name:" + getBundle().getString("NewListName"));
		getBundle().setProperty("Choosen List", getBundle().getString("NewListName"));
		addtolist.getAddtolistBtnAdd().click();
	}

	/**
	 * user add the weekly ad deal to shoppingList from Item details page"
	 */
	@QAFTestStep(description = "I add the weeklyad deal to shoppingList from Item details page")
	public void iAddTheWeeklyadDealToShoppingListFromItemDetailsPage() {
		AddtolistTestPage addtolist = new AddtolistTestPage();
		WeeklyaddealdetailTestPage weeklydetails = new WeeklyaddealdetailTestPage();

		weeklydetails.waitForPageToLoad();
		weeklydetails.getWeeklyaddetailProductname().verifyPresent();
		String DealName = weeklydetails.getWeeklyaddetailProductname().getText();
		PerfectoUtils.reportMessage("Deal Name:" + DealName);
		System.out.println(DealName);
		getBundle().setProperty("ChoosenProduct", DealName);

		// Clicking add to list icon from item details page
		try {
			addtolist.getAddtolistIconPlus().waitForPresent(3000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		addtolist.getAddtolistIconPlus().verifyPresent();
		addtolist.getAddtolistIconPlus().click();
		PerfectoUtils.reportMessage("cliked on plus icon from navigation bar", MessageTypes.Pass);

		addtolist.getAddtolistChoosenlist().verifyPresent();
		String SListName = addtolist.getAddtolistChoosenlist().getText();
		getBundle().setProperty("NewListName", SListName);
		PerfectoUtils.reportMessage("List name(Shoping List ) Name:" + getBundle().getString("NewListName"));
		getBundle().setProperty("Choosen List", getBundle().getString("NewListName"));

		String newListNameValue = ConfigurationManager.getBundle().getString("NewListName");

		/* Check for Weekly Grocery */
		if (newListNameValue.equalsIgnoreCase("Weekly Groceries")) {
			PerfectoUtils.reportMessage("Incorrect List:", MessageTypes.Fail);
			AssertionService.fail("Weekly Groceries is not for hot user:");
		}

		/* Clicking add icon in add to list popup */
		addtolist.getAddtolistBtnAdd().click();
		PerfectoUtils.reportMessage("Clicked on Add button:", MessageTypes.Pass);
	}

	/**
	 * user navigate to weekly add through the hamburger icon
	 */
	@QAFTestStep(description = "I navigate to Weekly ad by cliking on Hamburger icon")
	public void iNavigateToWeeklyAdFromHomepageAisle() {
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		androidcommon.getAppHamburger().waitForPresent(5000);
		androidcommon.getAppHamburger().click();
		androidcommon.waitForPageToLoad();
		androidcommon.getAppSliderWeeklyad().waitForPresent(3000);
		androidcommon.getAppSliderWeeklyad().click();
		storelocator.waitForPageToLoad();
	}

	/**
	 * user see the list on clicking on plus icon from bottom of the page
	 */
	@QAFTestStep(description = "I see shopping list after selecting plus/Add from action bar")
	public void iSeeShoppingListAfterSelectingPlusAddFromActionBar() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		addtolist.waitForPageToLoad();
		addtolist.getAddtoList().click();
		PerfectoUtils.reportMessage("cliked on plus icon from bottom of page", MessageTypes.Pass);
		String SListName = addtolist.getAddtolistChoosenlist().getText();
		getBundle().setProperty("NewListName", SListName);
		PerfectoUtils.reportMessage("List name(Shoping List ) Name:" + getBundle().getString("NewListName"));
		getBundle().setProperty("Choosen List", getBundle().getString("NewListName"));
		addtolist.getAddtolistBtnAdd().click();
	}

	/**
	 * user selects multiple weekly add from the result
	 */
	@QAFTestStep(description = "I select multiple Weekly Ad from the result")
	public void iSelectMultipleWeeklyAdFromTheResult() {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();

		/* Getting the first and second weekly add name */
		List<String> dealname = new ArrayList<String>();
		WeeklyadResult strWeeklyAddnameone = weeklyadresults.getWeeklyadLstDealname().get(1);
		dealname.add(strWeeklyAddnameone.getText());

		if (weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).isEnabled()) {
			WeeklyadResult strWeeklyAddnamezero = weeklyadresults.getWeeklyadLstDealname().get(0);
			dealname.add(strWeeklyAddnamezero.getText());
		}

		getBundle().setProperty("arrActualItemname", dealname);

		/*
		 * Getting the object dynamically with respect to Weekly add name and
		 * Clicking on multiple weekly ad
		 */
		weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(1).click();
		PerfectoUtils.reportMessage("Multiple deals selected", MessageTypes.Pass);
	}

	/**
	 * user add a product to list from featured deals page
	 */
	@QAFTestStep(description = "I click on plus/Add to list from featured deals page")
	public void iClickOnPlusFromFeaturedDealsPage() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		AddtolistTestPage addtolist = new AddtolistTestPage();

		weeklyadlanding.getImgPlus().verifyPresent();
		weeklyadlanding.getImgPlus().click();

		if (weeklyadlanding.getWeeklyadPopupTitleWeeklyaderror().isPresent()) {
			weeklyadlanding.getWeeklyadPopupOkBtnWeeklyaderror().click();
		}

		if (weeklyadlanding.getLblPopcontent().isPresent()) {
			String strListname = weeklyadlanding.getLblPopcontent().getText();
			getBundle().setProperty("SelectedList", strListname);
			addtolist.getAddtolistBtnAdd().click();
			PerfectoUtils.reportMessage("Clicked: on add button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Toast message is yet to be implemnted", MessageTypes.Info);
		}
	}

	/**
	 * user navigates to item detail page and verifies it
	 */
	@QAFTestStep(description = "I verify Item details page")
	public void iVerifyItemDetailsPage() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		WeeklyadsresultlistTestPage weeklyresult = new WeeklyadsresultlistTestPage();

		weeklyadlanding.getImgAdimage().verifyPresent();
		if (weeklyresult.getImgDividerimage().isPresent()) {
			PerfectoUtils.reportMessage("Divider image is present for the selected image", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Divider image is not present for the selected image", MessageTypes.Info);
		}
		weeklyresult.getLblExpirydate().verifyPresent();
		weeklyresult.getLblPgtitleitemdetail().verifyPresent();
		weeklyresult.getLblProductprice().verifyPresent();
		weeklyresult.getLblProducttitle().verifyPresent();
	}

	/**
	 * user should see the deal page once the item is added to shopping list
	 */
	@QAFTestStep(description = "I should see deal page")
	public void iShouldSeeDealPage() {
		WeeklyadslandingTestPage weeklylanding = new WeeklyadslandingTestPage();
		String pageTitle = null;

		pageTitle = weeklylanding.getWeeklyadBtnCatagorydropdown().getText();
		if (pageTitle.equals("Featured Deals")) {
			PerfectoUtils.reportMessage("Item is added to shopping list successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Item is not added to shopping list", MessageTypes.Fail);
		}
	}

	/**
	 * user adds the weekly Ad deal from featured deals to list and cancel it
	 */
	@QAFTestStep(description = "I add the weekly Ad deal from featured deals to list and cancel it")
	public void iAddTheWeeklyAdDealToListAndCancelItFromFeaturedDeals() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		addtolist.waitForPageToLoad();
		addtolist.getAddtoList().click();
		PerfectoUtils.reportMessage("cliked on plus icon from bottom of page", MessageTypes.Pass);
		PerfectoUtils.reportMessage("List name(Shoping List ) Name:" + getBundle().getString("NewListName"));
		getBundle().setProperty("Choosen List", getBundle().getString("NewListName"));
		addtolist.getAddtolistBtnCancel().click();
	}

	/**
	 * user selects a weekly add by clicking on deal check box from result
	 */
	@QAFTestStep(description = "I select a Weekly Ad by clicking on deal check box from the result")
	public void iSelectAWeeklyAdByClickingOnDealCheckboxFromTheResult() {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		String strDeal = null;

		/* Getting the first and second weekly add name */
		weeklyadresults.waitForPageToLoad();
		try {
			weeklyadresults.getWeeklyadLstDealname().get(0).waitForPresent(5000);
			if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
				PerfectoUtils.reportMessage("Weekly ad deals are not listed for selected Store!!", MessageTypes.Info);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Selecting another store to get weekly ads", MessageTypes.Info);
			iClickOnViewAnotherStoreOption();
			iChooseAnStoreFromTheStoreListForGettingWeeklyads();
			weeklyadresults.getWeeklyadLstDealname().get(0).waitForPresent(5000);
		}
		strDeal = weeklyadresults.getWeeklyadLstDealname().get(0).getText();
		getBundle().setProperty("ChoosenProduct", strDeal);

		System.out.println(weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).getAttribute("checked"));
		if (weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).getAttribute("checked").equals("false"))
			PerfectoUtils.reportMessage("Checkbox is disabled when no item is checked..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Checkbox is not disabled when no item is checked..", MessageTypes.Fail);

		/*
		 * Getting the object dynamically with respect to Weekly add name and
		 * Clicking on multiple weekly ad
		 */
		weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).click();
		PerfectoUtils.reportMessage("Selected: " + strDeal + " weekly add", MessageTypes.Pass);

		System.out.println(weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).getAttribute("checked"));
		if (weeklyadresults.getWeeklyadCheckboxSelectdeal1().get(0).getAttribute("checked").equals("true"))
			PerfectoUtils.reportMessage("Checkbox is enabled when item is checked..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Checkbox is not enabled when item is checked..", MessageTypes.Fail);
	}

	/**
	 * user delete all the added list
	 */
	@QAFTestStep(description = "I delete all items from the added list")
	public static void iDeleteAllItemsFromTheAddedList() {
		AndroidStepDefShoppingList androidstepdefshoppinglist = new AndroidStepDefShoppingList();
		ListdetailsTestPage listdetailsTestPage = new ListdetailsTestPage();

		int itemCount;
		String strItemCount = listdetailsTestPage.getListpageLblShoppingitemcount().getText().replaceAll("Items", "")
				.replaceAll("Item", "").trim();
		System.out.println((strItemCount.replaceAll("Items", "")).replaceAll("Item", ""));
		itemCount = Integer.parseInt(strItemCount);

		if (itemCount > 0) {
			androidstepdefshoppinglist.iSelectTheOverflowIconFromTheActionBar();
			androidstepdefshoppinglist.iSelectDeleteAllItemsOption();
			androidstepdefshoppinglist.iShouldSeeAllItemsAreDeletedFromList();
		} else {
			PerfectoUtils.reportMessage("No items found.", MessageTypes.Pass);
		}
	}

	/**
	 * user selects an weekly ad from changed category result page
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select an Weekly Ad from changed category result page")
	public void iSelectAnWeeklyAdFromChangedCategoryResultPage() throws InterruptedException {

		iSelectAnWeeklyAdFromTheResult();
	}

	/**
	 * cold user add a weekyad deal to shopping list from items detail page
	 */
	@QAFTestStep(description = "I add the weeklyad deal to shoppingList from Item details page for cold user")
	public void iAddTheWeeklyadDealToShoppingListFromItemDetailsPageForColdUser() {
		AddtolistTestPage addtolist = new AddtolistTestPage();
		WeeklyaddealdetailTestPage weeklydetails = new WeeklyaddealdetailTestPage();

		weeklydetails.waitForPageToLoad();
		weeklydetails.getWeeklyaddetailProductname().verifyPresent();
		String DealName = weeklydetails.getWeeklyaddetailProductname().getText();
		PerfectoUtils.reportMessage("Deal Name:" + DealName);
		System.out.println(DealName);
		getBundle().setProperty("ChoosenProduct", DealName);

		// Clicking add to list icon from item details page
		try {
			addtolist.getAddtolistIconPlus().waitForPresent(3000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
		}
		addtolist.getAddtolistIconPlus().verifyPresent();
		addtolist.getAddtolistIconPlus().click();
		PerfectoUtils.reportMessage("cliked on plus icon from navigation bar", MessageTypes.Pass);
		String SListName = addtolist.getAddtolistChoosenlist().getText();
		getBundle().setProperty("NewListName", SListName);
		PerfectoUtils.reportMessage("List name(Shoping List ) Name:" + getBundle().getString("NewListName"));
		getBundle().setProperty("Choosen List", getBundle().getString("NewListName"));

		/* Clicking add icon in add to list popup */
		addtolist.getAddtolistBtnAdd().click();
		PerfectoUtils.reportMessage("Clicked on Add button:", MessageTypes.Pass);
	}

	/**
	 * User see Search field by clcking on search icon from featured deals page
	 */
	@QAFTestStep(description = "I see Search field by clcking on search icon from featured deals page")
	public void iSeeSearchFieldByClckingOnSearchIconFromFeaturedDealsPage() {
		StoremapviewTestPage mapview = new StoremapviewTestPage();

		/* Click on search icon */
		mapview.getStorelocatorIconSearch().waitForPresent(1000);
		mapview.getStorelocatorIconSearch().click();

		/* Verifying Search icon text */
		mapview.getStorelocatorTxtSearch().waitForPresent(2000);
		mapview.getStorelocatorTxtSearch().verifyPresent();
	}

	/**
	 * User is not able to add the weekly ad to list without selecting it
	 */
	@QAFTestStep(description = "I verify the user not able to add the weekly ad to list without selecting")
	public void iVerifyTheUserNotAbleToAddTheWeeklyAdToListWithoutSelecting() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		AddtolistTestPage addtolist = new AddtolistTestPage();

		weeklyadlanding.getImgPlus().verifyPresent();
		weeklyadlanding.getImgPlus().click();

		if (weeklyadlanding.getWeeklyadPopupTitleWeeklyaderror().isPresent()) {
			weeklyadlanding.getWeeklyadPopupOkBtnWeeklyaderror().click();
		}

		if (weeklyadlanding.getLblPopcontent().isPresent()) {
			String strListname = weeklyadlanding.getLblPopcontent().getText();
			getBundle().setProperty("SelectedList", strListname);
			addtolist.getAddtolistBtnAdd().click();
			PerfectoUtils.reportMessage("Clicked: on add button", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("Toast message is yet to be implemnted", MessageTypes.Info);
		}
	}

	/**
	 * user add weekly add to list from featured deals page
	 */
	@QAFTestStep(description = "I add the weekly Ads to list from featured deals page")
	public void iAddTheWeeklyAdsToListFromFeaturedDealsPage() {
		AddtolistTestPage addtolist = new AddtolistTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		addtolist.waitForPageToLoad();
		addtolist.getAddtoList().click();

		/* Click on bottom list and compare */
		String strNewlistName = getBundle().getString("NewListName");
		boolean listSelect = false;
		int i = 0;

		do {
			String listName = androidcommon.getAddtolistTxtNumberpicker().getText();
			if (listName.equals(strNewlistName)) {
				break;
			} else {

				int getSize = androidcommon.getAddtolistTxtNextpicker().size();

				if (getSize > 0) {
					int actualSize = getSize - 1;
					androidcommon.getAddtolistTxtNextpicker().get(actualSize).click();
				}

			}
			i++;

		} while (!listSelect && i < 10);

		String SListName = addtolist.getAddtolistChoosenlist().getText();
		getBundle().setProperty("listName", SListName);
		PerfectoUtils.reportMessage("Selected list: " + SListName, MessageTypes.Pass);

		addtolist.getAddtolistBtnAdd().click();
	}

	/**
	 * user verifies that the added item are added to the selected list
	 */
	@QAFTestStep(description = "I verify if the added items are available in the selected list")
	public void iVerifyIfTheAddedItemsAreAvailableInTheSelectedList() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String selectedListName = getBundle().getString("NewListName");
		String addedList = getBundle().getString("listName");
		if (!selectedListName.equalsIgnoreCase(addedList)) {
			PerfectoUtils.reportMessage("List name is selected is not newly created one: Selected: " + addedList, MessageTypes.Info);
			selectedListName = addedList;
		}

		/* Click on selected shopping list */
		try {
			weeklygrocery.getShopingListEntryByLable(selectedListName).waitForPresent(2000);
			weeklygrocery.getShopingListEntryByLable(selectedListName).click();
		} catch (Exception e) {
			PerfectoUtils.scrollToString(selectedListName, 80, 70, 2);
			weeklygrocery.getShopingListEntryByLable(selectedListName).waitForPresent(1000);
			weeklygrocery.getShopingListEntryByLable(selectedListName).click();
		}

		PerfectoUtils.reportMessage("Selected list: " + selectedListName, MessageTypes.Pass);

		String strCount = weeklygrocery.getWgTxtShoppingitemcount().getText();

		if (strCount.contains("Items")) {
			strCount = strCount.replace("Items", "").trim();
		} else if (strCount.contains("Item")) {
			strCount = strCount.replace("Item", "").trim();
		}

		int intCount = Integer.parseInt(strCount);

		if (intCount > 0) {
			PerfectoUtils.reportMessage("All " + intCount + " items are added to list", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("All " + intCount + " items are not added to list", MessageTypes.Fail);
		}
	}

	/**
	 * user choose the another category for weeklyAds
	 */
	@QAFTestStep(description = "I choose the another category for weeklyAds")
	public void iChooseTheAnotherCategoryForWeeklyAds() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();

		weeklyadlanding.getWeeklyadBtnCatagorydropdown().click();
		String Category = ConfigurationManager.getBundle().getString("WeeklyAds.anothercategoryname");
		waitForPresent("name=" + Category);
		click("name=" + Category);

		/* Storing product name of newly selected category in list */
		List<String> chngdweeklydeal = new ArrayList<String>();
		for (int i = 0; i < weeklyadlanding.getLblAdname().size(); i++) {
			chngdweeklydeal.add(weeklyadlanding.getLblAdname().get(i).getText());
		}

		getBundle().setProperty("changeweeklydeal", chngdweeklydeal);
		PerfectoUtils.reportMessage("Expected product name are" + chngdweeklydeal + "name", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify the changed weekly ad")
	public void iVerifyTheChangedWeeklyAd() {
		List<String> actualdweeklydeal = getBundle().getList("actualweeklydeal");
		List<String> chngdweeklydeal = getBundle().getList("changeweeklydeal");

		if (actualdweeklydeal.containsAll(chngdweeklydeal)) {
			PerfectoUtils.reportMessage("The store has not been changed ", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("The store has been changed successfully.", MessageTypes.Pass);
		}
	}

	/**
	 * User validate the Search Field is empty on clicking X icon
	 */
	@QAFTestStep(description = "I validate the Search Field is empty on clicking X icon")
	public void iValidateTheSearchFieldIsEmptyOnClickingXIcon() {
		WeeklyadslandingTestPage weeklyadslandingpage = new WeeklyadslandingTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();
		String searchtxtcontent = null;

		/* Clicking on X icon */
		weeklyadslandingpage.getBtnClosebutton().waitForPresent(3000);
		weeklyadslandingpage.getBtnClosebutton().click();

		/* Validate the Search Field is empty on clicking X icon */
		searchtxtcontent = weeklyadslandingpage.getLblSearchcontent().getText();
		if ((searchtxtcontent.trim()).equals("Search products")) {
			PerfectoUtils.reportMessage("Searched text is cleared in Searh Field on clicking X icon as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Searched text is not cleared in Searh Field on clicking X icon", MessageTypes.Fail);
		}
		androidcommon.getAppBtnCollapse().click();
	}

	/**
	 * Verify no results found for Invalid search
	 */
	@QAFTestStep(description = "Verify no result found for invalid search")
	public void verifyNoResultFoundForInvalidSearch() {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();

		int resultSize = weeklyadresults.getWeeklyadLstDealname().size();

		if (resultSize > 0) {
			PerfectoUtils.reportMessage(resultSize + "results found for Invalid search.", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("No results found for Invalid search.", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I click on plus/Add to list")
	public void iclickonplusAddtolist() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();

		weeklyadlanding.getImgPlus().verifyPresent();
		weeklyadlanding.getImgPlus().click();
		PerfectoUtils.reportMessage("cliked on plus icon from bottom of page", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I click on cancel from add to list pop up")
	public void iclickoncancelfromaddtolistpopup() {

		AddtolistTestPage addtolist = new AddtolistTestPage();
		addtolist.waitForPageToLoad();
		addtolist.getAddtolistBtnCancel().click();
		PerfectoUtils.reportMessage("cliked on cancel for add to list modal", MessageTypes.Pass);
	}

	@QAFTestStep(description = "I verify that add to list modal is not displayed")
	public void iverifythataddtolistmodalisnotdisplayed() {
		AddtolistTestPage addtolist = new AddtolistTestPage();
		addtolist.waitForPageToLoad();
		if (!addtolist.getAddtolistBtnCancel().isPresent()) {
			PerfectoUtils.reportMessage("Add to list modal is not displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list modal is  displayed", MessageTypes.Fail);
		}
	}

	/**
	 * user choose a category for weeklyAds dropdown
	 */
	@QAFTestStep(description = "I choose a category for weeklyAds dropdown")
	public void iChooseACategoryForWeeklyAdsDropdown() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		WeeklyadslandingTestPage weeklyadlandingpage = new WeeklyadslandingTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		weeklyadlanding.waitForPageToLoad();
		if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
			// new code to select a different store
			weeklyadlandingpage.getWeeklyadBtnViewanotherstore().waitForPresent();
			weeklyadlandingpage.getWeeklyadBtnViewanotherstore().click();
			StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
			store.click();
			if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
				PerfectoUtils.reportMessage("Weekly ad deals are not listed for selected Store!!", MessageTypes.Fail);

			}
		}
		if (weeklyadlanding.getWeeklyadBtnCatagorydropdown().isPresent()) {
			weeklyadlanding.getWeeklyadBtnCatagorydropdown().click();
			PerfectoUtils.horizontalswipe();
			try {
				weeklyadlanding.getLblCategoryName().get(0).waitForPresent(3000);
			} catch (Exception e) {
			}
			String categoryName = weeklyadlanding.getLblCategoryName().get(0).getText();
			String categoryItemCount = weeklyadlanding.getLblCategoryItemCount().get(0).getText();
			ConfigurationManager.getBundle().setProperty("WeeklyAds.categoryName", categoryName);
			ConfigurationManager.getBundle().setProperty("WeeklyAds.categoryCount", categoryItemCount);
			waitForPresent("name=" + categoryName);
			click("name=" + categoryName);
		} else {

			PerfectoUtils.reportMessage("There was an error displaying your store's weekly ad. Please try again", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "search and select multiple deals")
	public void searchAndSelectMultipleDeals() {
		WeeklyadslandingTestPage weeklyadslandingpage = new WeeklyadslandingTestPage();
		String deal1 = ConfigurationManager.getBundle().getString("WeeklyAds.Multiple.deal1");
		String deal2 = ConfigurationManager.getBundle().getString("WeeklyAds.Multiple.deal2");

		/**
		 * Select Deal1
		 */
		String Deal1 = iSearchAnDeal(deal1);
		getBundle().setProperty("ChoosenProduct1", Deal1);
		weeklyadslandingpage.getBtnClosebutton().click();
		/**
		 * Select Deal2
		 */
		String Deal2 = iSearchAnDeal(deal2);
		getBundle().setProperty("ChoosenProduct2", Deal2);
		weeklyadslandingpage.getBtnClosebutton().click();

		PerfectoUtils.androiddeviceback();
		PerfectoUtils.androiddeviceback();
	}

	@QAFTestStep(description = "I validate blue checkmark for selected deal in Features deal page")
	public void iValidateBlueCheckmarkForSelectedDealInFeaturesDealPage() {
		String deal1 = getBundle().getString("ChoosenProduct1");
		String deal2 = getBundle().getString("ChoosenProduct2");

		validatecheckboxselected(deal1);
		validatecheckboxselected(deal2);
	}

	public static void searchproduct(String searchproduct) {
		WeeklyadslandingTestPage weeklylanding = new WeeklyadslandingTestPage();

		weeklylanding.getWeeklyadBtnSearchdeals().verifyPresent();
		weeklylanding.getWeeklyadBtnSearchdeals().click();

		AndroidStepDef.enterValueIntoTheTextboxandClick(weeklylanding, searchproduct);
	}

	public void validatecheckboxselected(String ChoosenDeal) {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		WeeklyadslandingTestPage weeklyadslandingpage = new WeeklyadslandingTestPage();

		searchproduct(ChoosenDeal);

		WeeklyadResult result = weeklyadresults.getWeeklyadSearchresult().get(0);
		/* Get deal name and click */
		String DealName = result.getWeeklyadLblDealname().getText();
		if (DealName.equals(ChoosenDeal)) {
			String chkboxval = result.getWeeklyadCheckboxSelectdeal().getAttribute("checked");
			if (chkboxval.equals("true")) {
				PerfectoUtils.reportMessage("Deal " + DealName + " selected correctly", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Deal " + DealName + " is not selected correctly", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("No Deal with " + DealName + " is Filtered", MessageTypes.Fail);
		}

		weeklyadslandingpage.getBtnClosebutton().click();
	}

	@QAFTestStep(description = "navigate into each deal details page and back to deals page")
	public void navigateIntoEachDealDetailsPageAndBackToDealsPage() {
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		WeeklyaddealdetailTestPage weeklydetails = new WeeklyaddealdetailTestPage();
		WeeklyadslandingTestPage weeklyadslandingpage = new WeeklyadslandingTestPage();
		String DealName = getBundle().getString("ChoosenProduct");

		WeeklyadResult result = weeklyadresults.getWeeklyadSearchresult().get(0);
		result.getWeeklyadLblDealname().click();

		/**
		 * Validate Item Details Page
		 */
		String ItemName = weeklydetails.getWeeklyaddetailProductname().getText();
		if (ItemName.equals(DealName)) {
			PerfectoUtils.reportMessage("Successfully navigated to Item details page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Item details page", MessageTypes.Fail);
		}

		PerfectoUtils.androiddeviceback();
		weeklyadslandingpage.getBtnClosebutton().click();
		PerfectoUtils.androiddeviceback();
	}

	@QAFTestStep(description = "the added items should available in the list")
	public void theAddedItemsShouldAvailableInTheList() throws Exception {
		String Deal1 = getBundle().getString("ChoosenProduct1");
		String Deal2 = getBundle().getString("ChoosenProduct2");

		iShouldSeeTheSelectedItemInList(Deal1);
		iShouldSeeTheSelectedItemInList(Deal2);
	}

	public void iShouldSeeTheSelectedItemInList(String dealname) throws Exception {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		/* Validate if selected item is listed in selected list detail page */
		boolean isPdtDisplayed = false;
		String productName = "";
		int noOfSwipes = 0;

		/* Iteration to compare the selected pdt in the list details page */
		try {
			do {
				for (ShoppinglistResult product : weeklygrocery.getWgListItemlist()) {
					productName = product.getWgListItemname().getText();
					if (productName.contains("&quot;")) {
						productName = productName.replaceAll("&quot;", "\"");
					}
					if ((dealname.contains(productName))) {
						isPdtDisplayed = true;
						break;
					}
				}

				if (!isPdtDisplayed) {
					PerfectoUtils.verticalswipe(80, 75, 2);
				}
				noOfSwipes++;
			} while (noOfSwipes < 10 && !isPdtDisplayed);

		} catch (Exception e) {
			/* Deleting All the items in the list, if found exception */
			AndroidStepDefWeeklyAds.iDeleteAllItemsFromTheAddedList();
		}

		if (isPdtDisplayed) {
			PerfectoUtils.reportMessage("Added item: " + productName + " present in the list details page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Added item: " + productName + " is not present in the list details page", MessageTypes.Fail);
		}

	}

	/**
	 * user see the weekly grocery list after selecting plus/Add from action bar
	 */
	@QAFTestStep(description = "I see the weekly grocery list after selecting plus/Add from action bar")
	public void iSeeTheWeeklyGroceryListAfterSelectingPlusIconFromActionBar() {
		WeeklyadslandingTestPage weeklyadslanding = new WeeklyadslandingTestPage();
		MylistTestPage mylist = new MylistTestPage();
		AndroidcommonTestPage androidcommonpage = new AndroidcommonTestPage();
		String pickerName;

		// Clicking on plus/Add button
		weeklyadslanding.getImgPlus().isPresent();
		weeklyadslanding.getImgPlus().click();

		if (mylist.getMyListsBtnCancel().isPresent()) {
			PerfectoUtils.reportMessage("Able to see Add to list.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see Add to list.", MessageTypes.Fail);
		}
		if (androidcommonpage.getAddtolistTxtNumberpicker().isPresent()) {
			pickerName = androidcommonpage.getAddtolistTxtNumberpicker().getText();
			getBundle().setProperty("ChoosenList", pickerName);
		}
	}

	/**
	 * user choose a category for weekly add
	 */
	@QAFTestStep(description = "I choose the category for weeklyAds")
	public void iChooseTheCategoryForWeeklyAds() {
		WeeklyadslandingTestPage weeklyadlanding = new WeeklyadslandingTestPage();
		WeeklyadsresultlistTestPage weeklyadresults = new WeeklyadsresultlistTestPage();
		WeeklyadslandingTestPage weeklyadlandingpage = new WeeklyadslandingTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		weeklyadlanding.waitForPageToLoad();
		if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
			// new code to select a different store
			weeklyadlandingpage.getWeeklyadBtnViewanotherstore().waitForPresent();
			weeklyadlandingpage.getWeeklyadBtnViewanotherstore().click();
			StoreResult store = storelistresult.getStorelocatorLblStoreresults().get(1);
			store.click();
			if (weeklyadresults.getWeeklyadLstDealname().isEmpty()) {
				PerfectoUtils.reportMessage("Weekly ad deals are not listed for selected Store!!", MessageTypes.Fail);

			}
		}
		if (weeklyadlanding.getWeeklyadBtnCatagorydropdown().isPresent()) {
			weeklyadlanding.getWeeklyadBtnCatagorydropdown().click();

			String Category = null;
			// String Category2 =
			// ConfigurationManager.getBundle().getString("WeeklyAds.subcategoryName1");
			try {
				Category = ConfigurationManager.getBundle().getString("WeeklyAds.subcategoryName1");

				waitForPresent("name=" + Category);

			} catch (Exception e) {
				Category = ConfigurationManager.getBundle().getString("WeeklyAds.subcategoryName2");

				waitForPresent("name=" + Category);

			}
			String subcategoryItemCount = weeklyadlanding.getSubCategoryCount(Category).getText();
			getBundle().setProperty("WeeklyAds.categoryCount", subcategoryItemCount);

			System.out.println(Category);
			//waitForPresent("name=" + Category);
			click("name=" + Category);
		} else {

			PerfectoUtils.reportMessage("There was an error displaying your store's weekly ad. Please try again", MessageTypes.Fail);
		}

	}
}
