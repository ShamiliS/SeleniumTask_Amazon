package com.heb.automation.common;

import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.Response;

import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;
import com.qmetry.qaf.automation.util.Reporter;

public class IOSWebElementListener extends QAFWebElementCommandAdapter {

	@Override
	public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.IS_ELEMENT_DISPLAYED)) {
			Response response = new Response();

			response.setValue(true);
			commandTracker.setResponce(response);
		}

		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.CLEAR_ELEMENT)) {
			Response response = new Response();
			commandTracker.setResponce(response);
		}
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
			element.clear();
			element.click();
			element.getWrappedDriver().getKeyboard()
					.sendKeys((CharSequence[]) commandTracker.getParameters().get("value"));
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void afterCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
		if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
			try {
				PerfectoUtils.getAppiumDriver().hideKeyboard();
			} catch (Exception e) {
				/* Just ignore it */
			}
		}
	}

	@Override
	public void onFailure(QAFExtendedWebElement element, CommandTracker commandTracker) {
	/*	AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		IoscommonTestPage iosfun = new IoscommonTestPage();
		
		super.onFailure(element, commandTracker);

		if (appCrash.getExceptionBtnOk().isPresent()) {
			appCrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Unexpected error in Application. Click Ok button");
		}*/

		/*if (appCrash.getLoginrequiredPopup().isPresent()) {
			appCrash.getEnterPassword().sendKeys("automation1");
			appCrash.getSubmitLogincredentials().click();
		}

		if (appCrash.getSoftwareUpdatePopup().isPresent()) {
			appCrash.getSoftwareUpdateLater().click();
		}

		if (appCrash.getAllowPopup().isPresent()) {
			appCrash.getAllowPopup().click();
			PerfectoUtils.reportMessage("Allow is enabled");
		}*/

	/*	if (ioscommon.getAppLblLoading().isPresent()) {
			ioscommon.getAppLblLoading().waitForNotPresent(30000);
		}
		if (iosfun.getAppBtnSkip().isPresent()) {
			iosfun.getAppBtnSkip().click();
			PerfectoUtils.reportMessage("Clicked Skip button.");
		}*/
	}
}
