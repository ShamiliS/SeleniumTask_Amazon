package com.heb.automation.common;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import com.perfecto.reportium.client.ReportiumClient;
import com.qmetry.qaf.automation.step.QAFTestStepAdapter;
import com.qmetry.qaf.automation.step.StepExecutionTracker;

public class ThresholdListener extends QAFTestStepAdapter {
	public static final String PERFECTO_REPORT_CLIENT = "perfecto.report.client";

	public void beforExecute(StepExecutionTracker stepExecutionTracker) {
		try {
			ReportiumClient reportClient = (ReportiumClient) getBundle().getObject(PERFECTO_REPORT_CLIENT);
			reportClient.testStep(stepExecutionTracker.getStep().getDescription());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void afterExecute(StepExecutionTracker stepExecutionTracker) {
		long duration = (stepExecutionTracker.getEndTime() - stepExecutionTracker.getStartTime()) / 1000;
		if (stepExecutionTracker.getStep().getThreshold() > duration)
			stepExecutionTracker.setVerificationError("Threshold value is exceed");
	}
}