package com.heb.automation.common.components;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartDetails extends QAFWebComponent {

	@FindBy(locator = "cartpage.list.cartitemslist")
	private List<CartDetails> cartListCartItemsList;
	
	@FindBy(locator = "cartpage.list.cartitemnameslist")
	private List<CartDetails> cartListCartItemNamesList;


	
	public CartDetails(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	public List<CartDetails> getCartListCartItemsList() {
		return cartListCartItemsList;
	}

	public List<CartDetails> getCartListCartItemNamesList() {
		return cartListCartItemNamesList;
	}
	
}