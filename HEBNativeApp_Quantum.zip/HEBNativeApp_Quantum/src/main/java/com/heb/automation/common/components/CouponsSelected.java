package com.heb.automation.common.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsSelected extends QAFWebComponent {

	@FindBy(locator = "couponselection.lbl.expirekey")
	private QAFWebElement lblExpirekey;
	@FindBy(locator = "couponselection.lbl.expirevalue")
	private QAFWebElement lblExpirevalue;
	@FindBy(locator = "couponselection.lbl.coupondesc")
	private QAFWebElement couponsLblCoupondesc;

	public CouponsSelected(String loc) {
		super(loc);
	}

	public QAFWebElement getLblExpirekey() {
		return lblExpirekey;
	}

	public QAFWebElement getLblExpirevalue() {
		return lblExpirevalue;
	}
	
	public QAFWebElement getCouponsLblCoupondesc() {
		return couponsLblCoupondesc;
	}

}
