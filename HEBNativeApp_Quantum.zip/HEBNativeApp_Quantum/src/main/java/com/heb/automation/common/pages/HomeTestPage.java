package com.heb.automation.common.pages;

import java.util.List;

import com.heb.automation.common.components.ScrollableElement;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class HomeTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "home.lbl.recipes")
	private ScrollableElement homeLblRecipes;
	@FindBy(locator = "app.btn.footerhomeicon")
	private QAFWebElement appFooterHomeicon;
	@FindBy(locator = "home.footer.shopicon")
	private QAFWebElement homeFooterShopicon;
	@FindBy(locator = "app.btn.footershoppinglist")
	private QAFWebElement appFooterShoppinglist;
	@FindBy(locator = "home.footer.cart")
	private QAFWebElement homeFooterCart;
	@FindBy(locator = "home.footer.more")
	private QAFWebElement homeFooterMore;
	@FindBy(locator = "home.lbl.shoppinglist")
	private QAFWebElement homeLblShoppingList;
	@FindBy(locator = "home.lbl.productsfinder")
	private QAFWebElement homeLblProduct;
	@FindBy(locator = "home.lbl.signin")
	private QAFWebElement homeLblSignin;
	@FindBy(locator = "home.lbl.weeklyad")
	private QAFWebElement homeLblWeeklyAd;
	@FindBy(locator = "home.element.scroll")
	private QAFWebElement homeEleScroll;
	@FindBy(locator = "home.lbl.digitalcoupon")
	private QAFWebElement homeDigitalCoupon;
	@FindBy(locator = "home.lbl.storelocator")
	private QAFWebElement homeLblStoreLocator;
	@FindBy(locator = "home.lbl.welcomeuser")
	private QAFWebElement homeLblWelcomeUser;
	@FindBy(locator = "home.link.scanproduct")
	private QAFWebElement homeLnkScanProduct;
	@FindBy(locator = "home.lbl.shiptohome")
	private QAFWebElement homeLblShipToHome;
	@FindBy(locator = "home.lbl.shopmystore")
	private QAFWebElement homeLblShopMyStore;
	@FindBy(locator = "home.img.shiptohomeslide")
	private QAFWebElement homeImgShipToHomeSlide;
	@FindBy(locator = "home.lbl.products")
	private QAFWebElement lblProducts;
	@FindBy(locator = "home.img.searchicon")
	private QAFWebElement imgSearchicon;
	@FindBy(locator = "home.img.hero")
	private QAFWebElement imgHomeHero;
	@FindBy(locator = "topslot.img.image")
	private QAFWebElement imgTopslot;
	@FindBy(locator = "topslot.icon.coupons")
	private QAFWebElement iconTopslotCoupon;
	@FindBy(locator = "topslot.icon.products")
	private QAFWebElement iconTopslotProducts;
	@FindBy(locator = "topslot.icon.weeklyad")
	private QAFWebElement iconTopslotWeeklyad;
	@FindBy(locator = "topslot.lbl.coupons")
	private QAFWebElement lblTopslotCoupon;
	@FindBy(locator = "topslot.lbl.products")
	private QAFWebElement lblTopslotProducts;
	@FindBy(locator = "topslot.lbl.weeklyad")
	private QAFWebElement lblTopslotWeeklyad;
	@FindBy(locator = "home.img.heblogo")
	private QAFWebElement imageHeblogo;
	@FindBy(locator = "home.lbl.pharmacy")
	private QAFWebElement lblPharmacy;
	@FindBy(locator = "home.lbl.hebbarcode")
	private QAFWebElement lblHebBarcode;
	@FindBy(locator = "home.lbl.redeemcoupon")
	private QAFWebElement lblRedeemCoupon;
	@FindBy(locator = "home.lbl.curbsidepickup")
	private QAFWebElement lblCurbsidePickup;
	@FindBy(locator = "home.lbl.curbsidealert")
	private QAFWebElement lblCurbsideAlert;
	@FindBy(locator = "home.lbl.curbsidealertbody")
	private QAFWebElement lblCurbsideAlertbody;
	@FindBy(locator = "home.lbl.curbsidealertcancel")
	private QAFWebElement lblCurbsideAlertcancel;
	@FindBy(locator = "home.lbl.curbsidealertok")
	private QAFWebElement lblCurbsideAlertok;
	@FindBy(locator = "home.lbl.shiptohomealertbody")
	private QAFWebElement lblShiptohomeAlertbody;
	
	@FindBy(locator = "home.img.Newbarcode")
	private QAFWebElement homeimgNewbarcode;
	
	@FindBy(locator = "home.txt.Barcodedetailpage")
	private QAFWebElement hometxtBarcodedetailpage;
	@FindBy(locator = "home.lbl.HEBBarcodeHomescreenlist")
	private QAFWebElement homelblHEBBarcodeHomescreenlist;
	
	@FindBy(locator = "home.img.heroimage")
	private QAFWebElement homeimgheroimage;
	@FindBy(locator = "home.lbl.topslot")
	private QAFWebElement homelbltopslot;
	@FindBy(locator = "home.lbl.curbsidepickup")
	private QAFWebElement homelblcurbsidepickup;

	@FindBy(locator = "home.txt.pharmacy")
	private QAFWebElement hometxtpharmacy;
	
	@FindBy(locator = "home.img.Barcodemodal")
	private QAFWebElement homeimgBarcodemodal;
	@FindBy(locator = "home.icon.search")
	private QAFWebElement homeIconSearch;
	@FindBy(locator = "home.txt.searchbox")
	private QAFWebElement homeSearchBox;
	@FindBy(locator = "home.lbl.menulist")
	private List<QAFWebElement> homeMenuList;
	
	@FindBy(locator = "home.lbl.donationssecond")
	private QAFWebElement homelbldonationssecond;
	@FindBy(locator = "home.txt.donationalerttitle")
	private QAFWebElement hometxtdonationalerttitle;
	@FindBy(locator = "home.txt.donationalertmessage")
	private QAFWebElement hometxtdonationalertmessage;
	@FindBy(locator = "home.btn.donationalertcancel")
	private QAFWebElement homebtndonationalertcancel;
	@FindBy(locator = "home.btn.donationalertok")
	private QAFWebElement homebtndonationalertok;
	@FindBy(locator = "home.txt.webbrowesrtitle")
	private QAFWebElement hometxtwebbrowesrtitle;
	@FindBy(locator = "home.lbl.donations")
	private QAFWebElement homelbldonations;
	@FindBy(locator = "home.lbl.donationsfirst")
	private QAFWebElement homelbldonationsfirst;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {

	}

	public QAFWebElement getAppFooterHomeicon() {
		appFooterHomeicon.waitForPresent(5000);
		return appFooterHomeicon;
	}

	public QAFWebElement getAppFooterShoppinglist() {
		return appFooterShoppinglist;
	}

	public QAFWebElement getHomeLblWelcomeUser() {
		return homeLblWelcomeUser;
	}

	public QAFWebElement getHomeLblProduct() {

		return homeLblProduct;
	}

	public QAFWebElement getHomeDigitalCoupon() {
		homeDigitalCoupon.waitForPresent(3000);
		return homeDigitalCoupon;
	}

	public QAFWebElement getHomeEleScroll() {
		return homeEleScroll;
	}

	public QAFWebElement getHomeLblWeeklyAd() {
		return homeLblWeeklyAd;
	}

	public QAFWebElement getHomeLblSignin() {
		return homeLblSignin;
	}

	public QAFWebElement getHomeLblRecipes() {
		return homeLblRecipes;
	}

	public QAFWebElement getHomeFooterShopicon() {
		return homeFooterShopicon;
	}

	public QAFWebElement getappFooterShoppinglist() {
		return appFooterShoppinglist;
	}

	public QAFWebElement getHomeFooterCart() {
		return homeFooterCart;
	}

	public QAFWebElement getHomeFooterMore() {
		return homeFooterMore;
	}

	public QAFWebElement getHomeLblStoreLocator() {
		return homeLblStoreLocator;
	}

	public QAFWebElement getHomeLnkScanProduct() {
		return homeLnkScanProduct;
	}

	public QAFWebElement getHomeLblShoppingList() {
		return homeLblShoppingList;
	}

	public QAFWebElement getHomeLblShipToHome() {
		return homeLblShipToHome;
	}

	public QAFWebElement gethomeimgNewbarcode() {
		return homeimgNewbarcode;
	}
	
	public QAFWebElement gethomelblHEBBarcodeHomescreenlist() {
		return homelblHEBBarcodeHomescreenlist;
	}
	
	
	
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
/*
	public QAFWebElement getHomeLblShopMyStore() {
		return homeLblShopMyStore;
	}
*/
	public QAFWebElement getHomeImgShipToHomeSlide() {
		return homeImgShipToHomeSlide;
	}

	public QAFWebElement getLblProducts() {
		return lblProducts;
	}

	public QAFWebElement getImgSearchicon() {
		return imgSearchicon;
	}
	public QAFWebElement getImgHomeHero() {
		return imgHomeHero;
	}

	public QAFWebElement getImgTopslot() {
		return imgTopslot;
	}

	public QAFWebElement getIconTopslotCoupon() {
		return iconTopslotCoupon;
	}

	public QAFWebElement getIconTopslotProducts() {
		return iconTopslotProducts;
	}

	public QAFWebElement getIconTopslotWeeklyad() {
		return iconTopslotWeeklyad;
	}

	public QAFWebElement getLblTopslotCoupon() {
		return lblTopslotCoupon;
	}

	public QAFWebElement getLblTopslotWeeklyad() {
		return lblTopslotWeeklyad;
	}

	public QAFWebElement getLblPharmacy() {
		return lblPharmacy;
	}

	public QAFWebElement getLblHebBarcode() {
		return lblHebBarcode;
	}
	public QAFWebElement getLblTopslotProducts() {
		return lblTopslotProducts;
	}
	public QAFWebElement getImageHeblogo() {
		return imageHeblogo;
	}
	public QAFWebElement getLblRedeemCoupon() {
		return lblRedeemCoupon;
	}
	public QAFWebElement getLblCurbsidePickup() {
		return lblCurbsidePickup;
	}
	public QAFWebElement getLblCurbsideAlert() {
		return lblCurbsideAlert;
	}

	public QAFWebElement getLblCurbsideAlertbody() {
		return lblCurbsideAlertbody;
	}

	public QAFWebElement getLblCurbsideAlertcancel() {
		return lblCurbsideAlertcancel;
	}

	public QAFWebElement getLblCurbsideAlertok() {
		return lblCurbsideAlertok;
	}

	public QAFWebElement getLblShiptohomeAlertbody() {
		return lblShiptohomeAlertbody;
	}
	public QAFWebElement getHometxtBarcodedetailpage() {
		return hometxtBarcodedetailpage;
	}

	public QAFWebElement gethomeimgheroimage() {
		return homeimgheroimage;
	}
	
	public QAFWebElement gethomelbltopslot() {
		return homelbltopslot;
	}
	
	public QAFWebElement gethomelblcurbsidepickup() {
		return homelblcurbsidepickup;
	}
	
	public QAFWebElement gethometxtpharmacy() {
		return hometxtpharmacy;
	}
	public QAFWebElement getHomeimgBarcodemodal() {
		return homeimgBarcodemodal;
	}
	public QAFWebElement getHomeIconSearch() {
		return homeIconSearch;
	}
	public QAFWebElement getHomeSearchBox() {
		return homeSearchBox;
	}
	public List<QAFWebElement> getHomeMenuList() {
		return homeMenuList;
	}
	public QAFWebElement getHomeLblDonationsSecond() {
		return homelbldonationssecond;
	}
	public QAFWebElement getHomeTxtDonationAlertTitle() {
		return hometxtdonationalerttitle;
	}
	public QAFWebElement getHomeTxtDonationAlertMessage() {
		return hometxtdonationalertmessage;
	}
	public QAFWebElement getHomeBtnDonationAlertCancel() {
		return homebtndonationalertcancel;
	}
	public QAFWebElement getHomeBtnDonationAlertOk() {
		return homebtndonationalertok;
	}
	public QAFWebElement getHomeTxtWebbrowesrTitle() {
		return hometxtwebbrowesrtitle;
	}
	public QAFWebElement getHomeLblDonations() {
		return homelbldonations;
	}
	public QAFWebElement getHomeLblDonationsFirst() {
		return homelbldonationsfirst;
	}
	
}
