package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LoginsplashTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "login.txt.password")
	private QAFWebElement loginTxtPassword;
	@FindBy(locator = "login.btn.login")
	private QAFWebElement loginBtnLogin;
	@FindBy(locator = "login.txt.email")
	private QAFWebElement loginTxtEmail;
	@FindBy(locator = "login.btn.register")
	private QAFWebElement loginBtnRegister;
	@FindBy(locator = "login.lbl.continue")
	private QAFWebElement loginLblContinue;
	@FindBy(locator = "login.lbl.forgotpassword")
	private QAFWebElement loginLblForgotPassword;
	@FindBy(locator = "login.btn.ok")
	private QAFWebElement loginbtnok;
	@FindBy(locator = "login.lbl.tipemail")
	private QAFWebElement lblTipemail;
	@FindBy(locator = "login.lbl.tippassword")
	private QAFWebElement lblTippassword;
	
	@FindBy(locator = "login.lbl.popuplogin")
	private QAFWebElement LblPopuplogin;
	@FindBy(locator = "login.txt.forgotpassword")
	private QAFWebElement TxtForgotPassword;
	@FindBy(locator = "login.btn.submit")
	private QAFWebElement btnSubmit;
	@FindBy(locator = "login.btn.cancel")
	private QAFWebElement btnCancel;
	@FindBy(locator = "login.img.showpassword")
	private QAFWebElement imgShowpassword;
	@FindBy(locator = "login.txt.resetinstructions")
	private QAFWebElement txtResetInstructions;
	@FindBy(locator = "login.btn.resetpassword")
	private QAFWebElement BtnResetPassword;
	@FindBy(locator = "login.txt.emailerror")
	private QAFWebElement TxtEmailerror;
	@FindBy(locator = "login.lbl.loginerror")
	private QAFWebElement LblLoginError;
	@FindBy(locator = "login.txt.forgotpasswordemail")
	private QAFWebElement TxtForgotPasswordEmail;
	@FindBy(locator = "login.txt.forgotpassworderror")
	private QAFWebElement TxtForgotPasswordError;
	@FindBy(locator = "login.txt.requestsent")
	private QAFWebElement TxtRequestSent;
	@FindBy(locator = "login.lbl.invalidemailerror")
	private QAFWebElement LblInvalidEmailError;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLoginTxtPassword() {
		return loginTxtPassword;
	}

	public QAFWebElement getLoginBtnLogin() {
		return loginBtnLogin;
	}

	public QAFWebElement getLoginTxtEmail() {
		return loginTxtEmail;
	}

	public QAFWebElement getLoginBtnRegister() {
		return loginBtnRegister;
	}

	public QAFWebElement getLoginLblContinue() {
		return loginLblContinue;
	}

	public QAFWebElement getLoginLblForgotPassword() {
		return loginLblForgotPassword;
	}

	public QAFWebElement getLoginBtnOk() {
		return loginbtnok;
	}

	public HomeTestPage select() {
		HomeTestPage homepage = new HomeTestPage();
		homepage.waitForPageToLoad();
		return homepage;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public QAFWebElement getLblTipemail() {
		return lblTipemail;
	}

	public QAFWebElement getLblTippassword() {
		return lblTippassword;
	}

	public QAFWebElement getLblPopuplogin() {
		return LblPopuplogin;
	}
	
	public QAFWebElement getTxtForgotPassword() {
		return TxtForgotPassword;
	}
	
	public QAFWebElement getBtnSubmit() {
		return btnSubmit;
	}

	public QAFWebElement getbtnCancel() {
		return btnCancel;
	}
	
	public QAFWebElement getImgShowpassword() {
		return imgShowpassword;
	}
	
	public QAFWebElement getTxtResetInstructions() {
		return txtResetInstructions;
	}
	
	public QAFWebElement getBtnResetPassword() {
		return BtnResetPassword;
	}
	
	public QAFWebElement getTxtEmailerror() {
		return TxtEmailerror;
	}
	
	public QAFWebElement getLblLoginError() {
		return LblLoginError;
	}
	
	public QAFWebElement getTxtForgotPasswordEmail() {
		return TxtForgotPasswordEmail;
	}
	
	public QAFWebElement getTxtForgotPasswordError() {
		return TxtForgotPasswordError;
	}
	
	public QAFWebElement getTxtRequestSent() {
		return TxtRequestSent;
	}
	
	public QAFWebElement getLblInvalidEmailError() {
		return LblInvalidEmailError;
	}
}
