package com.heb.automation.common.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class TemplateTestPage<T extends WebDriverTestPage> extends WebDriverBaseTestPage<T> {

	@FindBy(locator = "template.btn.back")
	private QAFWebElement templateBtnBack;
	@FindBy(locator = "template.txt.page.header")
	private QAFWebElement templateTxtPageHeader;
	@FindBy(locator = "template.txt.page.header.format")
	private QAFWebElement templateTxtPageHeaderFormat;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getTemplateBtnBack() {
		return templateBtnBack;
	}

	public QAFWebElement getTemplateTxtPageHeader() {
		return templateTxtPageHeader;
	}

	public QAFWebElement getTemplateTxtPageHeaderFormat() {
		return templateTxtPageHeaderFormat;
	}

	public QAFWebElement getPageHeader(String lable) {
		String loc = String.format(pageProps.getString("template.txt.page.header.format"), lable);
		return new QAFExtendedWebElement(loc);
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
