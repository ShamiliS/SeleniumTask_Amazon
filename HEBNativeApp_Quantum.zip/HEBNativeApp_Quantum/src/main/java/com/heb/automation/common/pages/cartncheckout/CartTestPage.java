package com.heb.automation.common.pages.cartncheckout;

import java.util.List;

import com.heb.automation.common.components.CartDetails;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CartTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cartpage.lbl.estimatedtotal")
	private QAFWebElement cartpageLblEstimatedtotal;
	@FindBy(locator = "cartpage.lbl.estimatedprice")
	private QAFWebElement cartpageLblEstimatedprice;
	@FindBy(locator = "cartpage.lbl.total")
	private QAFWebElement cartpageLblTotal;
	@FindBy(locator = "cartpage.lbl.promocode")
	private QAFWebElement cartpageLblPromocode;
	@FindBy(locator = "cartpage.btn.apply")
	private QAFWebElement cartpageBtnApply;
	@FindBy(locator = "cartpage.btn.checkout")
	private QAFWebElement cartpageBtnCheckout;
	@FindBy(locator = "cartpage.lbl.deliverytitle")
	private QAFWebElement cartpageLblDeliverytitle;
	@FindBy(locator = "cartpage.lbl.productname")
	private QAFWebElement cartpageLblProductname;
	@FindBy(locator = "cartpage.lbl.quantitynumber")
	private QAFWebElement cartpageLblQuantitynumber;
	@FindBy(locator = "cartpage.btn.remove")
	private QAFWebElement cartpageBtnRemove;
	@FindBy(locator = "cartpage.img.productaddedtocart")
	private QAFWebElement cartpageImgProductaddedtocart;
	@FindBy(locator = "cartpage.lbl.productprice")
	private QAFWebElement cartpageLblProductprice;
	@FindBy(locator = "cartpage.lbl.uom")
	private QAFWebElement cartpageLblUom;
	@FindBy(locator = "cartpage.lbl.pgtitlecartwithitem")
	private QAFWebElement cartpageLblPgtitlecartwithitem;
	@FindBy(locator = "cartpage.btn.addtocart")
	private QAFWebElement cartpageBtnAddtocart;
	@FindBy(locator = "cartpage.link.cart")
	private QAFWebElement cartpageLinkCart;
	@FindBy(locator = "cartpage.lbl.qtypickernextrow")
	private QAFWebElement cartpageLblQtypickernextrow;
	@FindBy(locator = "cartpage.lbl.qtypickervisiblerow")
	private QAFWebElement cartpageLblQtypickervisiblerow;
	@FindBy(locator = "cartpage.txt.numberpicker")
	private QAFWebElement cartpageTxtNumberpicker;
	@FindBy(locator = "cartpage.list.cartitemslist")
	private List<CartDetails> cartListCartItemsList;
	@FindBy(locator = "cartpage.list.cartitemnameslist")
	private QAFWebElement cartListCartItemNamesList;
	@FindBy(locator = "cartpage.lbl.itemname")
	private QAFWebElement cartLblItemName;
	@FindBy(locator = "cartpage.lbl.productname")
	private List<QAFWebElement> cartpageLblProductnameList;
	@FindBy(locator = "cartpage.lbl.noitem")
	private QAFWebElement cartpageLblNoitem;
	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCartpageLblEstimatedtotal() {
		return cartpageLblEstimatedtotal;
	}

	public QAFWebElement getCartpageLblEstimatedprice() {
		return cartpageLblEstimatedprice;
	}

	public QAFWebElement getCartpageLblTotal() {
		return cartpageLblTotal;
	}

	public QAFWebElement getCartpageLblPromocode() {
		return cartpageLblPromocode;
	}

	public QAFWebElement getCartpageBtnApply() {
		return cartpageBtnApply;
	}

	public QAFWebElement getCartpageBtnCheckout() {
		return cartpageBtnCheckout;
	}

	public QAFWebElement getCartpageLblDeliverytitle() {
		return cartpageLblDeliverytitle;
	}

	public QAFWebElement getCartpageLblProductname() {
		return cartpageLblProductname;
	}

	public QAFWebElement getCartpageLblQuantitynumber() {
		return cartpageLblQuantitynumber;
	}

	public QAFWebElement getCartpageBtnRemove() {
		return cartpageBtnRemove;
	}

	public QAFWebElement getCartpageImgProductaddedtocart() {
		return cartpageImgProductaddedtocart;
	}

	public QAFWebElement getCartpageLblProductprice() {
		return cartpageLblProductprice;
	}

	public QAFWebElement getCartpageLblUom() {
		return cartpageLblUom;
	}

	public QAFWebElement getCartpageLblPgtitlecartwithitem() {
		return cartpageLblPgtitlecartwithitem;
	}
	public QAFWebElement getCartpageBtnAddtocart() {
		return cartpageBtnAddtocart;
	}

	public QAFWebElement getCartpageLinkCart() {
		return cartpageLinkCart;
	}
	
	public QAFWebElement getCartpageLblQtypickernextrow() {
		return cartpageLblQtypickernextrow;
	}

	public QAFWebElement getCartpageLblQtypickervisiblerow() {
		return cartpageLblQtypickervisiblerow;
	}

	public QAFWebElement getCartpageTxtNumberpicker() {
		return cartpageTxtNumberpicker;
	}
	
	public List<CartDetails> getCartListCartItemsList() {
		return cartListCartItemsList;
	}

	public QAFWebElement getCartListCartItemNamesList() {
		return cartListCartItemNamesList;
	}
	
	public QAFWebElement getCartLblItemName() {
		return cartLblItemName;
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getCartLblItemNameByLable(String lable) {
		String loc = String.format(pageProps.getString("cartpage.lbl.itemname"), lable);
		return new QAFExtendedWebElement(loc);
	}
		
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	
	public List<QAFWebElement> getCartpageLblProductnameList() {
		return cartpageLblProductnameList;
	}
	
	public QAFWebElement getCartpageLblNoitem() {
		return cartpageLblNoitem;
	}
}

