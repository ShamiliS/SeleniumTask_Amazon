package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CheckoutTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "checkout.link.viewallitem")
	private QAFWebElement checkoutLinkViewallitem;
	@FindBy(locator = "checkout.link.ordertotal")
	private QAFWebElement checkoutLinkOrdertotal;
	@FindBy(locator = "checkout.btn.shippingaddress")
	private QAFWebElement checkoutBtnShippingaddress;
	@FindBy(locator = "checkout.lbl.entershippingadd")
	private QAFWebElement checkoutLblEntershippingadd;
	@FindBy(locator = "checkout.img.homeicon")
	private QAFWebElement checkoutImgHomeicon;
	@FindBy(locator = "checkout.lbl.shippingmethod")
	private QAFWebElement checkoutLblShippingmethod;
	@FindBy(locator = "checkout.btn.submitorder")
	private QAFWebElement checkoutBtnSubmitorder;
	@FindBy(locator = "checkout.lbl.payementtitle")
	private QAFWebElement checkoutLblPayementtitle;
	@FindBy(locator = "checkout.lbl.creditcard")
	private QAFWebElement checkoutLblCreditcard;
	@FindBy(locator = "checkout.img.payementmethod")
	private QAFWebElement checkoutImgPayementmethod;
	@FindBy(locator = "checkout.img.shippingmethod")
	private QAFWebElement checkoutImgShippingmethod;
	@FindBy(locator = "checkout.txt.cardholdername")
	private QAFWebElement checkoutTxtCardholdername;
	@FindBy(locator = "checkout.txt.cardnumber")
	private QAFWebElement checkoutTxtCardnumber;
	@FindBy(locator = "checkout.txt.cardcvv")
	private QAFWebElement checkoutTxtCardcvv;
	@FindBy(locator = "checkout.txt.cardexp")
	private QAFWebElement checkoutTxtCardexp;
	@FindBy(locator = "checkout.chkbox.saveforfutureuse")
	private QAFWebElement checkoutChkboxSaveforfutureuse;
	@FindBy(locator = "checkout.txt.cvvinfo")
	private QAFWebElement checkoutTxtCvvinfo;
	@FindBy(locator = "checkout.btn")
	private QAFWebElement checkoutBtn;
	@FindBy(locator = "checkout.lbl.pgtitleguestcheckout")
	private QAFWebElement checkoutLblPgtitleguestcheckout;
	@FindBy(locator = "checkout.link.continue")
	private QAFWebElement checkoutLinkContinue;
	@FindBy(locator = "checkout.lbl.titleconfirmation")
	private QAFWebElement checkoutLblTitleconfirmation;
	@FindBy(locator = "checkout.lbl.donebutton")
	private QAFWebElement checkoutLblDonebutton;
	@FindBy(locator = "checkout.lbl.thankyou")
	private QAFWebElement checkoutLblThankyou;
	@FindBy(locator = "checkout.lbl.pgtitlecheckout")
	private QAFWebElement checkoutLblPgtitlecheckout;
	@FindBy(locator = "checkout.lbl.expiryset")
	private QAFWebElement checkoutLblExpiryset;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCheckoutLinkViewallitem() {
		return checkoutLinkViewallitem;
	}

	public QAFWebElement getCheckoutLinkOrdertotal() {
		return checkoutLinkOrdertotal;
	}

	public QAFWebElement getCheckoutBtnShippingaddress() {
		return checkoutBtnShippingaddress;
	}

	public QAFWebElement getCheckoutLblEntershippingadd() {
		return checkoutLblEntershippingadd;
	}

	public QAFWebElement getCheckoutImgHomeicon() {
		return checkoutImgHomeicon;
	}

	public QAFWebElement getCheckoutLblShippingmethod() {
		return checkoutLblShippingmethod;
	}

	public QAFWebElement getCheckoutBtnSubmitorder() {
		return checkoutBtnSubmitorder;
	}

	public QAFWebElement getCheckoutLblPayementtitle() {
		return checkoutLblPayementtitle;
	}

	public QAFWebElement getCheckoutLblCreditcard() {
		return checkoutLblCreditcard;
	}

	public QAFWebElement getCheckoutImgPayementmethod() {
		return checkoutImgPayementmethod;
	}

	public QAFWebElement getCheckoutImgShippingmethod() {
		return checkoutImgShippingmethod;
	}

	public QAFWebElement getCheckoutTxtCardholdername() {
		return checkoutTxtCardholdername;
	}

	public QAFWebElement getCheckoutTxtCardnumber() {
		return checkoutTxtCardnumber;
	}

	public QAFWebElement getCheckoutTxtCardcvv() {
		return checkoutTxtCardcvv;
	}

	public QAFWebElement getCheckoutTxtCardexp() {
		return checkoutTxtCardexp;
	}

	public QAFWebElement getCheckoutChkboxSaveforfutureuse() {
		return checkoutChkboxSaveforfutureuse;
	}

	public QAFWebElement getCheckoutTxtCvvinfo() {
		return checkoutTxtCvvinfo;
	}

	public QAFWebElement getCheckoutBtn() {
		return checkoutBtn;
	}

	public QAFWebElement getCheckoutLblPgtitleguestcheckout() {
		return checkoutLblPgtitleguestcheckout;
	}

	public QAFWebElement getCheckoutLinkContinue() {
		return checkoutLinkContinue;
	}
	public QAFWebElement getCheckoutLblTitleconfirmation() {
		return checkoutLblTitleconfirmation;
	}

	public QAFWebElement getCheckoutLblDonebutton() {
		return checkoutLblDonebutton;
	}

	public QAFWebElement getCheckoutLblThankyou() {
		return checkoutLblThankyou;
	}

	public QAFWebElement getCheckoutLblPgtitlecheckout() {
		return checkoutLblPgtitlecheckout;
	}

	public QAFWebElement getCheckoutLblExpiryset() {
		return checkoutLblExpiryset;
	}
	
	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
		checkoutLblPgtitlecheckout.waitForPresent(5000);	
	}
}
