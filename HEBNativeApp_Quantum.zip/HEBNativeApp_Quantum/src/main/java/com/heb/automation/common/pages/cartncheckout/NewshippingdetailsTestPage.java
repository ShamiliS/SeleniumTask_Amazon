package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class NewshippingdetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "newshipping.btn.save")
	private QAFWebElement newshippingBtnSave;
	@FindBy(locator = "newshipping.btn.back")
	private QAFWebElement newshippingBtnBack;
	@FindBy(locator = "newshipping.txt.firstname")
	private QAFWebElement newshippingTxtFirstname;
	@FindBy(locator = "newshipping.txt.lastname")
	private QAFWebElement newshippingTxtLastname;
	@FindBy(locator = "newshipping.txt.phnumber")
	private QAFWebElement newshippingTxtPhnumber;
	@FindBy(locator = "newshipping.txt.address1")
	private QAFWebElement newshippingTxtAddress1;
	@FindBy(locator = "newshipping.txt.address2")
	private QAFWebElement newshippingTxtAddress2;
	@FindBy(locator = "newshipping.txt.city")
	private QAFWebElement newshippingTxtCity;
	@FindBy(locator = "newshipping.txt.zipcode")
	private QAFWebElement newshippingTxtZipcode;
	@FindBy(locator = "newshipping.txt.state")
	private QAFWebElement newshippingTxtState;
	@FindBy(locator = "newshipping.lbl.addnewshippingaddress")
	private QAFWebElement newshippingLblAddnewshippingaddress;

	@FindBy(locator = "newshipping.popup.addresserror")
	private QAFWebElement AddressErrorPopup;

	@FindBy(locator = "newshipping.popup.addresserror.yes")
	private QAFWebElement AddressErrorYes;

	@FindBy(locator = "newshipping.popup.addresserror.no")
	private QAFWebElement AddressErrorNo;

	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getNewshippingBtnSave() {
		return newshippingBtnSave;
	}

	public QAFWebElement getNewshippingBtnBack() {
		return newshippingBtnBack;
	}

	public QAFWebElement getNewshippingTxtFirstname() {
		return newshippingTxtFirstname;
	}

	public QAFWebElement getNewshippingTxtLastname() {
		return newshippingTxtLastname;
	}

	public QAFWebElement getNewshippingTxtPhnumber() {
		return newshippingTxtPhnumber;
	}

	public QAFWebElement getNewshippingTxtAddress1() {
		return newshippingTxtAddress1;
	}

	public QAFWebElement getNewshippingTxtAddress2() {
		return newshippingTxtAddress2;
	}

	public QAFWebElement getNewshippingTxtCity() {
		return newshippingTxtCity;
	}

	public QAFWebElement getNewshippingTxtZipcode() {
		return newshippingTxtZipcode;
	}

	public QAFWebElement getNewshippingTxtState() {
		return newshippingTxtState;
	}

	public QAFWebElement getNewshippingLblAddnewshippingaddress() {
		return newshippingLblAddnewshippingaddress;
	}

	public QAFWebElement getAddressErrorPopup() {
		return AddressErrorPopup;
	}

	public QAFWebElement getAddressErrorYes() {
		return AddressErrorYes;
	}

	public QAFWebElement getAddressErrorNo() {
		return AddressErrorNo;
	}

	@Override
	public void waitForPageToLoad() {
		// TODO Auto-generated method stub
		super.waitForPageToLoad();
		newshippingBtnSave.waitForPresent(5000);
	
	}
}
