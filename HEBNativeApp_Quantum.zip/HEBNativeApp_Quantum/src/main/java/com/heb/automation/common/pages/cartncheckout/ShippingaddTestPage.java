package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShippingaddTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "shipping.lbl.shippgtiltle")
	private QAFWebElement shippingLblShippgtiltle;
	@FindBy(locator = "shipping.btn.save")
	private QAFWebElement shippingBtnSave;
	@FindBy(locator = "shipping.btn.yes")
	private QAFWebElement shippingBtnYes;
	@FindBy(locator = "shipping.btn.no")
	private QAFWebElement shippingBtnNo;
	@FindBy(locator = "shipping.txt.firstname")
	private QAFWebElement shippingTxtFirstname;
	@FindBy(locator = "shipping.txt.lastname")
	private QAFWebElement shippingTxtLastname;
	@FindBy(locator = "shipping.txt.phnumber")
	private QAFWebElement shippingTxtPhnumber;
	@FindBy(locator = "shipping.txt.address1")
	private QAFWebElement shippingTxtAddress1;
	@FindBy(locator = "shipping.txt.address2")
	private QAFWebElement shippingTxtAddress2;
	@FindBy(locator = "shipping.txt.city")
	private QAFWebElement shippingTxtCity;
	@FindBy(locator = "shipping.txt.zipcode")
	private QAFWebElement shippingTxtZipcode;
	@FindBy(locator = "shipping.txt.country")
	private QAFWebElement shippingTxtCountry;
	@FindBy(locator = "shipping.lbl.popupshipadd")
	private QAFWebElement shippingLblPopupshipadd;
	@FindBy(locator = "shipping.lbl.addresssuggested")
	private QAFWebElement shippingLblAddresssuggested;
	@FindBy(locator = "shipping.lbl.statetitle")
	private QAFWebElement shippingLblStatetitle;
	@FindBy(locator = "shipping.txt.namestate")
	private QAFWebElement shippingTxtNamestate;
	
	@FindBy(locator = "shipping.lbl.titlebillingaddress")
	private QAFWebElement shippingLblTitlebillingaddress;

	@FindBy(locator = "shipping.lbl.enteredbillingaddress")
	private QAFWebElement shippingLblEnteredbillingaddress;
	@FindBy(locator = "shipping.img.billing")
	private QAFWebElement shippingImgBilling;
	
	@FindBy(locator = "shipping.lbl.existingadd")
	private QAFWebElement shippingLblExistingadd;
	@FindBy(locator = "shipping.btn.select")
	private QAFWebElement shippingBtnSelect;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getShippingLblShippgtiltle() {
		return shippingLblShippgtiltle;
	}

	public QAFWebElement getShippingBtnSave() {
		return shippingBtnSave;
	}

	public QAFWebElement getShippingBtnYes() {
		return shippingBtnYes;
	}

	public QAFWebElement getShippingBtnNo() {
		return shippingBtnNo;
	}

	public QAFWebElement getShippingTxtFirstname() {
		return shippingTxtFirstname;
	}

	public QAFWebElement getShippingTxtLastname() {
		return shippingTxtLastname;
	}

	public QAFWebElement getShippingTxtPhnumber() {
		return shippingTxtPhnumber;
	}

	public QAFWebElement getShippingTxtAddress1() {
		return shippingTxtAddress1;
	}

	public QAFWebElement getShippingTxtAddress2() {
		return shippingTxtAddress2;
	}

	public QAFWebElement getShippingTxtCity() {
		return shippingTxtCity;
	}

	public QAFWebElement getShippingTxtZipcode() {
		return shippingTxtZipcode;
	}

	public QAFWebElement getShippingTxtCountry() {
		return shippingTxtCountry;
	}

	public QAFWebElement getShippingLblPopupshipadd() {
		return shippingLblPopupshipadd;
	}

	public QAFWebElement getShippingLblAddresssuggested() {
		return shippingLblAddresssuggested;
	}

	public QAFWebElement getShippingLblStatetitle() {
		return shippingLblStatetitle;
	}

	public QAFWebElement getShippingTxtNamestate() {
		return shippingTxtNamestate;
	}
	public QAFWebElement getShippingLblTitlebillingaddress() {
		return shippingLblTitlebillingaddress;
	}

	public QAFWebElement getShippingLblEnteredbillingaddress() {
		return shippingLblEnteredbillingaddress;
	}

	public QAFWebElement getShippingImgBilling() {
		return shippingImgBilling;
	}

	public QAFWebElement getShippingLblExistingadd() {
		return shippingLblExistingadd;
	}

	public QAFWebElement getShippingBtnSelect() {
		return shippingBtnSelect;
	}

}
