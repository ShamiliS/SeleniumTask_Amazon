package com.heb.automation.common.pages.cartncheckout;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShippingaddressTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "shipping.lbl.chooseshippingmethod")
	private QAFWebElement shippingLblChooseshippingmethod;
	@FindBy(locator = "shipping.lbl.usps")
	private QAFWebElement shippingLblUsps;
	
	@FindBy(locator = "shipping.lbl.addnewaddress")
	private QAFWebElement shippingLblAddnewaddress;
	@FindBy(locator = "shipping.lbl.shippgtiltle")
	private QAFWebElement shippingLblShippgtiltle;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getShippingLblChooseshippingmethod() {
		return shippingLblChooseshippingmethod;
	}

	public QAFWebElement getShippingLblUsps() {
		return shippingLblUsps;
	}

	
	public QAFWebElement getShippingLblAddnewaddress() {
		return shippingLblAddnewaddress;
	}

	public QAFWebElement getShippingLblShippgtiltle() {
		return shippingLblShippgtiltle;
	}

}
