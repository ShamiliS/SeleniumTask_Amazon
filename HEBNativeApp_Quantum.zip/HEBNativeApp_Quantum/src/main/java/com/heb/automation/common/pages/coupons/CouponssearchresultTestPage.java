package com.heb.automation.common.pages.coupons;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponssearchresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "couponsresult.lbl.couponexpire")
	private QAFWebElement couponsresultLblCouponexpire;
	@FindBy(locator = "couponsresult.img.couponimage")
	private QAFWebElement couponsresultImgCouponimage;
	@FindBy(locator = "couponsresult.lbl.offerlimit")
	private QAFWebElement couponsresultLblOfferlimit;
	@FindBy(locator = "couponsresult.img.nexticon")
	private QAFWebElement couponsresultImgNexticon;
	@FindBy(locator = "couponsresult.lbl.offercallout")
	private List<QAFWebElement> couponsresultLblOffercallout;
	@FindBy(locator = "couponsresult.lbl.coupondescription")
	private QAFWebElement couponsresultLblCoupondescription;
	@FindBy(locator = "couponsresult.img.selectplus")
	private QAFWebElement couponsresultImgSelectplus;
	@FindBy(locator = "couponsresult.icon.search")
	private QAFWebElement couponsresultIconSearch;
	@FindBy(locator = "couponsresult.lbl.searchtext")
	private QAFWebElement couponsresultLblSearchtext;
	@FindBy(locator = "couponsresult.lbl.pgtitleallcoupon")
	private QAFWebElement couponsresultLblPgtitleallcoupon;
	@FindBy(locator = "couponsresult.lbl.couponnamelist")
	private List<QAFWebElement> couponsresultLblCouponNameList;
	@FindBy(locator = "couponsresult.lbl.couponexpire")
	private List<QAFWebElement> LblCouponexpireList;
	@FindBy(locator = "couponsresult.img.couponimage")
	private List<QAFWebElement> ImgCouponimageList;
	@FindBy(locator = "couponsresult.lbl.couponnamedynamic")
	private List<QAFWebElement> LblCouponnamedynamic;
	@FindBy(locator = "couponsresult.icon.couponaddlist")
	private List<QAFWebElement> iconCouponaddList;
	@FindBy(locator = "couponsresult.chk.selectcoupondynamic")
	private List<QAFWebElement> chkSelectcoupondynamic;
	@FindBy(locator = "couponsresult.lbl.coupondescription")
	private List<QAFWebElement> LblCoupondescription;
	
	@FindBy(locator = "couponsresult.chk.selectcouponlist")
	private List<QAFWebElement> ChkSelectcouponlist;
	@FindBy(locator = "couponsresult.btn.sortORclear")
	private QAFWebElement btnClearSort;
	@FindBy(locator = "couponsresult.btn.signupnow")
	private QAFWebElement Btnsignupnow;
	@FindBy(locator = "couponsresult.icon.progressbar")
	private QAFWebElement iconProgressBar;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCouponsresultLblCouponexpire() {
		return couponsresultLblCouponexpire;
	}


	public QAFWebElement getCouponsresultImgCouponimage() {
		return couponsresultImgCouponimage;
	}

	public QAFWebElement getCouponsresultLblOfferlimit() {
		return couponsresultLblOfferlimit;
	}

	public QAFWebElement getCouponsresultImgNexticon() {
		return couponsresultImgNexticon;
	}

	public List<QAFWebElement> getCouponsresultLblOffercallout() {
		return couponsresultLblOffercallout;
	}

	public QAFWebElement getCouponsresultLblCoupondescription() {
		return couponsresultLblCoupondescription;
	}

	public QAFWebElement getCouponsresultImgSelectplus() {
		return couponsresultImgSelectplus;
	}

	public QAFWebElement getCouponsresultIconSearch() {
		return couponsresultIconSearch;
	}

	public QAFWebElement getCouponsresultLblSearchtext() {
		return couponsresultLblSearchtext;
	}

	public QAFWebElement getCouponsresultLblPgtitleallcoupon() {
		return couponsresultLblPgtitleallcoupon;
	}

	public List<QAFWebElement> getCouponsresultLblCouponNameList() {
		return couponsresultLblCouponNameList;
	}

	// DYNAMIC value declaring
	public QAFWebElement getCouponChkboxWithRespectToName(String label) {
		String loc = String.format(pageProps.getString("couponsresult.chk.selectcouponwithrestoname"), label);
		return new QAFExtendedWebElement(loc);
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<QAFWebElement> getLblCouponexpireList() {
		return LblCouponexpireList;
	}

	public List<QAFWebElement> getImgCouponimageList() {
		return ImgCouponimageList;
	}

	public List<QAFWebElement> getLblCouponnamedynamic() {
		return LblCouponnamedynamic;
	}

	// DYNAMIC value declaring
	public QAFWebElement getLblCouponnamedynamic(int label) {
		String loc = String.format(pageProps.getString("couponsresult.lbl.couponnamedynamic"), label);
		return new QAFExtendedWebElement(loc);
	}

	public List<QAFWebElement> getIconCouponaddList() {
		return iconCouponaddList;
	}
	
	// DYNAMIC value declaring
		public QAFWebElement getLblselectCouponnamedynamic(int label) {
			String loc = String.format(pageProps.getString("couponsresult.chk.selectcoupondynamic"), label);
			return new QAFExtendedWebElement(loc);
		}
		
	public List<QAFWebElement> getLblCoupondescription() {
		return LblCoupondescription;
	}
	
	public List<QAFWebElement> getChkSelectcouponlist() {
		return ChkSelectcouponlist;
	}
	public QAFWebElement getBtnClearSort() {
		return btnClearSort;
	}
	public QAFWebElement getBtnsignupnow() {
		return Btnsignupnow;
	}
	public QAFWebElement getIconProgressBar() {
		return iconProgressBar;
	}
}
