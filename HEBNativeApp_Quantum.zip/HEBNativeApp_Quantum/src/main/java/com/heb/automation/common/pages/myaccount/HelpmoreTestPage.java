package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class HelpmoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "help.lbl.faq")
	private QAFWebElement LblFaq;
	@FindBy(locator = "help.lbl.privacypolicy")
	private QAFWebElement LblPrivacypolicy;
	@FindBy(locator = "help.lbl.termandconditions")
	private QAFWebElement LblTermandconditions;
	@FindBy(locator = "help.rbtn.envcert1")
	private QAFWebElement RbtnEnvcert1;
	@FindBy(locator = "help.rbtn.envcert2")
	private QAFWebElement RbtnEnvcert2;
	@FindBy(locator = "help.lbl.pagetitle")
	private QAFWebElement LblPagetitle;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblFaq() {
		return LblFaq;
	}

	public QAFWebElement getLblPrivacypolicy() {
		return LblPrivacypolicy;
	}

	public QAFWebElement getLblTermandconditions() {
		return LblTermandconditions;
	}

	public QAFWebElement getRbtnEnvcert1() {
		return RbtnEnvcert1;
	}

	public QAFWebElement getRbtnEnvcert2() {
		return RbtnEnvcert2;
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

}
