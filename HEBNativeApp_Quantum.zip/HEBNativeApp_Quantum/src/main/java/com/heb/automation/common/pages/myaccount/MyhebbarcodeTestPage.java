package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyhebbarcodeTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "myhebbc.lbl.pagetitle")
	private QAFWebElement LblPagetitle;
	@FindBy(locator = "myhebbc.lbl.barcodephototext")
	private QAFWebElement LblBarcodephototext;
	@FindBy(locator = "myhebbc.lbl.namelabel")
	private QAFWebElement LblNamelabel;
	@FindBy(locator = "myhebbc.lbl.namevalue")
	private QAFWebElement LblNamevalue;
	@FindBy(locator = "myhebbc.img.barcode")
	private QAFWebElement ImgBarcode;
	@FindBy(locator = "myhebbc.lbl.barcodenumber")
	private QAFWebElement ImgBarcodenumber;
	@FindBy(locator = "vpp.myhebbc.lbl.pagetitle")
	private QAFWebElement vppMyhebBcLblPagetitle;
	@FindBy(locator = "vpp.myhebbc.lbl.valuedpartner")
	private QAFWebElement vppMyhebBcLblValuedPartner;
	@FindBy(locator = "vpp.myhebbc.lbl.barcodephototext")
	private QAFWebElement vppmyhebbcLblBarcodephotoText;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return LblPagetitle;
	}

	public QAFWebElement getLblBarcodephototext() {
		return LblBarcodephototext;
	}

	public QAFWebElement getLblNamelabel() {
		return LblNamelabel;
	}

	public QAFWebElement getLblNamevalue() {
		return LblNamevalue;
	}

	public QAFWebElement getImgBarcode() {
		return ImgBarcode;
	}

	public QAFWebElement getLblBarcodenumber() {
		return ImgBarcodenumber;
	}

	public QAFWebElement getvppMyhebBcLblPagetitle() {
		return vppMyhebBcLblPagetitle;
	}
	
	public QAFWebElement getvppMyhebBcLblValuedPartner() {
		return vppMyhebBcLblValuedPartner;
	}
	
	public QAFWebElement getvppmyhebbcLblBarcodephotoText() {
		return vppmyhebbcLblBarcodephotoText;
	}
}
