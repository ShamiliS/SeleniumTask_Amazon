package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;

public class MynotificationsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "mynotification.lbl.pgetitle")
	private QAFWebElement LblPgetitle;
	@FindBy(locator = "mynotification.lbl.getextraoffers")
	private QAFWebElement lblGetextraoffers;
	@FindBy(locator = "mynotification.lbl.mystore")
	private QAFWebElement LblMystore;
	@FindBy(locator = "mynotification.rbt.newsletter")
	private QAFWebElement RbtNewsletter;
	@FindBy(locator = "mynotification.rbt.promotional")
	private QAFWebElement RbtPromotional;
	@FindBy(locator = "mynotification.rbt.weeklyad")
	private QAFWebElement RbtWeeklyad;
	@FindBy(locator = "mynotification.lbl.selectastore")
	private QAFWebElement lblSelectastore;
	@FindBy(locator = "mynotification.btn.selectastore")
	private QAFWebElement btnSelectastore;
	
	@FindBy(locator = "mynotification.lbl.textmsgsforsignup")
	private QAFWebElement lblTextmsgsforsignup;
	@FindBy(locator = "mynotification.lbl.getextraoffers")
	private QAFWebElement btnGetextraoffers;
	@FindBy(locator = "mynotification.lbl.emailnotifications")
	private QAFWebElement lblEmailnotifications;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPgetitle() {
		return LblPgetitle;
	}

	public QAFWebElement getLblGetextraoffers() {
		return lblGetextraoffers;
	}

	public QAFWebElement getLblMystore() {
		return LblMystore;
	}

	public QAFWebElement getRbtNewsletter() {
		return RbtNewsletter;
	}

	public QAFWebElement getRbtPromotional() {
		return RbtPromotional;
	}

	public QAFWebElement getRbtWeeklyad() {
		return RbtWeeklyad;
	}
	
	public QAFWebElement getLblSelectastore() {
		return lblSelectastore;
	}

	public QAFWebElement getBtnSelectastore() {
		return btnSelectastore;
	}
	
	public QAFWebElement getlblTextmsgsforsignup() {
		return lblTextmsgsforsignup;
	}
	
	public QAFWebElement getBtnGetextraoffers() {
		return btnGetextraoffers;
	}
	
	public QAFWebElement getLblEmailnotifications() {
		return lblEmailnotifications;
	}

}
