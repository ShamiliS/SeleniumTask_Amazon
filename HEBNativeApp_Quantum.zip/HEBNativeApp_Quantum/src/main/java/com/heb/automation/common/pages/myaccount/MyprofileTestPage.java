package com.heb.automation.common.pages.myaccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyprofileTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "myprofile.txt.firstname")
	private QAFWebElement myprofileTxtFirstname;
	@FindBy(locator = "myprofile.txt.lastname")
	private QAFWebElement myprofileTxtLastname;
	@FindBy(locator = "myprofile.txt.email")
	private QAFWebElement myprofileTxtEmail;
	@FindBy(locator = "myprofile.txt.pagetitle")
	private QAFWebElement myprofileTxtPagetitle;
	
	@FindBy(locator = "myprofile.lnk.chgpwd")
	private QAFWebElement lnkChgpwd;
	@FindBy(locator = "myprofile.btn.saveprofile")
	private QAFWebElement btnSaveprofile;
	@FindBy(locator = "myprofile.btn.warningok")
	private QAFWebElement btnWarningok;
	@FindBy(locator = "myprofile.lbl.warning")
	private QAFWebElement lblWarning;
	@FindBy(locator = "myprofile.txt.popuperror")
	private QAFWebElement myprofileTxtPopuperror;
	@FindBy(locator = "myprofile.lbl.errpopup")
	private QAFWebElement lblErrpopup;
	@FindBy(locator = "myprofile.img.savebtn")
	private QAFWebElement myprofileImgSavebtn;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getMyprofileTxtPagetitle() {
		return myprofileTxtPagetitle;
	}

	public QAFWebElement getMyprofileTxtFirstname() {
		return myprofileTxtFirstname;
	}

	public QAFWebElement getMyprofileTxtLastname() {
		return myprofileTxtLastname;
	}

	public QAFWebElement getMyprofileTxtEmail() {
		return myprofileTxtEmail;
	}
	
	public QAFWebElement getLnkChgpwd() {
		return lnkChgpwd;
	}
	
	public QAFWebElement getBtnSaveprofile() {
		return btnSaveprofile;
	}
	
	public QAFWebElement getBtnWarningok() {
		return btnWarningok;
	}
	
	public QAFWebElement getLblErrpopup() {
		return lblErrpopup;
	}

	public QAFWebElement getLblWarning() {
		return lblWarning;
	}
	
	public QAFWebElement getMyprofileTxtPopuperror() {
		return myprofileTxtPopuperror;
	}
	public QAFWebElement getmyprofileImgSavebtn() {
		return myprofileImgSavebtn;
	}
}
