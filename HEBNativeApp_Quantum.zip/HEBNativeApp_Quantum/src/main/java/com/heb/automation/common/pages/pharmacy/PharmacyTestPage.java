package com.heb.automation.common.pages.pharmacy;

import java.util.List;

import com.heb.automation.common.components.ProductResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PharmacyTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "pharmacy.lbl.pagetitle")
	private QAFWebElement pharmacyLblPagetitle;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
	public QAFWebElement getPharmacyLblPagetitle() {
		return pharmacyLblPagetitle;
	}

	
}
