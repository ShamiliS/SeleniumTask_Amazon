package com.heb.automation.common.pages.products;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LegalDisclaimerTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "disclaimer.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "disclaimer.lbl.pageheader")
	private QAFWebElement lblPageheader;

	@FindBy(locator = "disclaimer.lbl.legalmessage")
	private QAFWebElement lblLegalmessage;

	@FindBy(locator = "disclaimer.lnk.viewfullpdtinfo")
	private QAFWebElement lnkViewfullpdtinfo;

	@FindBy(locator = "disclaimer.btn.navback")
	private QAFWebElement btnNavback;

	@FindBy(locator = "disclaimer.btn.ok")
	private QAFWebElement btnOk;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblLegalmessage() {
		return lblLegalmessage;
	}

	public QAFWebElement getLnkViewfullpdtinfo() {
		return lnkViewfullpdtinfo;
	}

	public QAFWebElement getBtnNavback() {
		return btnNavback;
	}

	public QAFWebElement getBtnOk() {
		return btnOk;
	}

}
