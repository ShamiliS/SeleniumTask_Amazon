package com.heb.automation.common.pages.products;

import java.util.List;

import com.heb.automation.common.components.ProductResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductsresultlistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "productresult.list.srchresult")
	private List<ProductResult> productresultlist;
	@FindBy(locator = "productresult.lbl.productname")
	private List<QAFWebElement> productresultLblProductnameList;
	@FindBy(locator = "productresult.lbl.productname")
	private QAFWebElement productresultLblProductname;
	@FindBy(locator = "prodsearchresult.txt.allproductscount")
	private QAFWebElement prodsearchresultTxtAllproductscount;
	
	@FindBy(locator = "productresult.btn.addtolist")
	private QAFWebElement BtnAddtolist;
	@FindBy(locator = "productresult.lbl.productprize")
	private QAFWebElement LblProductprize;
	@FindBy(locator = "productresult.img.productimage")
	private QAFWebElement ImgProductimage;
	
	@FindBy(locator = "productresult.img.productlocation")
	private QAFWebElement ImgProductlocation;
	@FindBy(locator = "productresult.lbl.allproducts")
	private QAFWebElement LblAllproducts;
	@FindBy(locator = "productresult.lbl.selectastore")
	private QAFWebElement lblSelectastore;
	@FindBy(locator = "productresult.lbl.selectedstore")
	private QAFWebElement lblSelectedStrore;
	@FindBy(locator = "productresult.lbl.changestore")
	private QAFWebElement lblChangestore;
	@FindBy(locator = "productresult.lbl.chooseanotherstore")
	private QAFWebElement lblChooseanotherstore;
	@FindBy(locator = "productresult.lbl.childproductname")
	private List<QAFWebElement> lblChildproductnamelist;
	
	
	@FindBy(locator = "productresult.lbl.allproductscount")
	private QAFWebElement lblallproductscount;
	@FindBy(locator = "productresult.lbl.inmystore")
	private QAFWebElement lblInmystore;
	@FindBy(locator = "productresult.lbl.inmystorecount")
	private QAFWebElement lblInmystorecount;
	@FindBy(locator = "productresult.lbl.tabs")
	private List<QAFWebElement> lblTabs;
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<ProductResult> getProductresultlist() {
		return productresultlist;
	}


	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<QAFWebElement> getProductresultLblProductnameList() {
		return productresultLblProductnameList;
	}

	// DYNAMIC value declaring
	public QAFWebElement getAddToLstBtnWithRespectToPdtName(String lable) {
		String loc = String.format(pageProps.getString("productresult.chkbox.addtolistpdtname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getProductresultLblProductname() {
		return productresultLblProductname;
	}

	public QAFWebElement getProdsearchresultTxtAllproductscount() {
		return prodsearchresultTxtAllproductscount;
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getAddToCartBtnWithRespectToCell(int lable) {
		String loc = String.format(pageProps.getString("productresult.btn.addtocartdynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	// DYNAMIC value declaring
	public QAFWebElement getPrdtNameWithRespectToCell(int lable) {
		String loc = String.format(pageProps.getString("productresult.lbl.productnamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getBtnAddtolist() {
		return BtnAddtolist;
	}

	public QAFWebElement getLblProductprize() {
		return LblProductprize;
	}

	public QAFWebElement getImgProductimage() {
		return ImgProductimage;
	}

	public QAFWebElement getImgProductlocation() {
		return ImgProductlocation;
	}

	public QAFWebElement getLblAllproducts() {
		return LblAllproducts;
	}

	
	public QAFWebElement getLblSelectastore() {
		return lblSelectastore;
	}
	
	public QAFWebElement getLblSelectedStrore() {
		return lblSelectedStrore;
	}

	public QAFWebElement getLblChangestore() {
		return lblChangestore;
	}
	
	public QAFWebElement getLblChooseanotherstore() {
		return lblChooseanotherstore;
	}
	
	public List<QAFWebElement> getLblChildproductnamelist() {
		return lblChildproductnamelist;
	}
	public QAFWebElement getLblallproductscount() {
		return lblallproductscount;
	}
	public QAFWebElement getLblInmystore() {
		return lblInmystore;
	}
	public QAFWebElement getLblInmystorecount() {
		return lblInmystorecount;
	}
	public List<QAFWebElement> getLblTabs() {
		return lblTabs;
	}
}
