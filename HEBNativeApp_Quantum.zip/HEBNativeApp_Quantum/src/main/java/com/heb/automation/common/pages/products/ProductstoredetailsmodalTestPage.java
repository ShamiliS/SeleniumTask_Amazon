package com.heb.automation.common.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ProductstoredetailsmodalTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "storemodal.lbl.pageheader")
	private QAFWebElement storemodalLblPageheader;
	@FindBy(locator = "storemodal.lbl.storename")
	private QAFWebElement storemodalLblStorename;
	@FindBy(locator = "storemodal.btn.backicon")
	private QAFWebElement storemodalBtnBackicon;
	@FindBy(locator = "storemodal.btn.closeicon")
	private QAFWebElement storemodalBtnCloseicon;
	@FindBy(locator = "storemodal.lbl.mylocation")
	private QAFWebElement storemodalLblMylocation;
	@FindBy(locator = "storemodal.lbl.mappin")
	private QAFWebElement storemodalLblMappin;
	@FindBy(locator = "storemodal.lbl.mapview")
	private QAFWebElement storemodalLblMapview;
	@FindBy(locator = "storemodal.lbl.miles")
	private QAFWebElement storemodalLblMiles;
	@FindBy(locator = "storemodal.lbl.location")
	private QAFWebElement storemodalLblLocation;
	@FindBy(locator = "storemodal.lnk.getdirection")
	private QAFWebElement storemodalLnkGetdirection;
	@FindBy(locator = "storemodal.lnk.call")
	private QAFWebElement storemodalLnkCall;
	@FindBy(locator = "storemodal.lnk.storefeature")
	private QAFWebElement storemodalLnkStorefeature;
	@FindBy(locator = "storemodal.lbl.pharmacy")
	private QAFWebElement storemodalLblPharmacy;
	@FindBy(locator = "storemodal.lbl.changemystore")
	private QAFWebElement storemodalLblChangemystore;
	@FindBy(locator = "pdp.lnk.stricon")
	private QAFWebElement pdpLnkStricon;
	@FindBy(locator = "strlist.lnk.strnamewithlocation")
	private List<QAFWebElement> strlistLnkStrnamewithlocation;
	@FindBy(locator = "strlist.lbl.productlocation")
	private List<QAFWebElement> strlistLblProductlocation;
	@FindBy(locator = "pdp.lnk.viewnearbystore")
	private QAFWebElement pdpLnkViewnearbystore;
	@FindBy(locator = "pdp.lnk.storename")
	private QAFWebElement pdpLnkStorename;
	@FindBy(locator = "pdp.lbl.productlocation")
	private QAFWebElement pdpLblProductlocation;
	@FindBy(locator = "storemodal.lbl.leavingappgetdirection")
	private QAFWebElement lblLeavingappgetdirection;
	@FindBy(locator = "storemodal.btn.cancelpopup")
	private QAFWebElement btnCancelpopup;
	@FindBy(locator = "storemodal.btn.okpopup")
	private QAFWebElement btnOkpopup;
	
	@FindBy(locator = "storemodal.lbl.weeklyad")
	private QAFWebElement lblWeeklyAd;
	@FindBy(locator = "storemodal.lbl.changestr")
	private QAFWebElement lblChangeStr;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getStoremodalLblPageheader() {
		return storemodalLblPageheader;
	}
	public QAFWebElement getLblWeeklyAdTxt() {
		return lblWeeklyAd;
	}
	public QAFWebElement getLblChangeStrTxt() {
		return lblChangeStr;
	}


	public QAFWebElement getStoremodalLblStorename() {
		return storemodalLblStorename;
	}

	public QAFWebElement getStoremodalBtnBackicon() {
		return storemodalBtnBackicon;
	}

	public QAFWebElement getStoremodalBtnCloseicon() {
		return storemodalBtnCloseicon;
	}

	public QAFWebElement getStoremodalLblMylocation() {
		return storemodalLblMylocation;
	}

	public QAFWebElement getStoremodalLblMappin() {
		return storemodalLblMappin;
	}

	public QAFWebElement getStoremodalLblMapview() {
		return storemodalLblMapview;
	}

	public QAFWebElement getStoremodalLblMiles() {
		return storemodalLblMiles;
	}

	public QAFWebElement getStoremodalLblLocation() {
		return storemodalLblLocation;
	}

	public QAFWebElement getStoremodalLnkGetdirection() {
		return storemodalLnkGetdirection;
	}

	public QAFWebElement getStoremodalLnkCall() {
		return storemodalLnkCall;
	}

	public QAFWebElement getStoremodalLnkStorefeature() {
		return storemodalLnkStorefeature;
	}

	public QAFWebElement getStoremodalLblPharmacy() {
		return storemodalLblPharmacy;
	}

	public QAFWebElement getStoremodalLblChangemystore() {
		return storemodalLblChangemystore;
	}

	public QAFWebElement getPdpLnkStricon() {
		return pdpLnkStricon;
	}

	public List<QAFWebElement> getStrlistLnkStrnamewithlocation() {
		return strlistLnkStrnamewithlocation;
	}

	public List<QAFWebElement> getStrlistLblProductlocation() {
		return strlistLblProductlocation;
	}

	public QAFWebElement getPdpLnkViewnearbystore() {
		return pdpLnkViewnearbystore;
	}

	public QAFWebElement getPdpLnkStorename() {
		return pdpLnkStorename;
	}

	public QAFWebElement getPdpLblProductlocation() {
		return pdpLblProductlocation;
	}
	public QAFWebElement getLblLeavingappgetdirection() {
		return lblLeavingappgetdirection;
	}
	public QAFWebElement getBtnCancelpopup() {
		return btnCancelpopup;
	}
	public QAFWebElement getBtnOkpopup() {
		return btnOkpopup;
	}
}
