package com.heb.automation.common.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipedetailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipedetail.btn.share")
	private QAFWebElement recipedetailpageHeaderSharebutton;
	@FindBy(locator = "recipedetail.btn.recipebox")
	private QAFWebElement recipedetailpageHeaderRecipeboxbutton;
	@FindBy(locator = "recipedetail.header.recipesbutton")
	private QAFWebElement recipedetailpageHeaderRecipesbutton;
	@FindBy(locator = "recipedetail.lbl.recipename")
	private QAFWebElement recipedetailpageRecipename;
	@FindBy(locator = "recipedetail.btn.addtobox")
	private QAFWebElement recipedetailpageAddtoBox;
	@FindBy(locator = "recipedetail.btn.addtolist")
	private QAFWebElement recipedetailpageAddtolist;
	@FindBy(locator = "recipedetail.chk.firstingrednt")
	private QAFWebElement recipedetailpageIngChkbox1;
	@FindBy(locator = "recipedetail.lstpopup.title")
	private QAFWebElement recipedetailpageLstpopupTitle;
	@FindBy(locator = "recipedetail.lbl.lstpopuplistname")
	private QAFWebElement recipedetailpageLstpopupListname;
	@FindBy(locator = "recipedetail.btn.lstpopupadd")
	private QAFWebElement recipedetailpageLstpopupBtnAdd;
	@FindBy(locator = "recipedetail.btn.lstpopupcancel")
	private QAFWebElement recipedetailpageLstpopupBtnCancel;
	@FindBy(locator = "recipedetail.toast.gotolist")
	private QAFWebElement recipedetailpageToastGotolist;
	@FindBy(locator = "recipedetail.txt.firstingrednt")
	private QAFWebElement recipedetailpageIngChkbox1text;
	@FindBy(locator = "recipedetail.txt.lstpopuphotuserlistname")
	private QAFWebElement recipedetailLstpopupHotuserLstname;
	@FindBy(locator = "recipedetail.txt.lstpopuphotusernextlistname")
	private QAFWebElement recipedetailLstpopupHotuserNextLstname;
	@FindBy(locator = "recipedetail.lbl.selectall")
	private QAFWebElement recipedetailpagelblselectall;
	@FindBy(locator = "recipedetail.lbl.ingredientslist")
	private List<QAFWebElement> recipedetailpageIngList;
	@FindBy(locator = "recipedetail.img.recipe")
	private QAFWebElement recipedetailImgRecipeimage;
	@FindBy(locator = "recipedetail.lbl.saverecipe")
	private QAFWebElement recipedetailLblSaverecipe;
	@FindBy(locator = "recipedetail.btn.loginrecipebox")
	private QAFWebElement recipedetailBtnLoginrecipebox;
	@FindBy(locator = "recipedetail.lbl.preptime")
	private QAFWebElement recipedetailLblPreptime;
	@FindBy(locator = "recipedetail.lbl.preptimevalue")
	private QAFWebElement recipedetailLblPreptimevalue;
	@FindBy(locator = "recipedetail.lbl.totaltime")
	private QAFWebElement recipedetailLblTotaltime;
	@FindBy(locator = "recipedetail.lbl.totaltimevalue")
	private QAFWebElement recipedetailLblTotaltimevalue;
	@FindBy(locator = "recipedetail.lbl.serves")
	private QAFWebElement recipedetailLblServes;
	@FindBy(locator = "recipedetail.lbl.servesvalue")
	private QAFWebElement recipedetailLblServesvalue;
	@FindBy(locator = "recipedetail.lbl.ingredients")
	private QAFWebElement recipedetailLblIngredients;
	@FindBy(locator = "recipedetail.lbl.nutritioninfo")
	private QAFWebElement recipedetailLblNutritioninfo;
	@FindBy(locator = "recipedetail.lbl.btn.Ingredients")
	private QAFWebElement recipedetailLblIngredientsheading;
	@FindBy(locator = "recipedetail.lbl.review")
	private QAFWebElement recipedetailLblReview;
	@FindBy(locator = "recipedetail.lbl.popuprecipeboxnameslist")
	private List<QAFWebElement> lblPopuprecipeboxnameslist;
	@FindBy(locator = "recipedetail.lbl.sharefacebook")
	private QAFWebElement recipedetailLblSharefacebook;
	@FindBy(locator = "recipedetail.lbl.sharegoogle+")
	private QAFWebElement recipedetailLblSharegoogle;
	@FindBy(locator = "recipedetail.lbl.shareemail")
	private QAFWebElement recipedetailLblShareemail;
	@FindBy(locator = "recipedetail.lbl.errorpopuptitle")
	private QAFWebElement lblErrorpopuptitle;
	@FindBy(locator = "recipedetail.btn.errorpopupyes")
	private QAFWebElement btnErrorpopupyes;
	@FindBy(locator = "recipedetail.btn.errorpopupno")
	private QAFWebElement btnErrorpopupno;
	@FindBy(locator = "recipedetail.lbl.ingredientslistchecked")
	private List<QAFWebElement> recipedetailLblIngredientslistchecked;
	@FindBy(locator = "recipedetail.lbl.unselectall")
	private QAFWebElement lblUnselectall;
	/*
	 * @FindBy(locator = "recipedetail.btn.addtolist") private
	 * List<QAFWebElement> btnAddtolist;
	 */
	@FindBy(locator = "recipedetail.lbl.recipename")
	private List<QAFWebElement> lblRecipenameList;
	@FindBy(locator = "recipedetail.btn.recipenamelist")
	private QAFWebElement btnFirstRecipename;
	@FindBy(locator = "recipedetail.btn.addtolistrecipe")
	private QAFWebElement btnFirstAddtolistlist;
	@FindBy(locator = "recipedetail.lbl.sharereminders")
	private QAFWebElement lblSharereminders;
	@FindBy(locator = "recipedetail.lbl.shareaddtonotes")
	private QAFWebElement lblShareaddtonotes;
	@FindBy(locator = "recipedetail.lbl.sharemore")
	private QAFWebElement lblSharemore;
	@FindBy(locator = "recipedetail.lbl.recipelist")
	private List<QAFWebElement> LblRecipelist;
	@FindBy(locator = "recipedetail.chk.firstingrednt")
	private List<QAFWebElement> recipedetailpageChkbox;

	@FindBy(locator = "recipedetail.btn.navigationbar")
	private QAFWebElement btnNavigationbar;


	@FindBy(locator = "recipedetail.btn.login")
	private QAFWebElement btnLogin;
	
	@FindBy(locator = "recipedetail.lbl.instructions")
	private QAFWebElement recipedetaillblinstructions;
	@FindBy(locator = "recipedetail.btn.selectall")
	private QAFWebElement recipedetailBtnSelectall;
	@FindBy(locator = "recipedetail.txt.lstpopuphotuserlistname")
	private List<QAFWebElement> txtListNameDisplayed;
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getRecipedetailpageAddtoBox() {
		return recipedetailpageAddtoBox;
	}

	public QAFWebElement getRecipedetailpageHeaderSharebutton() {
		return recipedetailpageHeaderSharebutton;
	}

	public QAFWebElement getRecipedetailpageHeaderRecipeboxbutton() {
		return recipedetailpageHeaderRecipeboxbutton;
	}

	public QAFWebElement getRecipedetailpageHeaderRecipesbutton() {
		return recipedetailpageHeaderRecipesbutton;
	}

	public QAFWebElement getRecipedetailpageRecipename() {
		return recipedetailpageRecipename;
	}

	public QAFWebElement getRecipedetailpageAddtolist() {
		return recipedetailpageAddtolist;
	}

	public QAFWebElement getRecipedetailpageIngChkbox1() {
		return recipedetailpageIngChkbox1;
	}

	public QAFWebElement getRecipedetailpageLstpopupTitle() {
		return recipedetailpageLstpopupTitle;
	}

	public QAFWebElement getRecipedetailpageLstpopupListname() {
		return recipedetailpageLstpopupListname;
	}

	public QAFWebElement getRecipedetailpageLstpopupBtnAdd() {
		return recipedetailpageLstpopupBtnAdd;
	}

	public QAFWebElement getRecipedetailpageLstpopupBtnCancel() {
		return recipedetailpageLstpopupBtnCancel;
	}

	public QAFWebElement getRecipedetailpageIngChkbox1text() {
		return recipedetailpageIngChkbox1text;
	}

	public QAFWebElement getRecipedetailLstpopupHotuserLstname() {
		return recipedetailLstpopupHotuserLstname;
	}

	public QAFWebElement getRecipedetailLstpopupHotuserNextLstname() {
		return recipedetailLstpopupHotuserNextLstname;
	}

	public QAFWebElement getRecipedetailpagelblselectall() {
		return recipedetailpagelblselectall;
	}

	public List<QAFWebElement> getRecipedetailpageIngList() {
		return recipedetailpageIngList;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getRecipedetailImgRecipeimage() {
		return recipedetailImgRecipeimage;
	}

	public QAFWebElement getRecipedetailpageToastGotolist() {
		return recipedetailpageToastGotolist;
	}

	public QAFWebElement getRecipedetailLblSaverecipe() {
		return recipedetailLblSaverecipe;
	}

	public QAFWebElement getRecipedetailBtnLoginrecipebox() {
		return recipedetailBtnLoginrecipebox;
	}

	public QAFWebElement getRecipedetailLblPreptime() {
		return recipedetailLblPreptime;
	}

	public QAFWebElement getRecipedetailLblPreptimevalue() {
		return recipedetailLblPreptimevalue;
	}

	public QAFWebElement getRecipedetailLblTotaltime() {
		return recipedetailLblTotaltime;
	}

	public QAFWebElement getRecipedetailLblTotaltimevalue() {
		return recipedetailLblTotaltimevalue;
	}

	public QAFWebElement getRecipedetailLblServes() {
		return recipedetailLblServes;
	}

	public QAFWebElement getRecipedetailLblServesvalue() {
		return recipedetailLblServesvalue;
	}

	public QAFWebElement getRecipedetailLblIngredients() {
		return recipedetailLblIngredients;
	}

	public QAFWebElement getRecipedetailLblNutritioninfo() {
		return recipedetailLblNutritioninfo;
	}

	public QAFWebElement getRecipedetailLblIngredientsheading() {
		return recipedetailLblIngredientsheading;
	}

	public QAFWebElement getRecipedetailLblReview() {
		return recipedetailLblReview;
	}

	public List<QAFWebElement> getLblPopuprecipeboxnameslist() {
		return lblPopuprecipeboxnameslist;
	}

	// DYNAMIC value declaring
	public QAFWebElement getLblPopuprecipeboxnameByLable(int lable) {
		String loc = String.format(pageProps.getString("recipedetail.lbl.popuprecipeboxname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getRecipedetailLblSharefacebook() {
		return recipedetailLblSharefacebook;
	}

	public QAFWebElement getLblErrorpopuptitle() {
		return lblErrorpopuptitle;
	}

	public QAFWebElement getBtnErrorpopupyes() {
		return btnErrorpopupyes;
	}

	public QAFWebElement getBtnErrorpopupno() {
		return btnErrorpopupno;
	}

	public QAFWebElement getRecipedetailLblSharegoogle() {
		return recipedetailLblSharegoogle;
	}

	public QAFWebElement getRecipedetailLblShareemail() {
		return recipedetailLblShareemail;
	}

	public List<QAFWebElement> getRecipedetailLblIngredientslistchecked() {
		return recipedetailLblIngredientslistchecked;
	}

	/*
	 * public List<QAFWebElement> getBtnAddtolist() { return btnAddtolist; }
	 */

	public List<QAFWebElement> getLblRecipenameList() {
		return lblRecipenameList;
	}

	// DYNAMIC value declaring
	public QAFWebElement getBtnRecipenameListByLable(int lable) {
		String loc = String.format(pageProps.getString("recipedetail.btn.recipenamelist"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getBtnAddtolistListByLable(int lable) {
		String loc = String.format(pageProps.getString("recipedetail.btn.addtolistlist"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnFirstRecipename() {
		return btnFirstRecipename;
	}

	public QAFWebElement getBtnFirstAddtolistlist() {
		return btnFirstAddtolistlist;
	}

	public QAFWebElement getLblUnselectall() {
		return lblUnselectall;
	}

	public QAFWebElement getLblSharereminders() {
		return lblSharereminders;
	}

	public QAFWebElement getLblShareaddtonotes() {
		return lblShareaddtonotes;
	}

	public QAFWebElement getLblSharemore() {
		return lblSharemore;
	}

	public List<QAFWebElement> getLblRecipelist() {
		return LblRecipelist;
	}

	public List<QAFWebElement> getRecipedetailpageChkbox() {
		return recipedetailpageChkbox;
	}

	public QAFWebElement getBtnNavigationbar() {
		return btnNavigationbar;
	}
	public QAFWebElement getBtnLogin() {
		return btnLogin;
	}
	public QAFWebElement getRecipedetaillblinstructions() {
		return recipedetaillblinstructions;
	}
	public QAFWebElement getRecipedetailBtnSelectall() {
		return recipedetailBtnSelectall;
	}
	public List<QAFWebElement> getTxtListNameDisplayed() {
		return txtListNameDisplayed;
	}
}
