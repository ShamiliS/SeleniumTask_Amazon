package com.heb.automation.common.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ReciperesultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "reciperesult.btn.recipebox")
	private QAFWebElement reciperesultHeaderRecipebox;
	@FindBy(locator = "reciperesult.btn.refine")
	private QAFWebElement reciperesultRefine;
	@FindBy(locator = "reciperesult.lbl.recipecount")
	private QAFWebElement reciperesultCount;
	@FindBy(locator = "reciperesult.list.item")
	private QAFWebElement reciperesultListItem;
	@FindBy(locator = "reciperesult.lbl.recipename")
	private QAFWebElement reciperesultRecipename;
	@FindBy(locator = "reciperesult.img.firstitem")
	private QAFWebElement reciperesultItem1;
	@FindBy(locator = "reciperesult.lbl.pagetitle")
	private QAFWebElement reciperesultPagetitle;
	@FindBy(locator = "refine.lbl.pagetitle")
	private QAFWebElement refinelblpagetitle;
	@FindBy(locator = "refine.btn.done")
	private QAFWebElement refinebtndone;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getReciperesultHeaderRecipebox() {
		return reciperesultHeaderRecipebox;
	}

	public QAFWebElement getReciperesultRefine() {
		return reciperesultRefine;
	}

	public QAFWebElement getReciperesultItem1() {
		return reciperesultItem1;
	}

	public QAFWebElement getReciperesultCount() {
		return reciperesultCount;
	}

	public QAFWebElement getReciperesultListItem() {
		return reciperesultListItem;
	}

	public QAFWebElement getReciperesultRecipename() {
		return reciperesultRecipename;
	}

	public QAFWebElement getReciperesultPagetitle() {
		return reciperesultPagetitle;
	}

	public QAFWebElement getRefineLblPagetitle() {
		return refinelblpagetitle;
	}

	public QAFWebElement getRefineBtnDone() {
		return refinebtndone;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
