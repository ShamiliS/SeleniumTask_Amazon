package com.heb.automation.common.pages.recipes;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RefineTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "refine.lbl.bymeal")
	private QAFWebElement refineLblBymeal;
	@FindBy(locator = "refine.cell.filter")
	private QAFWebElement refineCellFilter;
	@FindBy(locator = "refine.lbl.filterbyname")
	private QAFWebElement refineLblFilterbyname;
	@FindBy(locator = "refine.lbl.byingredient")
	private QAFWebElement refineLblByingredient;
	@FindBy(locator = "refine.lbl.bynutrition")
	private QAFWebElement refineLblBynutrition;
	@FindBy(locator = "refine.lbl.bydiet")
	private QAFWebElement refineLblBydiet;
	@FindBy(locator = "refine.lbl.bycookingmethod")
	private QAFWebElement refineLblBycookingmethod;
	@FindBy(locator = "refine.lbl.source")
	private QAFWebElement refineLblSource;
	@FindBy(locator = "refine.btn.refine")
	private QAFWebElement refineBtnRefine;
	@FindBy(locator = "refine.lbl.pagetitle")
	private QAFWebElement refineLblPagetitle;
	@FindBy(locator = "refine.lbl.filterbymeal")
	private QAFWebElement LblFilterbymeal;
	@FindBy(locator = "refine.lbl.filterbynutrition")
	private QAFWebElement LblFilterbynutrition;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getRefineLblBymeal() {
		return refineLblBymeal;
	}

	public QAFWebElement getRefineCellFilter() {
		return refineCellFilter;
	}

	public QAFWebElement getRefineLblFilterbyname() {
		return refineLblFilterbyname;
	}

	public QAFWebElement getRefineLblByingredient() {
		return refineLblByingredient;
	}

	public QAFWebElement getRefineLblBynutrition() {
		return refineLblBynutrition;
	}

	public QAFWebElement getRefineLblBydiet() {
		return refineLblBydiet;
	}

	public QAFWebElement getRefineLblBycookingmethod() {
		return refineLblBycookingmethod;
	}

	public QAFWebElement getRefineLblSource() {
		return refineLblSource;
	}

	public QAFWebElement getRefineBtnRefine() {
		return refineBtnRefine;
	}

	public QAFWebElement getRefineLblPagetitle() {
		return refineLblPagetitle;
	}

	public QAFWebElement getLblFilterbymeal() {
		return LblFilterbymeal;
	}

	public QAFWebElement getLblFilterbynutrition() {
		return LblFilterbynutrition;
	}

}
