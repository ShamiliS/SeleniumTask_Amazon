package com.heb.automation.common.pages.registeration;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CancelregistrationTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cancelregistration.lbl.title")
	private QAFWebElement cancelregistrationLblTitle;
	@FindBy(locator = "cancelregistration.lbl.message")
	private QAFWebElement cancelregistrationLblMessage;
	@FindBy(locator = "cancelregistration.btn.no")
	private QAFWebElement cancelregistrationBtnNo;
	@FindBy(locator = "cancelregistration.btn.yes")
	private QAFWebElement cancelregistrationBtnYes;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCancelregistrationLblTitle() {
		return cancelregistrationLblTitle;
	}

	public QAFWebElement getCancelregistrationLblMessage() {
		return cancelregistrationLblMessage;
	}

	public QAFWebElement getCancelregistrationBtnNo() {
		return cancelregistrationBtnNo;
	}

	public QAFWebElement getCancelregistrationBtnYes() {
		return cancelregistrationBtnYes;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
