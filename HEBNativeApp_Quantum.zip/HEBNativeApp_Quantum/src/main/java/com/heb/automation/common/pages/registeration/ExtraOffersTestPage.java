package com.heb.automation.common.pages.registeration;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ExtraOffersTestPage extends WebDriverBaseTestPage<com.qmetry.qaf.automation.ui.api.WebDriverTestPage> {

	@FindBy(locator = "extraoffers.btn.save")
	private QAFWebElement BtnSave;
	@FindBy(locator = "extraoffers.edt.mobilenum")
	private QAFWebElement EdtMobilenum;
	@FindBy(locator = "extraoffers.edt.mobilenumafterentered")
	private QAFWebElement EdtMobilenumafterentered;
	@FindBy(locator = "extraoffers.chk.iagree")
	private QAFWebElement ChkIagree;
	@FindBy(locator = "extraoffers.lbl.header")
	private QAFWebElement lblPageHeader;
	@FindBy(locator = "extraoffers.lbl.termscondition")
	private QAFWebElement lblTermsConditions;
	@FindBy(locator = "extraoffers.img.savebtn")
	private QAFWebElement imgSaveBtn;
	@FindBy(locator = "extraoffers.lbl.digitalcoupons")
	private QAFWebElement lbldigitalcoupons;
	@FindBy(locator = "extraoffers.txt.digitalcoupons")
	private QAFWebElement txtdigitalcoupons;
	@FindBy(locator = "extraoffers.edt.4digitpin")
	private QAFWebElement edt4digitpin;
	@FindBy(locator = "extraoffers.btn.submit")
	private QAFWebElement btnSubmit;
	@FindBy(locator = "extraoffers.lbl.digitcoupdesc")
	private QAFWebElement lblDigitcoupdesc;
	
	@FindBy(locator = "extraoffers.txt.mobilenumedit")
	private QAFWebElement txtMobileNumEdit;
	@FindBy(locator = "extraoffers.edt.premobilenum")
	private QAFWebElement EdtPremobilenum;

	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageHeader() {
		return lblPageHeader;
	}

	public QAFWebElement getBtnSave() {
		return BtnSave;
	}
	
	public QAFWebElement getEdtMobilenumafterentered() {
		return EdtMobilenumafterentered;
	}

	public QAFWebElement getEdtMobilenum() {
		return EdtMobilenum;
	}

	public QAFWebElement getChkIagree() {
		return ChkIagree;
	}

	public QAFWebElement getLblTermsConditions() {
		return lblTermsConditions;
	}

	public QAFWebElement getImgSaveBtn() {
		return imgSaveBtn;
	}

	public QAFWebElement getLbldigitalcoupons() {
		return lbldigitalcoupons;
	}

	public QAFWebElement gettxtdigitalcoupons() {
		return txtdigitalcoupons;
	}

	public QAFWebElement getedt4digitpin() {
		return edt4digitpin;
	}

	public QAFWebElement getBtnSubmit() {
		return btnSubmit;
	}
	
	public QAFWebElement getLblDigitcoupdesc() {
		return lblDigitcoupdesc;
	}
	public QAFWebElement getTxtMobileNumEdit() {
		return txtMobileNumEdit;
	}
	
	public QAFWebElement getEdtPremobilenum() {
		return EdtPremobilenum;
	}
}
