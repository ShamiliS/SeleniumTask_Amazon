package com.heb.automation.common.pages.registeration;


import com.heb.automation.common.databean.RegistrationBean;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RegistrastionTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	/** Registration Flow  || My Accounts 
	 * 1) Registration Landing Page 
	 * 2) Pick A store page
	 * 3) Want More ? Page
	 * 4) Extra Offers Page
	 *
	 */
	
	/** 1) Registration Landing Page  **/
	@FindBy(locator = "registration.txt.pagetitle")
	private QAFWebElement registrationTxtPagetitle;
	@FindBy(locator = "registration.txt.firstname")
	private QAFWebElement registrationTxtFirstname;
	@FindBy(locator = "registration.txt.lastname")
	private QAFWebElement registrationTxtLastname;
	@FindBy(locator = "registration.txt.email")
	private QAFWebElement registrationTxtEmail;
	@FindBy(locator = "registration.txt.password")
	private QAFWebElement registrationTxtPassword;
	@FindBy(locator = "registration.img.showpwd")
	private QAFWebElement ImgShowpwd;
	@FindBy(locator = "registration.img.hidepwd")
	private QAFWebElement ImgHidepwd;
	@FindBy(locator = "registration.chk.iagree")
	private QAFWebElement registrationChkIagree;
	@FindBy(locator = "registration.btn.submit")  // To create an Account
	private QAFWebElement registrationBtnSubmit;
	@FindBy(locator = "registration.lnk.skipandcontinueasguest")
	private QAFWebElement lnkSkipandcontinueasguest;
	@FindBy(locator = "registration.txt.pwdafterentrd")
	private QAFWebElement txtPwdafterentrd;
	@FindBy(locator = "registration.lbl.tipfirstname")
	private QAFWebElement lblTipfirstname;	
	@FindBy(locator = "registration.lbl.tiplastname")
	private QAFWebElement lblTiplastname;
	@FindBy(locator = "registration.lbl.tipemail")
	private QAFWebElement lblTipemail;
	@FindBy(locator = "registration.lbl.tippassword")
	private QAFWebElement lblTippassword;
	
	/*Functionalities REMOVED
	@FindBy(locator = "registration.txt.confirm.password")
	private QAFWebElement registrationTxtConfirmPassword;
	@FindBy(locator = "registration.txt.show.confirm.password")
	private QAFWebElement registrationTxtShowConfirmPassword;
	*/
	
	
	/** 2) PICK YOUR STORE PAGE **/
	
	@FindBy(locator = "registration.pickstore.lbl.pickstore")
	private QAFWebElement lblPickstore;
	@FindBy(locator = "registration.pickstore.btn.selectstore")
	private QAFWebElement registrationBtnSelectStore;
	@FindBy(locator = "registration.pickstore.lbl.skipfornow")
	private QAFWebElement btnSkipfornow;
	@FindBy(locator = "registration.pickstore.lbl.description")
	private QAFWebElement pickStoreDescription;
	
	
	/** 3) Want More ? Page **/
	
	// Covered separately 
	
	
	/** 4) Extra Offers **/
	//Covered separately 
	
	@FindBy(locator = "registration.lbl.errmsgonpwd")
	private QAFWebElement lblErrmsgonpwd;
	@FindBy(locator = "registration.lbl.errmsgonstore")
	private QAFWebElement lblErrmsgonstore;
	@FindBy(locator = "registration.lbl.errmsg")
	private QAFWebElement lblErrmsg;	
	@FindBy(locator = "registration.lbl.errmsgonturnstore")
	private QAFWebElement lblErrmsgonturnstore;	
	@FindBy(locator = "registeration.lbl.invalidemailmsg")
	private QAFWebElement LblInvalidmailmsg;

	@FindBy(locator = "registration.Whatsnewpage1.txt")
	private QAFWebElement Whatsnewpage1;
	
///////Whats new (2.0) section 
	@FindBy(locator = "registration.Whatsnewpage2.txt")
	private QAFWebElement Whatsnewpage2;
	@FindBy(locator = "registration.Whatsnewpage3.txt")
	private QAFWebElement Whatsnewpage3;
	@FindBy(locator = "registration.Whatsnewpage4.txt")
	private QAFWebElement Whatsnewpage4;
	
	@FindBy(locator = "registration.Whatsnewpage4.startshopping.lnk")
	private QAFWebElement startshoppinglnk;

	
	private RegistrationBean registrationBean = new RegistrationBean();

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public RegistrationBean getRegistrationBean() {
		return registrationBean;
	}

	public QAFWebElement getRegistrationTxtEmail() {
		return registrationTxtEmail;
	}

	public QAFWebElement getRegistrationTxtPassword() {
		return registrationTxtPassword;
	}

	public QAFWebElement getImgShowPwd() {
		return ImgShowpwd;
	}
	
	public QAFWebElement getImgHidePwd() {
		return ImgHidepwd;
	}

	public QAFWebElement getRegistrationTxtFirstname() {
		return registrationTxtFirstname;
	}

	public QAFWebElement getRegistrationTxtLastname() {
		return registrationTxtLastname;
	}

	public QAFWebElement getRegistrationChkIagree() {
		return registrationChkIagree;
	}

	public QAFWebElement getRegistrationBtnSubmit() {
		return registrationBtnSubmit;
	}

	public QAFWebElement getLblErrmsgonpwd() {
		return lblErrmsgonpwd;
	}

	public QAFWebElement getLblErrmsgonstore() {
		return lblErrmsgonstore;
	}

	public QAFWebElement getLblErrmsg() {
		return lblErrmsg;
	}
	
	public QAFWebElement getLblErrmsgonturnstore() {
		return lblErrmsgonturnstore;
	}	
	
	public QAFWebElement getLnkSkipandcontinueasguest() {
		return lnkSkipandcontinueasguest;
	}

	
	public QAFWebElement getLblPickstore() {
		return lblPickstore;
	}

	public QAFWebElement getTxtPwdafterentrd() {
		return txtPwdafterentrd;
	}
	
	public QAFWebElement getBtnSkipfornow() {
		return btnSkipfornow;
	}

	public QAFWebElement getLblInvalidmailmsg() {
		return LblInvalidmailmsg;
	}
	
	public QAFWebElement getRegistrationBtnSelectStore() {
		return registrationBtnSelectStore;
	}

	public QAFWebElement getPickStoreDescription() {
		return pickStoreDescription;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getLblTipfirstname() {
		return lblTipfirstname;
	}

	public QAFWebElement getLblTiplastname() {
		return lblTiplastname;
	}

	public QAFWebElement getLblTipemail() {
		return lblTipemail;
	}

	public QAFWebElement getLblTippassword() {
		return lblTippassword;
	}
	
	public QAFWebElement getTxtPagetitle() {
		return registrationTxtPagetitle;
	}
	public QAFWebElement getWhatsnewpage1() {
		return Whatsnewpage1;
	}

	public QAFWebElement getWhatsnewpage2() {
		return Whatsnewpage2;
	}

	public QAFWebElement getWhatsnewpage3() {
		return Whatsnewpage3;
	}

	public QAFWebElement getWhatsnewpage4() {
		return Whatsnewpage4;
	}
	public QAFWebElement getStartshoppinglnk() {
		return startshoppinglnk;
}

}
