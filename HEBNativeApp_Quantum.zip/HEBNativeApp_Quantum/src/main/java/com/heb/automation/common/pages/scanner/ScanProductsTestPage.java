package com.heb.automation.common.pages.scanner;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ScanProductsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "scanpdts.lbl.pagetitle")
	private QAFWebElement lblPagetitle;
	@FindBy(locator = "scanpdts.lbl.scandescription")
	private QAFWebElement lblScandescription;
	@FindBy(locator = "scanpdts.lbl.multiscanswitch")
	private QAFWebElement lblMultiscanswitch;
	@FindBy(locator = "scanpdts.btn.back")
	private QAFWebElement btnBack;

	@FindBy(locator = "scanpdts.btn.cancel")
	private QAFWebElement btnCancel;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getLblScandescription() {
		return lblScandescription;
	}

	public QAFWebElement getLblMultiscanswitch() {
		return lblMultiscanswitch;
	}

	public QAFWebElement getBtnBack() {
		return btnBack;
	}

	public QAFWebElement getBtnCancel() {
		return btnCancel;
	}
}
