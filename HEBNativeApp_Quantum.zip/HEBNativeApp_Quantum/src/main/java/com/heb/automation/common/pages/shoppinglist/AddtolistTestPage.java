package com.heb.automation.common.pages.shoppinglist;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AddtolistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "addtolist.btn.add")
	private QAFWebElement addtolistBtnAdd;
	@FindBy(locator = "addtolist.btn.cancel")
	private QAFWebElement addtolistBtnCancel;
	@FindBy(locator = "addtolist.lbl.listname")
	private QAFWebElement addtolistListname;
	@FindBy(locator = "addtolist.lbl.choosenlist")
	private QAFWebElement addtolistChoosenlist;
	@FindBy(locator = "addtolist.done")
	private QAFWebElement addtolistDone;
	@FindBy(locator = "addtolist.selectpickerwheel")
	private QAFWebElement addtolistSelectpickerwheel;
	@FindBy(locator = "addtolist.btn.addtolist")
	private QAFWebElement AddtoList;
	@FindBy(locator = "addtolist.icon.plus")
	private QAFWebElement addtolistIconPlus;
	@FindBy(locator = "addtolist.lbl.listnameslist")
	private List<QAFWebElement> lblListnameslist;
	
	@FindBy(locator = "addtolist.lbl.weeklygroceries")
	private QAFWebElement lblWeeklygroceries;
	@FindBy(locator = "addtolist.lbl.weeklygrocerieslist")
	private List<QAFWebElement> lblWeeklygrocerieslist;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getAddtolistBtnAdd() {
		return addtolistBtnAdd;
	}

	public QAFWebElement getAddtolistBtnCancel() {
		return addtolistBtnCancel;
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("addtolist.lbl.listname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getAddtolistListname() {
		return addtolistListname;
	}

	public QAFWebElement getAddtolistChoosenlist() {
		return addtolistChoosenlist;
	}

	public QAFWebElement getAddtolistDone() {
		return addtolistDone;
	}

	public QAFWebElement getAddtolistSelectpickerwheel() {
		return addtolistSelectpickerwheel;
	}

	public QAFWebElement getAddtoList() {
		return AddtoList;
	}

	public QAFWebElement getAddtolistIconPlus() {
		return addtolistIconPlus;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<QAFWebElement> getLblListnameslist() {
		return lblListnameslist;
	}
	
	public QAFWebElement getLblWeeklygroceries() {
		return lblWeeklygroceries;
	}

	public List<QAFWebElement> getLblWeeklygrocerieslist() {
		return lblWeeklygrocerieslist;
	}
}
