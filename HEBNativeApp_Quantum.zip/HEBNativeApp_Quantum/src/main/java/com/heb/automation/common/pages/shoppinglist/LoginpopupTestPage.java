package com.heb.automation.common.pages.shoppinglist;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LoginpopupTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "loginpopup.txt.alerttitle")
	private QAFWebElement loginpopupTxtAlerttitle;
	@FindBy(locator = "loginpopup.txt.email")
	private QAFWebElement loginpopupTxtfldEmail;
	@FindBy(locator = "loginpopup.txt.password")
	private QAFWebElement loginpopupTxtfldPassword;
	@FindBy(locator = "loginpopup.btn.cancel")
	private QAFWebElement loginpopupBtnCancel;
	@FindBy(locator = "loginpopup.btn.login")
	private QAFWebElement loginpopupBtnLogin;
	@FindBy(locator = "loginpopup.lbl.text")
	private QAFWebElement loginpopupLblLoginmsg;
	@FindBy(locator = "loginpopup.lnk.forgotpassword")
	private QAFWebElement loginpopupLblForgetpwd;
	@FindBy(locator = "loginpopup.btn.overlaylogin")
	private QAFWebElement loginpopupBtnOverlaylogin;
	@FindBy(locator = "loginpopup.btn.submit")
	private QAFWebElement loginpopupBtnSubmit;
	@FindBy(locator = "login.btn.ok")
	private QAFWebElement loginpopupBtnOk;
	@FindBy(locator = "loginLblPopuptitle")
	private QAFWebElement loginLblPopuptitle;
	@FindBy(locator = "login.lbl.popmsg")
	private QAFWebElement loginLblPopmsg;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLoginpopupTxtAlerttitle() {
		return loginpopupTxtAlerttitle;
	}

	public QAFWebElement getLoginpopupTxtfldEmail() {
		return loginpopupTxtfldEmail;
	}

	public QAFWebElement getLoginpopupTxtfldPassword() {
		return loginpopupTxtfldPassword;
	}

	public QAFWebElement getLoginpopupBtnCancel() {
		return loginpopupBtnCancel;
	}

	public QAFWebElement getLoginpopupBtnLogin() {
		return loginpopupBtnLogin;
	}

	public QAFWebElement getLoginpopupLblLoginmsg() {
		return loginpopupLblLoginmsg;
	}

	public QAFWebElement getLoginpopupLblForgetpwd() {
		return loginpopupLblForgetpwd;
	}

	public QAFWebElement getLoginpopupBtnOverlaylogin() {
		return loginpopupBtnOverlaylogin;
	}

	public QAFWebElement getLoginpopupBtnSubmit() {
		return loginpopupBtnSubmit;
	}

	public QAFWebElement getLoginpopupBtnOk() {
		return loginpopupBtnOk;
	}

	public QAFWebElement getLoginLblPopuptitle() {
		return loginLblPopuptitle;
	}

	public QAFWebElement getLoginLblPopmsg() {
		return loginLblPopmsg;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
