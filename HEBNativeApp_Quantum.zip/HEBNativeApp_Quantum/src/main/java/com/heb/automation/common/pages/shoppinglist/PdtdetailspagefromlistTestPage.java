package com.heb.automation.common.pages.shoppinglist;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PdtdetailspagefromlistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "productdetails.txt.pagetitle")
	private QAFWebElement productdetailsTxtPagetitle;
	@FindBy(locator = "productdetails.btn.done")
	private QAFWebElement productdetailsBtnDone;
	@FindBy(locator = "productdetails.txt.productname")
	private QAFWebElement productdetailsTxtProductname;
	@FindBy(locator = "productdetails.txt.productquantity")
	private QAFWebElement productdetailsTxtProductquantity;
	@FindBy(locator = "productdetails.edt.notes")
	private QAFWebElement productdetailsEdtNotes;
	@FindBy(locator = "productdetails.img.product")
	private QAFWebElement productdetailsImgProduct;
	@FindBy(locator = "productdetails.txt.setquantity")
	private QAFWebElement productdetailsTxtSetquantity;
	@FindBy(locator = "productdetails.txt.quantity")
	private QAFWebElement productdetailsTxtQuantity;
	@FindBy(locator = "productdetails.btn.save")
	private QAFWebElement productdetailsBtnSave;
	@FindBy(locator = "productdetails.btn.cancel")
	private QAFWebElement productdetailsBtnCancel;
	@FindBy(locator = "productdetails.lbl.moredetails")
	private QAFWebElement productdetailsLblMoredetails;
	/*@FindBy(locator = "productdetails.btn.addtocart")
	private QAFWebElement productdetailsBtnAddtocart;*/

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getProductdetailsTxtPagetitle() {
		return productdetailsTxtPagetitle;
	}

	public QAFWebElement getProductdetailsBtnDone() {
		return productdetailsBtnDone;
	}

	public QAFWebElement getProductdetailsTxtProductname() {
		return productdetailsTxtProductname;
	}

	public QAFWebElement getProductdetailsTxtProductquantity() {
		return productdetailsTxtProductquantity;
	}

	public QAFWebElement getProductdetailsEdtNotes() {
		return productdetailsEdtNotes;
	}

	public QAFWebElement getProductdetailsImgProduct() {
		return productdetailsImgProduct;
	}

	public QAFWebElement getProductdetailsTxtSetquantity() {
		return productdetailsTxtSetquantity;
	}

	public QAFWebElement getProductdetailsTxtQuantity() {
		return productdetailsTxtQuantity;
	}

	public QAFWebElement getProductdetailsBtnSave() {
		return productdetailsBtnSave;
	}

	public QAFWebElement getProductdetailsBtnCancel() {
		return productdetailsBtnCancel;
	}

	public QAFWebElement getProductdetailsLblMoredetails() {
		return productdetailsLblMoredetails;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}
}
