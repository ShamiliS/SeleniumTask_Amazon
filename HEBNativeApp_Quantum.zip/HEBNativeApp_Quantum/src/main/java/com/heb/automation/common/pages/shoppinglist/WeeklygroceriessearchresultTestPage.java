package com.heb.automation.common.pages.shoppinglist;

import java.util.List;

import com.heb.automation.common.components.ShoppinglistSearchResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklygroceriessearchresultTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "wgsr.lbl.searchsrctext")
	private QAFWebElement wgLblSearchsrctext;
	@FindBy(locator = "wgsr.list.searchlist")
	private List<ShoppinglistSearchResult> wgListSearchlist;
	@FindBy(locator = "wgsr.lbl.searchresult.itemname")
	private QAFWebElement wgLblSearchresultItemname;
	@FindBy(locator = "wgsr.lbl.searchresult.itemimage")
	private QAFWebElement wgLblSearchresultItemimage;
	@FindBy(locator = "wgsr.btn.searchresult.scan")
	private QAFWebElement wgBtnSearchresultScan;
	@FindBy(locator = "wgsr.lbl.searchresult.itemcount")
	private QAFWebElement wgLblSearchresultItemcount;
	@FindBy(locator = "wgsr.lbl.searchresult.checkofcount")
	private QAFWebElement wgLblSearchresultCheckofcount;
	@FindBy(locator = "wgsr.btn.searchresult.scanimage")
	private QAFWebElement wgBtnSearchresultScanimage;
	@FindBy(locator = "wgsr.txt.searchresult.scanname")
	private QAFWebElement wgTxtSearchresultScanname;
	@FindBy(locator = "wgsr.btn.searchresult.cancel")
	private QAFWebElement wgBtnSearchresultCancel;
	@FindBy(locator = "wgsr.lbl.searchresult.itemname")
	private List<QAFWebElement> wgLblSearchresultItemnameListQAF;
	@FindBy(locator = "wgsr.btn.searchresult.scanhotuser")
	private QAFWebElement wgBtnSearchresultScanhotuser;
	@FindBy(locator = "wgsr.list.searchlistname")
	private List<QAFWebElement> ListSearchListName;
	@FindBy(locator = "wgsr.list.searchlist")
	private QAFWebElement wgLblSpecificitemname;
	@FindBy(locator = "wgsr.list.specificitemname")
	private List<QAFWebElement> wgListSpecificitemname;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getWgLblSearchsrctext() {
		return wgLblSearchsrctext;
	}

	public List<ShoppinglistSearchResult> getWgListSearchlist() {
		return wgListSearchlist;
	}

	public QAFWebElement getWgLblSearchresultItemname() {
		return wgLblSearchresultItemname;
	}

	public QAFWebElement getWgLblSearchresultItemimage() {
		return wgLblSearchresultItemimage;
	}

	public QAFWebElement getWgBtnSearchresultScan() {
		return wgBtnSearchresultScan;
	}

	public QAFWebElement getWgLblSearchresultItemcount() {
		return wgLblSearchresultItemcount;
	}

	public QAFWebElement getWgLblSearchresultCheckofcount() {
		return wgLblSearchresultCheckofcount;
	}

	public QAFWebElement getWgBtnSearchresultScanimage() {
		return wgBtnSearchresultScanimage;
	}

	public QAFWebElement getWgTxtSearchresultScanname() {
		return wgTxtSearchresultScanname;
	}

	public QAFWebElement getWgBtnSearchresultCancel() {
		return wgBtnSearchresultCancel;
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListItemEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("wgsr.txt.itemname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListItemnameEntryByLable(int lable) {
		String loc = String.format(pageProps.getString("wgsr.lbl.searchresult.itemname"), lable);
		return new QAFExtendedWebElement(loc);
	}

	// DYNAMIC value declaring
	public QAFWebElement getShopingListItemChkBoxEntryByLable(String lable) {
		String loc = String.format(pageProps.getString("wgsr.chk.chkBoxWithRespecToItem"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public List<QAFWebElement> getWgLblSearchresultItemnameListQAF() {
		return wgLblSearchresultItemnameListQAF;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getWgBtnSearchresultScanhotuser() {
		return wgBtnSearchresultScanhotuser;
	}

	public List<QAFWebElement> getListSearchListName() {
		return ListSearchListName;
	}

	public QAFWebElement getWgLblSpecificitemname() {
		return wgLblSpecificitemname;
	}

	public List<QAFWebElement> getWgListSpecificitemname() {
		return wgListSpecificitemname;
	}

}
