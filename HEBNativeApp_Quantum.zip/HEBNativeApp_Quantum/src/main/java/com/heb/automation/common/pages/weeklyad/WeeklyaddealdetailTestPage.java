package com.heb.automation.common.pages.weeklyad;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyaddealdetailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "weeklyaddetail.img.productimage")
	private QAFWebElement weeklyaddetailProductimage;
	@FindBy(locator = "weeklyaddetail.lbl.productexpdetail")
	private QAFWebElement weeklyadProductexpdetail;
	@FindBy(locator = "weeklyaddetail.lbl.productdetailpagename")
	private QAFWebElement weeklyadProductdetailpagename;
	/*@FindBy(locator = "weeklyaddetail.btn.addtocart")
	private QAFWebElement AddtoList;*/
	@FindBy(locator = "weeklyaddetail.btn.addtolist")
	private QAFWebElement weeklyaddetailBtnAddtolist;
	private QAFWebElement weeklyaddetailProductexpdetail;
	@FindBy(locator = "weeklyaddetail.img.productaddicon")
	private QAFWebElement weeklyaddetailProductaddicon;
	@FindBy(locator = "weeklyaddetail.lbl.productname")
	private QAFWebElement weeklyaddetailProductname;
	@FindBy(locator = "weeklyaddetail.btn.addtolist")
	private QAFWebElement btnAddtolist;
	
	@FindBy(locator = "weeklyaddetail.lbl.shoppinglisterrortitle")
	private QAFWebElement lblShoppinglisterrortitle;
	@FindBy(locator = "weeklyaddetail.lbl.shoppinglisterrormsg")
	private QAFWebElement lblShoppinglisterrormsg;
	@FindBy(locator = "weeklyaddetail.btn.shoppinglisterrorok")
	private QAFWebElement btnShoppinglisterrorok;
	@FindBy(locator = "weeklyaddetail.lbl.offervalid")
	private QAFWebElement lblOffervalid;
	@FindBy(locator = "weeklyaddetail.lbl.pdtprice")
	private QAFWebElement lblPdtprice;
	
	@FindBy(locator = "weeklyaddetail.img.searchicon")
	private QAFWebElement imgSearchicon;
	@FindBy(locator = "weeklyaddetail.txt.searchfield")
	private QAFWebElement txtSearchfield;
	@FindBy(locator = "weeklyaddetail.img.back")
	private QAFWebElement imgBack;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getWeeklyaddetailProductimage() {
		return weeklyaddetailProductimage;
	}

	public QAFWebElement getWeeklyaddetailProductexpdetail() {
		return weeklyaddetailProductexpdetail;
	}

	public QAFWebElement getWeeklyaddetailProductaddicon() {
		return weeklyaddetailProductaddicon;
	}

	public QAFWebElement getWeeklyaddetailProductname() {
		return weeklyaddetailProductname;
	}

	public QAFWebElement getWeeklyaddetailBtnAddtolist() {
		return weeklyaddetailBtnAddtolist;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public QAFWebElement getBtnAddtolist() {
		return btnAddtolist;
	}

	public QAFWebElement getLblShoppinglisterrortitle() {
		return lblShoppinglisterrortitle;
	}

	public QAFWebElement getLblShoppinglisterrormsg() {
		return lblShoppinglisterrormsg;
	}

	public QAFWebElement getBtnShoppinglisterrorok() {
		return btnShoppinglisterrorok;
	}
	
	public QAFWebElement getLblOffervalid() {
		return lblOffervalid;
	}

	public QAFWebElement getLblPdtprice() {
		return lblPdtprice;
	}

	public QAFWebElement getImgSearchicon() {
		return imgSearchicon;
	}

	public QAFWebElement getTxtSearchfield() {
		return txtSearchfield;
	}
	
	public QAFWebElement getImgBack() {
		return imgBack;
	}
}
