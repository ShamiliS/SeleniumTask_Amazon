package com.heb.automation.common.pages.weeklyad;

import java.util.List;

import com.heb.automation.common.components.WeeklyadResult;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyadsresultlistTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "weeklyadresult.searchresult")
	private List<WeeklyadResult> weeklyadSearchresult;
	@FindBy(locator = "weeklyadresult.checkbox.selectdeal")
	private List<QAFWebElement> weeklyadCheckboxSelectdeal1;
	@FindBy(locator = "weeklyadresult.searchresult")
	private WeeklyadResult Loadweeklyadresult;
	@FindBy(locator = "weeklyadresult.lbl.dealnamelist")
	private List<WeeklyadResult> weeklyadLstDealname;

	@FindBy(locator = "weeklyadresult.img.itemimage")
	private WeeklyadResult ImgItemimage;
	
	@FindBy(locator = "weeklyadresult.img.dividerimage")
	private WeeklyadResult ImgDividerimage;
	@FindBy(locator = "weeklyadresult.lbl.producttitle")
	private WeeklyadResult LblProducttitle;
	@FindBy(locator = "weeklyadresult.lbl.productprice")
	private WeeklyadResult LblProductprice;
	@FindBy(locator = "weeklyadresult.lbl.expirydate")
	private WeeklyadResult LblExpirydate;
	@FindBy(locator = "weeklyadresult.lbl.pgtitleitemdetail")
	private WeeklyadResult LblPgtitleitemdetail;
	@FindBy(locator = "weeklyadresult.lbl.offervalid")
	private WeeklyadResult LblOffervalid;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public List<WeeklyadResult> getWeeklyadSearchresult() {
		return weeklyadSearchresult;
	}

	public List<QAFWebElement> getWeeklyadCheckboxSelectdeal1() {
		return weeklyadCheckboxSelectdeal1;
	}

	public WeeklyadResult getLoadweeklyadresult() {
		return Loadweeklyadresult;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	public List<WeeklyadResult> getWeeklyadLstDealname() {
		return weeklyadLstDealname;
	}

	// DYNAMIC value declaring
	public QAFWebElement getWeeklyAddChkBoxWithRespectToName(String lable) {
		String loc = String.format(pageProps.getString("weeklyadresult.chk.selectdealwithrestoname"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public WeeklyadResult getImgItemimage() {
		return ImgItemimage;
	}

	public WeeklyadResult getImgDividerimage() {
		return ImgDividerimage;
	}

	public WeeklyadResult getLblProducttitle() {
		return LblProducttitle;
	}

	public WeeklyadResult getLblProductprice() {
		return LblProductprice;
	}

	public WeeklyadResult getLblExpirydate() {
		return LblExpirydate;
	}

	public WeeklyadResult getLblPgtitleitemdetail() {
		return LblPgtitleitemdetail;
	}
	public WeeklyadResult getLblOffervalid() {
		return LblOffervalid;
	}

}
