/**
 * 
 */
package com.heb.automation.common.steps;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.pharmacy.PharmacyTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common CommonStep

	I navigate back to homepage
	I click register button from Login Splash page
	I verify pharmacy page
	I click on donations
	Validate dialog box on HomePage
	I click on OK
	I click on Cancel
	Verify donations page opens in the mobile web browse*/

public class CommonSteps {

	/**
	 * Navigate back to home page
	 */
	@QAFTestStep(description = "I navigate back to homepage")
	public void iNavigateToHomepageUsingBackButton() {

		PerfectoUtils.getAppiumDriver().navigate().back();
	}

	/**
	 * Wait and Click Register button
	 */
	@QAFTestStep(description = "I click register button from Login Splash page")
	public void iClickRegisterButtonFromLoginSplashPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginBtnRegister().waitForPresent(5000);
		loginsplash.getLoginBtnRegister().click();
		PerfectoUtils.reportMessage("Clicked register button from Login Splash page", MessageTypes.Info);
	}

	/**
	 * Validate the ErrMessage is displayed using Perfecto command
	 * 
	 * @param ErrMessage
	 *            String which needs to be verified as displayed or not
	 */
	public static void validattextinpage(String ErrMessage) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		Map<String, Object> params1 = new HashMap<>();
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.MINUTES);
		params1.put("content", ErrMessage);
		String isBtnPlayVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnPlayVisible.equals("false")) {
			PerfectoUtils.reportMessage("The expected text " + ErrMessage + " is not displayed", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("The expected text " + ErrMessage + " is displayed as expected", MessageTypes.Pass);
		}
	}

	/**
	 * Validate the ErrMessage is displayed using Perfecto command
	 * 
	 * @param ErrMessage
	 *            String which needs to be verified as displayed or not
	 */
	public static void validatExploreText(String ErrMessage) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		Map<String, Object> params1 = new HashMap<>();
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.MINUTES);
		params1.put("content", ErrMessage);
		String isBtnPlayVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnPlayVisible.equals("false")) {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage + " is not displayed", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage + " is displayed as expected", MessageTypes.Pass);
			CommonSteps.clickTextWithPerfectoCmd("Explore My");
		}
	}

	public static void clickTextWithPerfectoCmd(String ErrMessage) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		Map<String, Object> params1 = new HashMap<>();
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(30, TimeUnit.MINUTES);
		params1.put("content", ErrMessage);
		String isBtnPlayVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:select",
				params1);
	}

	/**
	 * Validate the ErrMessage or element is displayed using Perfecto command
	 * 
	 * @param ErrMessage
	 *            String which needs to be verified as displayed or not
	 * @param element
	 *            QAFWebElement which needs to be verified as displayed or not
	 */
	public static void validaterrormessages(String ErrMessage, QAFWebElement element) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", ErrMessage);
		String isErrorMessageVisible = (String) register.getTestBase().getDriver()
				.executeScript("mobile:checkpoint:text", params1);

		if (!isErrorMessageVisible.equals("false")) {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage + " is displayed as expected", MessageTypes.Pass);
		} else if (element.isPresent()) {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage + " is displayed as expected,element present",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage + " is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Verify pharmacy page
	 */
	@QAFTestStep(description = "I verify pharmacy page")
	public void verifyPharmacyPage() {
		PharmacyTestPage pharmacyPage = new PharmacyTestPage();
		HomeTestPage homePage = new HomeTestPage();

		homePage.getImgHomeHero().waitForNotVisible(5000);
		pharmacyPage.getPharmacyLblPagetitle().waitForPresent(5000);

		if (pharmacyPage.getPharmacyLblPagetitle().isPresent())
			PerfectoUtils.reportMessage("Pharmacy page is loaded..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Pharmacy page is not loaded..", MessageTypes.Fail);

	}
		
	/**
	 * Clicking on donations Label
	 */
	@QAFTestStep(description = "I click on donations")
	public void iClickOnDonations() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeLblDonations().click();
	}

	/**
	 * Dialog box appear when clicking on donations
	 */
	@QAFTestStep(description = "Validate dialog box on HomePage")
	public static void validateDialogBoxOnHomePage() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeTxtDonationAlertTitle().waitForPresent(50000);
		homePage.getHomeTxtDonationAlertTitle().verifyPresent();
		String alertMessage = homePage.getHomeTxtDonationAlertMessage().getText();
		
		if(alertMessage.equals("You’re now leaving the H-E-B app to visit H-E-B’s website at heb.com."))
			PerfectoUtils.reportMessage("Dialog box Appears with "+alertMessage, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Dialog box not Appears with "+alertMessage, MessageTypes.Fail);
		
		homePage.getHomeBtnDonationAlertCancel().verifyPresent();
		homePage.getHomeBtnDonationAlertOk().verifyPresent();
	}

	/**
	 * Clicking on OK from Dialog Box
	 */
	@QAFTestStep(description = "I click on OK")
	public static void iClickOnOK() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeBtnDonationAlertOk().waitForPresent(50000);
		homePage.getHomeBtnDonationAlertOk().click();
	}
	
	/**
	 * Clicking on Cancel from Dialog Box
	 */
	@QAFTestStep(description = "I click on Cancel")
	public void iClickOnCancel() {
		HomeTestPage homePage = new HomeTestPage();

		homePage.getHomeBtnDonationAlertCancel().waitForPresent(50000);
		homePage.getHomeBtnDonationAlertCancel().click();
	}
	
	/**
	 * Verify HEB site is opening in Mobile browser
	 */
	@QAFTestStep(description = "Verify donations page opens in the mobile web browse")
	public static void verifyDonationsPageOpensInTheMobileWebBrowse() {
		HomeTestPage homePage = new HomeTestPage();
		
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "GROUP:\\Android\\cert\\HEB_Logo.png");
		params1.put("threshold", "20");
		params1.put("duration", "20");
		params1.put("interval", "4"); 
		String result1 = (String) homePage.getTestBase().getDriver().executeScript("mobile:image:find", params1);
		
		System.out.println(result1);
		
		if(result1.equalsIgnoreCase("true"))
			PerfectoUtils.reportMessage("HEB site is opened in MobileBrowser", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("HEB site is not opened in MobileBrowser", MessageTypes.Fail);
	}	
	
	@QAFTestStep(description = "I click on hero Image")
	public void iClickOnHeroImage() {
		HomeTestPage homePage = new HomeTestPage();
		
		homePage.getImgHomeHero().verifyPresent();
		homePage.getImgHomeHero().click();
		homePage.waitForPageToLoad();
	}
	
}

