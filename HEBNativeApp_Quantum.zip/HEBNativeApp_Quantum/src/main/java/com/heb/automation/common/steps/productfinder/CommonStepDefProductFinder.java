/**
 * 
 */
package com.heb.automation.common.steps.productfinder;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.StoreDetailModel;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsearchresultTestPage;
import com.heb.automation.common.pages.products.ProductsresultlistTestPage;
import com.heb.automation.common.pages.products.ProductstoredetailsmodalTestPage;
import com.heb.automation.common.pages.products.RefineTestPage;
import com.heb.automation.common.pages.shoppinglist.AddtolistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriessearchresultTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.products.IOSStepdefproducts;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Common ProductFinder

	I click on Refine button in Search result page
	I navigate to Refine Page
	I navigate back to Products page
	I select the product
	I see previously viewed page
	I select Nutrition Fact
	I see Nutrition Facts page is displayed with nutritional facts panel
	I navigate Supplement Facts
	I validate the product finder page
	I select a category from mid of the page
	I navigate Safety and Regulatory
	I navigate to ratings tab
	I should see the CDP Page
	I verify the Guarantee promise field in PDP
	I should see the Search Results page of products
	I select Specifications from Description page
	I verify the user navigated to Specifications page
	I verify the Product description is available in Description page
	I select Find in Near Store option
	I validate shiptohome in aisle
	I verify the Store Detail modal
	I click back from the store detail modal
	I close the store detail modal
	I scroll and check screen get scrolled
	I verify the product location information
	I verify the Get direction
	I verify the Call option
	I verify weekly ad option is not present
	I verify change store option is not present
	I navigate to store result list modal
	I select a store with product location
	I click on view nearby store
	I verify the nearby store list modal is displayed
	I verify that {0} closest stores will be display in neraby stores modal
	I verify the coupons section
	I click on the store name
	I should see PDP page
	I should see store result list modal
	I click on the X or close button
	I verify the product name displayed below the nearby store header
	I verify that maximum of {0} stores is getting displayed in the store modal
	I verify the error message and try again option for the Store availability module
	I verify that user still remains on the PDP page
	I verify the error message if product is not available in any nearby stores
	I navigate to PDP page by searching the product {0}
	I select a store
	I verify the Store feature is getting displayed
	I navigate to Store feature page
	Verify Store Name,Address,Aisle Number and distance to the store in the store modal
	I set the {0} location
	I verify that section is reloaded after clicking try again button
	I verify that store availability section is below View All Coupons module
	navigate to Product Information Disclaimer page
	Select Cancel option from Add to list popup
	Verify the add to list popup has been closed
*/

public class CommonStepDefProductFinder {

	/**
	 * Wait for Refine button in product search result page and click it
	 */
	@QAFTestStep(description = "I click on Refine button in Search result page")
	public void iClickOnRefineButtonInSearchResultPage() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();

		try {
			productsearchresult.getProdsearchresultTxtFiltericon().verifyPresent();
			productsearchresult.getProdsearchresultTxtFiltericon().click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Wait for Refine page to be loaded and Verify the Page title
	 */
	@QAFTestStep(description = "I navigate to Refine Page")
	public void iNavigateToRefinePage() {
		RefineTestPage refinepage = new RefineTestPage();
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();

		try {
			refinepage.getRefineTxtPagetitle().waitForPresent(5000);
			refinepage.getRefineTxtPagetitle().verifyPresent();
		} catch (Exception e) {
			productsearchresult.getProdsearchresultTxtFiltericon().waitForPresent(3000);
			productsearchresult.getProdsearchresultTxtFiltericon().click();

			refinepage.getRefineTxtPagetitle().verifyPresent();
		}

	}

	/**
	 * Navigate back and verify the Product page name is displayed as "Products"
	 */
	@QAFTestStep(description = "I navigate back to Products page")
	public void userIsNavigatedToProductsPage() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		PerfectoUtils.getAppiumDriver().navigate().back();

		// Verify Page title as "Products"
		productlanding.getProductsLblPagename().waitForPresent(5000);
		productlanding.getProductsLblPagename().verifyText("Products");
	}

	/**
	 * Click on first product
	 */
	@QAFTestStep(description = "I select the product")
	public void iSelectTheProduct() {
		ProductsearchresultTestPage productsearch = new ProductsearchresultTestPage();
		ProductsresultlistTestPage productsresult = new ProductsresultlistTestPage();
		// Clicking on product row
		productsresult.getProductresultLblProductnameList().get(0).click();
	}

	/**
	 * Check if PDP description page is displayed else PDP page is displayed and
	 * Report accordingly
	 */
	@QAFTestStep(description = "I see previously viewed page")
	public void iSeeDescriptionPage() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		if (productdetail.getPdpLblDescriptionPgTitle().isPresent()) {
			PerfectoUtils.reportMessage("Description page is visible:", MessageTypes.Info);
		} else if (productdetail.getPdpTxtPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Item detail page is visible:", MessageTypes.Info);
		}
	}

	/**
	 * Scroll till Nutrition facts and Click on it
	 */
	@QAFTestStep(description = "I select Nutrition Fact")
	public void iSelectNutritionFact() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		// Click Nutrition facts
		IOSStepdef.scrollToFacts("Nutrition Facts", 90, 80, 2);
		productdetail.getPdpLblNutritionalfacts().waitForPresent(30000);
		productdetail.getPdpLblNutritionalfacts().click();
		PerfectoUtils.reportMessage("Clicked: Nutrtion facts", MessageTypes.Info);
	}

	/**
	 * Verify whether the Nutrition facts page is displayed
	 */
	@QAFTestStep(description = "I see Nutrition Facts page is displayed with nutritional facts panel")
	public void iSeeNutritionFactsPageIsDisplayedWithNutritionalFactsPanel() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		productdetail.waitForPageToLoad();
		productdetail.getPdpLblNutritionalfacts().waitForPresent(5000);

		if (productdetail.getPdpLblNutritionalfacts().verifyPresent()) {
			PerfectoUtils.reportMessage("Nutrition facts page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Nutrition facts page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Scroll till Supplement facts and click on it and verify Supplement Fact
	 * page is displayed
	 */
	@QAFTestStep(description = "I navigate Supplement Facts")
	public void iNavigateSupplementFacts() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		productdetail.waitForPageToLoad();
		try {
			if (productdetail.getLblSupplementfact().isPresent()) {
				IOSStepdef.scrollToFacts("Supplement Facts", 90, 80, 2);
				PerfectoUtils.verticalswipe();
				productdetail.getLblSupplementfact().click();
			} else {
				IOSStepdef.scrollToFacts("Supplement Facts", 90, 80, 2);
				PerfectoUtils.verticalswipe();
				productdetail.getLblSupplementfact().verifyPresent();
				productdetail.getLblSupplementfact().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		productdetail.getLblSupplementfact().waitForPresent(5000);
		productdetail.getLblSupplementfact().verifyPresent();
	}

	/**
	 * Verify whether the Products page is displayed
	 */
	@QAFTestStep(description = "I validate the product finder page")
	public void iValidateTheProductFinderPage() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		productlanding.waitForPageToLoad();
		if (productlanding.getProductsLblPagename().isPresent()) {
			PerfectoUtils.reportMessage("Able to see Product finder page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see product finder page", MessageTypes.Fail);
		}
	}

	/**
	 * If Product category is present, then click on it
	 */
	@QAFTestStep(description = "I select a category from mid of the page")
	public void iSelectACategoryFromMidOfThePage() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		if (productlanding.getProductsCategoryname().isPresent()) {
			productlanding.getProductsCategoryname().click();
			productlanding.getProductsCategoryname().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Category is not present", MessageTypes.Info);
		}
	}

	/**
	 * Click on Product Description heading and Verify the Description page
	 * title, Safety and Regulatory tab. Click on Safety and Regulatory. Verify
	 * if Safety title is displayed. Navigate back to Description page and
	 * validate its title.
	 */
	@QAFTestStep(description = "I navigate Safety and Regulatory")
	public void iNavigateSafetyAndRegulatory() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		productdetail.waitForPageToLoad();
		try {
			if (productdetail.getLblPdtdescriptionheading().isPresent()) {
				productdetail.getLblPdtdescriptionheading().click();
			} else {
				PerfectoUtils.verticalswipe();
				productdetail.getLblPdtdescriptionheading().verifyPresent();
				productdetail.getLblPdtdescriptionheading().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		productdetail.getPdpLblDescriptionPgTitle().verifyPresent();
		PerfectoUtils.verticalswipe();
		productdetail.getPdpLblSafetyAndRegulatory().verifyPresent();
		productdetail.getPdpLblSafetyAndRegulatory().click();

		if (productdetail.getPdpLblSafetyTitle().isPresent()) {
			PerfectoUtils.reportMessage("Able to see Safety and Regulatory page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see Safety and Regulatory page", MessageTypes.Fail);
		}
		PerfectoUtils.androiddeviceback();

		if (productdetail.getPdpLblDescriptionPgTitle().isPresent()) {
			PerfectoUtils.androiddeviceback();
		}
	}

	/**
	 * If PDP ratings is present click n it or else swipe and click. Verify the
	 * Ratings label.
	 */
	@QAFTestStep(description = "I navigate to ratings tab")
	public void iNavigateToRatingsTab() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		try {
			if (productdetail.getPdpLblRatings().isPresent()) {
				productdetail.getPdpLblRatings().click();
			} else {
				PerfectoUtils.verticalswipe();
				productdetail.getPdpLblRatings().verifyPresent();
				productdetail.getPdpLblRatings().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		productdetail.getPdpLblRatings().waitForPresent(5000);
		productdetail.getPdpLblRatings().verifyPresent();
	}

	/**
	 * Check the products availability in In My Store tab, If there are no
	 * products available, Move to All Products tab and get the number of
	 * products displayed. Fail the step if there are no products.
	 */
	@QAFTestStep(description = "I should see the CDP Page")
	public void iShouldSeeTheCDPPage() {
		ProductsresultlistTestPage productsresultpage = new ProductsresultlistTestPage();

		try {
			int getcount = productsresultpage.getProductresultlist().size();
			if (getcount > 0) {
				PerfectoUtils.reportMessage("Product displayed successfully in CDP Page in In My Store", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Product is not displayed in In My Store", MessageTypes.Info);
				productsresultpage.getLblAllproducts().waitForPresent(3000);
				productsresultpage.getLblAllproducts().click();
				PerfectoUtils.reportMessage("Clicked All products tab..");
				int getcount2 = productsresultpage.getProductresultlist().size();
				if (getcount2 > 0) {
					PerfectoUtils.reportMessage("Product displayed successfully in CDP Page in all products tab", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Product is not displayed in CDP Page in all products tab", MessageTypes.Fail);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			productsresultpage.getLblAllproducts().waitForPresent(3000);
			productsresultpage.getLblAllproducts().click();
			int getcount2 = productsresultpage.getProductresultlist().size();
			if (getcount2 > 0) {
				PerfectoUtils.reportMessage("Product displayed successfully for the filtered option", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Product is not displayed for the filtered option", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Perform vertical swipe, verify Guarantee message is present or not
	 */
	@QAFTestStep(description = "I verify the Guarantee promise field in PDP")
	public void iVerifyTheGuaranteePromiseFieldInPDP() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.verticalswipe();

		if (productdetails.getPdpImgHebgurantee().isPresent()) {
			PerfectoUtils.reportMessage("Guarantee promise message is displayed as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Guarantee promise message is not available for the selected product.", MessageTypes.Info);
		}
	}

	/**
	 * Verify the search term is present in Search results page. Fail the step
	 * if it is not available
	 */
	@QAFTestStep(description = "I should see the Search Results page of products")
	public void iShouldSeeTheSearchResultsPageOfProducts() {
		WeeklygroceriessearchresultTestPage wgsearchresult = new WeeklygroceriessearchresultTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		wgsearchresult.waitForPageToLoad();
		// Validate relevant products are displayed
		String strValidProductname = getBundle().getString("products.productname");

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", strValidProductname);
			Object result1 = weeklygrocery.getTestBase().getDriver().executeScript("mobile:text:find", params1);
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is displayed in Result", MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Searched Product " + strValidProductname + " is not displayed in Result", MessageTypes.Fail);
		}

		weeklygrocery.getShopingListEntryByLable("Search Results").waitForPresent(3000);
		weeklygrocery.getShopingListEntryByLable("Search Results").verifyPresent();

	}

	/**
	 * Perform vertical swipe, If PDP specification is present, click it. Fail
	 * the step if it is not present.
	 */
	@QAFTestStep(description = "I select Specifications from Description page")
	public void iSelectSpecificationsFromDescriptionPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		productdetails.waitForPageToLoad();
		PerfectoUtils.verticalswipe();

		if (productdetails.getPdpLblSpecification().isPresent()) {
			productdetails.getPdpLblSpecification().waitForPresent(5000);
			productdetails.getPdpLblSpecification().verifyPresent();
			productdetails.getPdpLblSpecification().click();
			PerfectoUtils.reportMessage("Clicked on Specifications.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Specifications not found for the selected product!!", MessageTypes.Fail);
		}
	}

	/**
	 * Verify if Specifications title is present. Fail the step if it is not
	 * present.
	 */
	@QAFTestStep(description = "I verify the user navigated to Specifications page")
	public void iVerifyTheUserNavigatedToSpecificationsPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		if (productdetails.getLblSpecificationspagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Specifications page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Specifications page", MessageTypes.Fail);
		}
	}

	/**
	 * Verify the product description heading and content are present
	 */
	@QAFTestStep(description = "I verify the Product description is available in Description page")
	public void iVerifyTheProductDescriptionIsAvailableInDescriptionPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		productdetails.getLblPdtdescriptionheading().verifyPresent();
		productdetails.getLblPdtdescriptionparagraph().verifyPresent();
	}

	/**
	 * Swipe till Find in Near Store button and Click on it
	 */
	@QAFTestStep(description = "I select Find in Near Store option")
	public void iSelectFindInNearStoreOption() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		// Swiping if not visible in the screen
		if (!productdetail.getPdpBtnFindinnearbystore().isPresent()) {
			PerfectoUtils.verticalswipe(80, 75, 2);
		}
		PerfectoUtils.verticalswipe();
		// PerfectoUtils.swipeIfInBottom(productdetail.getPdpBtnFindinnearbystore());

		// Clicking on Find in nearby store
		productdetail.getPdpBtnFindinnearbystore().waitForPresent(3000);
		productdetail.getPdpBtnFindinnearbystore().click();
		PerfectoUtils.reportMessage("Clicked on View Nearby Stores..", MessageTypes.Pass);

	}

	/**
	 * Wait for not present of Ship to Home tab in Home page
	 */
	@QAFTestStep(description = "I validate shiptohome in aisle")
	public void iValidateShiptohomeInAisle() {
		HomeTestPage homepage = new HomeTestPage();

		homepage.waitForPageToLoad();
		homepage.getHomeLblShipToHome().waitForNotPresent(3000);
		PerfectoUtils.reportMessage("Ship To Home tab is not present as expected", MessageTypes.Pass);
	}

	/*
	 * Verify different sections page header, store name, mapview, get direction
	 * link, call link store feature link, pharmacy section in the store details
	 * modal
	 * 
	 * @param 'selectedStore'
	 */
	@QAFTestStep(description = "I verify the Store Detail modal")
	public void iVerifyTheStoreDetailModal() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		String storeName = ConfigurationManager.getBundle().getString("selectedStore");

		// Verify the page header
		storedetailsmodal.getStoremodalLblPageheader().waitForPresent(3000);
		storedetailsmodal.getStoremodalLblPageheader().verifyPresent();
		String displayStrName = storedetailsmodal.getStoremodalLblPageheader().getText();

		if (storeName.contains(displayStrName))
			PerfectoUtils.reportMessage("Selected store details page is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Selected store details page is not displayed..", MessageTypes.Fail);

		// Verify map section
		storedetailsmodal.getStoremodalLblMapview().verifyPresent();
		storedetailsmodal.getStoremodalLblLocation().verifyPresent();
		storedetailsmodal.getStoremodalLblMappin().verifyPresent();

		// Verify store details

		String displayStrNameDetails = storedetailsmodal.getStoremodalLblStorename().getText();
		if (storeName.contains(displayStrNameDetails))
			PerfectoUtils.reportMessage("Store name matches in store details...");
		else
			PerfectoUtils.reportMessage("Store name not matches in store details...", MessageTypes.Fail);

		storedetailsmodal.getStoremodalLblMiles().verifyPresent();
		storedetailsmodal.getStoremodalLblLocation().verifyPresent();
		storedetailsmodal.getStoremodalLblPharmacy().verifyPresent();
		storedetailsmodal.getStoremodalLnkGetdirection().verifyPresent();
		storedetailsmodal.getStoremodalLnkCall().verifyPresent();
		PerfectoUtils.scrollToElement(storedetailsmodal.getStoremodalLnkStorefeature());
		storedetailsmodal.getStoremodalLnkStorefeature().verifyPresent();

	}

	/*
	 * Verify back button is present and click on it
	 */
	@QAFTestStep(description = "I click back from the store detail modal")
	public void iClickBackFromTheStoreDetailModal() {

		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify back button is present and click on it
		storedetailsmodal.getStoremodalBtnBackicon().waitForPresent(3000);
		storedetailsmodal.getStoremodalBtnBackicon().verifyPresent();
		storedetailsmodal.getStoremodalBtnBackicon().click();
		PerfectoUtils.reportMessage("Clicked on the back icon...");
	}

	/*
	 * Verify close icon is present and click on it
	 */
	@QAFTestStep(description = "I close the store detail modal")
	public void iCloseTheStoreDetailModal() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify close icon is present and click on it
		storedetailsmodal.getStoremodalBtnCloseicon().waitForPresent(3000);
		storedetailsmodal.getStoremodalBtnCloseicon().verifyPresent();
		storedetailsmodal.getStoremodalBtnCloseicon().click();
		PerfectoUtils.reportMessage("Clicked on the close option...");
	}

	/*
	 * Perform swipe actions
	 */
	@QAFTestStep(description = "I scroll and check screen get scrolled")
	public void iScrollAndCheckScreenGetScrolled() {
		PerfectoUtils.horizontalswipe();
		PerfectoUtils.verticalswipe();
		PerfectoUtils.reportMessage("Swiping...");

	}

	/*
	 * Verify product location is displayed in store details modal
	 * 
	 * @param 'productlocation'
	 */
	@QAFTestStep(description = "I verify the product location information")
	public void iVerifyTheProductLocationInformation() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		String productLocation = ConfigurationManager.getBundle().getString("productlocation");

		try {
			// Verify product location is displayed in store details modal
			storedetailsmodal.getStoremodalLblLocation().waitForPresent(3000);
			storedetailsmodal.getStoremodalLblLocation().verifyPresent();
			String productLocationDetails = storedetailsmodal.getStoremodalLblLocation().getText();

			if (productLocation.equalsIgnoreCase(productLocationDetails))
				PerfectoUtils.reportMessage("Product location displayed in store details modal is matched..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Product location displayed in store details modal is not matched..", MessageTypes.Fail);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			PerfectoUtils.reportMessage("Location not found...");
		}
	}

	/*
	 * Click on get direction and check THE prompt to leave the app is displayed
	 */
	@QAFTestStep(description = "I verify the Get direction")
	public void iVerifyTheGetDirection() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Click on get direction and check THE prompt to leave the app is
		// displayed
		storedetailsmodal.getStoremodalLnkGetdirection().waitForPresent(3000);
		storedetailsmodal.getStoremodalLnkGetdirection().verifyPresent();
		storedetailsmodal.getStoremodalLnkGetdirection().click();
		storedetailsmodal.getLblLeavingappgetdirection().waitForPresent(30000);
		storedetailsmodal.getLblLeavingappgetdirection().verifyPresent();
		storedetailsmodal.getBtnCancelpopup().verifyPresent();
		storedetailsmodal.getBtnOkpopup().verifyPresent();
		storedetailsmodal.getBtnCancelpopup().click();
		storedetailsmodal.getStoremodalLnkGetdirection().verifyPresent();
	}

	/*
	 * Verify call option is present
	 */
	@QAFTestStep(description = "I verify the Call option")
	public void iVerifyTheCallOption() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Click on phone number and check THE prompt to leave the app is
		// displayed
		storedetailsmodal.getStoremodalLnkCall().verifyPresent();
		storedetailsmodal.getStoremodalLnkCall().click();

	}

	/*
	 * Verify weekly add is not present
	 */
	@QAFTestStep(description = "I verify weekly ad option is not present")
	public void iVerifyWeeklyAdOptionIsNotPresent() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify weekly add is not present

		try {
			String text1 = storedetailsmodal.getLblWeeklyAdTxt().getText();
			if (text1.contains("View Weekly Ad"))
				PerfectoUtils.reportMessage("Weekly add is present..", MessageTypes.Fail);
			else
				PerfectoUtils.reportMessage("Weekly add is not present..", MessageTypes.Pass);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.reportMessage("Weekly add is not present..", MessageTypes.Pass);
		}

	}

	/*
	 * Verify change store option is not present
	 */
	@QAFTestStep(description = "I verify change store option is not present")
	public void iVerifyChangeStoreOptionIsNotPresent() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify change store option is not present
		PerfectoUtils.verticalswipe();
		// storedetailsmodal.getStoremodalLblChangemystore().verifyNotPresent();
		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Change Store");
			Object result1 = storedetailsmodal.getTestBase().getDriver().executeScript("mobile:text:find", params1);
			PerfectoUtils.reportMessage("Changestore is present..", MessageTypes.Fail);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Changestore is not present..", MessageTypes.Pass);
		}

	}

	/*
	 * Click on the View nearby store
	 */
	@QAFTestStep(description = "I navigate to store result list modal")
	public void iNavigateToStoreResultListModal() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		// Click on the View nearby store
		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
		PerfectoUtils.swipeIfInBottom(storedetailsmodal.getPdpLnkViewnearbystore());
		storedetailsmodal.getPdpLnkViewnearbystore().waitForPresent(3000);
		storedetailsmodal.getPdpLnkViewnearbystore().verifyPresent();
		storedetailsmodal.getPdpLnkViewnearbystore().click();
		PerfectoUtils.reportMessage("Clicked on the View nearby store...");

	}

	/**
	 * Check for a store with location and click on it
	 * 
	 * @return selectedStore and productlocation
	 */
	@QAFTestStep(description = "I select a store with product location")
	public void iSelectAStoreWithProductLocation() {

		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();
		String selectedStore = null;
		String location = null;

		// Select a store with location from store list
		int size1 = storedetailsmodal.getStrlistLnkStrnamewithlocation().size();
		int size2 = storedetailsmodal.getStrlistLblProductlocation().size();

		System.out.println(size1 + " " + size2);
		selectedStore = storedetailsmodal.getStrlistLnkStrnamewithlocation().get(size1 - 1).getText();
		location = storedetailsmodal.getStrlistLblProductlocation().get(size2 - 1).getText();
		System.out.println(selectedStore);
		System.out.println(location);
		storedetailsmodal.getStrlistLnkStrnamewithlocation().get(size1 - 1).verifyPresent();
		storedetailsmodal.getStrlistLnkStrnamewithlocation().get(size1 - 1).click();
		ConfigurationManager.getBundle().setProperty("selectedStore", selectedStore);
		ConfigurationManager.getBundle().setProperty("productlocation", location);
		PerfectoUtils.reportMessage("Clicked on the store name with location..");

	}

	@QAFTestStep(description = "I click on view nearby store")
	public void iClickOnViewNearbyStore() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (storelocator.getStorelocatorTxtPopupmsg().isPresent()) {
			PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Pass);
			storelocator.getStorelocatorBtnAllow().click();
		}

		PerfectoUtils.verticalswipe();
		PerfectoUtils.scrollToElement(productdetails.getlnkviewnearbystores());
		PerfectoUtils.verticalswipe();
		try {
			if (productdetails.getlnkviewnearbystores().isPresent()) {
				productdetails.getlnkviewnearbystores().click();
				PerfectoUtils.reportMessage("nearby store clicked", MessageTypes.Pass);
				productdetails.waitForPageToLoad();
			} else {
				PerfectoUtils.reportMessage("nearby store is not present", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.scrollToElement(productdetails.getlnkviewnearbystores());
			productdetails.getlnkviewnearbystores().waitForPresent(5000);
			productdetails.getlnkviewnearbystores().click();
			productdetails.waitForPageToLoad();
		}
	}

	@QAFTestStep(description = "I verify the nearby store list modal is displayed")
	public void iVerifyTheNearbyStoreListModalIsDisplayed() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		productdetails.waitForPageToLoad();
		int count = productdetails.getlblstorelist().size();
		getBundle().setProperty("size", count);
		productdetails.gettxtnearbystores().verifyPresent();
		productdetails.getlblcancelicon().verifyPresent();
		productdetails.getlblproductname().verifyPresent();
		productdetails.getlblcancelicon().click();

	}

	@QAFTestStep(description = "I verify that {0} closest stores will be display in neraby stores modal")
	public void iVerifyThatClosestStoresWillBeDisplayInNerabyStoresModal(long l1) {

		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		int count = productdetails.getlblstorelist().size();

		PerfectoUtils.reportMessage("Number of stores are: " + count, MessageTypes.Info);
		System.out.println("stores " + count);
	}

	@QAFTestStep(description = "I verify the coupons section")
	public void iVerifyTheCouponsSection() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();

		PerfectoUtils.scrollToElement(productdetail.getcouponsectiontxtcoupons());

		if (productdetail.getcouponsectiontxtcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons section is present ", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons section is not present ", MessageTypes.Fail);
		}

	}

	/**
	 * Click on the store name and return productlocation & selectedStore
	 */
	@QAFTestStep(description = "I click on the store name")
	public void iClickOnTheStoreName() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Click on store name from pdp
		PerfectoUtils.verticalswipe();
		PerfectoUtils.scrollToElement(storedetailsmodal.getPdpLnkStorename());
		storedetailsmodal.getPdpLnkStorename().waitForPresent(3000);
		storedetailsmodal.getPdpLnkStorename().verifyPresent();
		String prodlocation = storedetailsmodal.getPdpLblProductlocation().getText();
		String selectedStore = storedetailsmodal.getPdpLnkStorename().getText();
		ConfigurationManager.getBundle().setProperty("productlocation", prodlocation);
		ConfigurationManager.getBundle().setProperty("selectedStore", selectedStore);
		storedetailsmodal.getPdpLnkStorename().click();
		PerfectoUtils.reportMessage("Clicked on store name..");
	}

	/**
	 * Verify PDP page is displayed
	 */
	@QAFTestStep(description = "I should see PDP page")
	public void iShouldSeePDPPage() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify store availability section is displayed
		storedetailsmodal.getPdpLnkViewnearbystore().waitForPresent(3000);
		storedetailsmodal.getPdpLnkViewnearbystore().verifyPresent();
	}

	/**
	 * Verify store result modal is displayed
	 */
	@QAFTestStep(description = "I should see store result list modal")
	public void iShouldSeeStoreResultListModal() {
		ProductstoredetailsmodalTestPage storedetailsmodal = new ProductstoredetailsmodalTestPage();

		// Verify nearby store list get displayed
		storedetailsmodal.getStoremodalLblPageheader().waitForPresent(3000);
		String pageheader = storedetailsmodal.getStoremodalLblPageheader().getText();
		if (pageheader.contains("Nearby Stores"))
			PerfectoUtils.reportMessage("Nearby Stores modal displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Nearby Stores modal not displayed..", MessageTypes.Fail);

	}

	/*
	 * @QAFTestStep(description =
	 * "I verify that maximum of {0} stores is getting displayed in the store modal"
	 * ) public void
	 * iVerifyThatMaximumOfStoresIsGettingDisplayedInTheStoreModal(long l1) {
	 * ProductdetailTestPage productdetail = new ProductdetailTestPage(); int
	 * count = productdetail.getlblstorelist().size(); if (count <= 10 && count
	 * > 0) { PerfectoUtils.reportMessage("Number of store getting displayed is" + count,
	 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
	 * "More than 10 stores are getting displayed" + count, MessageTypes.Fail);
	 * } }
	 */

	@QAFTestStep(description = "I click on the X or close button")
	public void iClickOnTheXOrCloseButton() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		if (productdetail.gettxtnearbystores().isPresent()) {
			productdetail.getlblcancelicon().click();
			PerfectoUtils.reportMessage("Clicked on X or the close button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Modal not displayed and Close button or X icon is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the product name displayed below the nearby store header")
	public void iVerifyTheProductNameDisplayedBelowTheNearbyStoreHeader() {
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		if (productdetail.getlblproductname().isPresent()) {
			PerfectoUtils.reportMessage("Product name is getting displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Product name is not getting displayed", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify that maximum of {0} stores is getting displayed in the store modal")
	public void iVerifyThatMaximumOfStoresIsGettingDisplayedInTheStoreModal(long l1) {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		int size = productdetails.getlblstorelist().size();
		PerfectoUtils.reportMessage("Number of stores are: " + size, MessageTypes.Info);
		System.out.println("stores " + size);

		if (size > 10) {
			PerfectoUtils.reportMessage("More than 10 stores are there", MessageTypes.Info);
		} else {
			PerfectoUtils.reportMessage("10 stores are present in the page", MessageTypes.Pass);
		}
		productdetails.getlblcancelicon().click();
	}

	@QAFTestStep(description = "I verify the error message and try again option for the Store availability module")
	public void iVerifyTheErrorMessageAndTryAgainOptionForTheStoreAvailabilityModule() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
		PerfectoUtils.verticalswipe();
		productdetails.waitForPageToLoad();
		if (productdetails.gettxtstoreavailability().isPresent()) {
			productdetails.gettxtstoresnotloadederror().verifyPresent();
			productdetails.getbtntryagain().verifyPresent();
			PerfectoUtils.reportMessage("Store could not be loaded error is present", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store could not be loaded error message is not there", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify that user still remains on the PDP page")
	public void iVerifyThatUserStillRemainsOnThePDPPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		if (productdetails.gettxtstoreavailability().isPresent()) {
			PerfectoUtils.reportMessage("user still in PDP page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("user navigated to some other page", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the error message if product is not available in any nearby stores")
	public void iVerifyTheErrorMessageIfProductIsNotAvailableInAnyNearbyStores() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
		productdetails.gettxtstoreavailability().waitForPresent(2000);
		PerfectoUtils.verticalswipeSlow();

		productdetails.gettxtnotavailable().waitForPresent(10000);
		if (productdetails.gettxtnotavailable().isPresent()) {
			PerfectoUtils.reportMessage("able to see not available in nearby stores error", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not able to see not available in nearby stores error", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I navigate to PDP page by searching the product {0}")
	public void iNavigateToPDPPageBySearchingTheProduct(String productname) {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		// Enter product name in search field
		getBundle().setProperty("productName", productname);

		// Enter input search term and click search button on keyboard
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(productname);

		// new search icon click function
		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_SEARCH");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);

		try {
			ioscommon.getAppLblLoading().waitForPresent(3000);
			ioscommon.getAppLblLoading().waitForNotPresent(15000);
		} catch (Exception e) {
			// ignore..
		}
		productdetails.gettxtnostoreproduct().waitForPresent(3000);
		productdetails.gettxtnostoreproduct().click();
		productdetails.waitForPageToLoad();

	}

	@QAFTestStep(description = "I select a store")
	public void iSelectAStore() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		int size = productdetails.getlblstorelist().size();
		System.out.println(size);
		String StoreName = productdetails.getlblstorelist().get(1).getText();
		System.out.println(StoreName);
		productdetails.getlblstorelist().get(1).waitForPresent(3000);
		productdetails.getlblstorelist().get(3).click();
		productdetails.waitForPageToLoad();

		/*
		 * if (productdetails.getpdpstorepagestorenametxt().isPresent()) {
		 * 
		 * PerfectoUtils.reportMessage("User is on the store detail page", MessageTypes.Pass);
		 * 
		 * }
		 * 
		 * else { PerfectoUtils.reportMessage("User is not on the store detail page",
		 * MessageTypes.Fail); }
		 */

	}

	@QAFTestStep(description = "I verify the Store feature is getting displayed")
	public void iVerifyTheStoreFeatureIsGettingDisplayed() {

		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		if (productdetails.getpdpstorepagestorefeaturelbl().isPresent()) {
			PerfectoUtils.reportMessage("Store feature is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.scrollToElement(productdetails.getpdpstorepagestorefeaturelbl());
			productdetails.getpdpstorepagestorefeaturelbl().waitForPresent(2000);
			PerfectoUtils.reportMessage("Store feature is displayed", MessageTypes.Pass);

		}
	}

	@QAFTestStep(description = "I navigate to Store feature page")
	public void iNavigateToStoreFeaturePage() throws InterruptedException {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		productdetails.getpdpstorepagestorefeaturelbl().click();
		productdetails.getpdpstorefeaturetxtstorefeature().waitForPresent(5000);
		if (productdetails.getpdpstorefeaturetxtstorefeature().isPresent()) {
			PerfectoUtils.reportMessage(" Navigated to Store feature page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Store feature Page ", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Verify Store Name,Address,Aisle Number and distance to the store in the store modal")
	public void verifyStoreNameAddressAisleNumberAndDistanceToTheStoreInTheStoreModal() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();
		int l = productdetails.getStorelist().size();
		if (l > 0) {
			for (StoreDetailModel singlecell : productdetails.getStorelist()) {
				singlecell.getstorename().isPresent();
				singlecell.getstoreaddress().isPresent();
				singlecell.getstoremiles().isPresent();
				System.out.println(singlecell.getstorename().getText());
				System.out.println(singlecell.getstoreaddress().getText());
				System.out.println(singlecell.getstoremiles().getText());
				break;
			}
			PerfectoUtils.reportMessage("Store details are present in store modal", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store details are not present in storemodal", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I set the {0} location")
	public void iSetTheLocation(String str1) {

		// Set location
		PerfectoUtils.setLocation(str1);

	}

	@QAFTestStep(description = "I verify that section is reloaded after clicking try again button")
	public void iVerifyThatSectionIsReloadedAfterClickingTryAgainButton() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
		PerfectoUtils.verticalswipe();
		productdetails.gettxtstoreavailability().waitForPresent(2000);
		if (productdetails.getbtntryagain().isPresent()) {
			productdetails.getbtntryagain().click();
			PerfectoUtils.reportMessage("Try Again button is clicked", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Try Again button is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify that store availability section is below View All Coupons module")
	public void iVerifyThatStoreAvailabilitySectionIsBelowViewAllCouponsModule() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.scrollToElement(productdetails.getcouponsectiontxtcoupons());
		productdetails.getcouponsectiontxtcoupons().waitForPresent(2000);

		int startY = Integer.parseInt(productdetails.getcouponsectiontxtcoupons().getAttribute("Y"));
		System.out.println(startY);

		PerfectoUtils.scrollToElement(productdetails.gettxtstoreavailability());
		productdetails.gettxtstoreavailability().waitForPresent(2000);

		int endY = Integer.parseInt(productdetails.gettxtstoreavailability().getAttribute("Y"));
		System.out.println(endY);

		if (endY > startY) {
			PerfectoUtils.reportMessage("store availability section is below View All Coupons module", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("store availability section is not below View All Coupons module", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "navigate to Product Information Disclaimer page")
	public void navigateToProductInformationDisclaimerPage() {

		ProductdetailTestPage pdtdetails = new ProductdetailTestPage();

		PerfectoUtils.verticalswipe();
		pdtdetails.getPdpImgLegaldisclamier().waitForPresent(3000);
		pdtdetails.getPdpImgLegaldisclamier().click();
		PerfectoUtils.reportMessage("Clicked on Product Information Disclaimer..", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Select Cancel option from Add to list popup")
	public void selectCancelOptionFromAddToListPopup() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		addtolist.getAddtolistBtnCancel().waitForPresent(1000);
		addtolist.getAddtolistBtnCancel().click();
		PerfectoUtils.reportMessage("Clicked on Cancel button from the add to list popup.", MessageTypes.Pass);

	}

	@QAFTestStep(description = "Verify the add to list popup has been closed")
	public void verifyTheAddToListPopupHasBeenClosed() {
		AddtolistTestPage addtolist = new AddtolistTestPage();

		if (!addtolist.getAddtolistBtnCancel().isPresent()) {
			PerfectoUtils.reportMessage("Add to list popup closed.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Add to list popup not closed.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I clicked on product image")
	public void iClickedOnProductImage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		productdetails.getPdpImgProductimage().waitForPresent(5000);
		productdetails.getPdpImgProductimage().click();
	}

	@QAFTestStep(description = "I verify enlarged product image from the Product Detail Page")
	public void iVerifyEnlargedProductImageFromTheProductDetailPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		if (productdetails.getPdpImgProductimage().isPresent() && !productdetails.getPdpBtnAddtolist().isPresent()) {
			PerfectoUtils.reportMessage("Enlarged product image is coming after clicking on the image.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see enlarged product image.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify Central Market Guarantee on the Product Detail Page")
	public void iVerifyCentralMarketGuaranteeOnTheProductDetailPage() {
		ProductdetailTestPage productdetails = new ProductdetailTestPage();

		PerfectoUtils.verticalswipe();
		if (productdetails.getLblCentralMarketGuarantee().isPresent()) {
			productdetails.getLblCentralMarketGuarantee().verifyPresent();
			String msg = productdetails.getLblCentralMarketGuarantee().getText();
			PerfectoUtils.reportMessage("Guarantee message is present " + msg, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Unable to see Guarantee message.", MessageTypes.Fail);
		}
	}

}
