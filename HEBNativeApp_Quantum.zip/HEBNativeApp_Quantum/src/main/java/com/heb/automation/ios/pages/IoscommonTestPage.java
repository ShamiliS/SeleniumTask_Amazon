package com.heb.automation.ios.pages;

import java.util.List;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class IoscommonTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "app.btn.footerhomeicon")
	private QAFWebElement appFooterHomeicon;
	@FindBy(locator = "app.btn.footershopicon")
	private QAFWebElement appFooterShopicon;
	@FindBy(locator = "app.btn.footershoppinglist")
	private QAFWebElement appFooterShoppinglist;
	@FindBy(locator = "app.btn.footermore")
	private QAFWebElement appFooterMore;
	@FindBy(locator = "app.btn.moreregister")
	private QAFWebElement appMoreRegister;
	@FindBy(locator = "app.btn.morefaqs")
	private QAFWebElement appMoreFaqs;
	@FindBy(locator = "app.btn.moreprivacypolicy")
	private QAFWebElement appMorePrivacypolicy;
	@FindBy(locator = "app.btn.moreorderlookup")
	private QAFWebElement appMoreOrderlookup;
	@FindBy(locator = "app.lbl.morepagetitle")
	private QAFWebElement appMoreMore;
	@FindBy(locator = "app.btn.moresigin")
	private QAFWebElement appMoreSigin;
	@FindBy(locator = "app.btn.moretermsandconditions")
	private QAFWebElement appMoreTermsandconditions;
	@FindBy(locator = "app.lbl.moremystorename")
	private QAFWebElement appMoreMystorename;
	@FindBy(locator = "app.btn.backios")
	private QAFWebElement appBtnBackIOS;
	@FindBy(locator = "app.btn.scanproducts")
	private QAFWebElement headerBtnScanProducts;
	@FindBy(locator = "appscan.lbl.pagetitle")
	private QAFWebElement scanLblPagetitle;
	@FindBy(locator = "appscan.btn.back")
	private QAFWebElement scanBtnBack;
	@FindBy(locator = "appscan.popup.lbl.enablecamera")
	private QAFWebElement scanPopupEnablecamera;
	@FindBy(locator = "appscan.btn.okenablecamera")
	private QAFWebElement scanBtnOkEnablecamera;
	@FindBy(locator = "app.edt.searchtoaddproducts")
	private QAFWebElement headerEdtSearchtoaddproducts;
	@FindBy(locator = "header.icon.barcodescan")
	private QAFWebElement headerIconBarcodescan;
	@FindBy(locator = "header.btn.Cancel")
	private QAFWebElement headerBtnCancel;
	@FindBy(locator = "appscan.btn.enterreceiptnumber")
	private QAFWebElement scanreceiptBtnEnterreceiptnumber;
	@FindBy(locator = "appscan.txt.scanproduct")
	private QAFWebElement scanTxtScanproduct;
	@FindBy(locator = "appscan.txt.scanreceipt")
	private QAFWebElement scanTxtScanreceipt;
	@FindBy(locator = "addtolist.btn.done")
	private QAFWebElement addtolistBtnDone;
	@FindBy(locator = "addtolist.btn.cancel")
	private QAFWebElement addtolistBtnCancel;
	@FindBy(locator = "addtolist.lbl.wglist")
	private QAFWebElement addtolistLblWgList;
	@FindBy(locator = "addtolist.txt.numberpicker")
	private QAFWebElement addtolistTxtNumberpicker;
	@FindBy(locator = "addtolist.txt.nextpicker")
	private List<QAFWebElement> addtolistTxtNextpicker;
	@FindBy(locator = "app.allowpopup.btn.allow")
	private QAFWebElement appPopupBtnAllowPermission;
	@FindBy(locator = "home.lbl.welcomeuser")
	private QAFWebElement homelblwelcomeuser;
	@FindBy(locator = "app.btn.morefaqs")
	private QAFWebElement appmorefaqs;
	@FindBy(locator = "app.lbl.faqpagetitle")
	private QAFWebElement appfaqlblpagetitle;
	@FindBy(locator = "app.lbl.privacypolicypagetitle")
	private QAFWebElement appprivacypolicylblpagetitle;
	@FindBy(locator = "app.lbl.termsandconditionspagetitle")
	private QAFWebElement apptermsandconditionslblpagetitle;
	@FindBy(locator = "appscan.btn.mylist")
	private QAFWebElement scanbtnmylist;
	@FindBy(locator = "app.lbl.moreonlineorderhotuser")
	private QAFWebElement appMoreLblOnlineorderHotuser;
	@FindBy(locator = "app.lbl.loading")
	private QAFWebElement appLblLoading;
	@FindBy(locator = "app.btn.footerproducts")
	private QAFWebElement btnFooterproducts;
	@FindBy(locator = "app.allowpopup.btn.deny")
	private QAFWebElement appBtnPopupallowpermissiondeny;
	@FindBy(locator = "app.btn.skip")
	private QAFWebElement appBtnSkip;
	@FindBy(locator = "app.btn.footerdigitalcoupon")
	private QAFWebElement btnFooterdigitalcoupon;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getScanreceiptBtnEnterreceiptnumber() {
		return scanreceiptBtnEnterreceiptnumber;
	}

	public QAFWebElement getAppFooterHomeicon() {
		return appFooterHomeicon;
	}

	public QAFWebElement getAppFooterShopicon() {
		return appFooterShopicon;
	}

	public QAFWebElement getAppFooterShoppinglist() {
		return appFooterShoppinglist;
	}

	/*
	 * public QAFWebElement getAppFooterCart() { return appFooterCart; }
	 */

	public QAFWebElement getAppFooterMore() {
		return appFooterMore;
	}

	public QAFWebElement getAppMoreRegister() {
		return appMoreRegister;
	}

	public QAFWebElement getAppMoreFaqs() {
		return appMoreFaqs;
	}

	public QAFWebElement getAppMorePrivacypolicy() {
		return appMorePrivacypolicy;
	}

	public QAFWebElement getAppMoreOrderlookup() {
		return appMoreOrderlookup;
	}

	public QAFWebElement getAppMoreMore() {
		return appMoreMore;
	}

	public QAFWebElement getAppMoreSigin() {
		return appMoreSigin;
	}

	public QAFWebElement getAppMoreTermsandconditions() {
		return appMoreTermsandconditions;
	}

	public QAFWebElement getAppMoreMystorename() {
		return appMoreMystorename;
	}

	public QAFWebElement getAppBtnBackIOS() {
		return appBtnBackIOS;
	}

	public QAFWebElement getScanLblPagetitle() {
		return scanLblPagetitle;
	}

	public QAFWebElement getScanBtnBack() {
		return scanBtnBack;
	}

	public QAFWebElement getScanPopupEnablecamera() {
		return scanPopupEnablecamera;
	}

	public QAFWebElement getScanBtnOkEnablecamera() {
		return scanBtnOkEnablecamera;
	}

	public QAFWebElement getHeaderEdtSearchtoaddproducts() {
		return headerEdtSearchtoaddproducts;
	}

	public QAFWebElement getHeaderIconBarcodescan() {
		return headerIconBarcodescan;
	}

	public QAFWebElement getHeaderBtnCancel() {
		return headerBtnCancel;
	}

	public QAFWebElement getScanTxtScanproduct() {
		return scanTxtScanproduct;
	}

	public QAFWebElement getScanTxtScanreceipt() {
		return scanTxtScanreceipt;
	}

	public QAFWebElement getAddtolistBtnDone() {
		return addtolistBtnDone;
	}

	public QAFWebElement getAddtolistBtnCancel() {
		return addtolistBtnCancel;
	}

	public QAFWebElement getAddtolistLblWgList() {
		return addtolistLblWgList;
	}

	public QAFWebElement getHeaderBtnScanProducts() {
		return headerBtnScanProducts;
	}

	public QAFWebElement getAddtolistTxtNumberpicker() {
		return addtolistTxtNumberpicker;
	}

	public List<QAFWebElement> getAddtolistTxtNextpicker() {
		return addtolistTxtNextpicker;
	}

	public QAFWebElement getAppPopupBtnAllowPermission() {
		return appPopupBtnAllowPermission;
	}

	public QAFWebElement getHomeLblWelcomeUser() {
		return homelblwelcomeuser;
	}

	public QAFWebElement getAppmoreFaqs() {
		return appmorefaqs;
	}

	public QAFWebElement getAppFaqsblbPageTitle() {
		return appfaqlblpagetitle;
	}

	public QAFWebElement getAppLblPrivacyPolicy() {
		return appprivacypolicylblpagetitle;
	}

	public QAFWebElement getAppLblTermsAndConditions() {
		return apptermsandconditionslblpagetitle;
	}

	public QAFWebElement getAppMoreLblOnlineorderHotuser() {
		return appMoreLblOnlineorderHotuser;
	}

	public QAFWebElement getScanBtnMyList() {
		return scanbtnmylist;
	}

	public QAFWebElement getAppLblLoading() {
		return appLblLoading;
	}

	@Override
	public void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	// DYNAMIC value declaring
	public QAFWebElement getFullDynamicNameByLable(String lable) {
		String loc = String.format(pageProps.getString("app.lbl.dynamicnamefull"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getBtnFooterproducts() {
		return btnFooterproducts;
	}

	public QAFWebElement getAppBtnPopupallowpermissiondeny() {
		return appBtnPopupallowpermissiondeny;
	}

	public QAFWebElement getAppBtnSkip() {
		return appBtnSkip;
	}

	public QAFWebElement getBtnFooterdigitalcoupon() {
		return btnFooterdigitalcoupon;
	}

}
