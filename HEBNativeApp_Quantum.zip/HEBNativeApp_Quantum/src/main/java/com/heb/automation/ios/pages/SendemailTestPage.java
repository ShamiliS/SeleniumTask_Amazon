package com.heb.automation.ios.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SendemailTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "sendemail.lbl.pagetitle")
	private QAFWebElement sendemailLblPageheader;
	@FindBy(locator = "sendemail.txt.sendername")
	private QAFWebElement sendemailEdtSendername;
	@FindBy(locator = "sendemail.txt.senderemail")
	private QAFWebElement sendemailEdtSenderemail;
	@FindBy(locator = "sendemail.txt.recipientemail")
	private QAFWebElement sendemailEdtRecipientemail;
	@FindBy(locator = "sendemail.chk.sendmecopy")
	private QAFWebElement sendemailChkSendmecopy;
	@FindBy(locator = "sendemail.lbl.message")
	private QAFWebElement sendemailLblMessage;
	@FindBy(locator = "sendemail.img.imageview")
	private QAFWebElement sendemailImgImageview;
	@FindBy(locator = "sendemail.edt.imagetitle")
	private QAFWebElement sendemailEdtImagetitle;
	@FindBy(locator = "sendemail.txt.message")
	private QAFWebElement sendemailEdtMessage;
	@FindBy(locator = "sendemail.btn.send")
	private QAFWebElement sendemailBtnSend;
	@FindBy(locator = "sendemail.btn.submit")
	private QAFWebElement sendemailBtnSubmit;
	@FindBy(locator = "sendemail.btn.cancel")
	private QAFWebElement sendemailBtnCancel;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getSendemailLblPageheader() {
		return sendemailLblPageheader;
	}

	public QAFWebElement getSendemailEdtSendername() {
		return sendemailEdtSendername;
	}

	public QAFWebElement getSendemailEdtSenderemail() {
		return sendemailEdtSenderemail;
	}

	public QAFWebElement getSendemailEdtRecipientemail() {
		return sendemailEdtRecipientemail;
	}

	public QAFWebElement getSendemailChkSendmecopy() {
		return sendemailChkSendmecopy;
	}

	public QAFWebElement getSendemailLblMessage() {
		return sendemailLblMessage;
	}

	public QAFWebElement getSendemailImgImageview() {
		return sendemailImgImageview;
	}

	public QAFWebElement getSendemailEdtImagetitle() {
		return sendemailEdtImagetitle;
	}

	public QAFWebElement getSendemailEdtMessage() {
		return sendemailEdtMessage;
	}

	public QAFWebElement getSendemailBtnSend() {
		return sendemailBtnSend;
	}
	
	public QAFWebElement getSendemailBtnSubmit() {
		return sendemailBtnSubmit;
	}

	public QAFWebElement getSendemailBtnCancel() {
		return sendemailBtnCancel;
	}

}
