package com.heb.automation.ios.steps;

import static com.heb.automation.common.PerfectoUtils.getAppiumDriver;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import static com.qmetry.qaf.automation.step.CommonStep.click;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.FAQTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.coupons.CouponssearchresultTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.ChangepasswordTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.myaccount.MyprofileTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.products.ProductlandingTestPage;
import com.heb.automation.common.pages.products.ProductsearchresultTestPage;
import com.heb.automation.common.pages.products.RefineTestPage;
import com.heb.automation.common.pages.recipes.RecipeslandingTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.scanner.ScannerTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.common.steps.myaccount.CommonStepDefMyAccounts;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.pages.SendemailTestPage;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.heb.automation.ios.steps.products.IOSStepdefproducts;
import com.heb.automation.ios.steps.recipes.IOSStepdefrecipes;
import com.heb.automation.ios.steps.shoppinglist.IOSStepdefshopinglist;
import com.heb.automation.ios.steps.storelocator.IOSStepDefStoreLocator;
import com.heb.automation.ios.steps.weeklyad.IOSStepdefWeeklyAd;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in IOSStep

	I am an Cold User
	I am a hot user using {0}{1} credential
	I navigate to Weekly ad from homepage
	I navigate to Coupons page
	I navigate back to homepage
	I am a hot user using {0}{1} with new list added
	I am a cold user with product added in list
	I navigate to shopping list
	I submit the registeration form
	I see homepage
	I am on Login splash page
	I delete the newly created list
	I navigate to FAQ
	I validate FAQ page
	I navigate to Privacy Policy
	I validate Privacy Policy page
	I naviagate to Terms & Conditions
	I validate Terms & Conditions page
	I validate logout
	I logout the application
	I validate the error message for invalid product
	I validate the refine filter options
	I validate share page
	I validate hint is available for all text fields in login page
	I click on search field from homepage
	I navigate and scan the receipt from Scan Receipt screen
	I validate email content
	I validate content of social media
	I navigate to social media page
	I navigate to email page
	I should see the Search Products screen
	I am a hot user for Email update
	I click on Cancel/ device back button
	I click Continue without registering link/Cancel button
	I validate sections in more/help page
	I click Register button from Hamburger or More
	I validate the Orginating page browse
	I am logging in as a hot user using {0}{1} credential from guest user
	I navigate and scan the item {0} from scan products screen
	I change the prod environment in IOS
	I verify the HEB Barcode in the home page
	I click on the HEB Barcode
	I verify the My HEB Barcode page
	I verify on clicking out of the barcode modal dismisses the modal
	I verify the barcode on top of homescreen list
	I verify that HEBbarcode is not displayed in homescreen list
	I verify the HEB Barcode is not displayed in the home page
	I verify the home hero image
	I verify the top slot
	I verify the sub menu order as cold user
	I verify the sub menu order as hot user with curbside store
	I verify the sub menu navigations as cold user
	I verify the sub menu navigations as hot user
	I verify the sub menu order as hot user without curbside store
	I click login button from Hamburger or More
	I navigate to home page
	I validate the show password functionality
	I validate Coupons selection page as cold user
	I validate Coupons selection page as hot user
	I am a VPP user using {0}{1} credential
	Verify donations Second item in the list*/

public class IOSStepdef {

	/**
	 * Allowing permission to handle pop up.Logging as a cold user.
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am an Cold User")
	public void iAmAnColdUser() throws Exception {
		HomeTestPage homepage = new HomeTestPage();
		IOSStepdef iosStep = new IOSStepdef();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		try {
			checkPreLogin();
		} catch (Exception e) {
			iosStep.handlePopup();
			checkPreLogin();
		}

		/* Logging in as a Cold user */
		if (homepage.getHomeLblSignin().isPresent()) {
			PerfectoUtils.reportMessage("Logged in as a Cold user.", MessageTypes.Pass);
		} else if (loginsplash.getLoginTxtEmail().isPresent()) {
			PerfectoUtils.reportMessage("User is in Login Splash page.");
			loginsplash.getLoginLblContinue().click();
			PerfectoUtils.reportMessage("Clicked continue button.");

		} else {
			PerfectoUtils.reportMessage("User already Logged in . Hence logout and login again", MessageTypes.Info);
			iValidateLogout();
			homepage.getAppFooterHomeicon().click();
			homepage.getHomeLblSignin().waitForPresent(3000);
		}
	}

	/**
	 * Allowing permission to handle pop up.Logging as a hot user.Handling the
	 * login error.
	 * 
	 * @param username
	 * @param pswd
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a hot user using {0}{1} credential")
	public static void iAmAHotUserUsingCredential(String username, String pswd) throws Exception {
		HomeTestPage home = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		try {
			checkPreLogin();
		} catch (Exception e) {

			iosstepdef.handlePopup();
			checkPreLogin();

		}

		getBundle().setProperty("CurrentPassword", pswd);

		if (home.getHomeLblSignin().isPresent()) {
			home.getHomeLblSignin().click();

			loginsplash.getLoginTxtEmail().waitForPresent(5000);
			loginsplash.getLoginTxtEmail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(username);
			loginsplash.getLoginTxtPassword().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(pswd);
			PerfectoUtils.reportMessage("Entered username and password.");
			IOSStepdef.clickKeyboardDone();
			loginsplash.getLoginBtnLogin().verifyPresent();
			loginsplash.getLoginBtnLogin().click();

			PerfectoUtils.reportMessage("Clicked Login button.");

			handleloginerror();
			checkloginerror();
			home = loginsplash.select();
		} else {
			PerfectoUtils.reportMessage("Error occured while logging in.", MessageTypes.Fail);
		}
	}

	private static void checkloginerror() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		HomeTestPage home = new HomeTestPage();

		try {
			if (home.getHomeLblProduct().isPresent()) {
				PerfectoUtils.reportMessage("Login Successful.", MessageTypes.Pass);
			}
		} catch (Exception e) {

			if (appCrash.getExceptionLblloginError().isPresent()) {
				PerfectoUtils.reportMessage("Login Error occured.", MessageTypes.Info);
				appCrash.getExceptionBtnOk().click();
				PerfectoUtils.reportMessage("Clicked Ok button.");
				handleloginerror();
			} else if (appCrash.getExceptionBtnOk().isPresent()) {
				PerfectoUtils.reportMessage("Login Error occured.", MessageTypes.Fail);
				appCrash.getExceptionBtnOk().click();
				PerfectoUtils.reportMessage("Clicked OK button.");
			}
		}
	}

	/**
	 * Navigation to Weekly Ad from home page.
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I navigate to Weekly ad from homepage")
	public void iNavigateToWeeklyAdFromHomepage() throws InterruptedException {
		HomeTestPage homepage = new HomeTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IOSStepdefWeeklyAd iosStepDefWeeklyAd = new IOSStepdefWeeklyAd();
		StorelocatorTestPage storelocator = new StorelocatorTestPage();

		if (homepage.getHomeLblWeeklyAd().isPresent()) {
			homepage.getHomeLblWeeklyAd().click();
			PerfectoUtils.reportMessage("Clicked On WeeklyAd from Homepage.", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("Swiping to find weekly Ads..");
			PerfectoUtils.verticalswipe();
			PerfectoUtils.swipeIfInBottom(homepage.getHomeLblWeeklyAd());
			homepage.getHomeLblWeeklyAd().verifyPresent();
			homepage.getHomeLblWeeklyAd().click();
			PerfectoUtils.reportMessage("Clicked On WeeklyAd from Homepage.", MessageTypes.Pass);
		}

		try {
			homepage.getHomeLblWeeklyAd().waitForNotPresent(5000);
		} catch (Exception e) {
			homepage.getHomeLblWeeklyAd().click();
		}

		try {
			storelocatorErrorHandle();
		} catch (Exception e) {
			// ignore..
		}
		if (storelocator.getStorelocatorLblRefine().isPresent()) {
			homepage.getAppFooterHomeicon().click();
			// PerfectoUtils.setLocation("San antonio");
			// PerfectoUtils.verticalswipe();
			try {
				homepage.getHomeLblWeeklyAd().waitForPresent(5000);
			} catch (Exception e) {
				// PerfectoUtils.verticalswipe();
				homepage.getHomeLblWeeklyAd().waitForPresent();
			}
			homepage.getHomeLblWeeklyAd().click();
			iosStepDefWeeklyAd.iChooseAnStoreFromTheStoreListForGettingWeeklyads();
		}

		try {
			if (weeklygrocery.getShopingListEntryByLable("Weekly Ad Error").isPresent()) {
				PerfectoUtils.reportMessage("Weekly Ad Error!! Try again after some time!!", MessageTypes.Pass);
				appcrash.getExceptionBtnOk().click();

				iosStepDefWeeklyAd.iClickOnViewAnotherStoreOption();
				iosStepDefWeeklyAd.iChooseAnAnotherStoreFromTheStoreListForGettingWeeklyads();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Navigation to Coupons page.
	 */
	@QAFTestStep(description = "I navigate to Coupons page")
	public void iNavigateToCouponsPage() {
		HomeTestPage homepage = new HomeTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		if (!homepage.getHomeDigitalCoupon().getAttribute("hidden").equals("false")) {
			PerfectoUtils.verticalswipe();
		}
		ioscommon.getBtnFooterdigitalcoupon().click();
		PerfectoUtils.reportMessage("Clicked Coupons from Footer bar.", MessageTypes.Pass);

		/* Handling Exceptions */
		if (appcrash.getExceptionSkipCoupons().isPresent()) {
			appcrash.getExceptionSkipCoupons().click();
		}

		try {
			if (ioscommon.getAppLblLoading().isPresent()) {
				ioscommon.getAppLblLoading().waitForNotVisible(30000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Clicking IOS back button.
	 */
	@QAFTestStep(description = "I navigate back to homepage")
	public void iNavigateToHomepageUsingBackButton() {
		IoscommonTestPage iocCommonTestPage = new IoscommonTestPage();

		iocCommonTestPage.getAppBtnBackIOS().click();
	}

	/**
	 * Adding a new List as a hot user.
	 * 
	 * @param user
	 * @param pswd
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a hot user using {0}{1} with new list added")
	public void iAmAHotUserUsingWithNewList(String user, String pswd) throws Exception {
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		IOSStepdef.iAmAHotUserUsingCredential(user, pswd);
		iosStepDefShopList.iNavigateToMyListPage();
		deleteFewShoppingLists();
		iosStepDefShopList.iClickOnPlusIconToAddList();
		iosStepDefShopList.iShouldSeeThePopupToEnterListName();
		iosStepDefShopList.iEnterTheShoppingListName();
		iosStepDefShopList.iClickTheAddButton();
		ioscommonpage.getAppFooterHomeicon().waitForPresent(5000);
		ioscommonpage.getAppFooterHomeicon().click();
		if (!ioscommonpage.getHomeLblWelcomeUser().isPresent()) {
			ioscommonpage.getAppFooterHomeicon().click();
		}
	}

	/**
	 * Adding product in List as a cold user
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a cold user with product added in list")
	public void iAmAColdUserWithProductAddedInList() throws Exception {
		IOSStepdefshopinglist iosStepDefShopList = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();

		iAmAnColdUser();
		iosStepDefShopList.iNavigateToMyListPage();
		iosStepDefShopList.iNavigateToWeeklyGroceriesPage();
		iosStepDefShopList.iSeeSearchFieldIsDisplayedByClickingOnSearchIcon();
		iosStepDefShopList.iSearchForProductFromListDetailsPage("milk");
		iosStepDefShopList.iShouldSeeTheSearchResultsPage();
		iosStepDefShopList.iSelectAUPCSpecificItem();
		iosStepDefShopList.iShouldSeeTheSelectedItemInTheSelectedListPage();
		ioscommonpage.getAppFooterHomeicon().waitForPresent(3000);
		ioscommonpage.getAppFooterHomeicon().click();
	}

	public static void enterValueIntoTheTextboxandClick(WebDriverTestPage driver, String inputValue) {

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(inputValue);

		/* New search icon click function */
		Map<String, Object> param1 = new HashMap<>();
		param1.put("keySequence", "KEYBOARD_SEARCH");
		PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
	}

	/**
	 * Navigation to shopping List
	 */
	@QAFTestStep(description = "I navigate to shopping list")
	public void iNavigateToShoppingList() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		/* Click Shopping list icon from the footer */
		ioscommon.getAppFooterShoppinglist().waitForPresent(5000);
		ioscommon.getAppFooterShoppinglist().click();
		PerfectoUtils.reportMessage("Shopping List", MessageTypes.Pass);
	}

	/**
	 * Clicking in Submit button to submit the registration form.
	 */
	@QAFTestStep(description = "I submit the registeration form")
	public static void iSubmitTheRegisterationForm() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.verticalswipe();
		register.getRegistrationBtnSubmit().waitForPresent(5000);
		register.getRegistrationBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked Sumbit button", MessageTypes.Info);
	}

	/**
	 * Verification of home page.
	 */
	@QAFTestStep(description = "I see homepage")
	public static void iSeeHomepage() {
		HomeTestPage homepage = new HomeTestPage();

		/* Verifying the home page */
		if (homepage.getHomeLblProduct().verifyPresent()) {
			PerfectoUtils.reportMessage("User is navigated back to homepage", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User is not navigated back to homepage", MessageTypes.Fail);
		}
	}

	public static void scrollToListNameInMyList(String strname) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		int i = 0;
		int intX = 0;
		/*
		 * int intStartY = 188; int intEndY = 128;
		 */

		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * 0.90);
		int intEndY = (int) (size.height * 0.80);
		do {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 1);
			try {
				weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
		} while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20);
		weeklygrocery.getShopingListEntryByLable(strname).click();
	}

	/**
	 * Verification whether user is in home page or not.Logged in as a cold
	 * user.
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am on Login splash page")
	public void iAmOnLoginSplashPage() throws Exception {
		HomeTestPage homepage = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		IoscommonTestPage iosCommonPage = new IoscommonTestPage();
		String checklogin;

		try {
			IOSStepdef.checkPreLogin();
		} catch (Exception e) {
			handlePopup();
			IOSStepdef.checkPreLogin();
		}

		PerfectoUtils.horizontalswipe();

		/* Allow permission pop up handle */
		if (iosCommonPage.getAppPopupBtnAllowPermission().isPresent()) {
			iosCommonPage.getAppPopupBtnAllowPermission().click();
			PerfectoUtils.reportMessage("Allow button clicked in Permission pop-up notification");
		}

		if (homepage.getHomeLblSignin().isPresent()) {

			/* User is in Home Page */
			System.out.println("Logged in as a cold user");
			homepage.getHomeLblSignin().click();
			loginsplash.getLoginBtnRegister().waitForPresent(70000);
		} else if (homepage.getHomeLblWelcomeUser().isPresent()) {

			checklogin = homepage.getHomeLblWelcomeUser().getText();
			if (checklogin.contains("Hi")) {
				iValidateLogout();
				PerfectoUtils.reportMessage("Clicked Log Out button.", MessageTypes.Pass);
				homepage.getAppFooterHomeicon().click();
			}
			homepage.getHomeLblSignin().click();
			loginsplash.getLoginBtnRegister().waitForPresent(70000);
			loginsplash.getLoginLblContinue().verifyPresent();
		}
	}

	/**
	 * Deleting newly created list
	 * 
	 * @param intStartX
	 * @param intStartY
	 * @param intEndX
	 */
	@QAFTestStep(description = "I delete the newly created list")
	public void iDeleteTheNewlyCreatedList() {
		IoscommonTestPage iocCommonTestPage = new IoscommonTestPage();
		MylistTestPage myListPage = new MylistTestPage();

		/* Clicking on App back button */
		iocCommonTestPage.getAppBtnBackIOS().click();
		myListPage.waitForPageToLoad();
		myListPage.getMyListLblLstNameHotUser().waitForPresent(5000);
		String strDeleteListName = getBundle().getPropertyValue("NewListName");

		/* Getting the x and y co-ordinates */
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(myListPage.getShopingListEntryByLable(strDeleteListName).getAttribute("Y"));
		int intEndX = Integer.parseInt(myListPage.getShopingListEntryByLable(strDeleteListName).getAttribute("X"));
		getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
		PerfectoUtils.reportMessage("Swiping across the list name: " + strDeleteListName + " to delete");
		myListPage.waitForPageToLoad();
		click("name=Delete");
		PerfectoUtils.reportMessage("Clicked Delete for list name: " + strDeleteListName + " ");
	}

	/**
	 * Navigation to FAQ.
	 */
	@QAFTestStep(description = "I navigate to FAQ")
	public void iValidateFAQ() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getHomeLblWelcomeUser().waitForPresent(2000);
		ioscommon.getHomeLblWelcomeUser().click();
		ioscommon.getAppmoreFaqs().verifyPresent();
		ioscommon.getAppmoreFaqs().click();
	}

	/**
	 * Validation of FAQ.
	 */
	@QAFTestStep(description = "I validate FAQ page")
	public void iNavigateToFAQPage() {
		FAQTestPage FAQPage = new FAQTestPage();
		boolean faqpage;

		/* Verifying FAQ page title */
		faqpage = FAQPage.getAppFaqsblbPageTitle().verifyPresent();
		if (faqpage) {
			PerfectoUtils.reportMessage("FAQ Page has displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("FAQ Page has not displayed", MessageTypes.Fail);
		}

		FAQPage.getLblFaqcommonques().verifyPresent();
		FAQPage.getLblFaqproduct().verifyPresent();
		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqproductques(), 80, 60, 2);
		FAQPage.getLblFaqproductques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqmylistques(), 80, 60, 2);
		FAQPage.getLblFaqmylist().verifyPresent();
		FAQPage.getLblFaqmylistques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqpharmacyques(), 80, 60, 2);
		FAQPage.getLblFaqpharmacy().verifyPresent();
		FAQPage.getLblFaqpharmacyques().verifyPresent();

		PerfectoUtils.scrollToStringuntilfindelement(FAQPage.getLblFaqdigcoupques(), 80, 60, 2);
		FAQPage.getLblFaqdigcoup().verifyPresent();
		FAQPage.getLblFaqdigcoupques().verifyPresent();
	}

	/**
	 * Navigation to Privacy Policy.
	 */
	@QAFTestStep(description = "I navigate to Privacy Policy")
	public void iValidatePrivacyPolicy() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getHomeLblWelcomeUser().waitForPresent(5000);
		ioscommon.getHomeLblWelcomeUser().click();
		ioscommon.getAppLblPrivacyPolicy().verifyPresent();
		ioscommon.getAppLblPrivacyPolicy().click();
	}

	/**
	 * Validation of Privacy Policy.
	 */
	@QAFTestStep(description = "I validate Privacy Policy page")
	public void iNavigateToPrivacyPolicyPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		boolean privacypolicypage;

		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		privacypolicypage = ioscommon.getAppLblPrivacyPolicy().verifyPresent();

		if (privacypolicypage) {
			// PerfectoUtils.reportMessage("Privacy Policy Page has displayed",
			// MessageTypes.Pass);
			CommonSteps.validattextinpage("Privacy Policy");
			CommonSteps.validattextinpage("PERSONAL INFORMATION");
		} else {
			PerfectoUtils.reportMessage("Privacy Policy Page has not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Navigation to Terms & Conditions.
	 */
	@QAFTestStep(description = "I naviagate to Terms & Conditions")
	public void iValidateTermsConditions() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getHomeLblWelcomeUser().waitForPresent(2000);
		ioscommon.getHomeLblWelcomeUser().click();
		ioscommon.getAppLblTermsAndConditions().waitForPresent(3000);

		if (!ioscommon.getAppLblTermsAndConditions().isPresent()) {
			PerfectoUtils.scrollToStringuntilfindelement(ioscommon.getAppLblTermsAndConditions(), 80, 60, 2);
		}
		ioscommon.getAppLblTermsAndConditions().waitForPresent(3000);
		ioscommon.getAppLblTermsAndConditions().click();
		PerfectoUtils.reportMessage("Clicked on Terms and Conditions.", MessageTypes.Pass);
	}

	/**
	 * Validation of Terms & Conditions.
	 */
	@QAFTestStep(description = "I validate Terms & Conditions page")
	public void iNavigateToTermsConditionsPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		boolean termsandconditions;

		/* Verifying Terms & Conditions page title */
		PerfectoUtils.getAppiumDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		termsandconditions = ioscommon.getAppLblTermsAndConditions().isPresent();

		if (termsandconditions) {
			PerfectoUtils.reportMessage("Terms & Conditions Page has displayed", MessageTypes.Pass);
			CommonSteps.validattextinpage("H-E-B Terms & Conditions");
			CommonSteps.validattextinpage("heb.com Terms of Use");
		} else {
			PerfectoUtils.reportMessage("Terms & Conditions Page has not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Scrolling to see the Logout button.Clicking on Logout button.
	 */
	@QAFTestStep(description = "I validate logout")
	public static void iValidateLogout() {
		HomeTestPage homepage = new HomeTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();

		// Navigate to home page
		homepage.getAppFooterHomeicon().waitForPresent(3000);
		homepage.getAppFooterHomeicon().click();

		homepage.getHomeLblWelcomeUser().waitForPresent(5000);
		if (homepage.getHomeLblWelcomeUser().isPresent()) {
			homepage.getHomeLblWelcomeUser().click();
		}

		/* Scrolling to make the "Log Out" button visible */
		PerfectoUtils.scrollToLogoutInIos();
		myaccount.getBtnLogout().waitForPresent(3000);
		myaccount.getBtnLogout().click();
		PerfectoUtils.reportMessage("Clicked on Logout button..", MessageTypes.Info);

		try {
			myaccount.getBtnLogout().waitForNotPresent(1000);
		} catch (Exception e) {
			myaccount.getBtnLogout().click();
			PerfectoUtils.reportMessage("Clicked on Logout button again..");
			myaccount.getBtnLogout().waitForNotPresent(5000);
		}

		/* Validate the result page */
		myaccount.getBtnSignin().waitForPresent(60000);

		if (myaccount.getBtnSignin().isPresent()) {
			PerfectoUtils.reportMessage("Logged out successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Logged out successfully", MessageTypes.Fail);
		}
		homepage.getAppFooterHomeicon().click();
	}

	/**
	 * Logout the Application.
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I logout the application")
	public static void iLogoutTheApplication() throws InterruptedException {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		ioscommon.getAppFooterMore().verifyPresent();
		ioscommon.getAppFooterHomeicon().click();
		iosstepdef.iOSLogout();
	}

	public void storelocatorErrorHandle() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		RegistrastionTestPage register = new RegistrastionTestPage();

		/* Handling the store locator error */
		try {
			storelistresult.getStoreresult().waitForPresent(10000);
		} catch (Exception e) {
			try {
				if (appcrash.getExceptionLblStoreLocError().isPresent()) {
					PerfectoUtils.reportMessage("Store Location Error: Unable to search for stores. Please try again.");
					if (appcrash.getExceptionLblContinueWithoutStore().isPresent()) {
						appcrash.getExceptionLblContinueWithoutStore().click();
					} else if (appcrash.getExceptionBtnOk().isPresent()) {
						appcrash.getExceptionBtnOk().click();
					} else {
						PerfectoUtils.reportMessage("Not clicked any option in Store location error pop up", MessageTypes.Info);
					}
				} else if (register.getLblErrmsgonturnstore().isPresent()) {
					appcrash.getExceptionBtnOk().click();
				} else if (weeklygrocery.getShopingListEntryByLable("access your location").isPresent()) {
					PerfectoUtils.reportMessage("Allowing H-E-B to access device location", MessageTypes.Info);
					ioscommon.getAppPopupBtnAllowPermission().verifyPresent();
					ioscommon.getAppPopupBtnAllowPermission().click();
				}
			} catch (Exception f) {
				e.printStackTrace();
			}
		}
	}

	public void clickKeyboardDoneIcon() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		Object result2 = (String) ioscommon.getTestBase().getDriver().executeScript("mobile:checkpoint:text", params1);
		if (result2.equals("true")) {
			try {
				// click search button on keyboard
				Map<String, Object> param4 = new HashMap<>();
				param4.put("keySequence", "KEYBOARD_DONE");
				PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param4);
			} catch (Exception g) {
				try {
					params1.put("Timeout", "20");
					Object result1 = ioscommon.getTestBase().getDriver().executeScript("mobile:text:select", params1);
				} catch (Exception e) {
					try {
						Map<String, Object> params3 = new HashMap<>();
						params3.put("content", "Done");
						params3.put("profile", "DocumentConversion_Speed");
						params3.put("analysis", "manual");
						params3.put("inverse", "yes");
						params3.put("screen.top", "69%");
						params3.put("screen.height", "31%");
						params3.put("screen.left", "51%");
						params3.put("screen.width", "49%");
						params3.put("Timeout", "20");
						Object result1 = ioscommon.getTestBase().getDriver().executeScript("mobile:text:select",
								params3);
					} catch (Exception f) {
						PerfectoUtils.reportMessage("Error Occured while Clicking Done button.", MessageTypes.Fail);
					}
				}
			}
		}
	}

	public static void scrollToItemInList(String strname) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		int i = 0;
		int intX = 0;
		/*
		 * int intStartY = 188; int intEndY = 128;
		 */

		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * 0.90);
		int intEndY = (int) (size.height * 0.85);
		do {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 1);
			try {
				weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
		} while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20);
	}

	/**
	 * Validating the error message for invalid product.
	 */
	@QAFTestStep(description = "I validate the error message for invalid product")
	public void iValidateTheErrorMessageForInvalidProduct() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();
		IoscommonTestPage iocCommonTestPage = new IoscommonTestPage();

		String message = productlanding.getLblErrmsg().getText();

		if (productlanding.getLblErrmsg().isPresent()) {
			PerfectoUtils.reportMessage("Error: " + message + " for search term", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Able to see the searched product", MessageTypes.Fail);
		}
		iocCommonTestPage.getAppBtnBackIOS().click();
	}

	/**
	 * Validation of refine filter options.
	 */
	@QAFTestStep(description = "I validate the refine filter options")
	public void iValidateTheRefineFilterOptions() {
		ProductsearchresultTestPage productsearchresult = new ProductsearchresultTestPage();
		RefineTestPage refine = new RefineTestPage();

		/* Clicking on Filter icon */
		productsearchresult.getProdsearchresultTxtFiltericon().verifyPresent();
		productsearchresult.getProdsearchresultTxtFiltericon().click();

		/* Selecting the filter */
		refine.waitForPageToLoad();
		refine.getRefineTxtPagetitle().verifyPresent();		
		int i=0;		
		do { 			
			PerfectoUtils.verticalswipe();;
			i++;
		} while (!refine.getRefineBtnAtoz().isPresent() && i<=15);		
		refine.getRefineBtnAtoz().click();
		refine.getBtnRefine().verifyPresent();
		refine.getBtnRefine().click();

		/* Verifying the Filter */
		productsearchresult.getProdsearchresultTxtPagetitle().waitForPresent(7000);
		if (productsearchresult.getProdsearchresultTxtPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Filter is selected successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Filter is not selected successfully", MessageTypes.Fail);
		}
	}

	public static void scrollToElement(String strname) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		int intX = 50;
		/*
		 * int intStartY = 188; int intEndY = 128;
		 */
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * 0.80);
		int intEndY = (int) (size.height * 0.75);

		PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 2);

		while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20) {
			/* Swiping till half of the page */
			PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, 2);
			try {
				if (weeklygrocery.getShopingListEntryByLable(strname).isPresent()) {
					weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
		}
	}

	public static void scrollToListNameInMyList(String strname, float startSize, float endSize, int swipeDuration) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		int intX = 0;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));
		do {

			if (weeklygrocery.getShopingListEntryByLable(strname).isPresent()) {
				PerfectoUtils.reportMessage("Found: " + strname, MessageTypes.Pass);
				break;
			} else {
				PerfectoUtils.getAppiumDriver().swipe(intX, intStartY, intX, intEndY, swipeDuration);
			}
			i++;
		} while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20);
	}

	public static void halfpageverticalswipe() {

		Dimension size = getAppiumDriver().manage().window().getSize();
		System.out.println("Swiping...");
		int starty = (int) (size.height * 0.30);
		int endy = (int) (size.height * 0.20);
		int startx = size.width / 2;
		getAppiumDriver().swipe(startx, starty, startx, endy, 1);
	}

	/**
	 * Validation of Share page
	 */
	@QAFTestStep(description = "I validate share page")
	public void iValidateSharePage() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		if (!couponsdetailspage.getLblShareemail().isPresent()) {
			PerfectoUtils.reportMessage("Email is not installed in the device", MessageTypes.Info);
		} else {
			couponsdetailspage.getLblShareemail().verifyPresent();
		}
		if (!couponsdetailspage.getLblSharegmail().isPresent()) {
			PerfectoUtils.reportMessage("Email is not installed in the device", MessageTypes.Pass);
		} else {
			couponsdetailspage.getLblShareemail().verifyPresent();
		}

		if (!couponsdetailspage.getLblSharefacebook().isPresent()) {
			PerfectoUtils.reportMessage("Facebook is not installed in the device", MessageTypes.Info);
		} else {
			couponsdetailspage.getLblSharefacebook().verifyPresent();
		}
		if (couponsdetailspage.getLblSharecancel().isPresent()) {
			couponsdetailspage.getLblSharecancel().click();
		}
	}

	/**
	 * Validating the Hint text for all fields in Login Page - NA for iOS
	 */
	@QAFTestStep(description = "I validate hint is available for all text fields in login page")
	public void iValidateHintIsAvailableForAllTextFieldsInLoginPage() {

		PerfectoUtils.reportMessage("Step not applicable for iOS.", MessageTypes.Pass);
	}

	/**
	 * Clicking on search field from home page.
	 */
	@QAFTestStep(description = "I click on search field from homepage")
	public void iClickOnSearchFieldFromHomepage() {
		HomeTestPage homepage = new HomeTestPage();

		homepage.getImgSearchicon().waitForPresent(5000);
		homepage.getImgSearchicon().click();
		PerfectoUtils.reportMessage("Clicked on search field from homepage.", MessageTypes.Pass);
	}

	/**
	 * Injecting Image. Clicking on Scan Receipts. Stop Image Injection.
	 */
	@QAFTestStep(description = "I navigate and scan the receipt from Scan Receipt screen")
	public void iNavigateAndScanTheReceiptFromScanReceiptScreen() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		ScannerTestPage scanner = new ScannerTestPage();

		/* Setting the image to "Scan" */
		String repositoryFile = ConfigurationManager.getBundle().getString("scanner.reporitoryimage.scanreceipts");
		String appName = ConfigurationManager.getBundle().getString("app.name");

		PerfectoUtils.imageInjection(repositoryFile, appName);

		/* Clicking on "Scan Receipts" button */
		if (ioscommon.getScanTxtScanreceipt().isPresent()) {
			ioscommon.getScanTxtScanreceipt().click();
			PerfectoUtils.reportMessage("Navigated to Scan Receipts page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Scan Receipt button not found.", MessageTypes.Fail);
		}

		/* Checking whether the "Enable camera" pop-up is present */
		try {
			if (ioscommon.getScanBtnOkEnablecamera().isPresent()) {
				ioscommon.getScanBtnOkEnablecamera().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		/* Stopping Image Injection */
		PerfectoUtils.stopimageinjection();

		/* Handling the error pop-ups */
		if (scanner.getLblProductnotfound().isPresent()) {
			PerfectoUtils.reportMessage("Product not found!", MessageTypes.Info);
			if (scanner.getBtnCancelproductnotfound().isPresent()) {
				scanner.getBtnCancelproductnotfound().click();
			} else if (scanner.getBtnOkproductnotfound().isPresent()) {
				scanner.getBtnOkproductnotfound().click();
			}
		} else if (scanner.getLblNorecipesfound().isPresent()) {
			PerfectoUtils.reportMessage("No Recipes found!", MessageTypes.Fail);
			scanner.getBtnOknorecipesfound().click();

		}
	}

	public static void scrollToFacts(String strname, float startSize, float endSize, int swipeDuration) {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		int i = 0;
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = (int) (size.width * (50 / 100));
		int intStartY = (int) (size.height * (startSize / 100));
		int intEndY = (int) (size.height * (endSize / 100));
		try {
			PerfectoUtils.getAppiumDriver().scrollTo(strname);
			weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
		} catch (Exception e1) {
			do {

				/* Swiping till half of the page */
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intStartX, intEndY, swipeDuration);
				try {
					weeklygrocery.getShopingListEntryByLable(strname).waitForPresent(6000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				i++;
			} while (!weeklygrocery.getShopingListEntryByLable(strname).isPresent() && i < 20);
		}
	}

	/**
	 * Validation of Email content. Verification of Gmail.
	 */
	@QAFTestStep(description = "I validate email content")
	public void iValidateEmailContent() {
		SendemailTestPage emailpage = new SendemailTestPage();
		IOSStepdefproducts iosstep = new IOSStepdefproducts();

		if (emailpage.getSendemailLblPageheader().isPresent()) {
			emailpage.waitForPageToLoad();
			emailpage.getSendemailLblPageheader().verifyPresent();
			emailpage.getSendemailEdtSendername().verifyPresent();
			emailpage.getSendemailEdtSenderemail().verifyPresent();
			emailpage.getSendemailEdtRecipientemail().verifyPresent();
			emailpage.getSendemailEdtMessage().verifyPresent();
			emailpage.getSendemailChkSendmecopy().verifyPresent();
			emailpage.getSendemailBtnCancel().verifyPresent();
			PerfectoUtils.verticalswipe();
			emailpage.getSendemailBtnSubmit().waitForPresent(5000);
			emailpage.getSendemailBtnSubmit().verifyPresent();
		} else {
			try {
				iosstep.iVerifyGmailContent();
			} catch (Exception e) {
				CommonSteps.validaterrormessages("H-E-B product:", emailpage.getSendemailLblPageheader());
				CommonSteps.validaterrormessages("https://openapi.uat.heb.com:443/product-detail/",
						emailpage.getSendemailLblPageheader());
			}
		}
	}

	/**
	 * Verification of Social media contents.
	 */
	@QAFTestStep(description = "I validate content of social media")
	public void iValidateContentOfSocialMedia() {
		ShareTestPage sharepage = new ShareTestPage();
		String msg = null;

		if (sharepage.getLblPleaselogin().isPresent()) {
			msg = sharepage.getLblPleaselogin().getText();
			PerfectoUtils.reportMessage(msg, MessageTypes.Fail);
			sharepage.getBtnOk().click();
		} else {
			CommonSteps.validaterrormessages("Cancel", sharepage.getBtnCancel());
			CommonSteps.validaterrormessages("Facebook", sharepage.getLblTitle());
		}

	}

	/**
	 * Navigation to Social media page.
	 */
	@QAFTestStep(description = "I navigate to social media page")
	public void iNavigateToSocialMediaPage() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsdetailspage.waitForPageToLoad();
		
		if (!couponsdetailspage.getLblSharefacebook().isPresent())			
		{
		PerfectoUtils.rightSwipe();
		}
		
		if (!couponsdetailspage.getLblSharefacebook().isPresent()) {
			PerfectoUtils.reportMessage("Unable to see Facebook icon!!Please check facebook is not installed in the device",
					MessageTypes.Fail);
		} else {
			couponsdetailspage.getLblSharefacebook().click();
			couponsdetailspage.getLblSharefacebook().waitForNotPresent(3000);
		}
	}

	/**
	 * Navigation to Email page.
	 */
	@QAFTestStep(description = "I navigate to email page")
	public void iNavigateToEmailPage() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		if (couponsdetails.getLblShareemail().isPresent()) {
			PerfectoUtils.reportMessage("Email is installed in the device", MessageTypes.Info);
			PerfectoUtils.swipeIfInRightmost(couponsdetails.getLblShareemail());
			couponsdetails.getLblShareemail().waitForPresent(3000);
			couponsdetails.getLblShareemail().click();
			PerfectoUtils.reportMessage("Clicking on Email option.", MessageTypes.Pass);
			couponsdetails.getLblShareemail().waitForNotPresent(3000);
		} else {
			try {
				swipeAndCheckEmail();
				if (couponsdetails.getLblShareemail().isPresent()) {
					PerfectoUtils.reportMessage("Email is installed in the device", MessageTypes.Info);
					couponsdetails.getLblShareemail().click();
					PerfectoUtils.reportMessage("Clicking on Email option.", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Email option not available. Checking for Gmail option..", MessageTypes.Pass);
					clickOnGmailIfAvailable();
				}

			} catch (NumberFormatException e) {
				PerfectoUtils.reportMessage("Email option not found. Checking for Gmail option..", MessageTypes.Pass);
				/* Clicking on Gmail if available */
				clickOnGmailIfAvailable();
			}
		}
	}

	public static void swipeAndCheckEmail() {
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		PerfectoUtils.reportMessage("Swiping and checking for Email option...");

		/* Swiping horizontally to check whether Email is available */
		Dimension size = getAppiumDriver().manage().window().getSize();
		int intStartX = Integer.parseInt(couponsdetails.getLblReminders().getAttribute("X"));
		int intEndX = (int) (size.width * 0.90);
		int intStartY = Integer.parseInt(couponsdetails.getLblReminders().getAttribute("Y"));
		getAppiumDriver().swipe(intEndX, intStartY, intStartX, intStartY, 1);
	}

	public void clickOnGmailIfAvailable() {
		ProductdetailTestPage pdppage = new ProductdetailTestPage();

		if (pdppage.getlblGmail().isPresent()) {
			PerfectoUtils.reportMessage("Gmail is installed in the device", MessageTypes.Pass);
			pdppage.getlblGmail().click();
			PerfectoUtils.reportMessage("Clicked on Gmail option.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email and Gmail are not installed in the device", MessageTypes.Fail);
		}
	}

	/**
	 * Verification of Search product text in search product screen.
	 */
	@QAFTestStep(description = "I should see the Search Products screen")
	public void iShouldSeeTheSearchProductsScreen() {
		ProductlandingTestPage productlanding = new ProductlandingTestPage();

		productlanding.getProductsTxtEntersearchtext().waitForPresent(5000);
		productlanding.getProductsTxtEntersearchtext().verifyPresent();
	}

	/**
	 * Updating Email as a hot user. Handling the login Error
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a hot user for Email update")
	public void iAmAHotUserForEmailUpdate() throws Exception {
		HomeTestPage home = new HomeTestPage();
		IoscommonTestPage iosCommonPage = new IoscommonTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		String username = getBundle().getString("hebhotuser.emailchangeuser.email");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");

		getBundle().setProperty("CurrentPassword", pswd);

		// Allow permission pop-up handle
		if (iosCommonPage.getAppPopupBtnAllowPermission().isPresent()) {
			iosCommonPage.getAppPopupBtnAllowPermission().click();
			PerfectoUtils.reportMessage("Allow button clicked in Permission pop-up notification");
		}

		try {
			checkPreLogin();
		} catch (Exception e) {
			handlePopup();
			checkPreLogin();
		}

		/* Logging in the application */
		if (home.getHomeLblSignin().isPresent()) {
			System.out.println("Logging in the Application");
			home.getHomeLblSignin().click();

			loginsplash.getLoginTxtEmail().waitForPresent(5000);
			loginsplash.getLoginTxtEmail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(username);
			loginsplash.getLoginTxtPassword().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(pswd);
			IOSStepdef.clickKeyboardDone();
			loginsplash.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);

			/* Handling the login Error in iOS */
			try {
				handleloginerror();
				/* Entering the alternate Email- If the login gets failed */
				enteringTheAlternateEmailAndLogIn();
			} catch (Exception e) {
				if (loginsplash.getLoginBtnLogin().isPresent()) {
					loginsplash.getLoginBtnLogin().click();
					PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);
				}

				/* Entering the alternate Email- If the login gets failed */
				enteringTheAlternateEmailAndLogIn();
			}
			home = loginsplash.select();
		} else {
			PerfectoUtils.reportMessage("Error occured while logging in.", MessageTypes.Fail);
		}
	}

	public void enteringTheAlternateEmailAndLogIn() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		HomeTestPage home = new HomeTestPage();

		String alternateEmail = "";
		String username = getBundle().getString("hebhotuser.emailchangeuser.email");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");

		try {
			home.getHomeLblWelcomeUser().waitForPresent(10000);
			PerfectoUtils.reportMessage("Login successful.", MessageTypes.Pass);
		} catch (Exception e) {

			clickingOkFromThePopup();

			/* Entering the alternate Email and logging in */
			PerfectoUtils.reportMessage("Loggin in again with the alternate Username.", MessageTypes.Pass);

			if (username.contains("1")) {
				alternateEmail = username.replaceAll("1@heb.com", "@heb.com");
			} else {
				alternateEmail = username.replaceAll("@heb.com", "1@heb.com");
			}

			loginsplash.getLoginTxtEmail().waitForPresent(5000);
			loginsplash.getLoginTxtEmail().click();
			loginsplash.getLoginTxtEmail().sendKeys("");
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(alternateEmail);
			loginsplash.getLoginTxtPassword().click();
			loginsplash.getLoginTxtPassword().sendKeys("");
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(pswd);
			IOSStepdef.clickKeyboardDone();
			loginsplash.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked on Login button.", MessageTypes.Pass);

			/* Validating whether Login is successful or not */
			if (home.getHomeLblWelcomeUser().isPresent()) {
				PerfectoUtils.reportMessage("Login Successful.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Login failed.", MessageTypes.Pass);
			}

		}
	}

	private void clickingOkFromThePopup() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		if (appCrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Popup found. Clicking OK button.", MessageTypes.Pass);
			appCrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Clicked OK button.");
		} else if (appCrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Popup found. Clicking Ok button.", MessageTypes.Pass);
			appCrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Clicked Ok button.");
		}
	}

	/**
	 * Clicking on Cancel button.
	 */
	@QAFTestStep(description = "I click on Cancel/ device back button")
	public void iClickOnCancelDeviceBackButton() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		/* Clicking device back button */
		changepswd.getChangepswdBtnBackIOS().waitForPresent(10000);
		changepswd.getChangepswdBtnBackIOS().click();
		PerfectoUtils.reportMessage("Done.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Continue without registering link.
	 */
	@QAFTestStep(description = "I click Continue without registering link/Cancel button")
	public void iClickContinueWithoutRegisteringLink() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		loginsplash.getLoginLblContinue().waitForPresent(5000);
		loginsplash.getLoginLblContinue().verifyPresent();
		loginsplash.getLoginLblContinue().click();
		PerfectoUtils.reportMessage("Clicked Continue without registering link..");

	}

	/**
	 * Validation the sections in more page.
	 */
	@QAFTestStep(description = "I validate sections in more/help page")
	public void iValidateSectionsInMoreHelpPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		/* Validating the Top sections */
		PerfectoUtils.reportMessage("Validating the More screen as a cold user.", MessageTypes.Pass);
		myaccount.getBtnSignin().verifyPresent();
		ioscommon.getAppMoreRegister().verifyPresent();

		/* Validating the bottom sections */
		myaccount.getBtnFaqs().verifyPresent();
		myaccount.getBtnPrivacypolicy().verifyPresent();
		PerfectoUtils.verticalswipe(80, 75, 2);
		myaccount.getBtnTermsncondtn().verifyPresent();
		myaccount.getLblRatethisapp().verifyPresent();
		myaccount.getLblContactus().verifyPresent();
	}

	public void handleSkip() {
		IoscommonTestPage iosfun = new IoscommonTestPage();

		if (iosfun.getAppBtnSkip().isPresent()) {
			PerfectoUtils.reportMessage("Clicking on Skip button to see login splash page", MessageTypes.Pass);
			iosfun.getAppBtnSkip().click();
			PerfectoUtils.reportMessage("Clicked Skip button.", MessageTypes.Info);
		}
	}

	public void iOSLogout() {
		HomeTestPage homepage = new HomeTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		int i = 0;
		String checklogin = homepage.getHomeLblWelcomeUser().getAttribute("name");
		if (checklogin.contains("Hi")) {
			homepage.getHomeLblWelcomeUser().click();

			while ((!myaccount.getBtnMystore().isPresent()) && (i < 5)) {
				ioscommon.getAppBtnBackIOS().click();
				i++;
			}
			/* Scrolling to make the "Log Out" button visible */
			PerfectoUtils.scrollToLogoutInIos();
			myaccount.getBtnLogout().waitForPresent(8000);

			if (myaccount.getBtnLogout().isPresent()) {
				myaccount.getBtnLogout().click();
				PerfectoUtils.reportMessage("Clicked Log Out button.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Logout button is not displayed.", MessageTypes.Fail);
			}
			homepage.getAppFooterHomeicon().click();

		}
	}

	/**
	 * Clicking on Register button form More option.
	 */
	@QAFTestStep(description = "I click Register button from Hamburger or More")
	public void iClickRegisterButtonFromHamburger() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		RegistrastionTestPage registrationpage = new RegistrastionTestPage();

		ioscommon.getAppFooterMore().waitForPresent(3000);
		ioscommon.getAppFooterMore().click();
		PerfectoUtils.reportMessage("Clicked on More..");
		ioscommon.getAppMoreRegister().waitForPresent(2000);
		ioscommon.getAppMoreRegister().verifyPresent();
		ioscommon.getAppMoreRegister().click();
		PerfectoUtils.reportMessage("Clicked on Register button..");

		if (registrationpage.getRegistrationTxtEmail().isPresent())
			PerfectoUtils.reportMessage("Registration page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Registration page is not displayed", MessageTypes.Fail);

	}

	/**
	 * Verification of more page.
	 */
	@QAFTestStep(description = "I validate the Orginating page browse")
	public void iValidateTheOrginatingPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppMoreMore().waitForPresent(3000);
		if (ioscommon.getAppMoreMore().isPresent())
			PerfectoUtils.reportMessage("More Page is displayed..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("More Page is not displayed..", MessageTypes.Fail);
	}

	public static void checkPreLogin() throws Exception {
		HomeTestPage home = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		RegistrastionTestPage register = new RegistrastionTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		/* Checking for Pre-login */
		System.out.println("Checking for Pre-login");

		if (home.getHomeLblSignin().isPresent()) {
			PerfectoUtils.reportMessage("User is in Home page.");

		} else if (home.getHomeLblWelcomeUser().isPresent()) {
			PerfectoUtils.reportMessage("User already Logged in . Hence logout and login again");
			iValidateLogout();
			home.getAppFooterHomeicon().click();
			home.getHomeLblSignin().waitForPresent(5000);

		} else if (loginsplash.getLoginTxtEmail().isPresent()) {
			PerfectoUtils.reportMessage("User is in Login Splash page.");
			loginsplash.getLoginLblContinue().click();
			PerfectoUtils.reportMessage("Clicked continue button.");

		} else if (register.getTxtPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("User is in Registration page");
			ioscommon.getAppBtnBackIOS().click();
			loginsplash.getLoginLblContinue().click();
			home.getAppFooterHomeicon().waitForPresent(5000);
			home.getAppFooterHomeicon().click();
		} else {

			throw new Exception();

		}
	}

	private static void handleloginerror() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		/* Handling the login Error in iOS */
		if (appCrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Popup found. Clicking OK button.", MessageTypes.Pass);
			appCrash.getExceptionBtnOk().click();
			clickLoginbutton();
		} else {
			PerfectoUtils.reportMessage("No Login error found..");
			clickLoginbutton();
		}
	}

	public static void clickLoginbutton() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		try {
			if (loginsplash.getLoginBtnLogin().isPresent()) {
				loginsplash.getLoginBtnLogin().click();
				PerfectoUtils.reportMessage("Clicked Login button again.");
			}
		} catch (Exception e) {
			ioscommon.getAppLblLoading().waitForNotPresent(8000);
		}
	}

	public static void clickKeyboardDone() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");

		String isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnDoneVisible1.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);
		}

		if (isBtnDoneVisible1.equalsIgnoreCase("true")) {
			myprofile.getTestBase().getDriver().executeScript("mobile:text:select", params1);
		} else {
			PerfectoUtils.reportMessage("Performing press key command");
			try {
				Map<String, Object> param2 = new HashMap<>();
				param2.put("keySequence", "KEYBOARD_DONE");
				PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param2);
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Done button is not available in the Keyboard");
			}
		}
	}

	/**
	 * Logging as a hot user from guest user
	 * 
	 * @param username
	 * @param pswd
	 */
	@QAFTestStep(description = "I am logging in as a hot user using {0}{1} credential from guest user")
	public void iAmLoggingInAsAHotUserUsingCredentialFromGuestUser(String username, String pswd) {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		getBundle().setProperty("CurrentPassword", pswd);

		if (loginsplash.getLoginTxtEmail().isPresent()) {
			System.out.println("Logging in the Application");

			loginsplash.getLoginTxtEmail().waitForPresent(5000);
			loginsplash.getLoginTxtEmail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(username);
			loginsplash.getLoginTxtPassword().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(pswd);
			PerfectoUtils.reportMessage("Entered username and password.");
			IOSStepdef.clickKeyboardDone();
			loginsplash.getLoginBtnLogin().verifyPresent();
			loginsplash.getLoginBtnLogin().click();
			PerfectoUtils.reportMessage("Clicked Login button.");

			handleloginerror();
			checkloginerror();

		} else
			PerfectoUtils.reportMessage("Login splash page is not displayed..", MessageTypes.Fail);
	}

	/**
	 * Scanning the product from scan products screen.
	 * 
	 * @param repositoryFile
	 */
	@QAFTestStep(description = "I navigate and scan the item {0} from scan products screen")
	public static void iNavigateAndScanTheItemFromScanProductsScreen(String repositoryFile) {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		RecipeslandingTestPage recipe = new RecipeslandingTestPage();
		ScannerTestPage scanner = new ScannerTestPage();

		/* Setting the image to "Scan" */
		String appName = ConfigurationManager.getBundle().getString("app.name");

		PerfectoUtils.imageInjection(repositoryFile, appName);

		/* Clicking on "Scan Products" button */
		if (ioscommon.getHeaderBtnScanProducts().isPresent()) {
			ioscommon.getHeaderBtnScanProducts().click();
		} else {
			PerfectoUtils.reportMessage("Scan Products button not found, hence clicking on scanner button.", MessageTypes.Info);
			recipe.getBtnScaninsearchbox().isPresent();
			recipe.getBtnScaninsearchbox().click();
		}

		// Checking for the allow camera pop-up
		if (scanner.getLblAccesscamerapopuptitle().isPresent()) {
			PerfectoUtils.reportMessage("Allow camera popup found.", MessageTypes.Pass);
			scanner.getBtnAccesscamerapopupok().waitForPresent(5000);
			scanner.getBtnAccesscamerapopupok().click();
			PerfectoUtils.reportMessage("Clicked Ok button from the Allow Camera popup.", MessageTypes.Pass);
		}

		// Checking whether the "Enable camera" pop-up is present
		try {
			if (scanner.getLblEnablecamerapopuptitle().isPresent()) {
				PerfectoUtils.reportMessage("Enable Camera popup found.", MessageTypes.Pass);
				ioscommon.getScanBtnOkEnablecamera().click();
				PerfectoUtils.reportMessage("Please Enable Camera in Settings and try again.", MessageTypes.Fail);
			} else if (scanner.getLblNorecipefoundpopuptitle().isPresent()) {
				PerfectoUtils.reportMessage("No recipes found.", MessageTypes.Pass);
				scanner.getBtnNorecipefoundpopupok().click();
				PerfectoUtils.reportMessage("Please check the Wi-Fi connection is turned on (or) the scanned barcode is a valid one",
						MessageTypes.Fail);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Stopping Image injection
		PerfectoUtils.stopimageinjection();
	}

	/**
	 * Logging as a cold user.Changing the environment
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I change the prod environment in IOS")

	public void iosEnvironmentChange() throws Exception {

		HomeTestPage homepage = new HomeTestPage();
		IoscommonTestPage iosCommonPage = new IoscommonTestPage();
		String envi = "prod";
		handleSkip();
		checkPreLogin();
		System.out.println("Setting condition for cold user");

		// Allow permission pop up handle
		if (iosCommonPage.getAppPopupBtnAllowPermission().isPresent()) {
			iosCommonPage.getAppPopupBtnAllowPermission().click();
			PerfectoUtils.reportMessage("Allow button clicked in Permission pop-up notification");
		}

		// Logging in as a Cold user
		if (homepage.getHomeLblSignin().isPresent()) {
			System.out.println("Logged in as a cold user");
			PerfectoUtils.reportMessage("Logged in as a Cold user.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User already Logged in . Hence logout and login again", MessageTypes.Info);
			iValidateLogout();
			homepage.getAppFooterHomeicon().click();
			homepage.getHomeLblSignin().waitForPresent(3000);
			System.out.println("Logged in as a cold user");
		}

		// Change the environment
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "More");
		Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params1);

		try {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Environment");
			Object result2 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params2);
		} catch (Exception e) {
			e.printStackTrace();
			PerfectoUtils.verticalswipe();
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Environment");
			Object result2 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params2);

		}

		Map<String, Object> params3 = new HashMap<>();
		params3.put("content", "Networking");
		Object result3 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params3);

		Map<String, Object> params4 = new HashMap<>();
		params4.put("content", "Environment");
		Object result4 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params4);

		if (envi.contains("prod") || envi.contains("Prod") || envi.contains("Production")
				|| envi.contains("production")) {
			Map<String, Object> params5 = new HashMap<>();
			params5.put("content", "Production");
			Object result5 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params5);
		} else {
			Map<String, Object> params5 = new HashMap<>();
			params5.put("content", "Certification");
			Object result5 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params5);
		}

		Map<String, Object> params6 = new HashMap<>();
		params6.put("content", "Done");
		Object result6 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params6);

		iosCommonPage.getAppMoreMore().waitForPresent(5000);
		if (iosCommonPage.getAppMoreMore().isPresent())
			PerfectoUtils.reportMessage("More page is displayed");
		else
			PerfectoUtils.reportMessage("More page is not displayed", MessageTypes.Fail);

	}

	/*
	 * @QAFTestStep(description = "I am an cold user without setting store")
	 * public void iAmAnColdUserWithoutSettingStore() {
	 * 
	 * getBundle().setProperty("setLocation", "false");
	 * 
	 * HomeTestPage homepage = new HomeTestPage(); IoscommonTestPage
	 * iosCommonPage = new IoscommonTestPage();
	 * 
	 * handleSkip(); checkPreLogin();
	 * 
	 * Allow permission pop up handle if
	 * (iosCommonPage.getAppPopupBtnAllowPermission().isPresent()) {
	 * iosCommonPage.getAppPopupBtnAllowPermission().click(); PerfectoUtils.reportMessage(
	 * "Allow button clicked in Permission pop-up notification"); }
	 * 
	 * Logging in as a Cold user if (homepage.getHomeLblSignin().isPresent()) {
	 * PerfectoUtils.reportMessage("Logged in as a Cold user.", MessageTypes.Pass); } else {
	 * PerfectoUtils.reportMessage("User already Logged in . Hence logout and login again",
	 * MessageTypes.Info); iValidateLogout();
	 * homepage.getAppFooterHomeicon().click();
	 * homepage.getHomeLblSignin().waitForPresent(3000); } }
	 */
	@QAFTestStep(description = "I verify the HEB Barcode in the home page")
	public void IverifytheHEBBarcodeinthehomepage() {
		HomeTestPage homePage = new HomeTestPage();

		if (homePage.gethomeimgNewbarcode().verifyPresent()) {
			PerfectoUtils.reportMessage("HEB Barcode is displayed", MessageTypes.Pass);

		} else {
			PerfectoUtils.reportMessage("HEB Barcode is not displayed", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I click on the HEB Barcode")
	public void IclickontheHEBBarcode() {
		HomeTestPage homePage = new HomeTestPage();
		homePage.gethomeimgNewbarcode().click();
		PerfectoUtils.reportMessage("Clicked on HEB Barcode from home page.");

	}

	@QAFTestStep(description = "I verify the My HEB Barcode page")
	public void IverifytheMyHEBBarcodepage() {
		HomeTestPage homePage = new HomeTestPage();
		String name = homePage.getHometxtBarcodedetailpage().getText();
		System.out.println(name);

		// homePage.getHometxtBarcodedetailpage().verifyPresent();
		homePage.getHomeimgBarcodemodal().verifyPresent();

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:iOS\\HomePage_Barcode\\Barcode Detail Page.png");

			String isAvailable = (String) homePage.getTestBase().getDriver().executeScript("mobile:image:find",
					params1);

			if (isAvailable.equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("My HEB Barcode page is displayed Correctly", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("My HEB Barcode page is not displayed Correctly", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error occured while Injecting Image.", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify on clicking out of the barcode modal dismisses the modal")
	public void Iverifyonclickingoutofthebarcodemodaldismissesthemodal() {
		HomeTestPage homePage = new HomeTestPage();
		homePage.getHomeimgBarcodemodal().click();
		if (homePage.gethomeimgNewbarcode().verifyPresent()) {
			PerfectoUtils.reportMessage("barcode modal dismissed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("barcode modal not dismissed", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the barcode on top of homescreen list")
	public void Iverifythebarcodeontopofhomescreenlist() {
		HomeTestPage homePage = new HomeTestPage();

		if (homePage.gethomelblHEBBarcodeHomescreenlist().isPresent()) {
			PerfectoUtils.reportMessage("barcode is displayed in home screen list", MessageTypes.Pass);
			homePage.gethomelblHEBBarcodeHomescreenlist().click();
		} else {
			PerfectoUtils.reportMessage("barcode is not displayed in home screen list", MessageTypes.Fail);

		}
	}

	@QAFTestStep(description = "I verify that HEBbarcode is not displayed in homescreen list")
	public void IverifythatHEBbarcodeisnotdisplayedinhomescreenlist() {
		HomeTestPage homePage = new HomeTestPage();
		if (!homePage.gethomelblHEBBarcodeHomescreenlist().isPresent()) {
			PerfectoUtils.reportMessage("barcode is not displayed for cold user", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("barcode is  displayed for cold user", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify the HEB Barcode is not displayed in the home page")
	public void IverifytheHEBBarcodeisnotdisplayedinthehomepage() {
		HomeTestPage homePage = new HomeTestPage();
		if (!homePage.gethomeimgNewbarcode().isPresent()) {
			PerfectoUtils.reportMessage("barcode is not displayed for cold user in the top right of home page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("barcode is displayed for cold user in the top right of home page", MessageTypes.Fail);

		}
	}

	/**
	 * Verifying the hero image
	 */
	@QAFTestStep(description = "I verify the home hero image")
	public void iVerifyTheHomeHeroImage() {
		HomeTestPage homePage = new HomeTestPage();

		if (homePage.gethomeimgheroimage().isPresent()) {
			PerfectoUtils.reportMessage("Hero Image is present at top of the home page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Hero Image is not present", MessageTypes.Fail);
		}

	}

	/**
	 * Verifying the Top slot below hero image
	 */
	@QAFTestStep(description = "I verify the top slot")
	public void iVerifyTopSlot() {
		HomeTestPage homePage = new HomeTestPage();

		if (homePage.gethomelbltopslot().isPresent()) {
			homePage.getHomeDigitalCoupon().verifyPresent();
			homePage.getHomeLblProduct().verifyPresent();
			homePage.getHomeLblWeeklyAd().verifyPresent();
			PerfectoUtils.reportMessage("Top slot is present below home image", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Top slot is not present below home image", MessageTypes.Fail);
		}

	}

	/**
	 * Verifying the sub menu order in the home page for cold user
	 */
	@QAFTestStep(description = "I verify the sub menu order as cold user")
	public void iVerifyTheSubMenuOrderAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();

		boolean orderMatch1 = false, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false;

		homePage.getLblHebBarcode().verifyNotPresent();
		homePage.getHomeLblShoppingList().verifyPresent();
		if (!homePage.getLblPharmacy().isPresent())
			PerfectoUtils.verticalswipeSlow();
		homePage.getLblPharmacy().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch1 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		PerfectoUtils.verticalswipe();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);

	}

	public boolean verifyElement1AboveElement2(QAFWebElement element1, QAFWebElement element2) {
		boolean orderMatch = true;
		if (PerfectoUtils.verifyOrderOfElements(element1, element2))
			PerfectoUtils.reportMessage(element1.getText() + " and " + element2.getText() + " order is expected");
		else {
			PerfectoUtils.reportMessage(element1.getText() + " and " + element2.getText() + " order is not expected");
			orderMatch = false;
		}
		return orderMatch;
	}

	/**
	 * Verifying the sub menu order in the home page for hot user
	 */
	@QAFTestStep(description = "I verify the sub menu order as hot user with curbside store")
	public void iVerifyTheSubMenuOrderAsHotUserWithCurbside() {
		HomeTestPage homePage = new HomeTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();
		CommonStepDefMyAccounts commonmyaccount = new CommonStepDefMyAccounts();
		StorelistviewresultTestPage storelistview = new StorelistviewresultTestPage();

		if (homePage.gethomelblcurbsidepickup().isPresent()) {
			PerfectoUtils.reportMessage("Curbside Pickup is present", MessageTypes.Pass);
		} else {
			// Selecting store for curbside pickup
			iosmyaccount.iNavigateToMyAccountPage();
			myaccount.waitForPageToLoad();

			myaccount.getBtnMystore().waitForPresent(50000);
			myaccount.getBtnMystore().click();
			PerfectoUtils.reportMessage("Clicked on My Store.", MessageTypes.Pass);

			commonmyaccount.iNavigateToTheChangeMyHEBStore();
			IOSStepDefStoreLocator.iNavigateToListViewPage();

			PerfectoUtils.scrollToElement(storelistview.getstoreloclistviewlblcurbsidestore());
			storelistview.getstoreloclistviewlblcurbsidestore().waitForPresent(5000);
			storelistview.getstoreloclistviewlblcurbsidestore().click();
			storelistview.waitForPageToLoad();
			PerfectoUtils.reportMessage("Curbside Store is selected", MessageTypes.Pass);
			homePage.getAppFooterHomeicon().click();
			homePage.getHomeLblSignin().waitForPresent(3000);
		}

		homePage.getLblCurbsidePickup().verifyPresent();

		boolean orderMatch1 = false, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false, orderMatch5 = false,
				orderMatch6 = false;

		homePage.getLblRedeemCoupon().verifyPresent();
		if ((homePage.getLblRedeemCoupon().isPresent()) && (homePage.getLblCurbsidePickup().isPresent()))
			orderMatch1 = verifyElement1AboveElement2(homePage.getLblRedeemCoupon(), homePage.getLblCurbsidePickup());

		if (!homePage.getHomeLblShoppingList().isPresent())
			PerfectoUtils.verticalswipeSlow();

		homePage.getHomeLblShoppingList().verifyPresent();

		if ((homePage.getLblCurbsidePickup().isPresent()) && (homePage.getHomeLblShoppingList().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getLblCurbsidePickup(),
					homePage.getHomeLblShoppingList());

		PerfectoUtils.verticalswipe();
		homePage.getLblPharmacy().verifyPresent();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch5 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch6 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4 && orderMatch5 && orderMatch6)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);
	}

	/**
	 * Verifying the sub menu navigate to corresponding pages for cold user
	 */
	@QAFTestStep(description = "I verify the sub menu navigations as cold user")
	public void iVerifyTheSubMenuNavigationAsColdUser() {
		HomeTestPage homePage = new HomeTestPage();
		IOSStepdefshopinglist shoppinglist = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();
		IOSStepdefrecipes recipes = new IOSStepdefrecipes();
		IoscommonTestPage iosCommonPage = new IoscommonTestPage();

		// Clicking on My List
		shoppinglist.iNavigateToMyListPage();
		ioscommon.getAppBtnBackIOS().click();

		// clicking on Pharmacy
		homePage.getLblPharmacy().waitForPresent(3000);
		homePage.getLblPharmacy().click();
		homePage.waitForPageToLoad();
		if (homePage.gethometxtpharmacy().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Pharmacy page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Pharmacy page", MessageTypes.Fail);
		}
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Store Locator
		storelocator.iNavigateToStoreLocator();
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Recipes
		recipes.iNavigateToRecipes();
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Ship to home
		homePage.getHomeLblShipToHome().waitForPresent(3000);
		homePage.getHomeLblShipToHome().click();
		iosCommonPage.getAddtolistBtnCancel().waitForPresent(3000);
		iosCommonPage.getAddtolistBtnCancel().click();
		PerfectoUtils.reportMessage("Navigated to Ship to home", MessageTypes.Pass);

	}

	/**
	 * Verifying the sub menu navigate to corresponding pages for hot user
	 */
	@QAFTestStep(description = "I verify the sub menu navigations as hot user")
	public void iVerifyTheSubMenuNavigationAsHotUserWithCurbside() {
		HomeTestPage homePage = new HomeTestPage();
		IOSStepdefshopinglist shoppinglist = new IOSStepdefshopinglist();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();
		IOSStepdefrecipes recipes = new IOSStepdefrecipes();
		IoscommonTestPage iosCommonPage = new IoscommonTestPage();

		// Clicking on My HEB Barcode
		homePage.getHometxtBarcodedetailpage().waitForPresent(3000);
		Iverifyonclickingoutofthebarcodemodaldismissesthemodal();

		// clicking on curbside pickup

		// Clicking on My List
		shoppinglist.iNavigateToMyListPage();
		ioscommon.getAppBtnBackIOS().click();

		// clicking on Pharmacy
		homePage.getLblPharmacy().waitForPresent(3000);
		homePage.getLblPharmacy().click();
		homePage.waitForPageToLoad();
		if (homePage.gethometxtpharmacy().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Pharmacy page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not Navigated to Pharmacy page", MessageTypes.Fail);
		}
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Store Locator
		storelocator.iNavigateToStoreLocator();
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Recipes
		recipes.iNavigateToRecipes();
		ioscommon.getAppBtnBackIOS().click();

		// Clicking on Ship to home
		homePage.getHomeLblShipToHome().waitForPresent(3000);
		homePage.getHomeLblShipToHome().click();
		iosCommonPage.getAddtolistBtnCancel().waitForPresent(3000);
		iosCommonPage.getAddtolistBtnCancel().click();
		PerfectoUtils.reportMessage("Navigated to Ship to home", MessageTypes.Pass);
	}

	/**
	 * Verifying the Curbside pickup on list view
	 */
	@QAFTestStep(description = "I verify the sub menu order as hot user without curbside store")
	public void iVerifyTheSubMenuOrderAsHotUserWithoutCurbside() {
		HomeTestPage homePage = new HomeTestPage();
		boolean orderMatch1 = false, orderMatch2 = false, orderMatch3 = false, orderMatch4 = false, orderMatch5 = false,
				orderMatch6 = false;

		homePage.getLblRedeemCoupon().verifyPresent();
		homePage.getLblCurbsidePickup().verifyNotPresent();
		homePage.getHomeLblShoppingList().verifyPresent();
		if ((homePage.getLblRedeemCoupon().isPresent()) && (homePage.getHomeLblShoppingList().isPresent()))
			orderMatch1 = verifyElement1AboveElement2(homePage.getLblRedeemCoupon(), homePage.getHomeLblShoppingList());

		if (!homePage.getLblPharmacy().isPresent())
			PerfectoUtils.verticalswipeSlow();

		PerfectoUtils.verticalswipe();
		homePage.getLblPharmacy().verifyPresent();
		homePage.getHomeLblStoreLocator().verifyPresent();
		homePage.getHomeLblRecipes().verifyPresent();
		homePage.getHomeLblShipToHome().verifyPresent();

		if ((homePage.getHomeLblShoppingList().isPresent()) && (homePage.getLblPharmacy().isPresent()))
			orderMatch2 = verifyElement1AboveElement2(homePage.getHomeLblShoppingList(), homePage.getLblPharmacy());

		if ((homePage.getLblPharmacy().isPresent()) && (homePage.getHomeLblStoreLocator().isPresent()))
			orderMatch3 = verifyElement1AboveElement2(homePage.getLblPharmacy(), homePage.getHomeLblStoreLocator());

		if ((homePage.getHomeLblStoreLocator().isPresent()) && (homePage.getHomeLblRecipes().isPresent()))
			orderMatch4 = verifyElement1AboveElement2(homePage.getHomeLblStoreLocator(), homePage.getHomeLblRecipes());

		if ((homePage.getHomeLblRecipes().isPresent()) && (homePage.getHomeLblShipToHome().isPresent()))
			orderMatch5 = verifyElement1AboveElement2(homePage.getHomeLblRecipes(), homePage.getHomeLblShipToHome());

		if (orderMatch1 && orderMatch2 && orderMatch3 && orderMatch4 && orderMatch5)
			PerfectoUtils.reportMessage("Sub menu order is expected..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Sub menu order is not expected..", MessageTypes.Fail);
	}

	/**
	 * Wait for lists to be visible in My list page. Select over flow icon,
	 * Select Delete option, In delete mode, select the lists, and select delete
	 * icon from pop up.
	 */
	public static void deleteFewShoppingLists() {
		MylistTestPage mylistpage = new MylistTestPage();

		mylistpage.getMyListsLblListname().get(0).waitForPresent(8000);
		int listSize = mylistpage.getMyListsLblListname().size();
		int j = 0;

		while ((listSize > 6) && (j < 5)) {
			PerfectoUtils.reportMessage(listSize + " lists available. deleting some lists..", MessageTypes.Pass);
			String listName = mylistpage.getMyListsLblListname().get(listSize - 1).getText();
			if (!listName.contains("Wish List")) {
				/* Getting the x and y co-ordinates */
				Dimension size = getAppiumDriver().manage().window().getSize();
				int intStartX = (int) (size.width * 0.90);
				int intStartY = Integer
						.parseInt(mylistpage.getMyListsLblListname().get(listSize - 1).getAttribute("Y"));
				int intEndX = Integer.parseInt(mylistpage.getMyListsLblListname().get(listSize - 1).getAttribute("X"));
				getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
				PerfectoUtils.reportMessage("Swiping across the list name: " + listName + " to delete");
				click("name=Delete");
				PerfectoUtils.reportMessage("Clicked Delete for list name: " + listName + " ");
				j++;
			} else {
				listName = mylistpage.getMyListsLblListname().get(4).getText();

				if (listName.contains("Wish List"))
					break;

				Dimension size = getAppiumDriver().manage().window().getSize();
				int intStartX = (int) (size.width * 0.90);
				int intStartY = Integer.parseInt(mylistpage.getMyListsLblListname().get(4).getAttribute("Y"));
				int intEndX = Integer.parseInt(mylistpage.getMyListsLblListname().get(4).getAttribute("X"));
				getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
				PerfectoUtils.reportMessage("Swiping across the list name: " + listName + " to delete");
				click("name=Delete");
				PerfectoUtils.reportMessage("Clicked Delete for list name: " + listName + " ");

				listName = mylistpage.getMyListsLblListname().get(3).getText();

				if (!listName.contains("Wish List")) {
					size = getAppiumDriver().manage().window().getSize();
					intStartX = (int) (size.width * 0.90);
					intStartY = Integer.parseInt(mylistpage.getMyListsLblListname().get(3).getAttribute("Y"));
					intEndX = Integer.parseInt(mylistpage.getMyListsLblListname().get(3).getAttribute("X"));
					getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 1);
					PerfectoUtils.reportMessage("Swiping across the list name: " + listName + " to delete");
					click("name=Delete");
					PerfectoUtils.reportMessage("Clicked Delete for list name: " + listName + " ");
				}
				j++;
			}
			mylistpage.getMyListsLblListname().get(0).waitForPresent(8000);
			PerfectoUtils.reportMessage("Refreshing list count");
			listSize = mylistpage.getMyListsLblListname().size();
		}
	}

	/**
	 * Clicking on Login button form More option.
	 */
	@QAFTestStep(description = "I click login button from Hamburger or More")
	public void iClickLoginButtonFromHamburger() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		LoginsplashTestPage loginspalshpage = new LoginsplashTestPage();

		ioscommon.getAppFooterMore().waitForPresent(3000);
		ioscommon.getAppFooterMore().click();
		PerfectoUtils.reportMessage("Clicked on More..");
		ioscommon.getAppMoreSigin().waitForPresent(2000);
		ioscommon.getAppMoreSigin().verifyPresent();
		ioscommon.getAppMoreSigin().click();
		PerfectoUtils.reportMessage("Clicked on Login button..");

		if (loginspalshpage.getLoginTxtEmail().isPresent())
			PerfectoUtils.reportMessage("Login page is displayed", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Login page is not displayed", MessageTypes.Fail);

	}

	/**
	 * Verify user able to navigate to home page
	 */
	@QAFTestStep(description = "I navigate to home page")
	public void iNavigateToHomePage() {
		HomeTestPage homepage = new HomeTestPage();

		homepage.getAppFooterHomeicon().verifyPresent();
		homepage.getAppFooterHomeicon().click();

		PerfectoUtils.reportMessage("Clicked home options from footer..");

	}

	/**
	 * Click on show password icon and validate
	 */
	@QAFTestStep(description = "I validate the show password functionality")
	public static void iValidateTheShowPasswordFunctionality() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		PerfectoUtils.reportMessage("Show password is NA for IOS", MessageTypes.Info);
	}

	/**
	 * user validated the coupon selection page
	 */
	@QAFTestStep(description = "I validate Coupons selection page as cold user")
	public void iValidateCouponsSelectionPageAsColdUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		System.out.println(couponsselection.getLblYouMustLoginText().getText());
		if (couponsselection.getLblYouMustLoginText().getText().contains("You must be logged in"))
			PerfectoUtils.reportMessage("You must sign in text matches...");
		else
			PerfectoUtils.reportMessage("You must sign in text not matches...", MessageTypes.Fail);

		couponsselection.getCouponsBtnLogin().verifyPresent();
		couponsselection.getCouponsBtnRegister().verifyPresent();
		int size = couponsearch.getCouponsresultLblOffercallout().size();
		couponsearch.getCouponsresultLblOffercallout().get(size - 1).verifyPresent();
		String offerLimit = couponsearch.getCouponsresultLblCouponexpire().getText();
		if (offerLimit.contains("EXPIRES"))
			PerfectoUtils.reportMessage("Coupons EXPIRES text present..");
		else
			PerfectoUtils.reportMessage("Coupons EXPIRES text not present..", MessageTypes.Fail);
		if (offerLimit.contains("LIMIT"))
			PerfectoUtils.reportMessage("Coupons LIMIT text present..");
		else
			PerfectoUtils.reportMessage("Coupons LIMIT text not present..", MessageTypes.Fail);

		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();
		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().isPresent()) {
			PerfectoUtils.reportMessage("Coupons Selection Page is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Selection Page is not applicable with the latest build", MessageTypes.Fail);
		}
	}

	/**
	 * user validated the coupon selection page as hot user
	 */
	@QAFTestStep(description = "I validate Coupons selection page as hot user")
	public void iValidateCouponsSelectionPageAsHotUser() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		couponsselection.getCouponselectionLblAllcoupons().verifyPresent();
		couponsselection.getCouponsLblCoupondesc().verifyPresent();
		if (dcAutoEnrolFlag.contains("false")) {
			if (couponsearch.getBtnsignupnow().isPresent())
				PerfectoUtils.reportMessage("Sign up not button is displayed...");
			else
				PerfectoUtils.reportMessage("Sign up not button is not displayed...");
		}
		int size = couponsearch.getCouponsresultLblOffercallout().size();
		couponsearch.getCouponsresultLblOffercallout().get(size - 1).verifyPresent();
		String offerLimit = couponsearch.getCouponsresultLblCouponexpire().getText();
		if (offerLimit.contains("EXPIRES"))
			PerfectoUtils.reportMessage("Coupons EXPIRES text present..");
		else
			PerfectoUtils.reportMessage("Coupons EXPIRES text not present..", MessageTypes.Fail);
		if (offerLimit.contains("LIMIT"))
			PerfectoUtils.reportMessage("Coupons LIMIT text present..");
		else
			PerfectoUtils.reportMessage("Coupons LIMIT text not present..", MessageTypes.Fail);

		String strTtlavailCount = couponsselection.getCouponselectionLblAllcoupons().getText();
		strTtlavailCount = strTtlavailCount.replaceAll("All Coupons", "");
		strTtlavailCount = strTtlavailCount.replaceAll("\\(", "").replaceAll("\\)", "");

		if (couponsselection.getCouponsLblAvailable().isPresent()) {
			PerfectoUtils.reportMessage("Coupons Selection Page is validated and total available coupons are: " + strTtlavailCount,
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons Selection Page is not applicable with the latest build", MessageTypes.Fail);
		}
	}

	/**
	 * This method handles the popup such as skip, software update and allow
	 * popup
	 */
	public void handlePopup() {
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		IoscommonTestPage iosfun = new IoscommonTestPage();

		if (iosfun.getAppBtnSkip().isPresent()) {
			PerfectoUtils.reportMessage("Clicking on Skip button to see login splash page", MessageTypes.Pass);
			iosfun.getAppBtnSkip().click();
			PerfectoUtils.reportMessage("Clicked Skip button.", MessageTypes.Info);
		} else if (appCrash.getAllowPopup().isPresent()) {
			appCrash.getAllowPopup().click();
			PerfectoUtils.reportMessage("Allow is enabled");
		} else if (appCrash.getSoftwareUpdatePopup().isPresent()) {
			appCrash.getSoftwareUpdateLater().click();
		}

	}

	@QAFTestStep(description = "I am a VPP user using {0}{1} credential")
	public static void iAmAVPPUserUsingCredential(String username, String pswd) throws Exception {
		HomeTestPage home = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		try {
			checkPreLogin();
		} catch (Exception e) {

			iosstepdef.handlePopup();
			checkPreLogin();

		}

		getBundle().setProperty("CurrentPassword", pswd);

		if (home.getHomeLblSignin().isPresent()) {
			home.getHomeLblSignin().click();

			loginsplash.getLoginTxtEmail().waitForPresent(5000);
			loginsplash.getLoginTxtEmail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(username);
			loginsplash.getLoginTxtPassword().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(pswd);
			PerfectoUtils.reportMessage("Entered username and password.");
			IOSStepdef.clickKeyboardDone();
			loginsplash.getLoginBtnLogin().verifyPresent();
			loginsplash.getLoginBtnLogin().click();

			PerfectoUtils.reportMessage("Clicked Login button.");

			handleloginerror();
			checkloginerror();
			home = loginsplash.select();
		} else {
			PerfectoUtils.reportMessage("Error occured while logging in.", MessageTypes.Fail);
		}
	}

	/**
	 * LinkView for donations page second item
	 */
	@QAFTestStep(description = "Verify donations Second item in the list")
	public void verifyDonationsSecondItemInTheList() {
		HomeTestPage homePage = new HomeTestPage();

		int donations = homePage.getHomeMenuList().size();
		String donation = homePage.getHomeMenuList().get(donations - 2).getText();

		if (donation.equalsIgnoreCase("Sutherland Springs Donations"))
			PerfectoUtils.reportMessage("Donations Second item in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Donations not Second item in the list", MessageTypes.Fail);
	}

	/**
	 * LinkView for donations page first item
	 */
	@QAFTestStep(description = "Verify donations first item in the list")
	public void verifyDonationsFirstItemInTheList() {
		HomeTestPage homePage = new HomeTestPage();

		int donations = homePage.getHomeMenuList().size();
		System.out.println("Size of the List *****"+ donations);
		String donation = homePage.getHomeMenuList().get(donations-1).getText();
		System.out.println("Name *****"+ donation);
		if (donation.equalsIgnoreCase("Sutherland Springs Donations"))
			PerfectoUtils.reportMessage("Donations first item in the list", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Donations not first item in the list", MessageTypes.Fail);
	}

	/**
	 * This functionality is only applicable for Android 
	 */
	@QAFTestStep(description = "Verify donations in the left nav drawer")
	public void verifyDonationsInTheLeftNavdDrawer() {
		
		PerfectoUtils.reportMessage("This functionality not applicable in iOS ",MessageTypes.Pass);
	}
}
