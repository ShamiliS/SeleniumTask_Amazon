package com.heb.automation.ios.steps.coupons;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Dimension;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.components.Couponssearchresult;
import com.heb.automation.common.components.ListDetails;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.ShareTestPage;
import com.heb.automation.common.pages.coupons.CouponsdetailsTestPage;
import com.heb.automation.common.pages.coupons.CouponsemailTestPage;
import com.heb.automation.common.pages.coupons.CouponssearchresultTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.products.ProductdetailTestPage;
import com.heb.automation.common.pages.recipes.RecipedetailTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.shoppinglist.ListdetailsTestPage;
import com.heb.automation.common.pages.shoppinglist.SendemailTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.steps.coupons.CommonStepDefCoupons;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.heb.automation.ios.steps.shoppinglist.IOSStepdefshopinglist;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in Coupons

	I click Selected option in Details page
	I see Coupons page
	I see All Coupons page
	I see Search products page
	I add all the coupons to the shopping list
	I click on Add/Done button from the popup
	I should see the list of Coupons in the selected list page
	I add the coupon to the shopping list
	I navigate to Selected Savings tab
	I see Registration detail page
	I click on Search
	I click on Login from coupons landing page
	I select a coupon
	I navigate back to Coupons page from registration page
	I navigate to login page after clicking login button
	I navigate back to Coupons page from login page
	I verify Login/Submit message
	I should see the coupons selection page
	I select multiple available coupon
	I select an option from the sort popup
	I verify the sort option is not present
	I should see coupons selection page
	I validate selected coupons available in selected savings
	I select an different sort option from the sort popup
	I see No result for invalid coupons
	I send coupon by entering all mandatory field in email page
	I select coupons from Selected Savings tab
	I validate the filtered coupons selection page
	I verify the added coupons
	I navigate to Coupons page from footer
	I click on Cancel button
	I click on Login from coupons selection page
	I click on Login/Submit button from the popup
	I select an category from the coupons dropdown
	I validate register and Login button in coupons detail page
	I navigate to Selected Savings tab as a cold user
	I select coupons by clicking SELECT ALL
	I click on Unselecet All option and select single coupon
	I click share button
	I add the selected coupon to list
	I verify add to list options in selected savings tab
	Verify the Read more functionality
	Verify the Read more functionality not present
	I verify the coupons getting displayed
	I click clear from search result
	I verify counpon landing page is displayed
	I verify add to list and select button
	I see All Coupons are checked
	I see All coupons are unchecked
	I validate Selected Savings tab
	I enter mandatory field for cold user and click on Send button
	I note down the list name
	I select Select All button*/

public class IOSStepdefCoupons {

	/**
	 * Clicks on SELECT Button from Coupons Details page
	 */
	@QAFTestStep(description = "I click Selected option in Details page")
	public void iClickSelectedOptionInDetailsPage() {
		CouponsdetailsTestPage couponsdetail = new CouponsdetailsTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();

		couponsdetail.getCoupondetailsBtnSelect().waitForPresent(5000);
		couponsdetail.getCoupondetailsBtnSelect().click();

		try {
			appCrash.getExceptionBtnOk();
			PerfectoUtils.reportMessage("Digital Coupons error: Unable to clip Coupon at this time. Please try again");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifies whether the user navigated to the Coupons page. i.e. Verifying
	 * the page title
	 */
	@QAFTestStep(description = "I see Coupons page")
	public void iSeeCouponsPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		appcrash.waitForPageToLoad();

		if (appcrash.getExceptionBtnOk().isPresent()) {
			PerfectoUtils.reportMessage("Server issue", MessageTypes.Fail);
		}

		if (appcrash.getExceptionSkipCoupons().isPresent()) {
			appcrash.getExceptionSkipCoupons().click();
		}
		try {
			couponsselection.getCouponsLblPgtitlecoupons().waitForPresent(50000);
		} catch (Exception e) {
			// ignore
		}
		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			couponsselection.getCouponsLblPgtitlecoupons().verifyPresent();
			PerfectoUtils.reportMessage("Navigated to Coupons selection page.", MessageTypes.Pass);
		} else if (couponsdetails.getCouponsdetailLblPagetitle().getText().equalsIgnoreCase("Coupon Details")) {
			PerfectoUtils.reportMessage("Navigated to coupons details page.", MessageTypes.Pass);
		} else if (appcrash.getLblLoadingmore().isPresent()) {
			PerfectoUtils.reportMessage("Loading Digital Coupons Error:Unable to load coupons", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Coupons selection page.", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the Coupons page title
	 */
	@QAFTestStep(description = "I see All Coupons page")
	public void iSeeAllCouponsPage() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();

		couponsearch.getCouponsresultLblPgtitleallcoupon().waitForPresent(1000);
		couponsearch.getCouponsresultLblPgtitleallcoupon().verifyPresent();
	}

	/**
	 * Verifying the Search term is available in the Search results
	 */
	@QAFTestStep(description = "I see Search products page")
	public void iSeeSearchProductsPage() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		String strValidCouponname = getBundle().getString("coupons.couponname");

		couponsearch.waitForPageToLoad();
		// Entering coupons name
		PerfectoUtils.reportMessage("Search Coupon for: " + strValidCouponname + " product", MessageTypes.Pass);
		IOSStepdef.enterValueIntoTheTextboxandClick(couponsearch, strValidCouponname);

		try {
			couponsearch.getIconProgressBar().waitForNotPresent(30000);
		} catch (Exception e) {
		}
		int getsize = couponsearch.getCouponsresultLblCouponNameList().size();
		String strItemNameFromSearchResults = couponsearch.getLblCoupondescription().get(getsize - 1).getText();
		PerfectoUtils.reportMessage("Displayed Product is " + strItemNameFromSearchResults, MessageTypes.Pass);
		Boolean result = (strItemNameFromSearchResults.toLowerCase()).contains(strValidCouponname.toLowerCase());

		if (result) {
			PerfectoUtils.reportMessage("Searched Coupon is displayed in Result: " + strValidCouponname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No result displayed for the Searched Coupon: " + strValidCouponname, MessageTypes.Fail);
		}
	}

	/**
	 * Clicks on Select ALL and Plus Icon from SELECTED Section of Coupons page
	 */
	@QAFTestStep(description = "I add all the coupons to the shopping list")
	public void iAddAllTheCouponsToTheShoppingList() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		List<String> listFromCouponspage = new ArrayList<String>();

		int intCouponsSize = couponsSearchresultPage.getCouponsresultLblCouponNameList().size();
		if (intCouponsSize == 0) {
			PerfectoUtils.reportMessage("Coupons are not available under Selected Savings! Hence Adding!!", MessageTypes.Info);
			couponsselectionpage.getCouponsLblAvailable().click();
			iSelectMultipleAvailableCoupon();
			couponsselectionpage.getCouponsLblSelected().click();
		}

		// Adding all displayed coupon name to list
		for (QAFWebElement temp : couponsSearchresultPage.getCouponsresultLblCouponNameList()) {
			listFromCouponspage.add(temp.getText());
			System.out.println(temp.getText());
		}
		// Setting the list object to make comparison list details page
		getBundle().setProperty("listFromCouponspage", listFromCouponspage);
		couponsselectionpage.getCouponsBtnSelectall().click();
		couponsselectionpage.getCouponsLblAddtolist().waitForPresent(3000);
		couponsselectionpage.getCouponsLblAddtolist().click();
	}

	/**
	 * Clicks on Add button from the Add to list pop-up
	 */
	@QAFTestStep(description = "I click on Add/Done button from the popup")
	public void iClickOnAddDoneButtonFromThePopup() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		couponsselectionpage.getCouponsaddtolistTxtNumberpicker().waitForPresent(5000);
		String pickerName = couponsselectionpage.getCouponsaddtolistTxtNumberpicker().getText();
		System.out.println("The coupons have been added to list: " + pickerName);
		ConfigurationManager.getBundle().setProperty("NewListName", pickerName);
		ioscommon.getAddtolistBtnDone().click();
	}

	/**
	 * Verifies whether the Added Coupons are available in the Shopping list
	 * 
	 */
	@QAFTestStep(description = "I should see the list of Coupons in the selected list page")
	public void iShouldSeeTheListOfCouponsInTheSelectedListPage() {
		ListdetailsTestPage listdetailspage = new ListdetailsTestPage();

		List<String> listFromListDetailsPage = new ArrayList<String>();
		listdetailspage.waitForPageToLoad();
		listdetailspage.getListpageBtnMore().waitForPresent(7000);

		List<ListDetails> itemList = listdetailspage.getListpageLblItemNameList();
		String prdname = null;

		for (int i = 1; i <= itemList.size(); i++) {
			prdname = listdetailspage.getListpageLblItemnameByLable(i).getText();
			listFromListDetailsPage.add(prdname);
		}
		for (int i = 1; i < listFromListDetailsPage.size(); i++) {
			System.out.println(listFromListDetailsPage.get(i));
		}
		if (listFromListDetailsPage.size() > 0) {
			PerfectoUtils.reportMessage("Items matches with the selected items in coupons page", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Items matches with the selected items in coupons page", MessageTypes.Fail);
		}
	}

	/**
	 * Clicks the Check box of a Coupon and Clicks Plus Icon to Add to list from
	 * Coupons page
	 */
	@QAFTestStep(description = "I add the coupon to the shopping list")
	public void iAddTheCouponToTheShoppingList() {
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		CommonStepDefCoupons commonstepscoupons = new CommonStepDefCoupons();
		IOSStepdefshopinglist iosStepdefShop = new IOSStepdefshopinglist();

		PerfectoUtils.reportMessage("Getting the coupons size in Selected section.", MessageTypes.Pass);
		int intCouponsSize = couponsSearchresultPage.getCouponsresultLblCouponNameList().size();

		if (intCouponsSize == 0) {
			PerfectoUtils.reportMessage("Coupons are not available under Selected Savings! Hence Adding!!", MessageTypes.Info);
			couponsselectionpage.getCouponsLblAvailable().click();
			iSelectACoupon();
			commonstepscoupons.iClickOnSELECTFromCouponsDetailPage();
			iosStepdefShop.iSelectDeviceBackButton();
			iNavigateToSelectedSavingsTab();
		}

		String strCouponName = couponsSearchresultPage.getLblCoupondescription().get(intCouponsSize - 1).getText();
		getBundle().setProperty("ChoosenProduct", strCouponName);
		System.out.println("strCouponName: " + strCouponName);

		// Selecting the check box of first item
		couponsSearchresultPage.getChkSelectcouponlist().get(intCouponsSize - 1).click();
		// couponsSearchresultPage.getLblselectCouponnamedynamic(intCouponsSize-1).click();
		PerfectoUtils.reportMessage("Selected the checkbox for single item.", MessageTypes.Pass);
		// couponsSearchresultPage.getCouponChkboxWithRespectToName(strCouponName).click();
		couponsselectionpage.getCouponsLblAddtolist().waitForPresent(3000);

		if (couponsselectionpage.getCouponsLblAddtolist().getAttribute("enabled").equalsIgnoreCase("true")) {
			couponsselectionpage.getCouponsLblAddtolist().click();
			PerfectoUtils.reportMessage("Clicked Add to list button", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Check box not selected.", MessageTypes.Fail);
		}
	}

	/**
	 * Navigating to SELECTED Section and Verifying whether the coupons are
	 * available in the Section. If Coupons are not available, Add Coupons from
	 * AVAILABLE Section
	 */
	@QAFTestStep(description = "I navigate to Selected Savings tab")
	public void iNavigateToSelectedSavingsTab() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		int listsize;

		try {
			couponsselectionpage.getCouponsLblSelected().waitForPresent(5000);
			couponsselectionpage.getCouponsLblSelected().click();
		} catch (Exception e) {

			// iosstepdefshop.iSelectDeviceBackButton();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:iOS\\Coupons\\coupons_cross icon2.png");
				params1.put("screen.top", "0%");
				params1.put("screen.height", "100%");
				params1.put("screen.left", "0%");
				params1.put("screen.width", "100%");
				Object result1 = couponsselectionpage.getTestBase().getDriver().executeScript("mobile:image:select",
						params1);
			} catch (Exception f) {
				Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
				int intStartX = (int) (size.width * 0.90);
				int intStartY = (int) (size.height * 0.50);
				int intEndX = (int) (size.width * 0.10);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);

				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "Got It");
				Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params1);
				couponsselectionpage.getCouponsLblSelected().waitForPresent(3000);
			}
		}
		couponsselectionpage.getCouponsLblSelected().waitForPresent(5000);
		couponsselectionpage.getCouponsLblSelected().click();
		PerfectoUtils.reportMessage("Clicked on SELECTED section", MessageTypes.Pass);

		if (dcAutoEnrolFlag.equals("true")) {
			// Validating whether the SELECTED Section is not empty
			List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getCouponsresultLblCouponNameList();
			listsize = couponsNamesList.size();

			if (listsize != 0) {
				PerfectoUtils.reportMessage(listsize + " Coupons found.", MessageTypes.Info);

			} else {
				PerfectoUtils.reportMessage("Coupons not found!! Adding the coupons from Available Section..", MessageTypes.Info);

				couponsselectionpage.getCouponsLblAvailable().waitForPresent(1000);
				couponsselectionpage.getCouponsLblAvailable().click();

				// Selecting and adding the coupons to SLECTED Section
				int couponnamelistsize;
				List<QAFWebElement> couponsSelNamesList = couponsselectionpage.getLstItemlist();
				couponnamelistsize = couponsSelNamesList.size();

				/*
				 * Getting the coupon name and clicking on add button
				 * corresponding to the coupons names
				 */

				if (couponnamelistsize != 0) {
					// Select First Item
					String firstCouponName = couponsSelNamesList.get(couponnamelistsize - 1).getText();
					int addtolistSize = couponsSearchresultPage.getIconCouponaddList().size();
					couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 1).click();
					PerfectoUtils.reportMessage("Selected coupon name: " + firstCouponName, MessageTypes.Pass);

					// Navigating back to SELECTED Section
					couponsselectionpage.getCouponsLblSelected().waitForPresent(3000);
					couponsselectionpage.getCouponsLblSelected().click();

				} else {
					PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
				}
			}
		} else if (!couponsselectionpage.getCouponsPopupSignupOrSignin().isPresent()) {

			// Validating whether the SELECTED Section is not empty
			List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getCouponsresultLblCouponNameList();
			listsize = couponsNamesList.size();

			if (listsize != 0) {
				PerfectoUtils.reportMessage(listsize + " Coupons found.", MessageTypes.Info);

			} else {
				PerfectoUtils.reportMessage("Coupons not found!! Adding the coupons from Available Section..", MessageTypes.Info);

				couponsselectionpage.getCouponsLblAvailable().waitForPresent(1000);
				couponsselectionpage.getCouponsLblAvailable().click();

				// Selecting and adding the coupons to SLECTED Section
				int couponnamelistsize;
				List<QAFWebElement> couponsSelNamesList = couponsselectionpage.getLstItemlist();
				couponnamelistsize = couponsSelNamesList.size();

				/*
				 * Getting the coupon name and clicking on add button
				 * corresponding to the coupons names
				 */

				if (couponnamelistsize != 0) {
					// Select First Item
					String firstCouponName = couponsSelNamesList.get(couponnamelistsize - 1).getText();
					int addtolistSize = couponsSearchresultPage.getIconCouponaddList().size();
					couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 1).click();
					PerfectoUtils.reportMessage("Selected coupon name: " + firstCouponName, MessageTypes.Pass);

					// Navigating back to SELECTED Section
					couponsselectionpage.getCouponsLblSelected().waitForPresent(3000);
					couponsselectionpage.getCouponsLblSelected().click();

				} else {
					PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
				}
			}

		} else {

			couponsselectionpage.getCouponsPopupSignupOrSignin().waitForPresent(3000);

			if (couponsselectionpage.getCouponsPopupSignupOrSignin().isPresent()) {
				PerfectoUtils.reportMessage("DC auto enroll flag is false, The pop-up has been displayed as expected",
						MessageTypes.Pass);
				appcrash.getExceptionBtnOk().click();
				couponsselectionpage.getCouponsLblSelected().waitForPresent(5000);
			}

			couponsSearchresultPage.getBtnsignupnow().verifyPresent();

		}
	}

	/**
	 * Validating the Components from Registration page
	 */
	@QAFTestStep(description = "I see Registration detail page")
	public void iRegistrationDetailPage() {
		RegistrastionTestPage registrationpage = new RegistrastionTestPage();

		IOSStepDefMyAccounts.hidekeypad();
		registrationpage.getRegistrationTxtEmail().verifyPresent();
		registrationpage.getRegistrationTxtPassword().verifyPresent();
		registrationpage.getImgShowPwd().verifyPresent();
		registrationpage.getRegistrationTxtFirstname().verifyPresent();
		PerfectoUtils.scrollToStringuntilfindelement(registrationpage.getRegistrationChkIagree(), 80, 60, 2);
		PerfectoUtils.verticalswipe();
		registrationpage.getRegistrationChkIagree().verifyPresent();
	}

	/**
	 * Clicks on Search icon from Coupons page
	 */
	@QAFTestStep(description = "I click on Search")
	public void iClickOnSearch() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();

		couponsearch.getCouponsresultIconSearch().waitForPresent(10000);
		couponsearch.getCouponsresultIconSearch().click();
		couponsearch.getCouponsresultLblSearchtext().verifyPresent();
	}

	/**
	 * Clicks on Login button from Coupons Landing page
	 */
	@QAFTestStep(description = "I click on Login from coupons landing page")
	public void iClickOnLoginFromCouponsLandingPage() {

		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.waitForPageToLoad();
		couponsselection.getCouponsBtnLogin().waitForPresent(7000);
		couponsselection.getCouponsBtnLogin().click();
	}

	/**
	 * Selecting the first Coupon
	 */
	@QAFTestStep(description = "I select a coupon")
	public void iSelectACoupon() {
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		String prdname = "";
		int listsize;

		couponsSearchresultPage.getBtnClearSort().waitForPresent(5000);
		List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getCouponsresultLblCouponNameList();
		listsize = couponsNamesList.size();

		if (listsize == 0) {
			PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Pass);
			AddCouponsToSelectedSection();
		}

		prdname = couponsNamesList.get(listsize - 1).getText();
		ConfigurationManager.getBundle().setProperty("ChoosenProduct", prdname);
		try {
			couponsNamesList.get(listsize - 1).click();
		} catch (Exception e) {
			// couponsselection.couponselectionListCouponscell().get(2).click();
			couponsNamesList.get(listsize - 2).click();
		}
		PerfectoUtils.reportMessage("Selected coupon name: " + prdname, MessageTypes.Pass);
	}

	public void AddCouponsToSelectedSection() {
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsLblAvailable().waitForPresent(3000);
		couponsselection.getCouponsLblAvailable().click();
		PerfectoUtils.reportMessage("Navigating to Available section..");

		List<QAFWebElement> couponsNamesList = couponsselection.getCouponsLblItemWithClip();
		int couponnamelistsize = couponsNamesList.size();
		
		String firstCouponName = couponsselection.getCouponsLblItemWithClip().get(couponnamelistsize - 2).getText();
		int addtolistSize = couponsSearchresultPage.getIconCouponaddList().size();
		couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 2).click();
		PerfectoUtils.reportMessage("Selected coupon name: " + firstCouponName, MessageTypes.Pass);

		couponsselection.getCouponsLblSelected().waitForPresent(3000);
		couponsselection.getCouponsLblSelected().click();
		PerfectoUtils.reportMessage("Clicked on Selected tab..");

	}

	/**
	 * Clicks on Android Device back button to navigate back
	 */
	@QAFTestStep(description = "I navigate back to Coupons page from registration page")
	public void iNavigateBackToCouponsPageFromRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();

		// Checking whether Done button is visible
		iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();

		// Clicking Skip and Continue as Guest
		PerfectoUtils.verticalswipe();
		register.getLnkSkipandcontinueasguest().waitForPresent(5000);
		register.getLnkSkipandcontinueasguest().click();
		PerfectoUtils.reportMessage("Clicked skip and continue as guest option..", MessageTypes.Pass);

	}

	/**
	 * Clicking on Login button from Coupons Selection page
	 */
	@QAFTestStep(description = "I navigate to login page after clicking login button")
	public void iNavigateToLoginPageAfterClickingLoginButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		// Clicking on Login Button
		couponsselection.getCouponsBtnLogin().waitForPresent(5000);
		couponsselection.getCouponsBtnLogin().click();
	}

	/**
	 * Clicking on Continue Without registering. And Verifying whether navigate
	 * back to Coupons page
	 */
	@QAFTestStep(description = "I navigate back to Coupons page from login page")
	public void iNavigateBackToCouponsPageFromLoginPage() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();
		IOSStepdef iosstep = new IOSStepdef();

		if (loginpage.getLoginBtnLogin().isPresent()) {
			PerfectoUtils.reportMessage("Login page is displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Login page is not displayed", MessageTypes.Fail);
		}

		iosstep.iClickContinueWithoutRegisteringLink();

	}

	/**
	 * Verifying the Email, Password text and the Login Button
	 */
	@QAFTestStep(description = "I verify Login/Submit message")
	public void iVerifyLoginMessage() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();

		loginpage.getLoginTxtEmail().verifyPresent();
		loginpage.getLoginTxtPassword().verifyPresent();
		loginpage.getLoginBtnLogin().verifyPresent();
	}

	/**
	 * Verifying the user navigated to Coupons Selection Page i.e. the ALL
	 * COUPONS label is present
	 */
	@QAFTestStep(description = "I should see the coupons selection page")
	public void iShouldSeeTheCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			PerfectoUtils.reportMessage("Navigated to Coupons selection page.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Not navigated to Coupons selection page.", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting the Check box of 2 Coupons from SELECTED Section
	 */
	@QAFTestStep(description = "I select multiple available coupon")
	public void iSelectMultipleAvailableCoupon() {
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		try {
			if (couponsselection.getLblToastmsgcross().isPresent())
				couponsselection.getLblToastmsgcross().click();
		} catch (Exception e) {
		}

		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			int couponnamelistsize, couponsNamesListWithClipsize;
			List<QAFWebElement> couponsNamesList = couponsselection.getCouponsLblItemWithClip();
			couponnamelistsize = couponsNamesList.size();

			/*
			 * Getting the coupon name and clicking on add button corresponding
			 * to the coupons names
			 */

			if (couponnamelistsize != 0) {
				// Select First Item
				String firstCouponName = couponsselection.getCouponsLblItemWithClip().get(couponnamelistsize - 1)
						.getText();
				int addtolistSize = couponsSearchresultPage.getIconCouponaddList().size();
				couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 1).click();
				PerfectoUtils.reportMessage("Selected coupon name: " + firstCouponName, MessageTypes.Pass);
				getBundle().setProperty("FirstCoupons", firstCouponName);

				// Select Second Item
				List<QAFWebElement> couponsNamesListWithClip = couponsselection.getCouponsLblItemWithClip();
				couponsNamesListWithClipsize = couponsNamesListWithClip.size();
				String secondCouponName = couponsselection.getCouponsLblItemWithClip().get(couponnamelistsize - 2)
						.getText();
				couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 2).click();
				PerfectoUtils.reportMessage("Selected coupon name: " + secondCouponName, MessageTypes.Pass);
				getBundle().setProperty("SecondCoupons", secondCouponName);

			} else {
				PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
			}
		} else {
			if (couponsSearchresultPage.getBtnsignupnow().isPresent()) {
				PerfectoUtils.reportMessage("Signup Now button is displayed. Cannot navigate to selected coupon", MessageTypes.Info);
				int clipIcon = couponsselection.getLstSelectcheckbox().size();
				if (clipIcon == 0)
					PerfectoUtils.reportMessage("No clip icons present as exected", MessageTypes.Pass);
				else
					PerfectoUtils.reportMessage("Clip icons are present..", MessageTypes.Fail);

				couponsselection.getCouponsLblSelected().verifyPresent();
				couponsselection.getCouponsLblSelected().click();

			} else {
				PerfectoUtils.reportMessage("DCAutoEnrol flag is false");
				PerfectoUtils.reportMessage("Signup Now button is not displayed. Can navigate to selected coupon", MessageTypes.Pass);

				int couponnamelistsize, couponsNamesListWithClipsize;
				List<QAFWebElement> couponsNamesList = couponsselection.getCouponsLblItemWithClip();
				couponnamelistsize = couponsNamesList.size();

				/*
				 * Getting the coupon name and clicking on add button
				 * corresponding to the coupons names
				 */

				if (couponnamelistsize != 0) {
					// Select First Item
					String firstCouponName = couponsselection.getCouponsLblItemWithClip().get(couponnamelistsize - 1)
							.getText();
					int addtolistSize = couponsSearchresultPage.getIconCouponaddList().size();
					couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 1).click();
					PerfectoUtils.reportMessage("Selected coupon name: " + firstCouponName, MessageTypes.Pass);
					getBundle().setProperty("FirstCoupons", firstCouponName);

					// Select Second Item
					List<QAFWebElement> couponsNamesListWithClip = couponsselection.getCouponsLblItemWithClip();
					couponsNamesListWithClipsize = couponsNamesListWithClip.size();
					String secondCouponName = couponsselection.getCouponsLblItemWithClip().get(couponnamelistsize - 2)
							.getText();
					couponsSearchresultPage.getIconCouponaddList().get(addtolistSize - 2).click();
					PerfectoUtils.reportMessage("Selected coupon name: " + secondCouponName, MessageTypes.Pass);
					getBundle().setProperty("SecondCoupons", secondCouponName);

				} else {
					PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
				}

			}
		}
	}

	/**
	 * Selecting an Option from the Sort pop up
	 */
	@QAFTestStep(description = "I select an option from the sort popup")
	public void iSelectAnOptionFromTheSortPopup() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		String strSelectedOption = couponsselection.getLblSortpopupSecondoption().getText();
		couponsselection.getLblSortpopupSecondoption().click();
		PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
	}

	/**
	 * Verifying the Sort option is not present
	 */
	@QAFTestStep(description = "I verify the sort option is not present")
	public void iVerifyTheSortOptionIsNotPresent() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		if (!couponsselection.getCouponsBtnSort().isPresent()) {
			PerfectoUtils.reportMessage("Sort option is not present in the Search result page as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Sort option is visible in the Search result page", MessageTypes.Fail);
		}

		/*
		 * Map<String, Object> params1 = new HashMap<>(); params1.put("content",
		 * "GROUP:iOS\\Coupons\\sortImage.png"); params1.put("screen.top",
		 * "0%"); params1.put("screen.height", "99%");
		 * params1.put("screen.left", "0%"); params1.put("screen.width", "99%");
		 * System.out
		 * .println(couponsselection.getTestBase().getDriver().executeScript(
		 * "mobile:checkpoint:image", params1));
		 */

		/*
		 * Map<String, Object> params1 = new HashMap<>(); params1.put("content",
		 * "SORT");
		 * 
		 * String isSortPresent = (String)
		 * couponsselection.getTestBase().getDriver().executeScript(
		 * "mobile:checkpoint:text", params1);
		 * 
		 * if (isSortPresent.equalsIgnoreCase("false")) { PerfectoUtils.reportMessage(
		 * "Sort option is not present in the Search result page as expected.",
		 * MessageTypes.Pass); } else { PerfectoUtils.reportMessage(
		 * "Sort option present in the Search result page.", MessageTypes.Fail);
		 * }
		 */
	}

	/**
	 * Verifying the user has navigated to Coupons Selection Page i.e. verifying
	 * the ALL COUPONS label is visible
	 */
	@QAFTestStep(description = "I should see coupons selection page")
	public void iShouldSeeCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.getCouponsLblPgtitlecoupons().waitForPresent(5000);
		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons selection page displayed successfully", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons selection page is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * Validating the Clipped Coupons are available in SELECTED Section
	 */
	@QAFTestStep(description = "I validate selected coupons available in selected savings")
	public void iValidateSelectedCouponsAvailableInSelectedSavings() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		// Navigating back and to Selected tab
		couponsselection.getCouponsLblSelected().waitForPresent(3000);
		couponsselection.getCouponsLblSelected().click();
		if (!couponsselection.getCouponsPopupSignupOrSignin().isPresent()) {
			couponsselection.getCouponsLblAvailable().waitForPresent(3000);
			couponsselection.getCouponsLblAvailable().click();
			couponsselection.getCouponsLblSelected().waitForPresent(3000);
			couponsselection.getCouponsLblSelected().click();

			PerfectoUtils.reportMessage("Clicked on Selected Section.", MessageTypes.Pass);

			// Verify whether the user navigated to "Selected" section
			try {
				couponsselection.getCouponsBtnSelectall().waitForPresent(10000);
			} catch (Exception e1) {

				PerfectoUtils.reportMessage("Error occured while navigating to Selected Section.", MessageTypes.Fail);
			}

			String firstCouponname = getBundle().getString("FirstCoupons");
			String secondCouponname = getBundle().getString("SecondCoupons");

			try {
				if (weeklygrocery.getShopingListEntryByLable(firstCouponname).isPresent()) {
					PerfectoUtils.reportMessage("Selected coupon: " + firstCouponname + ": is available in Selected savings.",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Selected coupon: " + firstCouponname + ": is not available in Selected savings.",
							MessageTypes.Fail);
				}
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Exception caught while searching for first coupon: " + firstCouponname + ".",
						MessageTypes.Fail);
			}

			// Verify, if the second coupon is present
			try {

				/*
				 * if
				 * (!weeklygrocery.getShopingListEntryByLable(firstCouponname).
				 * isPresent()) {
				 * IOSStepdef.scrollToListNameInMyList(firstCouponname, 80, 75,
				 * 2); }
				 */

				if (weeklygrocery.getShopingListEntryByLable(secondCouponname).isPresent()) {
					PerfectoUtils.reportMessage("Selected coupon: " + secondCouponname + ": is available in Selected savings.",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Selected coupon: " + secondCouponname + ": is not available in Selected savings.",
							MessageTypes.Fail);
				}
			} catch (Exception e) {
				PerfectoUtils.reportMessage("Exception caught while searching for second coupon: " + secondCouponname + ".",
						MessageTypes.Fail);
			}
		} else if (dcAutoEnrolFlag.equals("false")) {

			PerfectoUtils.reportMessage("DCC auto enroll flag is off, cannot select coupons");
			PerfectoUtils.reportMessage("User need to sign up for digital coupons..", MessageTypes.Pass);
		} else
			PerfectoUtils.reportMessage("DCC auto enroll flag is not false, Still user not able to navigate to selected tab",
					MessageTypes.Fail);

	}

	/**
	 * Selecting a different Sort option from the pop up
	 */
	@QAFTestStep(description = "I select an different sort option from the sort popup")
	public void iSelectAnDifferentSortOptionFromTheSortPopup() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String sortby = getBundle().getString("coupons.sortby");
		String strSelectedOption = null;
		int getcell = couponsselection.getLblSortcells().size();
		System.out.println(getcell);
		strSelectedOption = couponsselection.getLblSortpopupSecondoption().getText();

		for (int i = 0; i < getcell; i++) {
			System.out.println(sortby + "  " + strSelectedOption);
			if (!sortby.equals(strSelectedOption)) {
				PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
				couponsselection.getLblSortpopupSecondoption().click();
				CommonStepDefCoupons.iSelectTheSortButton();
				strSelectedOption = couponsselection.getLblSortpopupSecondoption().getText();
			} else if (sortby.equals(strSelectedOption)) {
				PerfectoUtils.reportMessage("Selected option: " + strSelectedOption, MessageTypes.Pass);
				couponsselection.getLblSortpopupSecondoption().click();
				break;
			}
		}
	}

	/**
	 * Enter Invalid Coupons name and Verifying No Results Found.
	 */
	@QAFTestStep(description = "I see No result for invalid coupons")
	public void iSeeNoResultForInvalidCoupons() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();
		String strInvalidCouponname = ConfigurationManager.getBundle().getString("coupons.invalidcouponname");
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		// Entering invalid coupons name
		couponsearch.getCouponsresultIconSearch().click();
		PerfectoUtils.reportMessage("Search Coupon for: " + strInvalidCouponname + " product", MessageTypes.Pass);
		IOSStepdef.enterValueIntoTheTextboxandClick(couponsearch, strInvalidCouponname);

		couponsselection.getLblSearchresult().waitForPresent(5000);

		String strSearchResultsCount = couponsselection.getLblSearchresult().getText();

		if (strSearchResultsCount.contains("No Items Found")) {
			PerfectoUtils.reportMessage("No Result is found for " + strInvalidCouponname + " is displayed as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Provide invalid coupons name", MessageTypes.Fail);
		}
	}

	/**
	 * Enter the Mandatory fields in the Email page and Click on Send button
	 */
	@QAFTestStep(description = "I send coupon by entering all mandatory field in email page")
	public void iSendCouponByEnteringAllMandatoryFieldInEmailPage() {
		CouponsemailTestPage couponsemail = new CouponsemailTestPage();
		String youremail = ConfigurationManager.getBundle().getString("coupons.user.email");
		String recipientemail = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsemail.getLblPagetitle().verifyPresent();
		couponsemail.getEdtName().sendKeys("Test");
		couponsemail.getEdtSenderemail().sendKeys(youremail);
		couponsemail.getEdtRecipientemail().sendKeys(recipientemail);
		couponsemail.getEdtMessage().sendKeys("Testing");
		couponsemail.getChkSendcopy().click();
		couponsemail.getBtnSubmit().click();

		couponsdetailspage.getCouponsdetailLblPagetitle().waitForPresent(5000);
		if (couponsdetailspage.getCouponsdetailLblPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Email sent successfully to:" + recipientemail, MessageTypes.Pass);
		} else if (couponsemail.getBtnSubmit().isDisplayed()) {
			PerfectoUtils.reportMessage("Email not sent to:" + recipientemail, MessageTypes.Fail);
		}
	}

	/**
	 * Select a Coupon from SELECTED Section
	 */
	@QAFTestStep(description = "I select coupons from Selected Savings tab")
	public void iSelectCouponsFromSelectedSavingsTab() {
		CouponssearchresultTestPage couponsSearch = new CouponssearchresultTestPage();

		List<QAFWebElement> couponsNamesList = couponsSearch.getCouponsresultLblCouponNameList();
		int listsize = couponsNamesList.size();

		if (listsize == 0) {
			PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Pass);
			AddCouponsToSelectedSection();
		}

		// Getting the coupon name
		int intCouponsSize = couponsSearch.getCouponsresultLblCouponNameList().size();
		String strCouponName = couponsSearch.getCouponsresultLblCouponNameList().get(intCouponsSize - 1).getText();
		System.out.println("intCouponsSize: " + intCouponsSize + "\n" + "strCouponName: " + strCouponName);

		// Selecting the check box dynamically based on the coupons name
		couponsSearch.getCouponsresultLblCouponNameList().get(intCouponsSize - 1).click();
	}

	/**
	 * Verifying the Title has been changes as per the Selected category
	 */
	@QAFTestStep(description = "I validate the filtered coupons selection page")
	public void iValidateTheFilteredCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		String strSelectedcategory = ConfigurationManager.getBundle().getString("selectedcategory");
		couponsselection.getLblCategorytitle().waitForPresent(5000);
		couponsselection.getCouponsBtnSort().waitForNotVisible(10000);

		// Checking, if the title is Selected category
		if (couponsselection.getLblCategorytitle().getText().contains(strSelectedcategory)) {
			PerfectoUtils.reportMessage("The category has been changed successfully.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The category has been changed.", MessageTypes.Fail);
		}
	}

	/*
	 * @QAFTestStep(description = "I select a coupon after login") public void
	 * iSelectACouponAfterLogin() {
	 * 
	 * CouponssearchresultTestPage SearchresultPage = new
	 * CouponssearchresultTestPage(); CouponsselectionTestPage couponsselection
	 * = new CouponsselectionTestPage();
	 * 
	 * SearchresultPage.waitForPageToLoad(); int sizeget =
	 * couponsselection.getCouponsLblSearchresult().size(); String product =
	 * SearchresultPage.getLblCouponnamedynamic(sizeget).getText();
	 * System.out.println(sizeget + " " + product); iClickOnSearch();
	 * IOSStepdef.enterValueIntoTheTextboxandClick(couponsselection, product);
	 * iSelectACoupon();
	 * 
	 * }
	 */

	/**
	 * Verifying the Added Coupons are available in the Selected Shopping list
	 */
	@QAFTestStep(description = "I verify the added coupons")
	public void iVerifyTheAddedCoupons() {
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String clikedcoupons = ConfigurationManager.getBundle().getString("ChoosenProduct");
		System.out.println(clikedcoupons);
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (dcAutoEnrolFlag.contains("true")) {
			IOSStepdef.scrollToListNameInMyList(clikedcoupons, 85, 65, 2);

			// IOSStepdef.scrollToElement(clikedcoupons);
			if (weeklygrocery.getShopingListEntryByLable(clikedcoupons).isPresent()) {
				PerfectoUtils.reportMessage("The coupon available in selected savings tab", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("The coupon is not avaiable in selected savings tab", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("DCAutoEnrol flag is false");

		}
	}

	/**
	 * Clicking on Coupons option from the Application Footer bar
	 */
	@QAFTestStep(description = "I navigate to Coupons page from footer")
	public void iNavigateToCouponsPageFromFooter() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getBtnFooterdigitalcoupon().waitForPresent(3000);

		if (ioscommon.getBtnFooterdigitalcoupon().isPresent()) {
			ioscommon.getBtnFooterdigitalcoupon().click();
		} else {
			PerfectoUtils.reportMessage("Unable to see Digital Coupons Icon the Footer", MessageTypes.Fail);
		}
	}

	/**
	 * Clicks on Cancel button from the Login pop up
	 */
	@QAFTestStep(description = "I click on Cancel button")
	public void iClickOnCancelButton() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		if (storedetail.getstoredetailsLblCancel().isPresent()) {
			storedetail.getstoredetailsLblCancel().click();
		}
	}

	/**
	 * Clicks on Login button from Coupons Selection page
	 */
	@QAFTestStep(description = "I click on Login from coupons selection page")
	public void iClickOnLoginFromCouponsSelectionPage() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();

		couponsselection.waitForPageToLoad();
		couponsselection.getCouponsBtnLogin().waitForPresent(7000);
		couponsselection.getCouponsBtnLogin().click();
	}

	/**
	 * Clicks on Login button from the Login Pop up
	 */
	@QAFTestStep(description = "I click on Login/Submit button from the popup")
	public void iClickOnLoginSubmitButtonFromThePopup() {
		LoginsplashTestPage loginpage = new LoginsplashTestPage();
		AppcrashhandlerTestPage appCrash = new AppcrashhandlerTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		IOSStepdef.clickKeyboardDone();

		// Clicking on Submit button
		loginpage.getLoginBtnLogin().waitForPresent(5000);
		loginpage.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked on Login button from the popup.", MessageTypes.Pass);

		if (weeklygrocery.getShopingListEntryByLable("Log In Error").isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured, try entering valid credential", MessageTypes.Fail);
			appCrash.getExceptionBtnOk().click();
		}

		if (appCrash.getExceptionLblloginError().isPresent()) {
			PerfectoUtils.reportMessage("Log in Error occured, try entering valid credential", MessageTypes.Fail);
			appCrash.getExceptionBtnOk().click();
		}

		if (appCrash.getExceptionSkipCoupons().isPresent()) {
			PerfectoUtils.reportMessage("Swipe to Discover", MessageTypes.Pass);
			appCrash.getExceptionSkipCoupons().click();
		}
	}

	/**
	 * Selecting a category from the Coupons drop down options
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select an category from the coupons dropdown")
	public void iSelectAnCategoryFromTheCouponsDorpdown() throws InterruptedException {
		CouponsselectionTestPage selectcoupons = new CouponsselectionTestPage();

		// Condition verify the coupons list page
		selectcoupons.getCouponselectionLblAllcoupons().waitForPresent(6000);
		if (selectcoupons.getCouponselectionLblAllcoupons().isPresent()) {
			PerfectoUtils.reportMessage("Coupons List page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Coupons List page is not displayed", MessageTypes.Fail);
		}

		selectcoupons.getDropdownSelectcatagory().waitForPresent(5000);
		selectcoupons.getDropdownSelectcatagory().click();
		try {
			selectcoupons.getCouponSelectCategory().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			selectcoupons.getCouponSelectCategory().waitForPresent(5000);
		}
		System.out.println(selectcoupons.getCouponSelectCategory().getText());
		ConfigurationManager.getBundle().setProperty("selectedcategory",
				selectcoupons.getCouponSelectCategory().getText());
		selectcoupons.getCouponSelectCategory().click();

		selectcoupons.getBtnFilterApply().waitForPresent(5000);
		selectcoupons.getBtnFilterApply().click();
		PerfectoUtils.reportMessage("Clicked Apply button from Category filter page", MessageTypes.Pass);
		selectcoupons.getBtnFilterApply().waitForNotPresent(10000);
		selectcoupons.getCouponsBtnSort().waitForNotPresent(20000);
	}

	/**
	 * Verifying the Login and Register buttons are available in the Coupons
	 * Details page
	 */
	@QAFTestStep(description = "I validate register and Login button in coupons detail page")
	public void iValidateRegisterAndLoginButtonInCouponsDetailPage() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsdetailspage.getCouponsdetailBtnLogin().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnRegister().verifyPresent();
	}

	/**
	 * Clicking on SELECTED tab as a Cold user from Coupons Selection page
	 */
	@QAFTestStep(description = "I navigate to Selected Savings tab as a cold user")
	public void iNavigateToSelectedSavingsTabAsAColdUser() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		try {
			couponsselectionpage.getCouponsLblSelected().waitForPresent(5000);

		} catch (Exception e) {

			// iosstepdefshop.iSelectDeviceBackButton();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:iOS\\Coupons\\coupons_cross icon2.png");
				params1.put("screen.top", "0%");
				params1.put("screen.height", "100%");
				params1.put("screen.left", "0%");
				params1.put("screen.width", "100%");
				Object result1 = couponsselectionpage.getTestBase().getDriver().executeScript("mobile:image:select",
						params1);
			} catch (Exception f) {
				Dimension size = PerfectoUtils.getAppiumDriver().manage().window().getSize();
				int intStartX = (int) (size.width * 0.90);
				int intStartY = (int) (size.height * 0.50);
				int intEndX = (int) (size.width * 0.10);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);
				PerfectoUtils.getAppiumDriver().swipe(intStartX, intStartY, intEndX, intStartY, 3);

				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "Got It");
				Object result1 = PerfectoUtils.getAppiumDriver().executeScript("mobile:text:select", params1);
				couponsselectionpage.getCouponsLblSelected().waitForPresent(3000);
			}
		}

		couponsselectionpage.getCouponsLblSelected().waitForPresent(5000);
		couponsselectionpage.getCouponsLblSelected().click();
		PerfectoUtils.reportMessage("Clicked on SELECTED section", MessageTypes.Pass);

	}

	/**
	 * Select all coupons in Selected Savings page by clicking SELECT ALL option
	 */
	@QAFTestStep(description = "I select coupons by clicking SELECT ALL")
	public void iSelectCouponsByClickingSELECTALL() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();

		// Click Select ALL option
		couponsselectionpage.getCouponsBtnSelectall().click();

		// Verify Add to List is not available
		couponsselectionpage.getCouponsLblAddtolist().waitForNotPresent(5000);
		couponsselectionpage.getCouponsLblAddtolist().verifyNotPresent();
	}

	/**
	 * Click on UN SELECT ALL option. Click on single coupon.
	 */
	@QAFTestStep(description = "I click on Unselecet All option and select single coupon")
	public void iClickOnUnselecetAllOptionAndSelectSingleCoupon() {
		CouponsselectionTestPage couponsselectionpage = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();

		// Click UN Select All button
		couponsselectionpage.getCouponsBtnUnSelectall().click();

		// Select single coupon
		int intCouponsSize = couponsSearchresultPage.getCouponsresultLblCouponNameList().size();

		// Selecting the check box of first item
		couponsSearchresultPage.getChkSelectcouponlist().get(intCouponsSize - 1).click();
	}

	@QAFTestStep(description = "I click share button")
	public void iClickShareButton() {
		CouponsdetailsTestPage couponsdetailspage = new CouponsdetailsTestPage();

		couponsdetailspage.getCouponsdetailBtnShare().verifyPresent();
		couponsdetailspage.getCouponsdetailBtnShare().click();
	}

	/**
	 * Verify user able to add the selected coupon to list
	 */
	@QAFTestStep(description = "I add the selected coupon to list")
	public void iAddTheSelectedCouponTolist() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		int listSize = couponSelection.getLstSelectcheckbox().size();

		String couponname = couponSelection.getLblCouponnamelist().get(listSize - 1).getText();
		getBundle().setProperty("ChoosenProduct", couponname);

		couponSelection.getLstSelectcheckbox().get(listSize - 1).click();
		PerfectoUtils.reportMessage("Selected first item checkbox");
		couponSelection.getCouponsLblAddtolist().click();
		PerfectoUtils.reportMessage("Clicked on the add to list option", MessageTypes.Info);

	}

	/**
	 * Verify add to list options in selected savings tab
	 */
	@QAFTestStep(description = "I verify add to list options in selected savings tab")
	public void iVerifyAddToListOptionsinSelectedSavings() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		try {
			if (couponSelection.getLblToastmsgcross().isPresent())
				couponSelection.getLblToastmsgcross().click();
		} catch (Exception e) {
		}
		couponSelection.getCouponsBtnSelectall().verifyPresent();
		couponSelection.getCouponsLblAddtolist().verifyPresent();
		System.out.println(couponSelection.getCouponsLblAddtolist().getAttribute("enabled"));
		if (couponSelection.getCouponsLblAddtolist().getAttribute("enabled").equals("false"))
			PerfectoUtils.reportMessage("Add to list is disabled by default..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to list is not disabled by default..", MessageTypes.Fail);

		int checkBox = couponSelection.getLstSelectcheckbox().size();
		if (checkBox != 0)
			PerfectoUtils.reportMessage("Check box for select coupon is displayed..");
		else
			PerfectoUtils.reportMessage("Check box for select coupon is not displayed..", MessageTypes.Fail);

		couponSelection.getLstSelectcheckbox().get(checkBox - 1).click();
		System.out.println(couponSelection.getCouponsLblAddtolist().getAttribute("enabled"));
		if (couponSelection.getCouponsLblAddtolist().getAttribute("enabled").equals("true"))
			PerfectoUtils.reportMessage("Add to list is enabled..", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("Add to list is not enabled..", MessageTypes.Fail);

		if (couponSelection.getCouponsBtnUnSelectall().isPresent())
			couponSelection.getCouponsBtnUnSelectall().click();

		couponSelection.getCouponsBtnSelectall().click();
		couponSelection.getCouponsBtnUnSelectall().verifyPresent();

		couponSelection.getCouponsBtnUnSelectall().click();
		couponSelection.getCouponsBtnSelectall().verifyPresent();

	}

	@QAFTestStep(description = "Verify the Read more functionality")
	public void verifyTheReadMoreFunctionality() {

		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		PerfectoUtils.verticalswipe();
		if (couponsdetails.getBtnReadmore().isPresent()) {
			PerfectoUtils.reportMessage("ReadMore is present.", MessageTypes.Pass);
			couponsdetails.getBtnReadmore().click();
			PerfectoUtils.reportMessage("Clicked on ReadMore..");
			PerfectoUtils.verticalswipe();
			if (!couponsdetails.getBtnReadless().isPresent())
				PerfectoUtils.verticalswipeSlow();

			if (couponsdetails.getBtnReadless().isPresent()) {
				PerfectoUtils.reportMessage("ReadLess is present.", MessageTypes.Pass);
				couponsdetails.getBtnReadless().click();
				PerfectoUtils.reportMessage("Clicked on ReadLess..");
				if (couponsdetails.getBtnReadmore().isPresent()) {
					PerfectoUtils.reportMessage("ReadMore is present.", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("ReadMore is not present.", MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("ReadLess is not present.", MessageTypes.Fail);
			}
		} else {
			PerfectoUtils.reportMessage("ReadMore is not present.", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Verify the Read more functionality not present")
	public void verifyTheReadMoreFunctionalitynotpresent() {

		CouponsdetailsTestPage couponsdetails = new CouponsdetailsTestPage();

		PerfectoUtils.verticalswipe();
		if (couponsdetails.getBtnReadmore().isPresent()) {
			PerfectoUtils.reportMessage("ReadMore is present.", MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("ReadMore is not present.", MessageTypes.Pass);
		}

	}

	@QAFTestStep(description = "I verify the coupons getting displayed")
	public void iverifythecouponsgettingdisplayed() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();
		String selectedcategory = ConfigurationManager.getBundle().getPropertyValue("selectedcategory");
		String coupontitle = couponSelection.getLblCategorytitle().getText();
		if (selectedcategory.equalsIgnoreCase(coupontitle)) {
			PerfectoUtils.reportMessage("Selected category coupon is getting displayed", MessageTypes.Pass);
		}

		else {
			PerfectoUtils.reportMessage("Selected category coupon is not getting displayed", MessageTypes.Fail);
		}

	}

	/**
	 * CLick on Clear from search result
	 */
	@QAFTestStep(description = "I click clear from search result")
	public void iClickClearFromSearchResult() {
		CouponssearchresultTestPage couponsearch = new CouponssearchresultTestPage();

		couponsearch.getBtnClearSort().click();
		PerfectoUtils.reportMessage("Clicked clear button...");

	}

	/**
	 * Verify counpons landing page is displayed
	 */
	@QAFTestStep(description = "I verify counpon landing page is displayed")
	public void iVerifyCouponLandingPageIsDisplayed() {
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		couponSelection.getCouponselectionLblAllcoupons().waitForPresent(5000);
		couponSelection.getCouponselectionLblAllcoupons().verifyPresent();
		PerfectoUtils.reportMessage("Counpon landing page is displaye...");

	}

	/**
	 * Verify add to list and select button
	 */
	@QAFTestStep(description = "I verify add to list and select button")
	public void iVerifyAddToListAndSelectButton() {
		CouponsdetailsTestPage couponDetails = new CouponsdetailsTestPage();

		couponDetails.getBtnAddToList().verifyPresent();

	}

	@QAFTestStep(description = "I see All Coupons are checked")
	public void iSeeAllCouponsAreChecked() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearch = new CouponssearchresultTestPage();

		int size = couponsselection.getLstSelectedTabSelectedcheckbox().size();
		int intCouponsSize = couponsSearch.getCouponsresultLblCouponNameList().size();

		if (size == intCouponsSize)
			PerfectoUtils.reportMessage("All the coupon got checked.. Coupon checked: " + size, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("All the coupon are not checked.. Coupon checked: " + size, MessageTypes.Fail);
	}

	@QAFTestStep(description = "I see All coupons are unchecked")
	public void iSeeAllCouponsAreUnchecked() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearch = new CouponssearchresultTestPage();

		int size = couponsselection.getLstSelectedTabcheckbox().size();
		int intCouponsSize = couponsSearch.getCouponsresultLblCouponNameList().size();
		couponsselection.getCouponsBtnSelectall().waitForPresent(5000);

		if (!(size == intCouponsSize))
			PerfectoUtils.reportMessage("All the coupon got checked.. Coupon checked: " + size, MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("All the coupon are not checked.. Coupon checked: " + size, MessageTypes.Fail);
	}

	/**
	 * user validate Selected Savings tab
	 */
	@QAFTestStep(description = "I validate Selected Savings tab")
	public void iValidateSelectedSavingsTab() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		String dcAutoEnrolFlag = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		CommonStepDefCoupons commonstepdefCoupons = new CommonStepDefCoupons();

		couponsselection.getCouponsLblPgtitlecoupons().waitForPresent(5000);
		if (couponsselection.getCouponsLblPgtitlecoupons().isPresent()) {
			couponsselection.getCouponsLblCoupondesc().verifyPresent();
			couponsselection.getCouponsBtnSelectall().verifyPresent();

			if (couponsselection.getCouponsLblAddtolist().getAttribute("enabled").equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Add to list is Greyed Out.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Add to list is not Greyed Out.", MessageTypes.Fail);
			}

			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is validated.", MessageTypes.Pass);
		}

		if (couponsselection.getLblSelectedsavingswhenselected().isPresent()
				|| (couponsselection.getLblSelectedsavingswhenselected().getAttribute("Selected")).equals("true")) {
			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is Highlighted.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("SELECTED section in Digital Coupons page is not Highlighted.", MessageTypes.Fail);
		}

		if (dcAutoEnrolFlag.contains("true")) {
			commonstepdefCoupons.iVerifyRedeemButtonInSelectedTab();
		} else {
			couponsselection.getCouponsBtnRedeem().verifyNotPresent();
		}

	}

	/**
	 * Entering your name, your email id and recipient email id, hide keyboard
	 * and click send button. Validating the send button is not present after
	 * that. Fails the step if Unable to share via email error pop ups.
	 */
	@QAFTestStep(description = "I enter mandatory field for cold user and click on Send button")
	public void iEnterMandatoryFieldForColdUserAndClickOnSendButton() {
		SendemailTestPage sendemail = new SendemailTestPage();
		ProductdetailTestPage productdetail = new ProductdetailTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		IOSStepdef iosstep = new IOSStepdef();

		int i = 0;
		String recipientEmail = ConfigurationManager.getBundle().getString("default.user.email");
		System.out.println("recipientEmail: " + recipientEmail);

		// Checking whether the APP navigated Email page
		if (sendemail.getSendemailTxtRecipientemail().isPresent()) {

			sendemail.getSendemailTxtSendername().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("Qa");
			PerfectoUtils.reportMessage("Entered your name..Qa");
			sendemail.getSendemailTxtSenderemail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("sendemail@heb.com");
			PerfectoUtils.reportMessage("Entered your email..sendemail@heb.com");
			sendemail.getSendemailTxtRecipientemail().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(recipientEmail);

			PerfectoUtils.reportMessage("Entered Email: " + recipientEmail + " ", MessageTypes.Pass);
			iosstep.clickKeyboardDoneIcon();
			sendemail.getSendemailBtnSubmit().click();
			PerfectoUtils.reportMessage("Clicked Sumbit");
			do {
				try {
					sendemail.getSendemailBtnSubmit().waitForNotPresent(3000);
				} catch (Exception e) {
					i++;
				}
			} while (sendemail.getSendemailBtnSubmit().isPresent() && i < 20);

			if (weeklygrocery.getShopingListEntryByLable("Unable to share via email").isPresent()) {
				PerfectoUtils.reportMessage(
						"Unable to send email for this product at this time! Pls check the information you entered!!",
						MessageTypes.Fail);
				appcrash.getExceptionBtnOk().click();
			}

			productdetail.getPdpTxtPagetitle().waitForPresent(10000);

			if (productdetail.getPdpTxtPagetitle().isPresent()) {
				PerfectoUtils.reportMessage("Product Share via email is successful, PDP page is displayed", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Product Share via email is not successful, PDP page is not displayed", MessageTypes.Fail);
			}
		} else if (sendemail.getEditTo().isPresent()) {
			PerfectoUtils.reportMessage("Email option not found and hence navigated to Gmail.", MessageTypes.Pass);
			sendemail.getEditTo().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(recipientEmail);
			sendemail.getBtnSend().click();

		} else {
			sendemail.getBtnSend().isPresent();
			PerfectoUtils.reportMessage("Email & Gmail option not found.", MessageTypes.Fail);
		}
	}

	/**
	 * Note down the selected list name
	 */
	@QAFTestStep(description = "I note down the list name")
	public void iNoteDownTheListName() {
		RecipedetailTestPage recipedetail = new RecipedetailTestPage();

		int size = recipedetail.getTxtListNameDisplayed().size();

		List<String> ChoosenList1 = new ArrayList<String>();
		String ChoosenList = null;
		for (int i = 0; i < size; i++) {
			ChoosenList1.add(recipedetail.getTxtListNameDisplayed().get(i).getText());
		}
		for (int i = 0; i < size; i++) {
			if (!ChoosenList1.get(i).contains("Featured")) {
				ChoosenList = recipedetail.getTxtListNameDisplayed().get(i).getText();
				break;
			}
		}
		getBundle().setProperty("ChoosenList", ChoosenList);
		getBundle().setProperty("NewListName", ChoosenList);
		PerfectoUtils.reportMessage("Selected list: " + ChoosenList, MessageTypes.Pass);
	}
	
	@QAFTestStep(description = "I select Select All button")
	public void iSelectSelectAllButton() {
		CouponsselectionTestPage couponsselection = new CouponsselectionTestPage();
		CouponssearchresultTestPage couponsSearchresultPage = new CouponssearchresultTestPage();
		
		int listsize;

		couponsSearchresultPage.getBtnClearSort().waitForPresent(5000);
		List<QAFWebElement> couponsNamesList = couponsSearchresultPage.getCouponsresultLblCouponNameList();
		listsize = couponsNamesList.size();

		if (listsize == 0) {
			PerfectoUtils.reportMessage("Coupons not found!!", MessageTypes.Fail);
			AddCouponsToSelectedSection();
		}
		
		couponsselection.getCouponsBtnSelectall().verifyPresent();
		couponsselection.getCouponsBtnSelectall().click();

	}

}
