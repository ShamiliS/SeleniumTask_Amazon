/**
 * 
 */
package com.heb.automation.ios.steps.myaccount;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.heb.automation.android.pages.AndroidcommonTestPage;
import com.heb.automation.android.steps.AndroidStepDef;
import com.heb.automation.android.steps.coupons.AndroidStepdefCoupons;
import com.heb.automation.android.steps.myaccount.AndroidStepDefMyaccount;
import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.AppStoreTestPage;
import com.heb.automation.common.pages.AppcrashhandlerTestPage;
import com.heb.automation.common.pages.ContactUsTestPage;
import com.heb.automation.common.pages.HomeTestPage;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.coupons.CouponsselectionTestPage;
import com.heb.automation.common.pages.myaccount.ChangepasswordTestPage;
import com.heb.automation.common.pages.myaccount.MyaccountTestPage;
import com.heb.automation.common.pages.myaccount.MyhebbarcodeTestPage;
import com.heb.automation.common.pages.myaccount.MynotificationsTestPage;
import com.heb.automation.common.pages.myaccount.MyprofileTestPage;
import com.heb.automation.common.pages.registeration.DCEnrollmentTestPage;
import com.heb.automation.common.pages.registeration.ExtraOffersTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.common.pages.registeration.WantmoreTestPage;
import com.heb.automation.common.pages.shoppinglist.MylistTestPage;
import com.heb.automation.common.pages.shoppinglist.WeeklygroceriesTestPage;
import com.heb.automation.common.pages.storelocator.StoredetailsTestPage;
import com.heb.automation.common.pages.storelocator.StorelistviewresultTestPage;
import com.heb.automation.common.pages.storelocator.StorelocatorTestPage;
import com.heb.automation.common.pages.storelocator.StoremapviewTestPage;
import com.heb.automation.common.steps.CommonSteps;
import com.heb.automation.common.steps.myaccount.CommonStepDefMyAccounts;
import com.heb.automation.common.steps.registeration.CommonStepDefRegisteration;
import com.heb.automation.common.steps.storelocator.CommonStepDefStoreLocator;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.IOSStepdef;
import com.heb.automation.ios.steps.coupons.IOSStepdefCoupons;
import com.heb.automation.ios.steps.products.IOSStepdefproducts;
import com.heb.automation.ios.steps.registeration.IOSStepdefregisteration;
import com.heb.automation.ios.steps.shoppinglist.IOSStepdefshopinglist;
import com.heb.automation.ios.steps.storelocator.IOSStepDefStoreLocator;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.core.QAFTestBase;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

/*List of Steps in MyAccount

	I navigate to My Account page
	I see Registration page on clicking the Register button
	I update the Email, FirstName and LastName
	I verify the updated Email, FirstName and LastName
	I revert back the changes of Email, FirstName and LastName
	I am a hot user user with new registration
	I update the Email Subscriptions
	I verify the updated Subscriptions
	I do logout and login again
	I click on save button
	I validate the negative flow for change password
	I validate My Profile page by using invalid details
	I choose a store from the store locator page for store details
	I enter all required fields in registeration page
	I enter invalid phone number in offers page
	Enter the already enrolled Phone number in exptra offers page
	Enter the Previously un-enrolled Phone number in exptra offers page
	I validate error message for invalid mobile number
	I update the first name
	I see My Account/More page
	I login with updated email
	I navigate to extra offers page and validate the fields
	I enter all required fields in offers page
	Enter all required fields in Extra offers page
	I enter invalid password and validate error message
	I clear the mandatory field values and validate the error message
	I enter all required fields in Extra Offers page without Terms and Conditions
	I select a pharmacy store as my H-E-B store
	I navigate to store features and pharmacy number options
	I select a non pharmacy store as my H-E-B store
	I verify pharmacy info is not displayed for non pharmacy store
	I logout the application from MyAccount page
	I enter password in registration page
	I verify save button is disabled by default
	Clear the phone number field in offers page
	I verify save button is enabled after entering all details
	I register a new user enrolled with get extra offers
	I register new user with get extra offers with same phone number
	I verify tapping Show Password toggles password masking
	I click change password option
	I enter all fields in change password page
	I update the first name in My profile page
	I try to update the fields in My Profile page
	I verify the changes have been cancelled in My Profile page
	by tapping anywhere/clicking device back button should dismiss the keyboard
	I navigate to My H-E-B page
	I validate map and List view on denying permission
	I see home screen on clicking device back button from pick a store page
	I validate sections in Myaccount/more page as a hotuser
	I navigate to More/help page
	I validate sections in more/help page as a Cold user
	I validate options in Email notifications
	I validate all elements in Redeem Coupon page
	I see homepage/loginpage
	I validate weekly Ad switch is {0}
	I select store from My Store
	I enter invalid email in registeration page
	I enter all fields but not saved in change password page
	I verify the next button is available in keyboard
	I verify the Done button is available in keyboard
	I click on last name field
	I click on email field
	I see password is not valid text
	I enter all fields in change password page and cancel it
	I enter invalid password in registeration page
	I validate emailid&pwd by entering input with beyond limit in registeration page
	I navigate to offers page
	I validate the updated options in Email notifications
	I navigate back to previously viewed page
	I should see the Homepage/ More screen
	I validate default Email Preferences options
	I select store from My Store if not selected already
	I navigate to My Account page by clicking Hi <UserName> in HomePage
	I validate My Notifications page elements
	I click on Rate this App option
	I see H-E-B app page in App Store
	I click on Contact Us option
	I see Contact Us page
	I update the email notification
	I verify partner's name appears on the VPP Barcode screen
	I verify barcode appears at the bottom of the VPP Barcode screen
	I verify header image with the text on the VPP Barcode screen
	I verify Redeem Coupons does not appear on My Account page
	I verify Redeem button is not present in Selected Savings tab
	Create another account and navigate to Extra offers page
	Enter all required fields in offers page with already enrolled phone num
	I verify error message on the Log In page
	I verify email field is displayed on the Forgot Password page
	I verify error message for invalid email id
	I verify Reset Password button becomes enabled after entering email
	I verify email has send after clicking Reset Password button
	I enter invalid email id and valid password
	I enter valid email id and invalid password
	I am a hot user user with new registration and enrolled for Coupons
	I enter valid phone number in offers page
	I verify Redeem Coupons does not appear in the Left Nav menu
	I Login with invalid password 5 times
	Verify the Save button got disabled in offers page*/

public class IOSStepDefMyAccounts {

	/**
	 * Clicking on More option from Footer bar
	 * 
	 */
	@QAFTestStep(description = "I navigate to My Account page")
	public void iNavigateToMyAccountPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.waitForPageToLoad();
		ioscommon.getAppFooterMore().waitForPresent(5000);
		ioscommon.getAppFooterMore().click();
		PerfectoUtils.reportMessage("Clicked on More button from Footer.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Register button from My Lists page
	 * 
	 */
	@QAFTestStep(description = "I see Registration page on clicking the Register button")
	public void iSeeRegistrationPageOnClickingTheRegisterButton() {
		MylistTestPage mylist = new MylistTestPage();

		mylist.getMyListsBtnRegister().waitForPresent(3000);
		mylist.getMyListsBtnRegister().click();
		PerfectoUtils.reportMessage("Clicked on Register button..");
	}

	/**
	 * Updating the Email, First name and Last name and clicking Save button
	 * 
	 */
	@QAFTestStep(description = "I update the Email, FirstName and LastName")
	public void iUpdateTheEmailFirstNameAndLastName() {
		MyprofileTestPage myprofile = new MyprofileTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strNewEmailId = "";
		String strNewFirstname = "";
		String strNewLastname = "";

		// Getting the current email id, first name and password
		String strRegisterEmailId = myprofile.getMyprofileTxtEmail().getText();
		String strRegisterFirstname = myprofile.getMyprofileTxtFirstname().getText();
		String strregisterLastname = myprofile.getMyprofileTxtLastname().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregisterLastname", strregisterLastname);

		// Getting the new Email ID to update
		if (strRegisterEmailId.contains("1")) {
			strNewEmailId = strRegisterEmailId.replaceAll("1", "");
		} else {
			strNewEmailId = strRegisterEmailId.replaceAll("@heb", "1@heb");
		}

		// Creating the new First name to update
		if (strRegisterFirstname.contains("1")) {
			strNewFirstname = strRegisterFirstname.replaceAll("1", "");
		} else {
			strNewFirstname = strRegisterFirstname + "1";
		}

		// Creating the new last name to update
		if (strregisterLastname.contains("1")) {
			strNewLastname = strregisterLastname.replaceAll("1", "");
		} else {
			strNewLastname = strregisterLastname + "1";
		}

		getBundle().setProperty("NewEmailId", strNewEmailId);
		getBundle().setProperty("NewFirstname", strNewFirstname);
		getBundle().setProperty("NewLastname", strNewLastname);

		// Updating the First name
		myprofile.getMyprofileTxtFirstname().click();
		myprofile.getMyprofileTxtFirstname().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strNewFirstname);

		// Updating the last name
		myprofile.getMyprofileTxtLastname().click();
		myprofile.getMyprofileTxtLastname().sendKeys("");
		myprofile.getMyprofileTxtLastname().sendKeys(strNewLastname);

		// Updating the Email address
		myprofile.getMyprofileTxtEmail().click();
		myprofile.getMyprofileTxtEmail().sendKeys("");
		myprofile.getMyprofileTxtEmail().sendKeys(strNewEmailId);

		iosstepdef.clickKeyboardDoneIcon();

		// Checking if Save button is enabled
		if (myprofile.getBtnSaveprofile().isPresent()) {
			PerfectoUtils.reportMessage("Save button is enabled!", MessageTypes.Pass);
			myprofile.getBtnSaveprofile().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			// Click OK from the Warning pop-up
			if (weeklygrocery.getShopingListEntryByLable("Warning").isPresent()) {
				PerfectoUtils.reportMessage("Confirming for Email change", MessageTypes.Pass);
				clickOk();

				// Wait for the page to navigate to My account page
				myaccount.getBtnMystore().waitForPresent(50000);
				myaccount.getBtnMystore().verifyPresent();
			}
		} else {
			PerfectoUtils.reportMessage("Save button is not enabled!!", MessageTypes.Fail);
		}

		if (weeklygrocery.getShopingListEntryByLable("Update Profile").isPresent()) {
			PerfectoUtils.reportMessage("Error in updating user profile!! Server Down!!", MessageTypes.Fail);
			clickOk();
		} else {
			PerfectoUtils.reportMessage("First Name, Last name and Email are updated", MessageTypes.Pass);
		}

	}

	public static void clickOk() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		if (appcrash.getExceptionBtnOk().isPresent()) {
			appcrash.getExceptionBtnOk().click();
		} else if (appcrash.getExceptionBtnOk().isPresent()) {
			appcrash.getExceptionBtnOk().click();
		}
		PerfectoUtils.reportMessage("Clicked on Ok.", MessageTypes.Pass);
	}

	/**
	 * Verifying the Updated Email, First name and last names are available in
	 * My Profile page
	 * 
	 */
	@QAFTestStep(description = "I verify the updated Email, FirstName and LastName")
	public void iVerifyTheUpdatedEmailFirstNameAndLastName() {
		CommonStepDefMyAccounts myaccounts = new CommonStepDefMyAccounts();
		MyprofileTestPage myprofile = new MyprofileTestPage();
		IOSStepdefshopinglist ioscommonstep = new IOSStepdefshopinglist();

		// Navigating back to My profile page
		PerfectoUtils.reportMessage("Navigating back to My Profile page..", MessageTypes.Pass);
		myaccounts.iNavigateToMyProfilePage();

		String strNewEmailId = getBundle().getString("NewEmailId");
		String strNewFirstname = getBundle().getString("NewFirstname");
		String strNewLastname = getBundle().getString("NewLastname");

		// Checking whether the new Email ID has been updated
		if (myprofile.getMyprofileTxtEmail().getText().equalsIgnoreCase(strNewEmailId)) {
			PerfectoUtils.reportMessage("Email Id has been changed to " + strNewEmailId, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email Id has not been changed", MessageTypes.Fail);
		}

		// Checking whether the new First name has been updated
		if (myprofile.getMyprofileTxtFirstname().getText().equalsIgnoreCase(strNewFirstname)) {
			PerfectoUtils.reportMessage("Firstname has been changed to " + strNewFirstname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Firstname has not been changed", MessageTypes.Fail);
		}

		// Checking whether the new Last name has been updated
		if (myprofile.getMyprofileTxtLastname().getText().equalsIgnoreCase(strNewLastname)) {
			PerfectoUtils.reportMessage("Lastname has been changed to " + strNewLastname, MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Lastname has not been changed", MessageTypes.Fail);
		}

		ioscommonstep.iSelectDeviceBackButton();

	}

	/**
	 * Reverting back the Email, first name and last name fields an clicking on
	 * Save button
	 * 
	 */
	@QAFTestStep(description = "I revert back the changes of Email, FirstName and LastName")
	public void iRevertBackTheChangesOfEmailFirstNameAndLastName() {
		MyprofileTestPage myprofile = new MyprofileTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		String strOldEmailId = getBundle().getString("strRegisterEmailId");
		String strOldFirstname = getBundle().getString("strRegisterFirstname");
		String strOldLastname = getBundle().getString("strregisterLastname");

		// Updating the First name
		myprofile.getMyprofileTxtFirstname().click();
		myprofile.getMyprofileTxtFirstname().sendKeys("");
		myprofile.getMyprofileTxtFirstname().sendKeys(strOldFirstname);

		// Updating the last name
		myprofile.getMyprofileTxtLastname().sendKeys("");
		myprofile.getMyprofileTxtLastname().sendKeys(strOldLastname);

		// Updating the Email address
		myprofile.getMyprofileTxtEmail().sendKeys("");
		myprofile.getMyprofileTxtEmail().sendKeys(strOldEmailId);

		iosstepdef.clickKeyboardDoneIcon();

		// Checking if Save button is enabled
		if (myprofile.getBtnSaveprofile().isPresent()) {
			PerfectoUtils.verticalswipe();
			PerfectoUtils.reportMessage("Save button is enabled!", MessageTypes.Pass);
			myprofile.getBtnSaveprofile().waitForPresent(3000);
			myprofile.getBtnSaveprofile().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			// Click OK from the Warning pop-up
			if (weeklygrocery.getShopingListEntryByLable("Warning").isPresent()) {
				PerfectoUtils.reportMessage("Confirming for Email change", MessageTypes.Pass);
				clickOk();
				PerfectoUtils.reportMessage("Clicked Ok button.");

				// Wait for the page to navigate to My account page
				myaccount.waitForPageToLoad();
				myaccount.getBtnMystore().waitForPresent(80000);
				myaccount.getBtnMystore().verifyPresent();
			}
		} else {
			PerfectoUtils.reportMessage("Save button is not enabled!!", MessageTypes.Fail);
		}

	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I am a hot user user with new registration")
	public void iAmAHotUserUserWithNewRegistration() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		IOSStepdef iosstepdef = new IOSStepdef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		WantmoreTestPage wantmore = new WantmoreTestPage();

		// Prerequisite: verify the user is in login splash page
		iosstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();

		// Click Done button
		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		wantmore.getBtnDone().verifyPresent();
		wantmore.getBtnDone().click();
		PerfectoUtils.reportMessage("Clicked on Done button..");

		// Verify registration is success and currently in home page
		homepage.getHomeLblProduct().waitForPresent(50000);
		homepage.getHomeLblProduct().verifyPresent();
	}

	/**
	 * Updating the Email Subscriptions 1. Weekly Ads 2. Promotional 3. Monthly
	 * newsletter
	 * 
	 */
	@QAFTestStep(description = "I update the Email Subscriptions")
	public void iUpdateTheEmailSubscriptions() {
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();
		IOSStepdef iosdtepdef = new IOSStepdef();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String chkWeeklyAd = null;
		String chkPromotional = null;
		String chkMonthlyNL = null;

		mynotifipage.getRbtWeeklyad().waitForPresent(3000);

		// Checking whether the Weekly ad button is enabled
		chkWeeklyAd = mynotifipage.getRbtWeeklyad().getAttribute("value");

		if (chkWeeklyAd.equalsIgnoreCase("0")) {
			getBundle().setProperty("WeeklyAd_InitialStatus", "Off");
			mynotifipage.getRbtWeeklyad().click();
			// Select a Store
			if (mynotifipage.getLblSelectastore().isPresent()) {
				mynotifipage.getBtnSelectastore().click();
				storelocator.iChooseAStoreFromTheStoreLocatorPage();
				PerfectoUtils.reportMessage("Subscription enabled for Weekly Ad", MessageTypes.Pass);
			}
		} else if (chkWeeklyAd.equalsIgnoreCase("1")) {
			getBundle().setProperty("WeeklyAd_InitialStatus", "On");
			mynotifipage.getRbtWeeklyad().click();
			PerfectoUtils.reportMessage("Subscription disabled for Weekly Ad", MessageTypes.Pass);
		}

		ioscommon.getAppLblLoading().waitForNotPresent(50000);

		// Checking whether the Promotional button is enabled
		chkPromotional = mynotifipage.getRbtPromotional().getAttribute("value");

		if (chkPromotional.equalsIgnoreCase("1")) {
			getBundle().setProperty("Promotional_InitialStatus", "On");
			mynotifipage.getRbtPromotional().click();
			PerfectoUtils.reportMessage("Subscription disabled for Promotional", MessageTypes.Pass);
		} else if (chkPromotional.equalsIgnoreCase("0")) {
			getBundle().setProperty("Promotional_InitialStatus", "Off");
			mynotifipage.getRbtPromotional().click();
			PerfectoUtils.reportMessage("Subscription enabled for Promotional", MessageTypes.Pass);
		}

		ioscommon.getAppLblLoading().waitForNotPresent(50000);

		// Checking whether the Monthly Newsletter button is enabled
		chkMonthlyNL = mynotifipage.getRbtNewsletter().getAttribute("value");

		if (chkMonthlyNL.equalsIgnoreCase("1")) {
			getBundle().setProperty("MonthlyNewsletter_InitialStatus", "On");
			mynotifipage.getRbtNewsletter().click();
			PerfectoUtils.reportMessage("Subscription disabled for Monthly Newsletter", MessageTypes.Pass);
		} else if (chkMonthlyNL.equalsIgnoreCase("0")) {
			getBundle().setProperty("MonthlyNewsletter_InitialStatus", "Off");
			mynotifipage.getRbtNewsletter().click();
			PerfectoUtils.reportMessage("Subscription enabled for Monthly Newsletter", MessageTypes.Pass);
		}

		// Navigate back to MyAccount Page
		iosdtepdef.iNavigateToHomepageUsingBackButton();

		try {
			myaccount.getBtnMystore().waitForPresent(30000);
		} catch (Exception e) {
			try {
				myaccount.getBtnMystore().waitForPresent(10000);
				PerfectoUtils.reportMessage("Email subscriptions are updated", MessageTypes.Pass);
			} catch (Exception e1) {
				PerfectoUtils.reportMessage("Email subscriptions are not updated", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Verifying the Updated Email Subscriptions are available 1. Weekly Ads 2.
	 * Promotional 3. Monthly newsletter
	 * 
	 */
	@QAFTestStep(description = "I verify the updated Subscriptions")
	public void iVerifyTheUpdatedSubscriptions() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();

		String strWeeklyAd_InitialStatus = null;
		String strMonthlyNewsletter_InitialStatus = null;
		String strPromotional_InitialStatus = null;

		// Navigating back to My profile page
		myaccount.getLblMynotifications().waitForPresent(5000);
		myaccount.getLblMynotifications().click();

		// Checking if Navigated back to My Profile page
		if (mynotifipage.getRbtWeeklyad().isPresent()) {
			PerfectoUtils.verticalswipe();

			// Verifying the status of Weekly Ad subscription
			strWeeklyAd_InitialStatus = getBundle().getString("WeeklyAd_InitialStatus");
			if (strWeeklyAd_InitialStatus.equalsIgnoreCase("Off")) {
				if (mynotifipage.getRbtWeeklyad().getAttribute("value").equalsIgnoreCase("1")) {
					PerfectoUtils.reportMessage("The Subscription has been enabled for Weekly Ad", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been enabled for Weekly Ad",
							MessageTypes.Fail);
				}
			} else if (strWeeklyAd_InitialStatus.equalsIgnoreCase("On")) {
				if (mynotifipage.getRbtWeeklyad().getAttribute("value").equalsIgnoreCase("0")) {
					PerfectoUtils.reportMessage("The Subscription has been disabled for Weekly Ad", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been disabled for Weekly Ad",
							MessageTypes.Fail);
				}
			}

			// Verifying the status of Promotional subscription
			strPromotional_InitialStatus = getBundle().getString("Promotional_InitialStatus");
			if (strPromotional_InitialStatus.equalsIgnoreCase("Off")) {
				if (mynotifipage.getRbtPromotional().getAttribute("value").equalsIgnoreCase("1")) {
					PerfectoUtils.reportMessage("The Subscription has been enabled for Promotional", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been enabled for Promotional",
							MessageTypes.Fail);
				}
			} else if (strPromotional_InitialStatus.equalsIgnoreCase("On")) {
				if (mynotifipage.getRbtPromotional().getAttribute("value").equalsIgnoreCase("0")) {
					PerfectoUtils.reportMessage("The Subscription has been disabled for Promotional",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been disabled for Promotional",
							MessageTypes.Fail);
				}
			}

			// Verifying the status of Monthly Newsletter subscription
			strMonthlyNewsletter_InitialStatus = getBundle().getString("MonthlyNewsletter_InitialStatus");
			if (strMonthlyNewsletter_InitialStatus.equalsIgnoreCase("Off")) {
				if (mynotifipage.getRbtNewsletter().getAttribute("value").equalsIgnoreCase("1")) {
					PerfectoUtils.reportMessage("The Subscription has been enabled for Monthly Newsletter",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been enabled for Monthly Newsletter",
							MessageTypes.Fail);
				}
			} else if (strMonthlyNewsletter_InitialStatus.equalsIgnoreCase("On")) {
				if (mynotifipage.getRbtNewsletter().getAttribute("value").equalsIgnoreCase("0")) {
					PerfectoUtils.reportMessage("The Subscription has been disabled for Monthly Newsletter",
							MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("The Subscription has not been disabled for Monthly Newsletter",
							MessageTypes.Fail);
				}
			}
		} else {
			PerfectoUtils.reportMessage("Not navigated back to My Notifications page.", MessageTypes.Fail);
		}
	}

	/**
	 * Logging out and logging in again
	 * 
	 */
	@QAFTestStep(description = "I do logout and login again")
	public void iDoLogoutAndLoginAgain() {
		HomeTestPage home = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		// Clicking on logout
		IOSStepdef.iValidateLogout();

		// Navigating to login splash page
		if (home.getHomeLblSignin().isPresent()) {
			PerfectoUtils.reportMessage("In homepage..");
			home.getHomeLblSignin().click();
		} else if (loginsplash.getLoginTxtEmail().isPresent()) {
			PerfectoUtils.reportMessage("In login splash page.");
		}

		// Login Again
		String username = getBundle().getString("strRegisterEmailId");
		String pswd = getBundle().getString("strpassword");
		loginsplash.getLoginTxtEmail().waitForPresent(5000);
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		IOSStepdef.clickKeyboardDone();
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked on Login button..");

		try {
			loginsplash.getLoginBtnLogin().waitForNotPresent(30000);
		} catch (Exception e) {
			if (loginsplash.getLoginBtnLogin().isPresent()) {
				loginsplash.getLoginBtnLogin().click();
				PerfectoUtils.reportMessage("Clicked on Login button again..");
			}
			loginsplash.getLoginBtnLogin().waitForNotPresent(30000);
		}
	}

	/**
	 * Clicking on Save button from Change password screen
	 * 
	 */
	@QAFTestStep(description = "I click on save button")
	public void iClickOnSaveButton() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();

		IOSStepdef.clickKeyboardDone();
		// changepswd.getChangepswdTxtEnteroldpass().click();
		changepswd.getChangepswdBtnSave().verifyPresent();

		if (changepswd.getChangepswdBtnSave().getAttribute("enabled").equalsIgnoreCase("true")) {
			changepswd.getChangepswdBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");
		} else {
			PerfectoUtils.reportMessage("Save button is not enabled", MessageTypes.Fail);
		}

		if (weeklygrocery.getShopingListEntryByLable("Password Error").isPresent()) {
			PerfectoUtils.reportMessage("Password Error!!", MessageTypes.Info);
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Clicked on Ok button..");
		} else {
			PerfectoUtils.reportMessage("No Password Error!! Updated password!!", MessageTypes.Info);
		}
	}

	/**
	 * Entering the invalid password value and validating the error message
	 * 
	 */
	@QAFTestStep(description = "I validate the negative flow for change password")
	public void iValidateTheChangePasswordPage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		String pswd = getBundle().getString("default.user.password");
		changepswd.getLblPageTitle().waitForPresent(3000);
		changepswd.getLblPageTitle().click();
		PerfectoUtils.reportMessage("Clicked on Change Password.", MessageTypes.Pass);
		changepswd.getChangepswdTxtEnteroldpass().waitForPresent(3000);

		// Validation of old password
		validateerrorinchangepasswordpage("password1", pswd);
		// Validation of new password
		validateerrorinchangepasswordpage(pswd, pswd);
		// Validation of re-type Password
		validateerrorinchangepasswordpage("automation2", "automation3");

		changepswd.getChangepswdBtnBackIOS().waitForPresent(3000);
		changepswd.getChangepswdBtnBackIOS().click();
	}

	public void validateerrorinchangepasswordpage(String oldpassword, String newpassword) {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		changepswd.getChangepswdTxtEnteroldpass().click();
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpassword);
		changepswd.getChangepswdTxtEnternewpass().click();
		changepswd.getChangepswdTxtEnternewpass().sendKeys(newpassword);

		iosstepdef.clickKeyboardDoneIcon();
		if (changepswd.getChangepswdBtnSave().getAttribute("enabled").contains("false")) {
			PerfectoUtils.reportMessage("Save button is not enabled for invalid Password", MessageTypes.Pass);
		} else {
			changepswd.getChangepswdBtnSave().waitForPresent(3000);
			changepswd.getChangepswdBtnSave().click();
			PerfectoUtils.reportMessage("Clicked on Save button..");

			if (changepswd.getChangepswdLblPswderrormsg().isPresent()) {
				String errmsg = changepswd.getChangepswdLblPswderrormsg().getText();
				PerfectoUtils.reportMessage("Password is not changed:" + errmsg, MessageTypes.Pass);
				changepswd.getBtnWarningok().verifyPresent();
				changepswd.getBtnWarningok().click();
				PerfectoUtils.reportMessage("Clicked on Ok button from the popup..");
			} else {
				PerfectoUtils.reportMessage("Password is changed", MessageTypes.Fail);
			}
		}
	}

	/**
	 * Entering the Invalid inputs and Validating the error messages 1. First
	 * name 2. Last name 3. Email
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate My Profile page by using invalid details")
	public void iValidateMyProfilePageByUsingInvalidDetails() throws Exception {
		MyprofileTestPage myprofile = new MyprofileTestPage();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		CommonStepDefMyAccounts commonstepsMyacc = new CommonStepDefMyAccounts();

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtFirstname(), myprofile.getBtnSaveprofile(), "1234##",
				"First name is not valid");

		ioscommonpage.getAppBtnBackIOS().click();
		commonstepsMyacc.iNavigateToMyProfilePage();

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtLastname(), myprofile.getBtnSaveprofile(), "4567##",
				"Last name is not valid");
		ioscommonpage.getAppBtnBackIOS().click();
		commonstepsMyacc.iNavigateToMyProfilePage();

		checkingFieldsOnInvalidInput(myprofile.getMyprofileTxtEmail(), myprofile.getBtnSaveprofile(), "Testheb.com",
				"Email is not valid");
		ioscommonpage.getAppBtnBackIOS().click();

	}

	public static void checkingFieldsOnInvalidInput(QAFWebElement ElementPropertyofEdit,
			QAFWebElement ElementPropertySave, String inputValue, String expectedResult) {
		MyprofileTestPage myprofilepage = new MyprofileTestPage();

		ElementPropertyofEdit.click();
		ElementPropertyofEdit.sendKeys("");
		ElementPropertyofEdit.sendKeys(inputValue);
		hidekeypad();

		myprofilepage.getBtnSaveprofile().verifyPresent();
		myprofilepage.getBtnSaveprofile().click();
		PerfectoUtils.reportMessage("Clicked on Save button..");

		if (myprofilepage.getLblWarning().isPresent()) {
			PerfectoUtils.reportMessage("Warning message has populated", MessageTypes.Info);
			myprofilepage.getBtnWarningok().click();
			PerfectoUtils.reportMessage("Clicked on Ok button from the Popup..");
		}

		if (myprofilepage.getMyprofileTxtPopuperror().isPresent()) {
			PerfectoUtils.reportMessage("Error in updating profile! " + expectedResult, MessageTypes.Pass);
			myprofilepage.getBtnWarningok().click();
			PerfectoUtils.reportMessage("Clicked on OK button from the Popup..");
		} else {

			if (myprofilepage.getBtnSaveprofile().getAttribute("enabled").equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Save button disabled. Please check the values entered..",
						MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("No Error in updating profile. Save button not disabled!",
						MessageTypes.Fail);
			}
		}

	}

	/**
	 * Choosing a store from the Store locator list view
	 * 
	 */
	@QAFTestStep(description = "I choose a store from the store locator page for store details")
	public void iChooseAStoreFromTheStoreLocatorPageForStoreDetails() {
		StorelocatorTestPage storepage = new StorelocatorTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		String strNewStoreName, strOldStoreName, strNewStoreAdd;
		int getSize;

		strOldStoreName = getBundle().getString("oldStoreName");
		storepage.getStorelocatorImgListswitch().waitForPresent(5000);
		storepage.getStorelocatorImgListswitch().click();
		PerfectoUtils.reportMessage("Switching to listview..");

		storelistresult.launchPage(null);
		getSize = storelistresult.getStorelocatorLblStoreresults().size();
		strNewStoreName = storelistresult.getStorenameEntryByLable(getSize - 1).getText();
		strNewStoreAdd = storelistresult.getStoreaddressEntryByLable(getSize - 1).getText();

		if (strNewStoreName.equalsIgnoreCase(strOldStoreName)) {
			strNewStoreName = storelistresult.getStorenameEntryByLable(getSize - 2).getText();
			strNewStoreAdd = storelistresult.getStoreaddressEntryByLable(getSize - 2).getText();
			storelistresult.getStorenameEntryByLable(getSize - 2).click();
			PerfectoUtils.reportMessage("Selected Store: " + strNewStoreName);
		} else {
			strNewStoreName = storelistresult.getStorenameEntryByLable(getSize - 1).getText();
			strNewStoreAdd = storelistresult.getStoreaddressEntryByLable(getSize - 1).getText();
			storelistresult.getStorenameEntryByLable(getSize - 1).click();
		}

		getBundle().setProperty("StoreName", strNewStoreName);
		getBundle().setProperty("StoreAddressdetails", strNewStoreAdd);
		PerfectoUtils.reportMessage("Selected Store: " + strNewStoreName + "," + "Store address: " + strNewStoreAdd,
				MessageTypes.Pass);
	}

	/**
	 * Entering all the required fields in registration page, including the
	 * checking of "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in registeration page")
	public static void iEnterAllRequiredFieldsInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getTxtPagetitle().waitForPresent(50000);
		PerfectoUtils.setLocation("San antonio");

		try {
			clickNextButtonForNoOfTimes(3);
		} catch (Exception e) {
			e.printStackTrace();
		}
		register.getRegistrationBean().fillRandomData();
		register.getRegistrationBean().fillUiElements();

		register.getRegistrationTxtPassword().click();
		IOSStepdef.clickKeyboardDone();

		String strRegisterEmailId = register.getRegistrationTxtEmail().getText();
		String strRegisterFirstname = register.getRegistrationTxtFirstname().getText();
		String strregistrationLastname = register.getRegistrationTxtLastname().getText();
		String strRegisterpassword = register.getRegistrationTxtPassword().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregistrationLastname", strregistrationLastname);
		getBundle().setProperty("Registerpassword", strRegisterpassword);

		try {
			PerfectoUtils.verticalswipe();
			if (register.getRegistrationChkIagree().isPresent()) {
				register.getRegistrationChkIagree().click();
				PerfectoUtils.reportMessage("Clicked I agree check box..");
			} else {
				PerfectoUtils.scrollToStringuntilfindelement(register.getRegistrationChkIagree(), 80, 75, 2);
				if (!(register.getRegistrationBtnSubmit().getAttribute("enabled")).equals("true")) {
					register.getRegistrationChkIagree().click();
				}
				PerfectoUtils.reportMessage("Clicked I agree check box..");
			}
		} catch (Exception e) {
			PerfectoUtils.scrollToStringuntilfindelement(register.getRegistrationChkIagree(), 80, 75, 2);
			if (!(register.getRegistrationBtnSubmit().getAttribute("enabled")).equals("true")) {
				register.getRegistrationChkIagree().click();
			}
			PerfectoUtils.reportMessage("Clicked I agree check box");
		}
	}

	/**
	 * Enter Invalid mobile number and check "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter invalid phone number in offers page")
	public void iEnterInvalidPhoneNumberInOffersPage() {
		ExtraOffersTestPage extraoffertest = new ExtraOffersTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();
		String phoneNo = getBundle().getString("myaccount.details.invalidmobilenumber");

		extraoffertest.getEdtMobilenum().verifyPresent();
		extraoffertest.getEdtMobilenum().click();
		extraoffertest.getEdtMobilenum().sendKeys(phoneNo);
		iosstepdef.clickKeyboardDoneIcon();

		extraoffertest.getChkIagree().click();
		PerfectoUtils.reportMessage("Entered Invalid details in digital coupons page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Enter the already enrolled Phone number in exptra offers page")
	public void enterTheAlreadyEnrolledPhoneNumberInExptraOffersPage() {
		ExtraOffersTestPage extraoffertest = new ExtraOffersTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();
		String phoneNo = getBundle().getString("myaccount.details.coupons_alreadyenrolled");

		extraoffertest.getEdtMobilenum().verifyPresent();
		extraoffertest.getEdtMobilenum().click();
		// extraoffertest.getEdtMobilenum().sendKeys(phoneNo);
		PerfectoUtils.getDriver().getKeyboard().sendKeys(phoneNo);
		iosstepdef.clickKeyboardDoneIcon();

		extraoffertest.getChkIagree().click();
		PerfectoUtils.reportMessage("Entered Invalid details in digital coupons page", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Enter the Previously un-enrolled Phone number in exptra offers page")
	public void enterThePreviouslyUnEnrolledPhoneNumberInExptraOffersPage() {
		ExtraOffersTestPage extraoffertest = new ExtraOffersTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();
		String phoneNo = getBundle().getString("myaccount.details.coupons_unenrolled");

		extraoffertest.getEdtMobilenum().verifyPresent();
		extraoffertest.getEdtMobilenum().click();
		PerfectoUtils.getDriver().getKeyboard().sendKeys(phoneNo);
		// extraoffertest.getEdtMobilenum().sendKeys(phoneNo);
		iosstepdef.clickKeyboardDoneIcon();

		extraoffertest.getChkIagree().click();
		PerfectoUtils.reportMessage("Entered Invalid details in digital coupons page", MessageTypes.Pass);
	}

	/**
	 * Clicks Save button and Validates the Error message for the Invalid mobile
	 * number
	 * 
	 */
	@QAFTestStep(description = "I validate error message for invalid mobile number")
	public void iValidateErrorMessageForInvalidMobileNumber() {
		ExtraOffersTestPage extraoffertest = new ExtraOffersTestPage();

		if (extraoffertest.getBtnSave().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Submit is not enabled since invalid details are entered!", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Submit is enabled even though the invalid details are entered!",
					MessageTypes.Fail);
		}
	}

	/**
	 * Updating the First name fields from My Profile page
	 * 
	 */
	@QAFTestStep(description = "I update the first name")
	public void iUpdateTheFirstName() {

		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtFirstname().click();
		myprofile.getMyprofileTxtFirstname().sendKeys("ind");
		myprofile.getBtnSaveprofile().click();
		PerfectoUtils.reportMessage("Clicked on Save button..");
		QAFTestBase.pause(5000);
	}

	/**
	 * Verify whether navigated to More Page
	 * 
	 */
	@QAFTestStep(description = "I see My Account/More page")
	public void iSeeMyAccountPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		myaccount.getLblPagetitle().waitForPresent(5000);
		myaccount.getLblPagetitle().verifyPresent();
	}

	/**
	 * Logging out and logging in again with the updated Email
	 * 
	 */
	@QAFTestStep(description = "I login with updated email")
	public void iLoginAgain() {
		HomeTestPage home = new HomeTestPage();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		// Clicking on logout
		home.getAppFooterHomeicon().verifyPresent();
		home.getAppFooterHomeicon().click();
		IOSStepdef.iValidateLogout();

		// Login Again
		home.getHomeLblSignin().waitForPresent(3000);

		home.getHomeLblSignin().click();
		PerfectoUtils.reportMessage("Clicked Sign In and Navigating to login page..");
		String username = getBundle().getString("NewEmailId");
		String pswd = getBundle().getString("hebhotuser.emailchangeuser.password");
		loginsplash.getLoginTxtEmail().waitForPresent(5000);
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		IOSStepdef.clickKeyboardDone();
		PerfectoUtils.reportMessage("Entered the credentials.");
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login Button.", MessageTypes.Pass);
	}

	/**
	 * Clicks Extra Offers and validating the fields
	 * 
	 */
	@QAFTestStep(description = "I navigate to extra offers page and validate the fields")
	public void iNavigateToExtraOffersPageAndValidateTheFields() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			try {
				wantmore.getLblExtraOffers().waitForPresent(3000);
				wantmore.getLblExtraOffers().click();
				PerfectoUtils.reportMessage("Clicked on Extra Offers button..");
			} catch (Exception e) {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "Get Extra Offers");
				String isBtnDoneVisible = (String) wantmore.getTestBase().getDriver()
						.executeScript("mobile:checkpoint:text", params1);
				if (isBtnDoneVisible.equalsIgnoreCase("true")) {
					wantmore.getTestBase().getDriver().executeScript("mobile:text:select", params1);
					PerfectoUtils.reportMessage("Clicked Get Extra Offers page", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Did not clicked Get Extra Offers page", MessageTypes.Fail);
				}
			}

			extraoffers.getEdtMobilenum().waitForPresent(3000);
			extraoffers.getLblPageHeader().verifyPresent();
			extraoffers.getEdtMobilenum().verifyPresent();
			extraoffers.getChkIagree().verifyPresent();
			extraoffers.getLblDigitcoupdesc().verifyPresent();
			// extraoffers.getBtnSubmit().verifyPresent();
			extraoffers.getBtnSave().verifyPresent();

		} else {
			wantmore.getLblDigitalcoupons().waitForPresent(3000);
			wantmore.getLblDigitalcoupons().click();
			PerfectoUtils.reportMessage("Clicked on Digital Coupons..", MessageTypes.Pass);

		}
	}

	/**
	 * Entering All the required fields in Offers page and clicking save button
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in offers page")
	public void iEnterAllRequiredFieldsInOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();
		DCEnrollmentTestPage dcenrollment = new DCEnrollmentTestPage();

		PerfectoUtils.reportMessage("Registering for Digital coupons", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = strTimeStmp.substring(2, 12);
		String foutdigitpin = strTimeStmp.substring(2, 6);

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			extraoffers.getChkIagree().waitForPresent(3000);
			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			if (extraoffers.getBtnSave().getAttribute("enabled").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Save button is enabled..");
				extraoffers.getBtnSave().click();
				PerfectoUtils.reportMessage("Clicked on Submit button.");
			} else {
				PerfectoUtils.reportMessage("Save button not enabled.. Validate the input entered values!!",
						MessageTypes.Fail);
			}

		} else {
			dcenrollment.getTxtMobilenumber().waitForPresent(1000);
			dcenrollment.getTxtMobilenumber().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			dcenrollment.getChkTermsandconditions().waitForPresent(3000);
			dcenrollment.getChkTermsandconditions().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

			if (dcenrollment.getBtnSubmit().getAttribute("enabled").equalsIgnoreCase("true")) {
				PerfectoUtils.reportMessage("Save button is enabled..");
				dcenrollment.getBtnSubmit().click();
				PerfectoUtils.reportMessage("Clicked on Submit button.");
			} else {
				PerfectoUtils.reportMessage("Save button not enabled.. Validate the input entered values!!",
						MessageTypes.Fail);
			}
		}

		if (randomdata.getShopingListEntryByLable("SMS Error").isPresent()) {
			PerfectoUtils.reportMessage("SMS Error occurred!!", MessageTypes.Fail);
		}

	}

	@QAFTestStep(description = "Enter all required fields in Extra offers page")
	public void enterAllRequiredFieldsInExtraOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();
		DCEnrollmentTestPage dcenrollment = new DCEnrollmentTestPage();

		PerfectoUtils.reportMessage("Registering for Digital coupons", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = strTimeStmp.substring(2, 12);
		getBundle().setProperty("enrolledPhoneNumber", strPhonenum);

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			extraoffers.getChkIagree().waitForPresent(3000);
			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		} else {
			dcenrollment.getTxtMobilenumber().waitForPresent(1000);
			dcenrollment.getTxtMobilenumber().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			dcenrollment.getChkTermsandconditions().waitForPresent(3000);
			dcenrollment.getChkTermsandconditions().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		}
	}

	/**
	 * Entering Invalid password, clicking on Save button and validating the
	 * error message
	 * 
	 */
	@QAFTestStep(description = "I enter invalid password and validate error message")
	public void iEnterInvalidPasswordAndValidateErrorMessage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		IOSStepdef iostepdef = new IOSStepdef();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String strPswd = getBundle().getString("CurrentPassword");
		String strInvalidPswd1 = "test";

		changepswd.waitForPageToLoad();
		changepswd.getChangepswdTxtEnteroldpass().waitForPresent(5000);
		changepswd.getChangepswdTxtEnteroldpass().click();
		PerfectoUtils.getDriver().getKeyboard().sendKeys(strPswd);
		changepswd.getChangepswdTxtEnternewpass().click();
		PerfectoUtils.getDriver().getKeyboard().sendKeys(strInvalidPswd1);
		iostepdef.clickKeyboardDoneIcon();

		// Validate error message
		if (changepswd.getChangepswdSaveEnableByLable(1).isPresent()) {
			PerfectoUtils.reportMessage("Save button is enabled for invalid (less than 8 character) password!",
					MessageTypes.Fail);
		} else {
			PerfectoUtils.reportMessage("Save button is not enabled for invalid (less than 8 character) password!",
					MessageTypes.Pass);
		}

		ioscommon.getAppBtnBackIOS().click();
	}

	/**
	 * Clearing the mandatory fields values, click on Save button and validate
	 * the error messages
	 * 
	 */
	@QAFTestStep(description = "I clear the mandatory field values and validate the error message")
	public void iClearTheMandatoryFieldValuesAndValidateTheErrorMessage() {
		MyprofileTestPage myprofile = new MyprofileTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		// Clearing mandatory fields
		myprofile.getMyprofileTxtEmail().click();
		myprofile.getMyprofileTxtEmail().sendKeys("");
		myprofile.getMyprofileTxtEmail().sendKeys("a");
		PerfectoUtils.reportMessage("Entered Invalid email..", MessageTypes.Pass);

		iosstepdef.clickKeyboardDoneIcon();
		PerfectoUtils.verticalswipe();

		// Checking if Save button got disabled for invalid Email entry
		if (myprofile.getmyprofileImgSavebtn().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button got disabled as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button not disabled for invalid email entry..", MessageTypes.Fail);
		}

		// Validating the error message text on Invalid Email field
		boolean isErrMsgPresent = PerfectoUtils.validateTextIsPresent("Email is not valid");

		if (isErrMsgPresent)
			PerfectoUtils.reportMessage(isErrMsgPresent + ": Error message is present as expected.");
		else
			PerfectoUtils.reportMessage(isErrMsgPresent + ": Error message is not present in the screen.",
					MessageTypes.Fail);
	}

	/**
	 * Clicking on Save button without checking the "Terms and conditions" and
	 * validating the error message
	 * 
	 */
	@QAFTestStep(description = "I enter all required fields in Extra Offers page without Terms and Conditions")
	public void iEnterAllRequiredFieldsInExtraOffersPageWithoutTermsAndConditions() {
		IOSStepdef iosstepdef = new IOSStepdef();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();

		// Enter required fields
		extraoffers.getEdtMobilenum().verifyPresent();
		extraoffers.getEdtMobilenum().click();

		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(getBundle().getString("myaccount.details.phonenum"));
		iosstepdef.clickKeyboardDoneIcon();

		if (extraoffers.getLblPageHeader().isPresent()) {
			PerfectoUtils.reportMessage("Error:Please check Terms and Conditions", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Registered for digital coupons without phone number and pin",
					MessageTypes.Fail);
		}

		ioscommon.getAppBtnBackIOS().click();
	}

	/**
	 * Navigating to list view page, clicks on Refine option, Checks pharmacy
	 * option and clicking on "Done" button 2. Then selecting any of the store
	 * from the list view
	 * 
	 */
	@QAFTestStep(description = "I select a pharmacy store as my H-E-B store")
	public void iSelectAPharmacyStoreAsMyHEBStore() {
		CommonStepDefStoreLocator commonstepdefstore = new CommonStepDefStoreLocator();
		IOSStepDefStoreLocator iosstepdefstore = new IOSStepDefStoreLocator();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();

		IOSStepDefStoreLocator.iNavigateToListViewPage();
		commonstepdefstore.iSelectRefineButton();
		iosstepdefstore.iClickOnDoneApplyButtonAfterSelectingStores();

		// Select store from list view
		int getSize = storelistresult.getStorelocatorLblStoreresults().size();
		String strNewStoreName = storelistresult.getStorenameEntryByLable(getSize - 1).getText();
		getBundle().setProperty("StoreName", strNewStoreName);
		PerfectoUtils.reportMessage("Store Name:" + strNewStoreName);
		storelistresult.getStorenameEntryByLable(getSize - 1).click();
		PerfectoUtils.reportMessage("Selected the Store: " + strNewStoreName, MessageTypes.Pass);
	}

	/**
	 * Navigating to Store features and Clicking on Pharmacy phone number option
	 * and clicking on Cancel
	 * 
	 */
	@QAFTestStep(description = "I navigate to store features and pharmacy number options")
	public void iNavigateToStoreFeaturesAndPharmacyNumberOptions() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();

		// Navigate to Store features
		if (storedetail.getStoreldetailsLblSeestore().isPresent()) {
			storedetail.getStoreldetailsLblSeestore().click();
			storedetail.getStoreldetailsLblPgtitlestorefeature().verifyPresent();
			PerfectoUtils.reportMessage("Clicked on See Store Features", MessageTypes.Pass);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("Skipped click option", MessageTypes.Fail);
		}

		// Navigate to Pharmacy phone number
		storedetail.waitForPageToLoad();
		storedetail.getStoredetailsLnkPharmacyphonenumber().verifyAttribute("hidden", "false");
		String strPharmnum = storedetail.getStoredetailsLnkPharmacyphonenumber().getAttribute("label");
		weeklygrocery.getShopingListEntryByLable(strPharmnum).click();
		storedetail.waitForPageToLoad();

		if (storedetail.getStoreldetailsLblAlerttitle().isPresent()) {
			PerfectoUtils.reportMessage("Pharmacy Phone number dial alert is displayed", MessageTypes.Pass);
			storedetail.getStoredetailsLblCancel().click();
			PerfectoUtils.reportMessage("Clicked on cancel button", MessageTypes.Info);
			ioscommon.getAppBtnBackIOS().click();
		} else {
			PerfectoUtils.reportMessage("Pharmacy phone number is not present", MessageTypes.Fail);
		}
	}

	/**
	 * Searching with Non-pharmacy zip code and selecting a store from the
	 * result
	 * 
	 * @throws InterruptedException
	 */
	@QAFTestStep(description = "I select a non pharmacy store as my H-E-B store")
	public void iSelectANonPharmacyStoreAsMyHEBStore() throws InterruptedException {
		IOSStepDefStoreLocator iosstepdefstore = new IOSStepDefStoreLocator();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		IOSStepdefproducts iosstepdefprod = new IOSStepdefproducts();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		String strStoreName = getBundle().getString("storelocator.NonPharmacyStore");
		String intZipCode = getBundle().getString("storelocator.NonPharmacyStoreZip");
		IOSStepDefStoreLocator.iNavigateToListViewPage();
		iosstepdefstore.iSeeSearchFieldIsDisplayedByClickingOnSearchIconInMapViewOfStorelocator();
		iosstepdefprod.iEnterValidSearchTermAndSelectSearchButton(intZipCode);

		// Select store from list view
		storelistresult.waitForPageToLoad();

		System.out.println(strStoreName);

		try {
			ioscommon.getFullDynamicNameByLable(strStoreName).waitForPresent(5000);
			ioscommon.getFullDynamicNameByLable(strStoreName).click();
			PerfectoUtils.reportMessage("Non Pharmacy store selected: " + strStoreName, MessageTypes.Pass);
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Non Pharmacy store " + strStoreName + " is not Present", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the Pharmacy info is not present for the non-Pharmacy stores 1.
	 * Pharmacy label 2. Pharmacy Phone number
	 * 
	 */
	@QAFTestStep(description = "I verify pharmacy info is not displayed for non pharmacy store")
	public void iVerifyPharmacyInfoIsNotDisplayedForNonPharmacyStore() {
		StoredetailsTestPage storedetail = new StoredetailsTestPage();

		storedetail.waitForPageToLoad();

		if (!storedetail.getStoreDetailsLblPharmacy().isPresent()) {
			PerfectoUtils.reportMessage("Pharmacy details are not present for non pharmacy store as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Pharmacy details are present for non pharmacy store", MessageTypes.Fail);
		}
	}

	public void clickonsubmitbutton() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.verticalswipe();
		register.getRegistrationBtnSubmit().click();
		PerfectoUtils.reportMessage("Clicked on Submit button..");
		PerfectoUtils.horizontalswipe();
	}

	/**
	 * Clicking on Logout option from My Account page
	 * 
	 */
	@QAFTestStep(description = "I logout the application from MyAccount page")
	public void iLogoutTheApplicationFromMyAccountPage() throws Exception {

		IOSStepdef.iLogoutTheApplication();
	}

	@QAFTestStep(description = "I enter password in registration page")
	public void iEnterPasswordInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		hidekeypad();
		PerfectoUtils.verticalswipe();
		register.getRegistrationTxtPassword().verifyPresent();
		register.getRegistrationTxtPassword().sendKeys("testing");
		PerfectoUtils.reportMessage("Entered password..");
		hidekeypad();

	}

	/**
	 * verify save button is disabled by default
	 * 
	 */
	@QAFTestStep(description = "I verify save button is disabled by default")
	public void iVerifySaveButtonIsDisabledByDefault() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		String enabled = offerspage.getBtnSave().getAttribute("enabled");

		if (enabled.equals("false"))
			PerfectoUtils.reportMessage("save button is disabled by default", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("save button is not disabled by default", MessageTypes.Fail);

	}

	@QAFTestStep(description = "Clear the phone number field in offers page")
	public void clearThePhoneNumberFieldInOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();

		PerfectoUtils.scrollToElement(offerspage.getEdtMobilenumafterentered());
		offerspage.getEdtMobilenumafterentered().click();
		offerspage.getEdtMobilenumafterentered().clear();
		offerspage.getEdtMobilenumafterentered().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys("");
		PerfectoUtils.reportMessage("Entered phone number has been cleared..", MessageTypes.Pass);
	}

	/**
	 * verify save button is enabled after entering all details
	 * 
	 */
	@QAFTestStep(description = "I verify save button is enabled after entering all details")
	public void iVerifySaveButtonIsEnabledAfterEnteringAllDetails() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		AndroidcommonTestPage androidcommon = new AndroidcommonTestPage();

		PerfectoUtils.reportMessage("Registering for Extra Offers", MessageTypes.Pass);

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String strPhonenum = "8" + strTimeStmp.substring(3, 12);
		String strpin = strTimeStmp.substring(8, 12);

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			// extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			hidekeypad();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

		} else {
			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			extraoffers.getEdtMobilenum().sendKeys(strPhonenum);
			hidekeypad();

			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

		}
		extraoffers.getBtnSave().waitForPresent(10000);
		String enabled = extraoffers.getBtnSave().getAttribute("enabled");

		if (enabled.equals("true"))
			PerfectoUtils.reportMessage("save button is enabled after all details entered", MessageTypes.Pass);
		else
			PerfectoUtils.reportMessage("save button is not enabled after all details entered", MessageTypes.Fail);
	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I register a new user enrolled with get extra offers")
	public void iRegisterANewUserEnrolledWithGetExtraOffers() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		IOSStepdef iosstepdef = new IOSStepdef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		CommonStepDefMyAccounts commonstepsMyAccount = new CommonStepDefMyAccounts();
		AndroidStepDefMyaccount andStepDefMyAcc = new AndroidStepDefMyaccount();

		// Prerequisite: verify the user is in login splash page
		iosstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		commonstepsMyAccount.iNavigateToWantMorePageOnClickingSkipForNow();

		// Register for get extra offers

		iNavigateToExtraOffersPageAndValidateTheFields();
		iEnterAllRequiredFieldsInOffersPage();
		commonstepsMyAccount.iValidateTheUserRegisteredForOffersInWantmorePage();

		// Click Done from want more page
		CommonStepDefMyAccounts.iClickDoneFromWantMorePage();

		// Verify registration is success and currently in home page
		homepage.getHomeLblWeeklyAd().waitForPresent(50000);
		homepage.getHomeLblWeeklyAd().verifyPresent();
	}

	/**
	 * Doing registration and navigating to the device home screen
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I register new user with get extra offers with same phone number")
	public void iRegisterANewUserWithEnrolledWithGetExtraOffersWithSamePhoneNumber() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		IOSStepdef iosstepdef = new IOSStepdef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		CommonStepDefMyAccounts commonstepsMyAccount = new CommonStepDefMyAccounts();
		CommonStepDefMyAccounts commonStepDefMyAcc = new CommonStepDefMyAccounts();

		// Prerequisite: verify the user is in login splash page
		iosstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		commonstepsMyAccount.iNavigateToWantMorePageOnClickingSkipForNow();

		// Register for get extra offers

		iNavigateToExtraOffersPageAndValidateTheFields();
		commonStepDefMyAcc.iEnterAllRequiredFieldsInOffersPageWithRegisteredPhoneNumber();

	}

	/**
	 * Verifying entering password in registration page
	 */
	@QAFTestStep(description = "I verify tapping Show Password toggles password masking")
	public void iVerifyTappingShowPasswordTogglesPasswordMasking() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String masked = "true";

		register.getImgShowPwd().verifyPresent();
		register.getImgShowPwd().click();

		try {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "GROUP:Android/store Locator/testing_passwordunmasked.png");
			Object result1 = register.getTestBase().getDriver().executeScript("mobile:image:find", params1);

			PerfectoUtils.reportMessage("Password is unmasked on clicking show..", MessageTypes.Pass);
			masked = "false";

		} catch (Exception e) {
			PerfectoUtils.reportMessage("Password is not unmasked on clicking show..", MessageTypes.Fail);
		}

		if (masked.equals("false")) {
			register.getImgHidePwd().click();
			try {
				Map<String, Object> params1 = new HashMap<>();
				params1.put("content", "GROUP:Android/store Locator/testing_Passwordmasked.png");
				Object result1 = register.getTestBase().getDriver().executeScript("mobile:image:find", params1);

				PerfectoUtils.reportMessage("Password is masked on clicking show_hide..", MessageTypes.Pass);
				masked = "true";

			} catch (Exception e) {
				PerfectoUtils.reportMessage("Password is not masked on clicking show..", MessageTypes.Fail);
			}

		}

	}

	public static void hidekeypad() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		int i = 0;
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find",
				params1);

		while ((isBtnDoneVisible.equalsIgnoreCase("false")) && (i < 5)) {
			try {
				params1.put("content", "Next");
				Object result1 = register.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			} catch (Exception e) {
				try {
					// click search button on keyboard
					Map<String, Object> param1 = new HashMap<>();
					param1.put("keySequence", "KEYBOARD_NEXT");
					PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
				} catch (Exception g) {
					e.printStackTrace();
				}
			}

			params1.put("content", "Done");
			isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params1);
			i++;
		}

		IOSStepdef.clickKeyboardDone();
	}

	/**
	 * Clicking on Change Password option
	 * 
	 */
	@QAFTestStep(description = "I click change password option")
	public void iClickChangePasswordOption() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getLnkChgpwd().waitForPresent(3000);
		myprofile.getLnkChgpwd().click();
		PerfectoUtils.reportMessage("Clicked on Change Password option..");
	}

	/**
	 * Entering the required fields in Change password page
	 * 
	 */
	@QAFTestStep(description = "I enter all fields in change password page")
	public void iEnterAllFieldsInChangePasswordPage() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		String newpswd = getBundle().getString("myaccount.changepassword.password");
		String oldpswd = getBundle().getString("Registerpassword");

		changepswd.getChangepswdTxtEnteroldpass().verifyPresent();

		changepswd.getChangepswdTxtEnteroldpass().click();
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpswd);
		changepswd.getChangepswdTxtEnternewpass().click();
		changepswd.getChangepswdTxtEnternewpass().sendKeys(newpswd);

		changepswd.getChangepswdTxtEnteroldpass().click();
		getBundle().setProperty("strpassword", newpswd);

		/**
		 * Handling of 'OK' button for error previous and current password
		 * should not be same
		 */

		if (appcrash.getExceptionBtnOk().isPresent()) {
			appcrash.getExceptionBtnOk().click();
			PerfectoUtils.reportMessage("Clicked on Ok button from the pop up..");
		} else {
			PerfectoUtils.reportMessage("OK button is not present");
		}

		// Clicking on Cancel button in Login required pop-up
		if (appcrash.getExceptionTxtLoginrequired().isPresent()) {
			appcrash.getExceptionBtnCancel().click();
			PerfectoUtils.reportMessage("Unable to change password Login required popup appeared");
		}
	}

	/**
	 * Updating the First name fields from My Profile page
	 * 
	 */
	@QAFTestStep(description = "I update the first name in My profile page")
	public void iUpdateTheFirstNameInMyProfilePage() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtFirstname().verifyPresent();
		String fname = myprofile.getMyprofileTxtFirstname().getText();

		String randomName = PerfectoUtils.randomName();
		randomName = randomName.substring(0, randomName.indexOf("-"));
		myprofile.getMyprofileTxtFirstname().click();
		myprofile.getMyprofileTxtFirstname().clear();
		myprofile.getMyprofileTxtFirstname().sendKeys(randomName);
		PerfectoUtils.reportMessage("First Name id updated from: " + fname + " to: " + randomName, MessageTypes.Pass);
		hidekeypad();
	}

	/**
	 * Trying to Update the fields in My profile page 1. Email 2. First name 3.
	 * last name without clicking the save button
	 * 
	 */
	@QAFTestStep(description = "I try to update the fields in My Profile page")
	public void iTryToUpdateTheFieldsInMyProfilePage() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		String strNewEmailId = "";
		String strNewFirstname = "";
		String strNewLastname = "";

		// Getting the current email id, first name and password
		String strRegisterEmailId = myprofile.getMyprofileTxtEmail().getText();
		String strRegisterFirstname = myprofile.getMyprofileTxtFirstname().getText();
		String strRegisterLastname = myprofile.getMyprofileTxtLastname().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregisterLastname", strRegisterLastname);

		// Getting the new Email ID to update
		if (strRegisterEmailId.contains("1")) {
			strNewEmailId = strRegisterEmailId.replaceAll("1", "");
		} else {
			strNewEmailId = strRegisterEmailId.replaceAll("@heb", "1@heb");
		}

		// Creating the new First name to update
		if (strRegisterFirstname.contains("1")) {
			strNewFirstname = strRegisterFirstname.replaceAll("1", "");
		} else {
			strNewFirstname = strRegisterFirstname + "1";
		}

		// Creating the new last name to update
		if (strRegisterLastname.contains("1")) {
			strNewLastname = strRegisterLastname.replaceAll("1", "");
		} else {
			strNewLastname = strRegisterLastname + "1";
		}

		getBundle().setProperty("NewEmailId", strNewEmailId);
		getBundle().setProperty("NewFirstname", strNewFirstname);
		getBundle().setProperty("NewLastname", strNewLastname);

		// Updating the First name
		myprofile.getMyprofileTxtFirstname().sendKeys("");
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strNewFirstname);

		// Updating the last name
		myprofile.getMyprofileTxtLastname().sendKeys("");
		myprofile.getMyprofileTxtLastname().sendKeys(strNewLastname);

		// Updating the Email address
		myprofile.getMyprofileTxtEmail().sendKeys("");
		myprofile.getMyprofileTxtEmail().sendKeys(strNewEmailId);

		hidekeypad();
	}

	/**
	 * Verifying the values remain unchanged in My Profile page
	 * 
	 */
	@QAFTestStep(description = "I verify the changes have been cancelled in My Profile page")
	public void iVerifyTheChangesHaveBeenCancelledInMyProfilePage() {
		CommonStepDefMyAccounts commonsteps = new CommonStepDefMyAccounts();
		MyprofileTestPage myprofile = new MyprofileTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		commonsteps.iNavigateToMyProfilePage();

		String strExpectedEmailId = getBundle().getString("strRegisterEmailId");
		String strExpectedFirstname = getBundle().getString("strRegisterFirstname");
		String strExpectedLastname = getBundle().getString("strregisterLastname");

		String strActualEmailId = myprofile.getMyprofileTxtEmail().getText();
		String strActualFirstname = myprofile.getMyprofileTxtFirstname().getText();
		String strActualLastname = myprofile.getMyprofileTxtLastname().getText();

		if ((strActualEmailId.equals(strExpectedEmailId)) && (strActualFirstname.equals(strExpectedFirstname))
				&& (strActualLastname.equals(strExpectedLastname))) {
			PerfectoUtils.reportMessage("Changes are cancelled and Same values remain in Fields", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Changes are not cancelled and Same values are not remained in Fields",
					MessageTypes.Fail);
		}

		iosstepdef.iClickOnCancelDeviceBackButton();
	}

	/**
	 * Hiding the keyboard by clicking the device back button
	 * 
	 */
	@QAFTestStep(description = "by tapping anywhere/clicking device back button should dismiss the keyboard")
	public void byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		PerfectoUtils.horizontalswipe();
		register.getTxtPagetitle().waitForPresent(5000);
		register.getTxtPagetitle().click();

		register.getTxtPagetitle().waitForPresent(4000);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);
		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("timeout", "20");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		params1.put("content", "Next");
		String isBtnNextVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);
		if (isBtnNextVisible.equalsIgnoreCase("true")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Next");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("timeout", "20");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnNextVisible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnDoneVisible.equalsIgnoreCase("false") && isBtnNextVisible.equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Keyboard is getting closed when tapping at HEB image as expected.",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Keyboard is not getting closed when tapping at HEB image as expected.",
					MessageTypes.Fail);
		}
	}

	/**
	 * Navigating to My HEB page
	 * 
	 */
	@QAFTestStep(description = "I navigate to My H-E-B page")
	public void iNavigateToMyHEBPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();

		String strStoreName = "";
		myaccount.waitForPageToLoad();
		myaccount.getBtnMystore().waitForPresent(50000);

		if ((myaccount.getLblSelectstore().getText()).equals("Select a Store")) {
			strStoreName = myaccount.getLblSelectstore().getText();
		}

		myaccount.getBtnMystore().click();
		PerfectoUtils.reportMessage("Clicked on My Store.", MessageTypes.Pass);

		if (strStoreName.equalsIgnoreCase("Select a Store")) {
			storelocator.iChooseAStoreFromTheStoreLocatorPage();
			PerfectoUtils.reportMessage("Selected store.", MessageTypes.Info);
			myaccount.getBtnMystore().click();
			PerfectoUtils.reportMessage("Clicked on My Store.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store already selected.");
		}
	}

	/**
	 * Denying the Allow location access pop up and validating the store details
	 * are not available in Map view and List view in Store locator
	 * 
	 */
	@QAFTestStep(description = "I validate map and List view on denying permission")
	public void iValidateMapAndListViewOnDenyingPermission() {
		StorelocatorTestPage storelocator = new StorelocatorTestPage();
		StoremapviewTestPage mapview = new StoremapviewTestPage();
		StorelistviewresultTestPage storelistresult = new StorelistviewresultTestPage();
		WeeklygroceriesTestPage weeklygrocery = new WeeklygroceriesTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Click on Deny in location access pop up
		try {
			weeklygrocery.getShopingListEntryByLable("access your location").waitForPresent(3000);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (weeklygrocery.getShopingListEntryByLable("access your location").isPresent()) {
			PerfectoUtils.reportMessage("H-E-B to access device location Pop up", MessageTypes.Pass);
			ioscommon.getAppBtnPopupallowpermissiondeny().verifyPresent();
			ioscommon.getAppBtnPopupallowpermissiondeny().click();
			PerfectoUtils.reportMessage("Clicked Deny button.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Store locator location allow pop up is not populated", MessageTypes.Info);
		}

		// Validating map view is not loaded with stores
		storelocator.getStorelocatorLblRefine().verifyPresent();
		mapview.getStorelocatorMapSelectstore().verifyPresent();

		// Navigate to list view and validate stores are not displayed
		storelocator.getStorelocatorImgListswitch().click();
		int results = storelistresult.getStorelocatorLblStoreresults().size();

		if (results == 0) {
			PerfectoUtils.reportMessage("No Stores are displaying in List View", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Stores are displaying in List View", MessageTypes.Info);
		}
	}

	/**
	 * Clicking device back button and verify navigated to homescreen
	 * 
	 */
	@QAFTestStep(description = "I see home screen on clicking device back button from pick a store page")
	public void iSeeHomeScreenOnClickingDeviceBackButtonFromPickAStorePage() {

		// Functionality is not applicable to iOS
		PerfectoUtils.reportMessage("This Functionality is not applicable for iOS", MessageTypes.Info);
	}

	/**
	 * Validating the fields in My Account page as a hot user
	 * 
	 */
	@QAFTestStep(description = "I validate sections in Myaccount/more page as a hotuser")
	public void iValidateSectionsInMyaccountMorePageAsAHotuser() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		// Validating the Top sections
		myaccount.getBtnMyprofile().verifyPresent();
		myaccount.getLblMyhebbarcode().verifyPresent(); // Redeem Coupons
		myaccount.getLblMynotifications().verifyPresent();
		myaccount.getBtnMystore().verifyPresent();
		myaccount.getLblSelectstore().verifyPresent();

		// Validating the bottom sections
		myaccount.getBtnFaqs().verifyPresent();
		myaccount.getBtnPrivacypolicy().verifyPresent();
		PerfectoUtils.verticalswipe(80, 75, 2);
		myaccount.getBtnTermsncondtn().verifyPresent();
		myaccount.getLblRatethisapp().verifyPresent();
		myaccount.getLblContactus().verifyPresent();
		myaccount.getBtnLogout().verifyPresent();
	}

	/**
	 * Clicking on More icon from the Footer bar
	 * 
	 */
	@QAFTestStep(description = "I navigate to More/help page")
	public void iNavigateToMoreHelpPage() {
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		ioscommon.getAppFooterMore().waitForPresent(3000);
		ioscommon.getAppFooterMore().click();
		PerfectoUtils.reportMessage("Clicked on More option from Footer.", MessageTypes.Pass);
	}

	/**
	 * validating the sections from More page as a cold user
	 * 
	 */
	@QAFTestStep(description = "I validate sections in more/help page as a Cold user")
	public void iValidateSectionsInMoreHelpPageAsAColdUser() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		// Validating the Top sections
		PerfectoUtils.reportMessage("Validating the More screen as a cold user.", MessageTypes.Pass);
		myaccount.getBtnSignin().verifyPresent();
		ioscommon.getAppMoreRegister().verifyPresent();

		// Validating the bottom sections
		myaccount.getBtnFaqs().verifyPresent();
		myaccount.getBtnPrivacypolicy().verifyPresent();
		PerfectoUtils.verticalswipe(80, 75, 2);
		myaccount.getBtnTermsncondtn().verifyPresent();
		myaccount.getLblRatethisapp().verifyPresent();
		myaccount.getLblContactus().verifyPresent();

	}

	/**
	 * Selecting the toggle switch of all the Email notification options 1.
	 * Weekly ads 2. Promotional 3. Monthly newsletter and click on "Done"
	 * button
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I validate options in Email notifications")
	public void iValidateOptionsInEmailNotifications() throws Exception {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		MynotificationsTestPage mynotification = new MynotificationsTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		wantmore.getLblEmainotification().verifyPresent();

		// Verify the updated notifications
		wantmore.getWeeklyadSwitch().click();
		PerfectoUtils.reportMessage("Clicked on Weekly Ads Toggle switch..");

		// Select a Store
		if (mynotification.getLblSelectastore().isPresent()) {
			PerfectoUtils.reportMessage("Select a store pop up is displayed", MessageTypes.Pass);
			mynotification.getBtnSelectastore().click();
			storelocator.iChooseAStoreFromTheStoreLocatorPage();
		} else {
			PerfectoUtils.reportMessage("Select a store pop up is not displayed", MessageTypes.Fail);
		}

		ioscommon.getAppLblLoading().waitForNotPresent(50000);
		PerfectoUtils.reportMessage("Modified Subscription for Weekly Ad", MessageTypes.Pass);
		getBundle().setProperty("WeeklyAd", wantmore.getWeeklyadSwitch().getAttribute("value"));
		PerfectoUtils
				.reportMessage("Weekly Ads Subscription status: " + wantmore.getWeeklyadSwitch().getAttribute("value"));

		wantmore.getPromotionalSwitch().click();
		ioscommon.getAppLblLoading().waitForNotPresent(50000);
		getBundle().setProperty("Promotional", wantmore.getPromotionalSwitch().getAttribute("value"));
		PerfectoUtils.reportMessage(
				"Promotional Subscription status: " + wantmore.getPromotionalSwitch().getAttribute("value"));

		wantmore.getNewsletterSwitch().click();
		ioscommon.getAppLblLoading().waitForNotPresent(50000);
		getBundle().setProperty("Newsletter", wantmore.getNewsletterSwitch().getAttribute("value"));
		PerfectoUtils.reportMessage(
				"Newsletter Subscription status: " + wantmore.getNewsletterSwitch().getAttribute("value"));

		PerfectoUtils.verticalswipe();
		wantmore.getBtnDone().verifyPresent();
		wantmore.getBtnDone().click();
		PerfectoUtils.reportMessage("Clicked on Done button..");
	}

	/**
	 * Validating the fields from My HEB bar code page
	 * 
	 */
	@QAFTestStep(description = "I validate all elements in Redeem Coupon page")
	public void iValidateAllElementsInMyHEBBarcodePage() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			// myhebbarcode.getLblPagetitle().verifyPresent();// HEB Logo
			if (myhebbarcode.getLblBarcodephototext().isPresent()
					|| myhebbarcode.getLblBarcodephototext().isPresent()) {
				PerfectoUtils.reportMessage("Barcode photo text is present", MessageTypes.Pass);
			}
			// myhebbarcode.getLblBarcodephototext().verifyPresent(); // Text:
			// Scan
			// this
			// barcode
			// in store
			// to redeem
			// your
			// coupons
			myhebbarcode.getLblNamelabel().verifyPresent();
			myhebbarcode.getLblNamevalue().verifyPresent();
			myhebbarcode.getImgBarcode().verifyPresent();
			myhebbarcode.getLblBarcodenumber().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	/**
	 * Verifying navigated to Home page 1. Checks register option is present
	 * 
	 */
	@QAFTestStep(description = "I see homepage/loginpage")
	public void iSeeHomepageLoginpage() {

		IOSStepdef.iSeeHomepage();
	}

	/**
	 * Validating the Weekly Ad switch value is set to true after selecting the
	 * store from the pop up
	 * 
	 * @param str1
	 */
	@QAFTestStep(description = "I validate weekly Ad switch is {0}")
	public void iValidateWeeklyAdSwitchIs(String str1) {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		if (str1.equalsIgnoreCase("ON")) {
			str1 = "1";
		} else if (str1.equalsIgnoreCase("OFF")) {
			str1 = "0";
		}

		wantmore.getLblPageHeader().waitForPresent(5000);
		PerfectoUtils.horizontalswipe();
		String statusWeeklyAdToggle = wantmore.getWeeklyadSwitch().getAttribute("value");

		// Verify whether the Weekly Ad toggle switch is ON
		if (statusWeeklyAdToggle.equalsIgnoreCase(str1)) {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is set to " + str1 + " after selecting store",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is not set to " + str1 + " after selecting store",
					MessageTypes.Fail);
		}
	}

	/**
	 * selecting a store from My HEB Page
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I select store from My Store")
	public void iSelectStoreFromMyStore() throws Exception {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();

		myaccount.getLblSelectstore().verifyPresent();
		myaccount.getLblSelectstore().click();
		PerfectoUtils.reportMessage("Clicked on Seelct Store option..");

		storelocator.iChooseAStoreFromTheStoreLocatorPage();
		myaccount.getLblSelectstore().waitForPresent(5000);
		PerfectoUtils.reportMessage("Store name is selected as" + (myaccount.getLblSelectstore().getText()),
				MessageTypes.Pass);
	}

	/**
	 * Entering the Invalid Email in registration fields. and valid details in
	 * other fields
	 * 
	 */
	@QAFTestStep(description = "I enter invalid email in registeration page")
	public void iEnterInvalidEmailInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.launchPage(null);

		String strRegisterEmailId = getBundle().getString("registration.invalidemailaddress1");

		byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();

		register.getRegistrationTxtPassword().click();
		register.getRegistrationTxtPassword().sendKeys(getBundle().getString("registration.Password"));
		register.getImgShowPwd().click();
		PerfectoUtils.reportMessage("Entered valid Password..");

		register.getRegistrationTxtFirstname().click();
		register.getRegistrationTxtFirstname().sendKeys(getBundle().getString("registration.FirstName"));
		PerfectoUtils.reportMessage("Entered valid Firstname..");

		register.getRegistrationTxtLastname().click();
		register.getRegistrationTxtLastname().sendKeys(getBundle().getString("registration.LastName"));
		PerfectoUtils.reportMessage("Entered valid Lastname..");

		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().sendKeys(strRegisterEmailId);
		PerfectoUtils.reportMessage("Entered Invalid Email..");

		byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();

		PerfectoUtils.reportMessage("Required details are entered in registration page", MessageTypes.Pass);

		try {
			register.getRegistrationChkIagree().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			register.getRegistrationChkIagree().waitForPresent(5000);
		}

		register.getRegistrationChkIagree().click();
		PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
	}

	/**
	 * Enter All fields in Change OPassword page , but not selecting the "Save"
	 * button
	 * 
	 */
	@QAFTestStep(description = "I enter all fields but not saved in change password page")
	public void iEnterAllFieldsButNotSavedInChangePasswordPage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		String newpswd = getBundle().getString("myaccount.changepassword.password");
		String oldpswd = getBundle().getString("strpassword");

		changepswd.getChangepswdTxtEnteroldpass().click();
		changepswd.getChangepswdTxtEnteroldpass().waitForPresent(3000);
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpswd);
		changepswd.getChangepswdTxtEnternewpass().click();
		changepswd.getChangepswdTxtEnternewpass().sendKeys(newpswd);
		iosstepdef.clickKeyboardDoneIcon();
	}

	public static void clickNextButtonForNoOfTimes(int noOfTimes) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		int i = 1;
		Map<String, Object> params1 = new HashMap<>();

		while (i <= noOfTimes) {

			try {
				params1.put("content", "Next");
				Object result1 = register.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			} catch (Exception e) {
				// click search button on keyboard
				Map<String, Object> param1 = new HashMap<>();
				param1.put("keySequence", "KEYBOARD_NEXT");
				PerfectoUtils.getAppiumDriver().executeScript("mobile:presskey", param1);
			}
			i++;
		}

	}

	/**
	 * Verifying the next button is available in the Keyboard
	 * 
	 */
	@QAFTestStep(description = "I verify the next button is available in keyboard")
	public void iVerifyTheNextButtonIsAvailableInKeyboard() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.waitForPageToLoad();
		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Next");
		String isBtnNextVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find",
				params1);

		if (isBtnNextVisible.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Next");
			params2.put("timeout", "20");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnNextVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnNextVisible.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Next button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Next button is not available in the Keyboard.", MessageTypes.Fail);
		}
	}

	/**
	 * Verifying the Done button is available in the Keyboard
	 * 
	 */
	@QAFTestStep(description = "I verify the Done button is available in keyboard")
	public void iVerifyTheDoneButtonIsAvailableInKeyboard() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Done");
		String isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnDoneVisible1.equalsIgnoreCase("false")) {
			Map<String, Object> params2 = new HashMap<>();
			params2.put("content", "Done");
			params2.put("timeout", "20");
			params2.put("profile", "DocumentConversion_Speed");
			params2.put("analysis", "manual");
			params2.put("inverse", "yes");
			params2.put("screen.top", "69%");
			params2.put("screen.height", "31%");
			params2.put("screen.left", "51%");
			params2.put("screen.width", "49%");
			isBtnDoneVisible1 = (String) myprofile.getTestBase().getDriver().executeScript("mobile:text:find", params2);

		}

		if (isBtnDoneVisible1.equalsIgnoreCase("true")) {
			PerfectoUtils.reportMessage("Done button is available in the Keyboard as expected.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Done button is not available in the Keyboard.", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on last name field
	 * 
	 */
	@QAFTestStep(description = "I click on last name field")
	public void iClickOnLastNameField() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtLastname().waitForPresent(3000);
		myprofile.getMyprofileTxtLastname().click();
		PerfectoUtils.reportMessage("CLicked on Last name field.", MessageTypes.Pass);

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Delete");
		String isBtnDoneVisible = (String) myprofile.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);
		if (isBtnDoneVisible.equalsIgnoreCase("true")) {
			myprofile.getTestBase().getDriver().executeScript("mobile:text:select");
		}
	}

	/**
	 * Clicking on Email field
	 *
	 */
	@QAFTestStep(description = "I click on email field")
	public void iClickOnEmailField() {
		MyprofileTestPage myprofile = new MyprofileTestPage();

		myprofile.getMyprofileTxtEmail().waitForPresent(3000);
		myprofile.getMyprofileTxtEmail().click();
		PerfectoUtils.reportMessage("CLicked on Email field.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Submit button and validating the error message for Invalid
	 * password value
	 * 
	 */
	@QAFTestStep(description = "I see password is not valid text")
	public void iSeePasswordIsNotValidText() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		String errmsg = "Please enter a minimum of 8 characters, with at least 1 number.";

		hidekeypad();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", errmsg);
		String isBtnPlayVisible = (String) register.getTestBase().getDriver().executeScript("mobile:checkpoint:text",
				params1);

		if (isBtnPlayVisible.equals("true")) {
			PerfectoUtils.reportMessage("The expected error message is displayed as expected", MessageTypes.Pass);
			PerfectoUtils.reportMessage(errmsg);
		} else {
			PerfectoUtils.reportMessage("The expected error message is not displayed", MessageTypes.Fail);
			PerfectoUtils.reportMessage("Expected: " + errmsg);
		}

	}

	/**
	 * Entering the values from Change Password screen and canceling it
	 * 
	 */
	@QAFTestStep(description = "I enter all fields in change password page and cancel it")
	public void iEnterAllFieldsInChangePasswordPageAndCancelIt() {
		AppcrashhandlerTestPage appcrash = new AppcrashhandlerTestPage();
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		String newpswd = getBundle().getString("myaccount.changepassword.password");
		String oldpswd = getBundle().getString("strpassword");

		changepswd.getChangepswdTxtEnteroldpass().verifyPresent();
		changepswd.getChangepswdTxtEnteroldpass().click();
		changepswd.getChangepswdTxtEnteroldpass().sendKeys(oldpswd);
		changepswd.getChangepswdTxtEnternewpass().click();
		changepswd.getChangepswdTxtEnternewpass().sendKeys(newpswd);

		/**
		 * Handling of 'OK' button for error previous and current password
		 * should not be same
		 */

		if (appcrash.getExceptionBtnOk().isPresent()) {
			appcrash.getExceptionBtnOk().click();
		} else {
			PerfectoUtils.reportMessage("OK button is not present");
		}

		// Clicking on Cancel button in Login required pop-up
		if (appcrash.getExceptionTxtLoginrequired().isPresent()) {
			appcrash.getExceptionBtnCancel().click();
			PerfectoUtils.reportMessage("Unable to change password Login required popup appeared");
		}
		iosstepdef.iClickOnCancelDeviceBackButton();
	}

	/**
	 * Entering the Invalid Password value and valid value for the remaining
	 * fields
	 * 
	 */
	@QAFTestStep(description = "I enter invalid password in registeration page")
	public void iEnterInvalidPasswordInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		CommonSteps commonsteps = new CommonSteps();
		IoscommonTestPage ioscommon = new IoscommonTestPage();
		String strEmailId = getBundle().getString("registration.EmailAddress");
		String strpwd = getBundle().getString("registration.InvalidPassword");
		String fName = getBundle().getString("registration.FirstName");

		PerfectoUtils.horizontalswipe();
		ioscommon.getAppBtnBackIOS().waitForPresent(5000);
		ioscommon.getAppBtnBackIOS().click();
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		register.getRegistrationTxtFirstname().waitForPresent(3000);
		register.getRegistrationTxtFirstname().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(fName);

		clickNextButtonForNoOfTimes(2);
		register.getRegistrationTxtEmail().sendKeys(strEmailId);

		clickNextButtonForNoOfTimes(1);
		register.getRegistrationTxtPassword().sendKeys(strpwd);

		// byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();
		register.getImgShowPwd().click();

		PerfectoUtils.reportMessage("Required details are entered in registration page", MessageTypes.Pass);

		try {
			register.getRegistrationChkIagree().waitForPresent(5000);
		} catch (Exception e) {
			PerfectoUtils.verticalswipe();
			register.getRegistrationChkIagree().waitForPresent(5000);
		}
		register.getRegistrationChkIagree().click();
	}

	/**
	 * Entering Inputs beyond the limit and validating the Error messages on
	 * Clicking Submit button
	 * 
	 */
	@QAFTestStep(description = "I validate emailid&pwd by entering input with beyond limit in registeration page")
	public void iValidateEmailidPwdByEnteringInputWithBeyondLimitInRegisterationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		String strEmailId = getBundle().getString("registration.Emailaddress1_Limit");
		String strpassword = getBundle().getString("registration.Password_Limit");

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		register.getRegistrationTxtEmail().sendKeys(strEmailId);

		register.getRegistrationTxtPassword().click();
		register.getRegistrationTxtPassword().sendKeys(strpassword);

		register.getImgShowPwd().click();

		register.getRegistrationTxtFirstname().click();
		register.getRegistrationTxtFirstname().sendKeys("fname");
		hidekeypad();
		PerfectoUtils.verticalswipe();
		register.getRegistrationChkIagree().click();
		register.getRegistrationBtnSubmit().click();
		PerfectoUtils.reportMessage("Created Account!!", MessageTypes.Pass);
		hidekeypad();

		// Validate user account is not created and showing error messages
		IOSStepdefregisteration.regErrorMsgValidate();
	}

	/**
	 * Clicking on Extra Offers
	 * 
	 */
	@QAFTestStep(description = "I navigate to offers page")
	public void iNavigateToOffersPage() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", "Get Extra Offers");
		String isExtraOffersVisible = (String) mynotifipage.getTestBase().getDriver()
				.executeScript("mobile:text:select", params1);

		extraoffers.getLblPageHeader().waitForPresent(50000);
		extraoffers.getLblPageHeader().verifyPresent();
		PerfectoUtils.reportMessage("Clicked on Get More Offers", MessageTypes.Info);
	}

	/**
	 * Validating the Updated Email Subscriptions
	 * 
	 */
	@QAFTestStep(description = "I validate the updated options in Email notifications")
	public void iValidateTheUpdatedOptionsInEmailNotifications() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();

		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {
			myaccount.getLblMynotifications().waitForPresent(3000);
			myaccount.getLblMynotifications().click();
			PerfectoUtils.reportMessage("Clicked on My Notifications.", MessageTypes.Pass);

		} else {
			myaccount.getLblCouponsandpromotions().waitForPresent(1000);
			myaccount.getLblCouponsandpromotions().click();
			PerfectoUtils.reportMessage("Clicked on Coupons and Promotions.", MessageTypes.Pass);
		}

		String chkweeklyad = getBundle().getString("WeeklyAd");
		String chkpromotio = getBundle().getString("Promotional");
		String chknewlett = getBundle().getString("Newsletter");

		mynotifipage.getRbtWeeklyad().verifyPresent();
		if (chkweeklyad.equals(mynotifipage.getRbtWeeklyad().getAttribute("value"))) {
			PerfectoUtils.reportMessage("WeeklyAd updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("WeeklyAd not updated", MessageTypes.Fail);
		}

		if (chkpromotio.equals(mynotifipage.getRbtPromotional().getAttribute("value"))) {
			PerfectoUtils.reportMessage("Promotional updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Promotional not updated", MessageTypes.Fail);
		}

		if (chknewlett.equals(mynotifipage.getRbtNewsletter().getAttribute("value"))) {
			PerfectoUtils.reportMessage("Newsletter updated as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Newsletter not updated", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking the IOS back button
	 * 
	 */
	@QAFTestStep(description = "I navigate back to previously viewed page")
	public void iNavigateBackToPreviouslyViewedPage() {
		ChangepasswordTestPage changepswd = new ChangepasswordTestPage();

		changepswd.getChangepswdBtnBackIOS().waitForPresent(10000);
		changepswd.getChangepswdBtnBackIOS().click();

		PerfectoUtils.reportMessage("Done.", MessageTypes.Pass);
	}

	/**
	 * Checking whether navigated to More page 1. Checkpoint--> My Profile
	 * option
	 * 
	 */
	@QAFTestStep(description = "I should see the Homepage/ More screen")
	public void iShouldSeeTheHomepageMoreScreen() {
		MyaccountTestPage myaccount = new MyaccountTestPage();

		try {
			myaccount.getBtnMyprofile().waitForPresent(80000);

			if (myaccount.getBtnMyprofile().isPresent()) {
				PerfectoUtils.reportMessage("Navigated to more page.", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Not navigated to more page.", MessageTypes.Fail);
			}
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Error Occurer while navigating to more page.", MessageTypes.Fail);
		}
	}

	/**
	 * Validating the Default Email notification options 1. Weekly Ads 2.
	 * Promotional 3. Monthly newsletter
	 * 
	 */
	@QAFTestStep(description = "I validate default Email Preferences options")
	public void iValidateDefaultEmailPreferencesOptions() {
		WantmoreTestPage wantmore = new WantmoreTestPage();

		wantmore.getLblPageHeader().waitForPresent(5000);
		PerfectoUtils.verticalswipe();

		String statusWeeklyAdToggle = wantmore.getWeeklyadSwitch().getAttribute("value");
		String statusPromotionalToggle = wantmore.getPromotionalSwitch().getAttribute("value");
		String statusNewsletterToggle = wantmore.getNewsletterSwitch().getAttribute("value");

		/*
		 * Verify whether the Weekly Ad toggle switch is set to false by default
		 */
		if (statusWeeklyAdToggle.equalsIgnoreCase("0")) {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is set OFF by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Weekly Ad Email Preference is ON by default", MessageTypes.Fail);
		}

		/*
		 * Verify whether the Promotional toggle switch is set to true by
		 * default
		 */
		if (statusPromotionalToggle.equalsIgnoreCase("1")) {
			PerfectoUtils.reportMessage("Promotional Email Preference is set ON by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Promotional Email Preference is set OFF by default.", MessageTypes.Fail);
		}

		/*
		 * Verify whether the Newsletter toggle switch is set to true by default
		 */
		if (statusNewsletterToggle.equalsIgnoreCase("1")) {
			PerfectoUtils.reportMessage("Newsletter Email Preference is set ON by default as expected",
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Newsletter Email Preference is set OFF by default", MessageTypes.Fail);
		}
	}

	/**
	 * Selecting a Store from My HEb page, if not selected already
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I select store from My Store if not selected already")
	public void iSelectStoreFromMyStoreIfNotSelected() throws Exception {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		IOSStepDefStoreLocator storelocator = new IOSStepDefStoreLocator();

		myaccount.getLblSelectstore().waitForPresent(3000);

		if ((myaccount.getLblSelectstore().getText()).equals("Select a Store")) {
			PerfectoUtils.reportMessage("Select a Store is displayed as expected!!", MessageTypes.Pass);
			myaccount.getLblSelectstore().verifyPresent();
			myaccount.getLblSelectstore().click();
			PerfectoUtils.reportMessage("Clicked on Select a Store option..");
			storelocator.iChooseAStoreFromTheStoreLocatorPage();
			myaccount.getLblSelectstore().waitForPresent(5000);
			PerfectoUtils.reportMessage("Store name is selected as" + (myaccount.getLblSelectstore().getText()),
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("User selected store while registeration");
		}

	}

	/**
	 * Clicking Hi <UserName> in HomePage and navigate to My Account
	 * 
	 */
	@QAFTestStep(description = "I navigate to My Account page by clicking Hi <UserName> in HomePage")
	public void iNavigateToMyAccountPageByClickingHiUserNameInHomePage() {
		HomeTestPage home = new HomeTestPage();

		home.getHomeLblWelcomeUser().verifyPresent();
		home.getHomeLblWelcomeUser().click();
		PerfectoUtils.reportMessage("Clicked on Hi <UserName> in Home Page", MessageTypes.Pass);

		iSeeMyAccountPage();
	}

	/**
	 * Validating the fields from My Notifications page
	 * 
	 */
	@QAFTestStep(description = "I validate My Notifications page elements")
	public void iValidateMyNotificationsPageElements() {
		MynotificationsTestPage mynotifipage = new MynotificationsTestPage();
		IoscommonTestPage ioscommonpage = new IoscommonTestPage();
		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		if (Flagstatus.equalsIgnoreCase("true")) {

			mynotifipage.getLblPgetitle().verifyPresent();
			mynotifipage.getBtnGetextraoffers().verifyPresent();
			mynotifipage.getLblEmailnotifications().verifyPresent();
			mynotifipage.getRbtWeeklyad().verifyPresent();
			mynotifipage.getRbtNewsletter().verifyPresent();
			mynotifipage.getRbtPromotional().verifyPresent();
			ioscommonpage.getAppBtnBackIOS().verifyPresent();
		} else {
			mynotifipage.getLblEmailnotifications().verifyPresent();
			mynotifipage.getRbtWeeklyad().verifyPresent();
			mynotifipage.getRbtNewsletter().verifyPresent();
			mynotifipage.getRbtPromotional().verifyPresent();
			ioscommonpage.getAppBtnBackIOS().verifyPresent();
		}
	}

	/**
	 * Clicking on Rate this App option from More page
	 * 
	 */
	@QAFTestStep(description = "I click on Rate this App option")
	public void iClickOnRateThisAppOption() {
		MyaccountTestPage accounttestpage = new MyaccountTestPage();

		PerfectoUtils.scrollToStringuntilfindelement(accounttestpage.getLblRatethisapp(), 80, 75, 2);
		accounttestpage.getLblRatethisapp().waitForPresent(3000);
		accounttestpage.getLblRatethisapp().click();

		PerfectoUtils.reportMessage("Clicked on Rate this App from More", MessageTypes.Pass);
	}

	/**
	 * Validate HEB in App Store page
	 * 
	 */
	@QAFTestStep(description = "I see H-E-B app page in App Store")
	public void iSeeHEBAppPageInAppStore() {
		AppStoreTestPage appstorepage = new AppStoreTestPage();

		appstorepage.getLblHeb().waitForPresent(5000);
		appstorepage.getLblHeb().verifyPresent();
		appstorepage.getLblIphone().verifyPresent();
		appstorepage.getImgShare().verifyPresent();
	}

	/**
	 * Clicking on Contact Us option from More page
	 * 
	 */
	@QAFTestStep(description = "I click on Contact Us option")
	public void iClickOnContactUsOption() {
		MyaccountTestPage accounttestpage = new MyaccountTestPage();

		PerfectoUtils.scrollToStringuntilfindelement(accounttestpage.getLblContactus(), 70, 65, 2);
		PerfectoUtils.swipeIfInBottom(accounttestpage.getLblContactus());
		accounttestpage.getLblContactus().waitForPresent(3000);
		accounttestpage.getLblContactus().click();
		PerfectoUtils.reportMessage("Clicked on Contact Us.", MessageTypes.Pass);

		if (accounttestpage.getLblContactus().isPresent()) {
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "Contact Us");
			accounttestpage.getTestBase().getDriver().executeScript("mobile:text:select", params1);
			PerfectoUtils.reportMessage("Clicked again on Contact Us.", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Clicked on Contact Us from More", MessageTypes.Pass);
		}

	}

	/**
	 * Validate Contact Us page
	 * 
	 */
	@QAFTestStep(description = "I see Contact Us page")
	public void iSeeContactUsPage() {
		ContactUsTestPage ContactUsPage = new ContactUsTestPage();

		ContactUsPage.getTxtPagetitle().verifyPresent();

		if (ContactUsPage.getTxtPagetitle().isPresent()) {
			PerfectoUtils.reportMessage("Contact Us page is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Contact Us page is not displayed", MessageTypes.Fail);
		}
	}

	public static void EnterAllRequiredFieldsInRegisterationPage(String userName, String password) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getTxtPagetitle().waitForPresent(50000);
		PerfectoUtils.setLocation("San antonio");

		try {
			clickNextButtonForNoOfTimes(3);
		} catch (Exception e) {
			e.printStackTrace();
		}
		register.getRegistrationBean().fillRandomData();
		register.getRegistrationBean().setEmail(userName);
		register.getRegistrationBean().setPassword(password);
		register.getRegistrationBean().fillUiElements();

		register.getRegistrationTxtPassword().click();
		IOSStepdef.clickKeyboardDone();

		String strRegisterEmailId = register.getRegistrationTxtEmail().getText();
		String strRegisterFirstname = register.getRegistrationTxtFirstname().getText();
		String strregistrationLastname = register.getRegistrationTxtLastname().getText();
		String strRegisterpassword = register.getRegistrationTxtPassword().getText();

		getBundle().setProperty("strRegisterEmailId", strRegisterEmailId);
		getBundle().setProperty("strRegisterFirstname", strRegisterFirstname);
		getBundle().setProperty("strregistrationLastname", strregistrationLastname);
		getBundle().setProperty("Registerpassword", strRegisterpassword);

		try {
			PerfectoUtils.verticalswipe();
			if (register.getRegistrationChkIagree().isPresent()) {
				register.getRegistrationChkIagree().click();
				PerfectoUtils.reportMessage("Clicked I agree check box..");
			} else {
				PerfectoUtils.scrollToStringuntilfindelement(register.getRegistrationChkIagree(), 80, 75, 2);
				if (!(register.getRegistrationBtnSubmit().getAttribute("enabled")).equals("true")) {
					register.getRegistrationChkIagree().click();
				}
				PerfectoUtils.reportMessage("Clicked I agree check box..");
			}
		} catch (Exception e) {
			PerfectoUtils.scrollToStringuntilfindelement(register.getRegistrationChkIagree(), 80, 75, 2);
			if (!(register.getRegistrationBtnSubmit().getAttribute("enabled")).equals("true")) {
				register.getRegistrationChkIagree().click();
			}
			PerfectoUtils.reportMessage("Clicked I agree check box");
		}
	}

	/**
	 * I update the email notification
	 * 
	 */
	@QAFTestStep(description = "I update the email notification")
	public void iUpdateTheEmmailNotification() {
		WantmoreTestPage wantmore = new WantmoreTestPage();
		IoscommonTestPage ioscommon = new IoscommonTestPage();

		/* Switching Promotional button */
		wantmore.getPromotionalSwitch().click();
		ioscommon.getAppLblLoading().waitForNotPresent(50000);
		getBundle().setProperty("Promotional", wantmore.getPromotionalSwitch().getAttribute("value"));
		PerfectoUtils.reportMessage(
				"Promotional Subscription status: " + wantmore.getPromotionalSwitch().getAttribute("value"));

	}

	@QAFTestStep(description = "I verify partner's name appears on the VPP Barcode screen")
	public void iVerifyPartnersNameAppearsOnTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		if (myhebbarcode.getLblNamevalue().isPresent()) {
			myhebbarcode.getLblNamevalue().verifyPresent();
			PerfectoUtils.reportMessage("Partner's name : " + myhebbarcode.getLblNamevalue().getText(),
					MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Partner's name is not present", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify barcode appears at the bottom of the VPP Barcode screen")
	public void iVerifyBarcodeAppearsAtTheBottomOfTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myhebbarcode.getImgBarcode().verifyPresent();
			myhebbarcode.getLblBarcodenumber().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify header image with the text on the VPP Barcode screen")
	public void iVerifyHeaderImageWithTheTextOnTheVPPBarcodeScreen() {
		MyhebbarcodeTestPage myhebbarcode = new MyhebbarcodeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");

		if (Flagstatus.equalsIgnoreCase("true")) {
			myhebbarcode.getvppmyhebbcLblBarcodephotoText().verifyPresent();
		} else {
			PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
		}
	}

	@QAFTestStep(description = "I verify Redeem Coupons does not appear on My Account page")
	public void iVerifyRedeemCouponsDoesNotAppearOnMyAccountPage() {
		MyaccountTestPage myaccount = new MyaccountTestPage();
		HomeTestPage home = new HomeTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		iNavigateToMyAccountPage();

		if (Flagstatus.equalsIgnoreCase("true")) {
			myaccount.getLblMyhebbarcode().waitForPresent(3000);
			myaccount.getLblMyhebbarcode().verifyPresent();
			PerfectoUtils.reportMessage("Redeem Coupons is present.", MessageTypes.Pass);
		} else {
			if (!myaccount.getLblMyhebbarcode().isPresent()) {
				PerfectoUtils.reportMessage("Redeem Coupon section is not present", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Redeem Coupon section is present", MessageTypes.Fail);
			}
		}
		home.getAppFooterHomeicon().click();
	}

	@QAFTestStep(description = "I verify Redeem button is not present in Selected Savings tab")
	public void IVerifyRedeemButtonIsNotPresentInSelectedSavingsTab() {
		IOSStepdef iosstep = new IOSStepdef();
		IOSStepdefCoupons iosstepcoupons = new IOSStepdefCoupons();
		CouponsselectionTestPage couponSelection = new CouponsselectionTestPage();

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		iosstep.iNavigateToCouponsPage();
		iosstepcoupons.iNavigateToSelectedSavingsTab();

		if (Flagstatus.contains("true")) {
			// Verify redeem button is displayed
			if (couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Fail);
		} else {
			if (!couponSelection.getCouponsBtnRedeem().isPresent())
				PerfectoUtils.reportMessage("Redeem button is not displayed in selected tab..", MessageTypes.Pass);
			else
				PerfectoUtils.reportMessage("Redeem button is displayed in selected tab..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "Create another account and navigate to Extra offers page")
	public void createAnotherAccountAndNavigateToExtraOffersPage() {
		CommonSteps commonsteps = new CommonSteps();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		HomeTestPage home = new HomeTestPage();

		try {
			home.getAppFooterHomeicon().click();
		} catch (Exception e) {
			PerfectoUtils.reportMessage("Home button not found in the footer..");
			if (loginsplash.getLoginBtnRegister().isPresent()) {
				PerfectoUtils.reportMessage("User is in Login splash page..");
			} else {
				PerfectoUtils.reportMessage("Error occured while navigating to registration page..", MessageTypes.Fail);
			}
		}

		if (home.getHomeLblSignin().isPresent()) {
			home.getHomeLblSignin().click();
			PerfectoUtils.reportMessage("Navigated to Login splach page..");
		}

		commonsteps.iClickRegisterButtonFromLoginSplashPage();
		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();
		CommonStepDefMyAccounts.navigateToExtraOffersPageFromWantMorePage();
	}

	@QAFTestStep(description = "Enter all required fields in offers page with already enrolled phone num")
	public void enterAllRequiredFieldsInOffersPageWithAlreadyEnrolledPhoneNum() {
		ExtraOffersTestPage extraoffers = new ExtraOffersTestPage();
		WeeklygroceriesTestPage randomdata = new WeeklygroceriesTestPage();
		DCEnrollmentTestPage dcenrollment = new DCEnrollmentTestPage();

		PerfectoUtils.reportMessage("Registering for Digital coupons", MessageTypes.Pass);

		String strPhonenum = getBundle().getString("enrolledPhoneNumber");
		String isAutoEnrollEnabled = getBundle().getString("isAutoEnrollEnabled");

		if (isAutoEnrollEnabled.equalsIgnoreCase("true")) {

			// Enter required fields
			extraoffers.getEdtMobilenum().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			extraoffers.getChkIagree().waitForPresent(3000);
			extraoffers.getChkIagree().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");

		} else {
			dcenrollment.getTxtMobilenumber().waitForPresent(1000);
			dcenrollment.getTxtMobilenumber().click();
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(strPhonenum);
			IOSStepdef.clickKeyboardDone();

			dcenrollment.getChkTermsandconditions().waitForPresent(3000);
			dcenrollment.getChkTermsandconditions().click();
			PerfectoUtils.reportMessage("Clicked on I Agree checkbox..");
		}
	}

	/**
	 * verifying error message
	 * 
	 */
	@QAFTestStep(description = "I verify error message on the Log In page")
	public void iVerifyErrorMessageOnTheLogInPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getLblLoginError().isPresent()) {
			PerfectoUtils.reportMessage("Invalid Email/Password..", MessageTypes.Pass);
		} else if (loginsplash.getLblInvalidEmailError().isPresent()) {
			PerfectoUtils.reportMessage("Please enter email or password..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Successfully logged in", MessageTypes.Fail);
		}
		clickOk();
	}

	/**
	 * verifying email field is displayed on the Forgot Password page
	 * 
	 */
	@QAFTestStep(description = "I verify email field is displayed on the Forgot Password page")
	public void iVerifyEmailFieldIsDisplayedOnTheForgotPasswordPage() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		if (loginsplash.getTxtForgotPasswordEmail().isPresent()) {
			loginsplash.getTxtForgotPasswordEmail().verifyPresent();
			PerfectoUtils.reportMessage("email field is displayed", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("email field is not displayed", MessageTypes.Fail);
		}
	}

	/**
	 * verifying error message for invalid email id in Forgot Password page
	 * 
	 */
	@QAFTestStep(description = "I verify error message for invalid email id")
	public void iVerifyErrorMessageForInvalidEmailId() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("myaccount.invalidemail");
		loginsplash.getTxtForgotPasswordEmail().click();
		loginsplash.getTxtForgotPasswordEmail().sendKeys(username);
		loginsplash.getBtnResetPassword().click();
		loginsplash.getTxtForgotPasswordError().waitForPresent(2000);

		if (loginsplash.getTxtForgotPasswordError().isPresent()) {
			PerfectoUtils.reportMessage("Please enter a valid email..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("No error mesg", MessageTypes.Fail);
		}
		clickOk();
	}

	@QAFTestStep(description = "I verify Reset Password button becomes enabled after entering email")
	public void iVerifyResetPasswordButtonBecomesEnabledAfterEnteringEmail() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		loginsplash.getTxtForgotPasswordEmail().click();
		loginsplash.getTxtForgotPasswordEmail().sendKeys(username);

		if (loginsplash.getBtnResetPassword().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Reset Password button becomes enabled", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Reset Password button is disabled", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify email has send after clicking Reset Password button")
	public void iVerifyEmailHasSendAfterClickingResetPasswordButton() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();
		HomeTestPage homepage = new HomeTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		loginsplash.getTxtForgotPasswordEmail().click();
		loginsplash.getTxtForgotPasswordEmail().sendKeys(username);
		loginsplash.getBtnResetPassword().click();

		loginsplash.getTxtRequestSent().waitForPresent(5000);
		loginsplash.getTxtRequestSent().verifyPresent();
		PerfectoUtils.reportMessage("Request Sent!", MessageTypes.Pass);
		clickOk();

		if (homepage.getHomeLblSignin().isPresent()) {
			PerfectoUtils.reportMessage("Email has been sent", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Email has not been sent", MessageTypes.Fail);
		}
	}

	/**
	 * Entering invalid email id
	 * 
	 */
	@QAFTestStep(description = "I enter invalid email id and valid password")
	public void iEnterInvalidEmailIdAndValidPassword() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("myaccount.invalidemail");
		String pswd = ConfigurationManager.getBundle().getString("myaccount.hotuser1.user.password");

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		IOSStepdef.clickKeyboardDone();

		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);

	}

	/**
	 * Entering invalid password id
	 * 
	 */
	@QAFTestStep(description = "I enter valid email id and invalid password")
	public void iEnterValidEmailIdAndInvalidPassword() {
		LoginsplashTestPage loginsplash = new LoginsplashTestPage();

		String username = ConfigurationManager.getBundle().getString("hotuser1.user.email");
		String pswd = ConfigurationManager.getBundle().getString("myaccount.invalidpassword");

		loginsplash.getLoginTxtEmail().waitForPresent(3000);
		loginsplash.getLoginTxtEmail().click();
		loginsplash.getLoginTxtEmail().sendKeys(username);
		loginsplash.getLoginTxtPassword().click();
		loginsplash.getLoginTxtPassword().sendKeys(pswd);
		IOSStepdef.clickKeyboardDone();

		loginsplash.getLoginBtnLogin().verifyPresent();
		loginsplash.getLoginBtnLogin().click();
		PerfectoUtils.reportMessage("Clicked Login button.", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I am a hot user user with new registration and enrolled for Coupons")
	public void iAmAHotUserUserWithNewRegistrationAndEnrolledForCoupons() throws Exception {
		CommonSteps commonsteps = new CommonSteps();
		IOSStepdef iosstepdef = new IOSStepdef();
		HomeTestPage homepage = new HomeTestPage();
		CommonStepDefRegisteration commonregister = new CommonStepDefRegisteration();
		WantmoreTestPage wantmore = new WantmoreTestPage();

		// Prerequisite: verify the user is in login splash page
		iosstepdef.iAmOnLoginSplashPage();

		// Steps to register for a new user
		commonsteps.iClickRegisterButtonFromLoginSplashPage();

		iEnterAllRequiredFieldsInRegisterationPage();
		commonregister.iClickCreateAccount();

		// Skip select store
		CommonStepDefMyAccounts.iNavigateToWantMorePageOnClickingSkipForNow();

		// Navigate and Enroll the details from 'Extra Offers' page
		iNavigateToExtraOffersPageAndValidateTheFields();
		iEnterAllRequiredFieldsInOffersPage();
		CommonStepDefMyAccounts.iValidateTheUserRegisteredForOffersInWantmorePage();

		// Click Done button
		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		wantmore.getBtnDone().verifyPresent();
		wantmore.getBtnDone().click();
		PerfectoUtils.reportMessage("Clicked on Done button..");

		// Verify registration is success and currently in home page
		homepage.getHomeLblProduct().waitForPresent(50000);
		homepage.getHomeLblProduct().verifyPresent();
	}

	/**
	 * Enter Invalid mobile number and check "I agree" option
	 * 
	 */
	@QAFTestStep(description = "I enter valid phone number in offers page")
	public void iEnterValidPhoneNumberInOffersPage() {
		ExtraOffersTestPage Extraoffers = new ExtraOffersTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		// Getting the current time to form the unique Mobile number
		DateFormat dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss");
		Date date = new Date();

		String strTimeStmp = dateFormat.format(date).replace("/", "").replace(":", "").replace(" ", "");
		String mobileno = "8" + strTimeStmp.substring(3, 12);

		String Flagstatus = ConfigurationManager.getBundle().getString("isAutoEnrollEnabled");
		try {
			if (Extraoffers.getEdtMobilenum().isPresent())
				Extraoffers.getEdtMobilenum().click();
		} catch (Exception e) {
		}

		if (Extraoffers.getEdtMobilenum().isPresent()) {
			Extraoffers.getEdtMobilenum().click();
			Extraoffers.getEdtMobilenum().clear();
			Extraoffers.getEdtMobilenum().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Valid phone number: " + mobileno);
		} else {
			Extraoffers.getEdtPremobilenum().click();
			Extraoffers.getEdtPremobilenum().clear();
			Extraoffers.getEdtPremobilenum().sendKeys("");
			PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(mobileno);
			PerfectoUtils.reportMessage("Entered Valid phone number: " + mobileno);
		}
		iosstepdef.clickKeyboardDoneIcon();
		Extraoffers.getChkIagree().click();

		Extraoffers.getBtnSave().verifyPresent();
		Extraoffers.getBtnSave().click();
		PerfectoUtils.reportMessage("Clicked Save button..");

	}

	@QAFTestStep(description = "I verify Redeem Coupons does not appear in the Left Nav menu")
	public void iVerifyRedeemCouponsDoesNotAppearInTheLeftNavMenu() {
		PerfectoUtils.reportMessage("Not Applicable for IOS", MessageTypes.Pass);

	}

	@QAFTestStep(description = "I Login with invalid password 5 times")
	public void iLoginWithInvalidPassword5Times() {
		PerfectoUtils.reportMessage("Not Applicable for IOS", MessageTypes.Pass);
	}

	@QAFTestStep(description = "Verify the Save button got disabled in offers page")
	public void verifyTheSaveButtonGotDisabledInOffersPage() {
		ExtraOffersTestPage offerspage = new ExtraOffersTestPage();
		IOSStepdef iosstepdef = new IOSStepdef();

		iosstepdef.clickKeyboardDoneIcon();
		PerfectoUtils.scrollToElement(offerspage.getBtnSave());

		if (offerspage.getBtnSave().getAttribute("enabled").equalsIgnoreCase("false")) {
			PerfectoUtils.reportMessage("Save button is disabled..", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Save button is not disabled..", MessageTypes.Fail);
		}
	}

	@QAFTestStep(description = "I verify login screen changed to Forgot Password screen")
	public void iVerifyLoginScreenChangedToForgotPasswordScreen() {
		PerfectoUtils.reportMessage("Not Applicable for IOS", MessageTypes.Pass);

	}
}
