package com.heb.automation.ios.steps.registeration;

import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;

import java.util.HashMap;
import java.util.Map;

import com.heb.automation.common.PerfectoUtils;
import com.heb.automation.common.pages.LoginsplashTestPage;
import com.heb.automation.common.pages.registeration.RegistrastionTestPage;
import com.heb.automation.ios.pages.IoscommonTestPage;
import com.heb.automation.ios.steps.myaccount.IOSStepDefMyAccounts;
import com.heb.automation.ios.steps.storelocator.IOSStepDefStoreLocator;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.util.Reporter;

/*List of steps in Registeration

	I validate hint is available for all text fields in Registration page
	I validate hint is available for all text fields in Login pages
	I validate hint is avaiable for all text fields in Coupon Registration page
	I validate hint is avaiable for all text fields in Profile pages
	I select a store as My store
	I validate required fields by entering invalid inputs
	I enter first name field {0}
	I enter password field {0}
	I enter email address field {0}
	I verify keyboard is opened and cursor is at the First Name field
	I click on password field in Registration page
	I click skip and continue as guest
	I enable/disable T&C button
	I verify the Required and Optional fields in Registration page
	I verify the WhatsNew section*/


public class IOSStepdefregisteration {

	/**
	 * Validation of hints in all text fields in registration page.
	 */
	@QAFTestStep(description = "I validate hint is available for all text fields in Registration page")
	public void iValidateHintIsAvailableForAllTextFieldsInRegistrationPage() {

		PerfectoUtils.reportMessage("The hint validation of text field in Registration NA for iOS", MessageTypes.Info);
	}

	/**
	 * Validation of hints in all text fields in Login page.
	 */
	@QAFTestStep(description = "I validate hint is available for all text fields in Login pages")
	public void iValidateHintIsAvaiableForAllTextFieldsInLoginPages() {

		PerfectoUtils.reportMessage("The hint validation of text field in Login page NA for iOS", MessageTypes.Info);
	}

	/**
	 * Validation of hints in all text fields in Coupon Registration page.
	 */
	@QAFTestStep(description = "I validate hint is avaiable for all text fields in Coupon Registration page")
	public void iValidateHintIsAvaiableForAllTextFieldsInCouponRegistrationPage() {

		PerfectoUtils.reportMessage("The hint validation of text field in Coupon Registration page NA for iOS", MessageTypes.Info);
	}

	/**
	 * Validation of hints in all text fields in in Profile page.
	 */
	@QAFTestStep(description = "I validate hint is avaiable for all text fields in Profile pages")
	public void iValidateHintIsAvaiableForAllTextFieldsInProfilePages() {

		PerfectoUtils.reportMessage("The hint validation of text field in Profile page NA for iOS", MessageTypes.Info);
	}

	/**
	 * Selecting a store as My store
	 * 
	 * @throws Exception
	 */
	@QAFTestStep(description = "I select a store as My store")
	public void iSelectAStoreAsMyStore() throws Exception {
		IOSStepDefStoreLocator storeloc = new IOSStepDefStoreLocator();

		storeloc.iChooseAStoreFromTheStoreLocatorPage();
	}

	/**
	 * Validation of fields by entering invalid inputs.
	 */
	@QAFTestStep(description = "I validate required fields by entering invalid inputs")
	public void iValidateRequiredFieldsByEnteringInvalidInputs() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();

		String invalidEAddress = getBundle().getString("registration.InvalidEmailAddress");
		String invalidPwd = getBundle().getString("registration.InvalidPassword");
		String firstName = "#$@#$$";

		// Passing Invalid input
		try {
			iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();
		} catch (Exception e) {
			e.printStackTrace();
		}
		iEnterPasswordField(invalidPwd);
		iEnterFirstNameField(firstName);
		iEnterEmailAddressField(invalidEAddress);

		iEnableDisableTCButton();

		register.getRegistrationBtnSubmit().waitForPresent(5000);
		register.getRegistrationBtnSubmit().click();

		regErrorMsgValidate();
	}

	/**
	 * Entering the First name.
	 * 
	 * @param FirstName
	 */
	@QAFTestStep(description = "I enter first name field {0}")
	public void iEnterFirstNameField(String FirstName) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtFirstname().waitForPresent(3000);
		register.getRegistrationTxtFirstname().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(FirstName);
	}

	/**
	 * Entering the password field.
	 * 
	 * @param password
	 */
	@QAFTestStep(description = "I enter password field {0}")
	public void iEnterPasswordField(String password) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtPassword().waitForPresent(3000);
		register.getRegistrationTxtPassword().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(password);
	}

	/**
	 * Entering the email.
	 * 
	 * @param email
	 */
	@QAFTestStep(description = "I enter email address field {0}")
	public void iEnterEmailAddressField(String email) {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtEmail().waitForPresent(3000);
		register.getRegistrationTxtEmail().click();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(email);
	}

	/**
	 * Verifying the Keyboard and cursor on first name field.
	 */
	@QAFTestStep(description = "I verify keyboard is opened and cursor is at the First Name field")
	public void iVerifyKeyboardIsOpenedAndCursorIsAtTheFirstNameField() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		String firstName = "test";

		register.getRegistrationTxtFirstname().verifyPresent();
		PerfectoUtils.getAppiumDriver().getKeyboard().sendKeys(firstName);
		String actualFN = register.getRegistrationTxtFirstname().getText();

		if (actualFN.equals(firstName)) {
			PerfectoUtils.reportMessage("Cursor is at the First Name field as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Cursor is not at the First Name field", MessageTypes.Fail);
		}
	}

	/**
	 * Clicking on Password field.
	 */
	@QAFTestStep(description = "I click on password field in Registration page")
	public void iClickOnPasswordField() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		IOSStepDefMyAccounts.hidekeypad();
		register.getRegistrationTxtPassword().waitForPresent(3000);
		register.getRegistrationTxtPassword().click();
		PerfectoUtils.reportMessage("CLicked on Password field.", MessageTypes.Pass);
	}

	/**
	 * Clicking on Skip and Continue as guest from login splash page.
	 */
	@QAFTestStep(description = "I click skip and continue as guest")
	public void iClickSkipAndContinueAsGuest() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();

		iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();
		PerfectoUtils.verticalswipe();
		PerfectoUtils.verticalswipe();
		register.getLnkSkipandcontinueasguest().waitForPresent(5000);
		register.getLnkSkipandcontinueasguest().click();
		PerfectoUtils.reportMessage("Clicked skip and continue as guest option..", MessageTypes.Pass);
	}

	/**
	 * Clicking on Terms and Conditions checkbox.
	 */
	@QAFTestStep(description = "I enable/disable T&C button")
	public void iEnableDisableTCButton() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		IOSStepDefMyAccounts iosmyaccount = new IOSStepDefMyAccounts();

		iosmyaccount.byTappingAnywhereClickingDeviceBackButtonShouldDismissTheKeyboard();

		PerfectoUtils.verticalswipe();
		register.getRegistrationChkIagree().waitForPresent(5000);
		register.getRegistrationChkIagree().click();
	}

	/**
	 * Verification of Optional field in Registration page.
	 */
	@QAFTestStep(description = "I verify the Required and Optional fields in Registration page")
	public void iVerifyTheRequiredAndOptionalFieldsInRegistrationPage() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		IOSStepDefMyAccounts.hidekeypad();
		register.getRegistrationTxtFirstname().waitForPresent(3000);

		if (register.getRegistrationTxtLastname().getAttribute("value").contains("Optional")) {
			PerfectoUtils.reportMessage("Optional text is present in last name...", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("Optional text is not present in last name...", MessageTypes.Fail);
		}
	}

	public static void regErrorMsgValidate() {
		RegistrastionTestPage register = new RegistrastionTestPage();

		register.getRegistrationTxtEmail().waitForPresent(5000);
		// Validate the error messages
		String ErrMessage1 = "Please enter a valid email address.";
		String ErrMessage2 = "Please enter a minimum of 8 characters, with at least 1 number.";

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content", ErrMessage1);
		String isMsg1Visible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (!isMsg1Visible.equals("false")) {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage1 + " is displayed as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage1 + " is not displayed as expected",
					MessageTypes.Fail);
		}

		params1.put("content", ErrMessage2);
		String isMsg2Visible = (String) register.getTestBase().getDriver().executeScript("mobile:text:find", params1);

		if (!isMsg2Visible.equals("false")) {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage2 + " is displayed as expected", MessageTypes.Pass);
		} else {
			PerfectoUtils.reportMessage("The expected error message " + ErrMessage2 + " is not displayed as expected",
					MessageTypes.Fail);
		}
	}
	/*
	 * Verify whats new section page wise when auto enroll is true
	 */
	@QAFTestStep(description = "I verify the WhatsNew section")
	public void iVerifyTheWhatsNewSection() {
		RegistrastionTestPage register = new RegistrastionTestPage();
		IoscommonTestPage iosfun = new IoscommonTestPage();
		// verify first page and skip button

		if (register.getWhatsnewpage1().isPresent()) {
			String name = register.getWhatsnewpage1().getText();
			PerfectoUtils.reportMessage("Whatsnew section 1 page is present", MessageTypes.Pass);
			boolean isAutoEnrollEnabled = true;
			getBundle().setProperty("isAutoEnrollEnabled", isAutoEnrollEnabled);
			if (iosfun.getAppBtnSkip().isPresent()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 1", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 1", MessageTypes.Fail);
			}
			System.out.println(name);
			PerfectoUtils.rightSwipe();
		}

		else {
			PerfectoUtils.reportMessage("Whatsnew section 1 page is  not present", MessageTypes.Fail);
		}

		// verify 2 page and skip button
		if (register.getWhatsnewpage2().isPresent()) {
			String name2 = register.getWhatsnewpage2().getText();
			PerfectoUtils.reportMessage("Whatsnew section 2 page is present", MessageTypes.Pass);
			if (iosfun.getAppBtnSkip().isPresent()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 2", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 2", MessageTypes.Fail);
			}
			System.out.println(name2);
			PerfectoUtils.rightSwipe();

		} else {
			PerfectoUtils.reportMessage("Whatsnew section 2 page is not present", MessageTypes.Fail);
		}

		// verify 3 page and skip button
		if (register.getWhatsnewpage3().isPresent()) {
			String name3 = register.getWhatsnewpage3().getText();
			PerfectoUtils.reportMessage("Whatsnew section 3 page is present", MessageTypes.Pass);
			if (iosfun.getAppBtnSkip().isDisplayed()) {
				PerfectoUtils.reportMessage("Skip button is present in the Whatsnew page 3", MessageTypes.Pass);
			} else {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 3", MessageTypes.Fail);
			}
			System.out.println(name3);
			PerfectoUtils.rightSwipe();
			PerfectoUtils.rightSwipe();
		} else {
			PerfectoUtils.reportMessage("Whatsnew section 3 page is not present", MessageTypes.Fail);
		}

		// PerfectoUtils.rightSwipe();
		// Verify 4 page and no skip button
		if (register.getWhatsnewpage4().isPresent()) {
			register.getStartshoppinglnk().isPresent();
			String name4 = register.getWhatsnewpage4().getText();
			PerfectoUtils.reportMessage("Whatsnew section 4 page is present", MessageTypes.Pass);
			/// Image comparison ///////
			Map<String, Object> params1 = new HashMap<>();
			params1.put("content", "SKIP");
			String isBtnSkipVisible = (String) register.getTestBase().getDriver()
					.executeScript("mobile:checkpoint:text", params1);

			if (isBtnSkipVisible.equalsIgnoreCase("false")) {
				PerfectoUtils.reportMessage("Skip button is not present in the Whatsnew page 4", MessageTypes.Pass);
				if (register.getStartshoppinglnk().isPresent()) {
					PerfectoUtils.reportMessage("Start Shopping link present in the Whatsnew page 4", MessageTypes.Pass);
				} else {
					PerfectoUtils.reportMessage("Start shopping link is not present in the Whatsnew page 4", MessageTypes.Fail);
				}
			} else {
				PerfectoUtils.reportMessage("Skip button is  present in the Whatsnew page 4", MessageTypes.Fail);
			}
			System.out.println(name4);
		}

		else {
			PerfectoUtils.reportMessage("Whatsnew section 4 page is not present", MessageTypes.Fail);
		}

	}

}
