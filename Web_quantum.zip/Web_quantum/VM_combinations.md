# Machine 1 : 
<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'7','browserName':'Chrome','browserVersion':'60','resolution':'1280x1024','location':'US East'}"></parameter>

# Machine 2 :
<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'8.1','browserName':'Chrome','browserVersion':'59','resolution':'1280x1024','location':'US East'}"></parameter>		

#Machine 3 :

<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'10','browserName':'Chrome','browserVersion':'60','resolution':'1280x1024','location':'US East'}"></parameter>		

#Machine 4 :

<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'10','browserName':'Chrome','browserVersion':'beta','resolution':'1280x1024','location':'US East'}"></parameter>		

#Machine 5 :
<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'8.1','browserName':'Chrome','browserVersion':'60','resolution':'1280x1024','location':'US East'}"></parameter>		

#Machine 6 : 
<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'10','browserName':'Chrome','browserVersion':'60','resolution':'1280x1024','location':'US East'}"></parameter>		

#Machine 7 : 
<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'7','browserName':'Chrome','browserVersion':'beta','resolution':'1280x1024','location':'US East'}"></parameter>	


#Machine 8 :

<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'8.1','browserName':'Chrome','browserVersion':'beta','resolution':'1280x1024','location':'US East'}"></parameter>	


# Machine 9:

<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'10','browserName':'Chrome','browserVersion':'58','resolution':'1280x1024','location':'US East'}"></parameter>	

# Machine 10 : 

<parameter name="driver.additional.capabilities" value="{'platformName':'Windows','platformVersion':'8.1','browserName':'Chrome','browserVersion':'beta','resolution':'1280x1024','location':'US East'}"></parameter>	


#Mac Machine 1:

<parameter name="driver.additional.capabilities" value="{'platformName':'Mac','platformVersion':'OS X El Capitan','browserName':'Chrome','browserVersion':'60','resolution':'1440x900','location':'NA-US-PHX'}"></parameter>

#Mac Machine 2:

<parameter name="driver.additional.capabilities" value="{'platformName':'Mac','platformVersion':'macOS Sierra','browserName':'Chrome','browserVersion':'60','resolution':'1440x900','location':'NA-US-PHX'}"></parameter>

	
