package com.automation.web.commonutils;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.xalan.processor.TransformerFactoryImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class WriteXMLFile {

	public static void main(String argv[]) {
		
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("testdata");
			doc.appendChild(rootElement);

			// staff elements
			Element user = doc.createElement("user");
			rootElement.appendChild(user);
	/*
			// set attribute to staff element
			Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			user.setAttributeNode(attr);

	*/		// shorten way
			// staff.setAttribute("id", "1");

			// firstname elements
			Element email = doc.createElement("email");
			email.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("myEmail")));
			user.appendChild(email);

			// lastname elements
			Element password = doc.createElement("password");
			password.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("register.defaultPassword")));
			user.appendChild(password);

			// write the content into xml file
			TransformerFactoryImpl transformerFactory = new TransformerFactoryImpl();
			Transformer transformer = transformerFactory.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("resources\\qa\\testdata\\newaccounts.xml"));

			// Output to console for testing
			// StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);
			
			System.out.println(result);
			System.out.println("File saved!");

		  } catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		  } catch (TransformerException tfe) {
			tfe.printStackTrace();
		  }
		
	}
	  
	
	public static void getOrderId(){

		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("testdata");
			doc.appendChild(rootElement);

			// staff elements
			Element user = doc.createElement("orders");
			rootElement.appendChild(user);
	/*
			// set attribute to staff element
			Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			user.setAttributeNode(attr);

	*/		// shorten way
			// staff.setAttribute("id", "1");

			// firstname elements
			Element email = doc.createElement("email");
			email.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("myEmail")));
			user.appendChild(email);

			// lastname elements
			Element password = doc.createElement("newOrderId");
			password.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("OrderId")));
			user.appendChild(password);

			// write the content into xml file
			TransformerFactoryImpl transformerFactory = new TransformerFactoryImpl();
			Transformer transformer = transformerFactory.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("resources\\testdata\\newOrderId.xml"));

			// Output to console for testing
			// StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);
			
			System.out.println(result);
			System.out.println("File saved!");

		  } catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		  } catch (TransformerException tfe) {
			tfe.printStackTrace();
		  }
	}
	public static void getCancelOrderId(){

		try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root elements
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("testdata");
			doc.appendChild(rootElement);

			// staff elements
			Element user = doc.createElement("orders");
			rootElement.appendChild(user);
	/*
			// set attribute to staff element
			Attr attr = doc.createAttribute("id");
			attr.setValue("1");
			user.setAttributeNode(attr);

	*/		// shorten way
			// staff.setAttribute("id", "1");

			// firstname elements
			Element email = doc.createElement("email");
			email.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("myEmail")));
			user.appendChild(email);

			// lastname elements
			Element password = doc.createElement("cancelorderId");
			password.appendChild(doc.createTextNode(ConfigurationManager.getBundle().getString("OrderId")));
			user.appendChild(password);

			// write the content into xml file
			TransformerFactoryImpl transformerFactory = new TransformerFactoryImpl();
			Transformer transformer = transformerFactory.newTransformer();
			
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("resources\\testdata\\cancelOrderId.xml"));

			// Output to console for testing
			// StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);
			
			System.out.println(result);
			System.out.println("File saved!");

		  } catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		  } catch (TransformerException tfe) {
			tfe.printStackTrace();
		  }
	}

	
}