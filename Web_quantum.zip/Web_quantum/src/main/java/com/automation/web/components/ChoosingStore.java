package com.automation.web.components;

import java.util.List;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ChoosingStore extends QAFWebComponent {

	@FindBy(locator = "findstore.li.storenameslist")
	private List<QAFWebElement> StoreName;

	@FindBy(locator = "findstore.li.storeDetails")
	private List<QAFWebElement> StoreDetail;
	@FindBy(locator = "findstore.li.storeAddress")
	private List<QAFWebElement> StoreAddress;
	
	
	public ChoosingStore(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}


	public List<QAFWebElement> getStoreName() {
		return StoreName;
	}


	public List<QAFWebElement> getStoreDetail() {
		return StoreDetail;
	}


	public List<QAFWebElement> getStoreAddress() {
		return StoreAddress;
	}





	
	
	
	

}