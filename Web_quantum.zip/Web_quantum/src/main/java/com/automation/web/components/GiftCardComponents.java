package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class GiftCardComponents extends QAFWebComponent {

	@FindBy(locator = "shopgc.img.giftcardimageslist")
	private QAFWebElement shopgcImgGiftcardimageslist;
	@FindBy(locator = "shopgc.lbl.quantitylist")
	private QAFWebElement shopgcLblQuantitylist;
	@FindBy(locator = "shopgc.txt.quantitydropdownlist")
	private QAFWebElement shopgcTxtQuantitydropdownlist;
	@FindBy(locator = "shopgc.lbl.amount")
	private QAFWebElement shopgcLblAmount;
	@FindBy(locator = "shopgc.txt.amountdropdown")
	private QAFWebElement shopgcTxtAmountdropdown;
	@FindBy(locator = "shopgc.lbl.amountdropdownvalues")
	private QAFWebElement shopgcLblAmountdropdownvalues;
	@FindBy(locator = "shopgc.btn.addtocart")
	private QAFWebElement shopgcBtnAddtocart;

	public GiftCardComponents(String locator) {
		super(locator);
	}

	public QAFWebElement getImgGiftcardimageslist() {
		return shopgcImgGiftcardimageslist;
	}

	public QAFWebElement getLblQuantitylist() {
		return shopgcLblQuantitylist;
	}

	public QAFWebElement getTxtQuantitydropdownlist() {
		return shopgcTxtQuantitydropdownlist;
	}

	public QAFWebElement getLblAmount() {
		return shopgcLblAmount;
	}

	public QAFWebElement getTxtAmountdropdown() {
		return shopgcTxtAmountdropdown;
	}

	public QAFWebElement getLblAmountdropdownvalues() {
		return shopgcLblAmountdropdownvalues;
	}

	public QAFWebElement getBtnAddtocart() {
		return shopgcBtnAddtocart;
	}

}
