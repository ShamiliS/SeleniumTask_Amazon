package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class QuickReorderProducts extends QAFWebComponent{

	public QuickReorderProducts(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(locator = "quickreorder.lbl.productname")
	private QAFWebElement quickreorderLblProductname;
	@FindBy(locator = "quickreorder.lbl.addtocart")
	private QAFWebElement quickreorderLblAddtocart;
	@FindBy(locator = "quickreorder.lbl.cartblock")
	private QAFWebElement quickreorderLblCartblock;
	@FindBy(locator = "quickreorder.lbl.price")
	private QAFWebElement quickreorderLblPrice;
	
	public QAFWebElement getQuickreorderLblProductname() {
		return quickreorderLblProductname;
	}
	public QAFWebElement getQuickreorderLblAddtocart() {
		return quickreorderLblAddtocart;
	}
	public QAFWebElement getQuickreorderLblCartblock() {
		return quickreorderLblCartblock;
	}
	public QAFWebElement getQuickreorderLblPrice() {
		return quickreorderLblPrice;
	}


}
