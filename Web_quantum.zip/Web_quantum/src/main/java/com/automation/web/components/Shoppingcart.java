package com.automation.web.components;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Shoppingcart extends QAFWebComponent{
	
	@FindBy(locator = "cart.edt.qty")
	private QAFWebElement cartEdtQty;
	@FindBy(locator = "cart.lbl.productname")
	private QAFWebElement cartLblProductname;
	@FindBy(locator = "cart.btn.update")
	private QAFWebElement cartBtnUpdate;
	@FindBy(locator = "cart.lbl.itemtotal")
	private QAFWebElement cartLblItemtotal;
	@FindBy(locator = "cart.lnk.remove")
	private QAFWebElement cartLnkremove;
	@FindBy(locator = "cart.btn.minus")
	private QAFWebElement cartBtnMinus;
	@FindBy(locator = "cart.lnk.editdetails")
	private QAFWebElement cartLnkEditdetails;
	@FindBy(locator = "cart.lbl.discountvalue")
	private QAFWebElement cartLblDiscountvalue;
	@FindBy(locator = "cart.lbl.minqty")
	private QAFWebElement cartLblMinqty;
	
	
	public Shoppingcart(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}
	
	public QAFWebElement getCartEdtQty() {
		return cartEdtQty;
	}

	public QAFWebElement getCartLblProductname() {
		return cartLblProductname;
	}

	public QAFWebElement getCartBtnUpdate() {
		return cartBtnUpdate;
	}

	public QAFWebElement getCartLblItemtotal() {
		return cartLblItemtotal;
	}

	public QAFWebElement getCartLnkremove() {
		return cartLnkremove;
	}

	public QAFWebElement getCartBtnMinus() {
		return cartBtnMinus;
	}
	
	public QAFWebElement getCartLnkEditdetails() {
		return cartLnkEditdetails;
	}
	    
	public QAFWebElement getCartLblDiscountvalue() {
		return cartLblDiscountvalue;
	}
	
	public QAFWebElement getCartLblMinqty() {
		return cartLblMinqty;
	}
	
}
