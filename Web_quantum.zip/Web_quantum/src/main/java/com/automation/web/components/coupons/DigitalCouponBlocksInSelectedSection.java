package com.automation.web.components.coupons;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DigitalCouponBlocksInSelectedSection extends QAFWebComponent {

	public DigitalCouponBlocksInSelectedSection(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "dcselected.chk.couponblockitemcheckbox")
	private QAFWebElement chkCouponblockitemcheckbox;

	@FindBy(locator = "dcselected.lbl.couponblockitemdescription")
	private QAFWebElement lblCouponblockitemdescription;

	@FindBy(locator = "dcselected.img.couponblockitemimage")
	private QAFWebElement imgCouponblockitemimage;

	@FindBy(locator = "dcselected.lbl.couponblockexpdate")
	private QAFWebElement lblCouponblockexpdate;

	@FindBy(locator = "dcselected.lbl.couponblocklimitdescription")
	private QAFWebElement lblCouponblocklimitdescription;

	@FindBy(locator = "dcselected.lbl.couponblockitemprice")
	private QAFWebElement lblCouponblockitemprice;

	public QAFWebElement getChkCouponblockitemcheckbox() {
		return chkCouponblockitemcheckbox;
	}

	public QAFWebElement getLblCouponblockitemdescription() {
		return lblCouponblockitemdescription;
	}

	public QAFWebElement getImgCouponblockitemimage() {
		return imgCouponblockitemimage;
	}

	public QAFWebElement getLblCouponblockexpdate() {
		return lblCouponblockexpdate;
	}

	public QAFWebElement getLblCouponblocklimitdescription() {
		return lblCouponblocklimitdescription;
	}

	public QAFWebElement getLblCouponblockitemprice() {
		return lblCouponblockitemprice;
	}

}
