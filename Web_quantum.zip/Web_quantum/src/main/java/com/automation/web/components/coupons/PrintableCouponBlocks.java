package com.automation.web.components.coupons;

import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebComponent;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PrintableCouponBlocks extends QAFWebComponent {

	public PrintableCouponBlocks(String locator) {
		super(locator);
		// TODO Auto-generated constructor stub
	}

	@FindBy(locator = "printablecoupons.img.couponimagelist")
	private QAFWebElement imgCouponimagelist;

	@FindBy(locator = "printablecoupons.lbl.couponsummarylist")
	private QAFWebElement lblCouponsummarylist;

	@FindBy(locator = "printablecoupons.lbl.couponbrandslist")
	private QAFWebElement lblCouponbrandslist;

	@FindBy(locator = "printablecoupons.lbl.coupondetailslist")
	private QAFWebElement lblCoupondetailslist;

	public QAFWebElement getImgCouponimagelist() {
		return imgCouponimagelist;
	}

	public QAFWebElement getLblCouponsummarylist() {
		return lblCouponsummarylist;
	}

	public QAFWebElement getLblCouponbrandslist() {
		return lblCouponbrandslist;
	}

	public QAFWebElement getLblCoupondetailslist() {
		return lblCoupondetailslist;
	}

}
