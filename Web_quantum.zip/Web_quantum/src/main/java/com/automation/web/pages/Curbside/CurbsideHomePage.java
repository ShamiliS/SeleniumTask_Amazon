package com.automation.web.pages.Curbside;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CurbsideHomePage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "curbside.lbl.greeter")
	private QAFWebElement curbsideLblGreeter;

	@FindBy(locator = "curbside.img.logo")
	private QAFWebElement curbsideImgLogo;

	@FindBy(locator = "curbside.img.map")
	private QAFWebElement curbsideImgMap;

	@FindBy(locator = "curbside.li.stores")
	private List<QAFWebElement> curbsideLiStores;

	/**
	 * TextView of Curbside pickup Greeter title
	 */
	public QAFWebElement getCurbsideLblGreeter(){ return curbsideLblGreeter; }

	/**
	 * ImageView of CurbSide logo
	 */
	public QAFWebElement getCurbsideImgLogo(){ return curbsideImgLogo; }

	/**
	 * ImageView of CurbSide Map
	 */
	public QAFWebElement getCurbsideImgMap(){ return curbsideImgMap; }

	/**
	 * ListView of CurbSide Store names
	 */
	public List<QAFWebElement> getCurbsideLiStores(){ return curbsideLiStores; }

}