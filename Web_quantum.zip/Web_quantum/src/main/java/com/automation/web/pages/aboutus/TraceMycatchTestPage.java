package com.automation.web.pages.aboutus;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class TraceMycatchTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "tmcatch.lbl.pagetitle")
	private QAFWebElement lblPagetitle;

	@FindBy(locator = "tmcatch.txt.entertunacode")
	private QAFWebElement txtEntertunacode;

	@FindBy(locator = "tmcatch.btn.find")
	private QAFWebElement btnFind;

	@FindBy(locator = "tmcatch.lbl.noresultsfounderrormsg")
	private QAFWebElement lblNoresultsfounderrormsg;

	@FindBy(locator = "tmcatch.lbl.pdtseatchresults")
	private QAFWebElement lblPdtseatchresults;
	@FindBy(locator = "tmcatch.lbl.pdtnameheader")
	private QAFWebElement lblPdtnameheader;
	@FindBy(locator = "tmcatch.lbl.pdtcodelabel")
	private QAFWebElement lblPdtcodelabel;
	@FindBy(locator = "tmcatch.lbl.pdtcodevalue")
	private QAFWebElement lblPdtcodevalue;
	@FindBy(locator = "tmcatch.lbl.pdtdescription")
	private QAFWebElement lblPdtdescription;
	@FindBy(locator = "tmcatch.lbl.sorcinginfo")
	private QAFWebElement lblSorcinginfo;
	@FindBy(locator = "tmcatch.lbl.certifications")
	private QAFWebElement lblCertifications;

	public QAFWebElement getLblPdtseatchresults() {
		return lblPdtseatchresults;
	}

	public QAFWebElement getLblPdtnameheader() {
		return lblPdtnameheader;
	}

	public QAFWebElement getLblPdtcodelabel() {
		return lblPdtcodelabel;
	}

	public QAFWebElement getLblPdtcodevalue() {
		return lblPdtcodevalue;
	}

	public QAFWebElement getLblPdtdescription() {
		return lblPdtdescription;
	}

	public QAFWebElement getLblSorcinginfo() {
		return lblSorcinginfo;
	}

	public QAFWebElement getLblCertifications() {
		return lblCertifications;
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getTxtEntertunacode() {
		return txtEntertunacode;
	}

	public QAFWebElement getBtnFind() {
		return btnFind;
	}

	public QAFWebElement getLblNoresultsfounderrormsg() {
		return lblNoresultsfounderrormsg;
	}

}