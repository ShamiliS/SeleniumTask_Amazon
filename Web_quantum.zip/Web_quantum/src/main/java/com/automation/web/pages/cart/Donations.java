package com.automation.web.pages.cart;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Donations extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "donation.lbl.header")
	private QAFWebElement donationLblHeader;

	@FindBy(locator = "donation.lbl.donatenow")
	private QAFWebElement donationLblDonatenow;

	@FindBy(locator = "donation.btn.amountdropdown")
	private QAFWebElement donationBtnAmountdropdown;

	@FindBy(locator = "donation.btn.addtocart")
	private QAFWebElement donationBtnAddtocart;

	/**
	 * Textview of Donations page header
	 */
	public QAFWebElement getDonationLblHeader(){ return donationLblHeader; }

	/**
	 * Textview of Donate now
	 */
	public QAFWebElement getDonationLblDonatenow(){ return donationLblDonatenow; }

	/**
	 * Dropdownview of Donations amount
	 */
	public QAFWebElement getDonationBtnAmountdropdown(){ return donationBtnAmountdropdown; }

	/**
	 * Buttonview of Add to cart
	 */
	public QAFWebElement getDonationBtnAddtocart(){ return donationBtnAddtocart; }

}