package com.automation.web.pages.checkout;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CheckoutTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "checkout.lbl.header")
	private QAFWebElement checkoutLblHeader;

	@FindBy(locator = "checkout.lbl.securecheckout")
	private QAFWebElement checkoutLblSecurecheckout;

	@FindBy(locator = "checkout.lbl.registeredcustomer")
	private QAFWebElement checkoutLblRegisteredcustomer;

	@FindBy(locator = "checkout.edt.regstrduseremail")
	private QAFWebElement checkoutEdtRegstrduseremail;

	@FindBy(locator = "checkout.edt.regstrduserpassword")
	private QAFWebElement checkoutEdtRegstrduserpassword;

	@FindBy(locator = "checkout.btn.login")
	private QAFWebElement checkoutBtnLogin;

	@FindBy(locator = "checkout.lbl.newcustomer")
	private QAFWebElement checkoutLblNewcustomer;

	@FindBy(locator = "checkout.edt.newuseremail")
	private QAFWebElement checkoutEdtNewuseremail;

	@FindBy(locator = "checkout.edt.newuserpassword")
	private QAFWebElement checkoutEdtNewuserpassword;

	@FindBy(locator = "checkout.edt.newuserlastname")
	private QAFWebElement checkoutEdtNewuserlastname;

	@FindBy(locator = "checkout.edt.newuserfname")
	private QAFWebElement checkoutEdtNewuserfname;

	@FindBy(locator = "checkout.btn.createaccount")
	private QAFWebElement checkoutBtnCreateaccount;

	@FindBy(locator = "checkout.lbl.guestcheckout")
	private QAFWebElement checkoutLblGuestcheckout;

	@FindBy(locator = "checkout.btn.guestcheckout")
	private QAFWebElement checkoutBtnGuestcheckout;

	/**
	 * Textview of CheckOut
	 */
	public QAFWebElement getCheckoutLblHeader(){ return checkoutLblHeader; }

	/**
	 * Textview of Secure CheckOut
	 */
	public QAFWebElement getCheckoutLblSecurecheckout(){ return checkoutLblSecurecheckout; }

	/**
	 * Textview of CheckOut Registered Customers
	 */
	public QAFWebElement getCheckoutLblRegisteredcustomer(){ return checkoutLblRegisteredcustomer; }

	/**
	 * EditTextview of Email Address
	 */
	public QAFWebElement getCheckoutEdtRegstrduseremail(){ return checkoutEdtRegstrduseremail; }

	/**
	 * EditTextview of Password
	 */
	public QAFWebElement getCheckoutEdtRegstrduserpassword(){ return checkoutEdtRegstrduserpassword; }

	/**
	 * Buttonview of login
	 */
	public QAFWebElement getCheckoutBtnLogin(){ return checkoutBtnLogin; }

	/**
	 * Textview of CheckOut New Customers
	 */
	public QAFWebElement getCheckoutLblNewcustomer(){ return checkoutLblNewcustomer; }

	/**
	 * Textview of new user email
	 */
	public QAFWebElement getCheckoutEdtNewuseremail(){ return checkoutEdtNewuseremail; }

	/**
	 * EditTextview of new user Password
	 */
	public QAFWebElement getCheckoutEdtNewuserpassword(){ return checkoutEdtNewuserpassword; }

	/**
	 * EditTextview of new user LastName
	 */
	public QAFWebElement getCheckoutEdtNewuserlastname(){ return checkoutEdtNewuserlastname; }

	/**
	 * EditTextview of new user FirstName
	 */
	public QAFWebElement getCheckoutEdtNewuserfname(){ return checkoutEdtNewuserfname; }

	/**
	 * Buttonview of Create Account
	 */
	public QAFWebElement getCheckoutBtnCreateaccount(){ return checkoutBtnCreateaccount; }

	/**
	 * Textview of Guest checkout
	 */
	public QAFWebElement getCheckoutLblGuestcheckout(){ return checkoutLblGuestcheckout; }

	/**
	 * Buttonview of Guest checkout
	 */
	public QAFWebElement getCheckoutBtnGuestcheckout(){ return checkoutBtnGuestcheckout; }

}