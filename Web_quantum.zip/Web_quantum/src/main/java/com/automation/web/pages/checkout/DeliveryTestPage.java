package com.automation.web.pages.checkout;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class DeliveryTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "delivery.lbl.deliveryheader")
	private QAFWebElement deliveryLblDeliveryheader;

	@FindBy(locator = "delivery.lbl.deliveryaddress")
	private QAFWebElement deliveryLblDeliveryaddress;

	@FindBy(locator = "delivery.txt.deliverydate")
	private QAFWebElement deliveryTxtDeliverydate;

	@FindBy(locator = "delivery.txt.firstname")
	private QAFWebElement deliveryTxtFirstname;

	@FindBy(locator = "delivery.txt.lastname")
	private QAFWebElement deliveryTxtLastname;

	@FindBy(locator = "delivery.txt.phonefield1")
	private QAFWebElement deliveryTxtPhonefield1;

	@FindBy(locator = "delivery.txt.phonefield2")
	private QAFWebElement deliveryTxtPhonefield2;

	@FindBy(locator = "delivery.txt.phonefield3")
	private QAFWebElement deliveryTxtPhonefield3;

	@FindBy(locator = "delivery.txt.city")
	private QAFWebElement deliveryTxtCity;

	@FindBy(locator = "delivery.txt.streetaddress1")
	private QAFWebElement deliveryTxtStreetaddress1;

	@FindBy(locator = "delivery.txt.streetaddress2")
	private QAFWebElement deliveryTxtStreetaddress2;

	@FindBy(locator = "delivery.txt.statedropdown")
	private QAFWebElement deliveryTxtStatedropdown;

	@FindBy(locator = "delivery.btn.continue")
	private QAFWebElement deliveryBtnContinue;

	@FindBy(locator = "delivery.lbl.zipcode")
	private QAFWebElement deliveryLblZipcode;

	@FindBy(locator = "delivery.li.btn.usesameadd")
	private List<QAFWebElement> deliveryLiBtnUsesameadd;
	
	@FindBy(locator = "delivery.lbl.plsentervalidphonenumerrormsg")
	private QAFWebElement lblPlsentervalidphonenumerrormsg;
	
	@FindBy(locator = "delivery.lbl.errormsg")
	private QAFWebElement lblErrormsg;

	/**
	 * TextView for delivery tab header
	 */
	public QAFWebElement getDeliveryLblDeliveryheader(){ return deliveryLblDeliveryheader; }

	/**
	 * TextView for delivery address
	 */
	public QAFWebElement getDeliveryLblDeliveryaddress(){ return deliveryLblDeliveryaddress; }

	/**
	 * EditView for delivery date
	 */
	public QAFWebElement getDeliveryTxtDeliverydate(){ return deliveryTxtDeliverydate; }

	/**
	 * EditView for firstname
	 */
	public QAFWebElement getDeliveryTxtFirstname(){ return deliveryTxtFirstname; }

	/**
	 * EditView for lastname
	 */
	public QAFWebElement getDeliveryTxtLastname(){ return deliveryTxtLastname; }

	/**
	 * EditView for phone field 1
	 */
	public QAFWebElement getDeliveryTxtPhonefield1(){ return deliveryTxtPhonefield1; }

	/**
	 * EditView for phone field 2
	 */
	public QAFWebElement getDeliveryTxtPhonefield2(){ return deliveryTxtPhonefield2; }

	/**
	 * EditView for phone field 3
	 */
	public QAFWebElement getDeliveryTxtPhonefield3(){ return deliveryTxtPhonefield3; }

	/**
	 * EditView for city
	 */
	public QAFWebElement getDeliveryTxtCity(){ return deliveryTxtCity; }

	/**
	 * EditView for street address 1
	 */
	public QAFWebElement getDeliveryTxtStreetaddress1(){ return deliveryTxtStreetaddress1; }

	/**
	 * EditView for street address 2
	 */
	public QAFWebElement getDeliveryTxtStreetaddress2(){ return deliveryTxtStreetaddress2; }

	/**
	 * DropdownView for state
	 */
	public QAFWebElement getDeliveryTxtStatedropdown(){ return deliveryTxtStatedropdown; }

	/**
	 * ButtonView for continue
	 */
	public QAFWebElement getDeliveryBtnContinue(){ return deliveryBtnContinue; }

	/**
	 * TextView for zipcode
	 */
	public QAFWebElement getDeliveryLblZipcode(){ return deliveryLblZipcode; }

	/**
	 * Button View for use same address check box
	 */
	public List<QAFWebElement> getDeliveryLiBtnUsesameadd(){ return deliveryLiBtnUsesameadd; }

	public QAFWebElement getLblPlsentervalidphonenumerrormsg() {
		return lblPlsentervalidphonenumerrormsg;
	}
	
	public QAFWebElement getLblErrormsg(){ return lblErrormsg; }
}