package com.automation.web.pages.checkout;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PaymentTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "payment.lbl.paymentmethod")
	private QAFWebElement paymentLblPaymentmethod;

	@FindBy(locator = "payment.chk.sameAsShippingAddress")
	private QAFWebElement paymentChkSameAsShippingAddress;
	
	@FindBy(locator = "payment.lbl.paymentheader")
	private QAFWebElement paymentLblPaymentheader;

	@FindBy(locator = "payment.lbl.enteracreditcard")
	private QAFWebElement paymentLblEnteracreditcard;

	@FindBy(locator = "payment.txt.nameoncard")
	private QAFWebElement paymentTxtNameoncard;

	@FindBy(locator = "payment.txt.cardtypedropdown")
	private QAFWebElement paymentTxtCardtypedropdown;

	@FindBy(locator = "payment.txt.cardnumber")
	private QAFWebElement paymentTxtCardnumber;

	@FindBy(locator = "payment.txt.cardcvc")
	private QAFWebElement paymentTxtCardcvc;

	@FindBy(locator = "payment.txt.cardexpirymonth")
	private QAFWebElement paymentTxtCardexpirymonth;

	@FindBy(locator = "payment.txt.cardexpiryyear")
	private QAFWebElement paymentTxtCardexpiryyear;

	@FindBy(locator = "payment.lbl.billingaddress")
	private QAFWebElement paymentLblBillingaddress;

	@FindBy(locator = "payment.txt.firstname")
	private QAFWebElement paymentTxtFirstname;

	@FindBy(locator = "payment.txt.lastname")
	private QAFWebElement paymentTxtLastname;

	@FindBy(locator = "payment.txt.phonenumber1")
	private QAFWebElement paymentTxtPhonenumber1;

	@FindBy(locator = "payment.txt.phonenumber2")
	private QAFWebElement paymentTxtPhonenumber2;

	@FindBy(locator = "payment.txt.phonenumber3")
	private QAFWebElement paymentTxtPhonenumber3;

	@FindBy(locator = "payment.txt.streetaddress1")
	private QAFWebElement paymentTxtStreetaddress1;

	@FindBy(locator = "payment.txt.streetaddress2")
	private QAFWebElement paymentTxtStreetaddress2;

	@FindBy(locator = "payment.txt.city")
	private QAFWebElement paymentTxtCity;

	@FindBy(locator = "payment.txt.state")
	private QAFWebElement paymentTxtState;

	@FindBy(locator = "payment.txt.zipcode")
	private QAFWebElement paymentTxtZipcode;

	@FindBy(locator = "payment.txt.email")
	private QAFWebElement paymentTxtEmail;

	@FindBy(locator = "payment.txt.confirmemail")
	private QAFWebElement paymentTxtConfirmemail;

	@FindBy(locator = "payment.btn.submitorder")
	private QAFWebElement paymentBtnSubmitorder;

	@FindBy(locator = "payment.txt.cardtypemastercard")
	private QAFWebElement paymentTxtCardtypemastercard;

	@FindBy(locator = "payment.txt.cardexpiryyearvalue")
	private QAFWebElement paymentTxtCardexpiryyearvalue;

	@FindBy(locator = "payment.txt.cardexpirymonthvalue")
	private QAFWebElement paymentTxtCardexpirymonthvalue;

	@FindBy(locator = "payment.lbl.giftcardnumber")
	private QAFWebElement paymentLblGiftcardnumber;

	@FindBy(locator = "payment.txt.giftcardpin")
	private QAFWebElement paymentTxtGiftcardpin;

	@FindBy(locator = "payment.lbl.giftcardpin")
	private QAFWebElement paymentLblGiftcardpin;

	@FindBy(locator = "payment.lbl.giftcardandegiftcard")
	private QAFWebElement paymentLblGiftcardandegiftcard;

	@FindBy(locator = "payment.txt.giftcardnumber")
	private QAFWebElement paymentTxtGiftcardnumber;

	@FindBy(locator = "payment.btn.applygiftcard")
	private QAFWebElement paymentBtnApplygiftcard;

	@FindBy(locator = "payment.lbl.giftcardamt")
	private QAFWebElement paymentLblGiftcardamt;

	@FindBy(locator = "payment.lbl.ordertotalamt")
	private QAFWebElement paymentLblOrdertotalamt;

	@FindBy(locator = "payment.lbl.ordersubtotalamt")
	private QAFWebElement paymentLblOrdersubtotalamt;

	@FindBy(locator = "payment.lbl.giftcardappliedmessage")
	private QAFWebElement paymentLblGiftcardappliedmessage;

	@FindBy(locator = "payment.lbl.applytaxexemption")
	private QAFWebElement paymentLblApplytaxexemption;

	@FindBy(locator = "payment.chk.applytaxexemption")
	private QAFWebElement paymentChkApplytaxexemption;

	@FindBy(locator = "payment.lbl.estimatedtaxamt")
	private QAFWebElement paymentLblEstimatedtaxamt;

	@FindBy(locator = "payment.chk.savecreditcard")
	private QAFWebElement paymentChkSavecreditcard;

	@FindBy(locator = "payment.rbtn.enteracreditcard")
	private QAFWebElement paymentRbtnEnteracreditcard;

	@FindBy(locator = "payment.chk.ageverification")
	private QAFWebElement paymentChkAgeverification;

	@FindBy(locator = "payement.btn.makeprimarycard")
	private QAFWebElement payementBtnMakeprimarycard;

	@FindBy(locator = "payement.btn.myprimarycard")
	private QAFWebElement payementBtnMyprimarycard;

	@FindBy(locator = "payement.lbl.cardname")
	private QAFWebElement payementLblCardname;

	@FindBy(locator = "payement.lbl.defaultcards")
	private QAFWebElement payementLblDefaultcards;

	@FindBy(locator = "payment.lbl.cardtypeamericanexpress")
	private QAFWebElement paymentLblCardtypeamericanexpress;

	@FindBy(locator = "payment.lnk.giftcardremove")
	private QAFWebElement paymentLnkGiftcardremove;

	@FindBy(locator = "payment.lbl.errormsg")
	private QAFWebElement paymentLblErrormsg;

	@FindBy(locator = "payment.txt.cardtypeamericanexcard")
	private QAFWebElement paymentTxtCardtypeamericanexcard;
	
	@FindBy(locator = "payment.txt.phonenumber1error")
	private QAFWebElement paymentTxtPhonenumber1error;
	
	@FindBy(locator = "payment.txt.phonenumber2error")
	private QAFWebElement paymentTxtPhonenumber2error;
	
	@FindBy(locator = "payment.txt.phonenumber3error")
	private QAFWebElement paymentTxtPhonenumber3error;
	
	@FindBy(locator = "payment.lbl.entervalidphonenumbererrormsg")
	private QAFWebElement paymentLblEntervalidphonenumbererrormsg;
	
	@FindBy(locator = "payment.txt.specialhandlingamount")
	private QAFWebElement paymentTxtSpecialhandlingamount;
	
	@FindBy(locator = "payment.lbl.shippingmethod")
	private QAFWebElement paymentLblShippingmethod;
	
	@FindBy(locator = "payment.lbl.shiptohome")
	private QAFWebElement paymentLblShiptohome;
	
	@FindBy(locator = "payment.lbl.shippingamount")
	private QAFWebElement paymentLblShippingamount;
	
	public QAFWebElement getPaymentLblShippingmethod(){ return paymentLblShippingmethod; }
	
	public QAFWebElement getPaymentLblShiptohome(){ return paymentLblShiptohome; }
	
	public QAFWebElement getPaymentLblShippingamount(){ return paymentLblShippingamount; }

	/**
	 * TextView for payment method
	 */
	public QAFWebElement getPaymentLblPaymentmethod(){ return paymentLblPaymentmethod; }

	/**
	 * TextView for payment header
	 */
	public QAFWebElement getPaymentLblPaymentheader(){ return paymentLblPaymentheader; }

	/**
	 * TextView for enter a credit card
	 */
	public QAFWebElement getPaymentLblEnteracreditcard(){ return paymentLblEnteracreditcard; }

	/**
	 * EditView for name on card
	 */
	public QAFWebElement getPaymentTxtNameoncard(){ return paymentTxtNameoncard; }

	/**
	 * DropdownView for card type
	 */
	public QAFWebElement getPaymentTxtCardtypedropdown(){ return paymentTxtCardtypedropdown; }

	/**
	 * EditView for card number
	 */
	public QAFWebElement getPaymentTxtCardnumber(){ return paymentTxtCardnumber; }

	/**
	 * EditView for card cvc code
	 */
	public QAFWebElement getPaymentTxtCardcvc(){ return paymentTxtCardcvc; }

	/**
	 * DropdownView for card expiry month
	 */
	public QAFWebElement getPaymentTxtCardexpirymonth(){ return paymentTxtCardexpirymonth; }

	/**
	 * DropdownView for card expiry year
	 */
	public QAFWebElement getPaymentTxtCardexpiryyear(){ return paymentTxtCardexpiryyear; }

	/**
	 * TextView for billing address header
	 */
	public QAFWebElement getPaymentLblBillingaddress(){ return paymentLblBillingaddress; }

	/**
	 * EditView for firstname
	 */
	public QAFWebElement getPaymentTxtFirstname(){ return paymentTxtFirstname; }

	/**
	 * EditView for lastname
	 */
	public QAFWebElement getPaymentTxtLastname(){ return paymentTxtLastname; }

	/**
	 * EditView for phonenumber part one
	 */
	public QAFWebElement getPaymentTxtPhonenumber1(){ return paymentTxtPhonenumber1; }

	/**
	 * EditView for phonenumber part two
	 */
	public QAFWebElement getPaymentTxtPhonenumber2(){ return paymentTxtPhonenumber2; }

	/**
	 * EditView for phonenumber part three
	 */
	public QAFWebElement getPaymentTxtPhonenumber3(){ return paymentTxtPhonenumber3; }

	/**
	 * EditView for street address 1
	 */
	public QAFWebElement getPaymentTxtStreetaddress1(){ return paymentTxtStreetaddress1; }

	/**
	 * EditView for street addres 2
	 */
	public QAFWebElement getPaymentTxtStreetaddress2(){ return paymentTxtStreetaddress2; }

	/**
	 * EditView for city
	 */
	public QAFWebElement getPaymentTxtCity(){ return paymentTxtCity; }

	/**
	 * DropdownView for state
	 */
	public QAFWebElement getPaymentTxtState(){ return paymentTxtState; }

	/**
	 * EditView for zipcode
	 */
	public QAFWebElement getPaymentTxtZipcode(){ return paymentTxtZipcode; }

	/**
	 * EditView for email
	 */
	public QAFWebElement getPaymentTxtEmail(){ return paymentTxtEmail; }

	/**
	 * EditView for confirm email
	 */
	public QAFWebElement getPaymentTxtConfirmemail(){ return paymentTxtConfirmemail; }

	/**
	 * ButtonView for submit order
	 */
	public QAFWebElement getPaymentBtnSubmitorder(){ return paymentBtnSubmitorder; }

	/**
	 * DropdownView for card type as master card
	 */
	public QAFWebElement getPaymentTxtCardtypemastercard(){ return paymentTxtCardtypemastercard; }

	/**
	 * DropdownView for expiry year value
	 */
	public QAFWebElement getPaymentTxtCardexpiryyearvalue(){ return paymentTxtCardexpiryyearvalue; }

	/**
	 * DropdownView for expiry month value
	 */
	public QAFWebElement getPaymentTxtCardexpirymonthvalue(){ return paymentTxtCardexpirymonthvalue; }

	/**
	 * TextView for giftcard number
	 */
	public QAFWebElement getPaymentLblGiftcardnumber(){ return paymentLblGiftcardnumber; }

	/**
	 * EditView for giftcard pin
	 */
	public QAFWebElement getPaymentTxtGiftcardpin(){ return paymentTxtGiftcardpin; }

	/**
	 * TextView for giftcard pin
	 */
	public QAFWebElement getPaymentLblGiftcardpin(){ return paymentLblGiftcardpin; }

	/**
	 * TextView for giftcard and egift card
	 */
	public QAFWebElement getPaymentLblGiftcardandegiftcard(){ return paymentLblGiftcardandegiftcard; }

	/**
	 * EditView for giftcard number
	 */
	public QAFWebElement getPaymentTxtGiftcardnumber(){ return paymentTxtGiftcardnumber; }

	/**
	 * ButtonView for apply giftcard
	 */
	public QAFWebElement getPaymentBtnApplygiftcard(){ return paymentBtnApplygiftcard; }

	/**
	 * TextView for giftcard amount
	 */
	public QAFWebElement getPaymentLblGiftcardamt(){ return paymentLblGiftcardamt; }

	/**
	 * TextView for order total amount
	 */
	public QAFWebElement getPaymentLblOrdertotalamt(){ return paymentLblOrdertotalamt; }

	/**
	 * TextView for order subtotal amount
	 */
	public QAFWebElement getPaymentLblOrdersubtotalamt(){ return paymentLblOrdersubtotalamt; }

	/**
	 * TextView for giftcard applied
	 */
	public QAFWebElement getPaymentLblGiftcardappliedmessage(){ return paymentLblGiftcardappliedmessage; }

	/**
	 * TextView for apply tax exemption
	 */
	public QAFWebElement getPaymentLblApplytaxexemption(){ return paymentLblApplytaxexemption; }

	/**
	 * ChedkboxView for apply tax exemption
	 */
	public QAFWebElement getPaymentChkApplytaxexemption(){ return paymentChkApplytaxexemption; }

	/**
	 * TextView for estimated tax amount
	 */
	public QAFWebElement getPaymentLblEstimatedtaxamt(){ return paymentLblEstimatedtaxamt; }

	/**
	 * CheckboxView for save credit card
	 */
	public QAFWebElement getPaymentChkSavecreditcard(){ return paymentChkSavecreditcard; }

	/**
	 * RadiobuttonView for enter a credit card
	 */
	public QAFWebElement getPaymentRbtnEnteracreditcard(){ return paymentRbtnEnteracreditcard; }

	/**
	 * CheckboxView for age verification
	 */
	public QAFWebElement getPaymentChkAgeverification(){ return paymentChkAgeverification; }

	/**
	 * ButtonView for Make Primary card
	 */
	public QAFWebElement getPayementBtnMakeprimarycard(){ return payementBtnMakeprimarycard; }

	/**
	 * ButtonView for My Primary card
	 */
	public QAFWebElement getPayementBtnMyprimarycard(){ return payementBtnMyprimarycard; }

	/**
	 * LabelView for Card Name
	 */
	public QAFWebElement getPayementLblCardname(){ return payementLblCardname; }

	/**
	 * TextView for Default cards
	 */
	public QAFWebElement getPayementLblDefaultcards(){ return payementLblDefaultcards; }

	/**
	 * DropDownView for American Express
	 */
	public QAFWebElement getPaymentLblCardtypeamericanexpress(){ return paymentLblCardtypeamericanexpress; }

	/**
	 * LinkView for giftcard remove
	 */
	public QAFWebElement getPaymentLnkGiftcardremove(){ return paymentLnkGiftcardremove; }

	/**
	 * TextView for error message
	 */
	public QAFWebElement getPaymentLblErrormsg(){ return paymentLblErrormsg; }

	/**
	 * DropdownView for card type as American Express
	 */
	public QAFWebElement getPaymentTxtCardtypeamericanexcard(){ return paymentTxtCardtypeamericanexcard; }

	public QAFWebElement getPaymentTxtPhonenumber1error() {
		return paymentTxtPhonenumber1error;
	}


	public QAFWebElement getPaymentTxtPhonenumber2error() {
		return paymentTxtPhonenumber2error;
	}


	public QAFWebElement getPaymentTxtPhonenumber3error() {
		return paymentTxtPhonenumber3error;
	}


	public QAFWebElement getPaymentLblEntervalidphonenumbererrormsg() {
		return paymentLblEntervalidphonenumbererrormsg;
	}
	
	public QAFWebElement getPaymentChkSameAsShippingAddress() {
		return paymentChkSameAsShippingAddress;
	}
	
	public QAFWebElement getPaymentTxtSpecialhandlingamount() {
		return paymentTxtSpecialhandlingamount;
	}

}