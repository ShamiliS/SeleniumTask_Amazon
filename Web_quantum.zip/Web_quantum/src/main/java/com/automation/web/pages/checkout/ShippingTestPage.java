package com.automation.web.pages.checkout;

import java.util.List;

import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShippingTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "shippingtab.txt.firstname")
	private QAFWebElement shippingtabTxtFirstname;
	
	@FindBy(locator = "shippingtab.dd.shipto")
	private QAFWebElement shippingtabDDShipTo;
	
	@FindBy(locator = "shippingtab.rbtn.newshippingaddress")
	private QAFWebElement shippingtabRbtnNewShippingAddress;
	
	@FindBy(locator = "shippingtab.lbl.shippingtoaddressnickname")
	private QAFWebElement shippingtabLblShippingToAddressNickName;

	@FindBy(locator = "shippingtab.txt.lastname")
	private QAFWebElement shippingtabTxtLastname;

	@FindBy(locator = "shippingtab.txt.phonenumber1")
	private QAFWebElement shippingtabTxtPhonenumber1;

	@FindBy(locator = "shippingtab.txt.phonenumber2")
	private QAFWebElement shippingtabTxtPhonenumber2;

	@FindBy(locator = "shippingtab.txt.phonenumber3")
	private QAFWebElement shippingtabTxtPhonenumber3;

	@FindBy(locator = "shippingtab.txt.streetaddress1")
	private QAFWebElement shippingtabTxtStreetaddress1;

	@FindBy(locator = "shippingtab.txt.streetaddress2")
	private QAFWebElement shippingtabTxtStreetaddress2;

	@FindBy(locator = "shippingtab.txt.city")
	private QAFWebElement shippingtabTxtCity;

	@FindBy(locator = "shippingtab.txt.zipcode1")
	private QAFWebElement shippingtabTxtZipcode1;

	@FindBy(locator = "shippingtab.txt.zipcode2")
	private QAFWebElement shippingtabTxtZipcode2;

	@FindBy(locator = "shippingtab.lbl.isbusinesspurchase")
	private QAFWebElement shippingtabLblIsbusinesspurchase;

	@FindBy(locator = "shippingtab.txt.statedropdown")
	private QAFWebElement shippingtabTxtStatedropdown;

	@FindBy(locator = "shippingtab.lbl.shippingto")
	private QAFWebElement shippingtabLblShippingto;

	@FindBy(locator = "shippingtab.li.lbl.shippingtoaddresslist")
	private List<QAFWebElement> shippingtabLiLblShippingtoaddresslist;

	@FindBy(locator = "shippingtab.txt.prefixdropdown")
	private QAFWebElement shippingtabTxtPrefixdropdown;

	@FindBy(locator = "shippingtab.txt.countrydropdown")
	private QAFWebElement shippingtabTxtCountrydropdown;

	@FindBy(locator = "shippingtab.lbl.createnewshippingaddress")
	private QAFWebElement shippingtabLblCreatenewshippingaddress;

	@FindBy(locator = "shippingtab.lbl.shippingaddress")
	private QAFWebElement shippingtabLblShippingaddress;

	@FindBy(locator = "shippingtab.lbl.shippingheader")
	private QAFWebElement shippingtabLblShippingheader;

	@FindBy(locator = "shippingtab.lbl.verifyshippingsddress")
	private QAFWebElement shippingtabLblVerifyshippingsddress;

	@FindBy(locator = "shippingtab.btn.usethisaddress")
	private QAFWebElement shippingtabBtnUsethisaddress;

	@FindBy(locator = "shippingtab.btn.continueexistingaddress")
	private QAFWebElement shippingtabBtnContinueexistingaddress;

	@FindBy(locator = "shippingtab.btn.continuenewaddress")
	private QAFWebElement shippingtabBtnContinuenewaddress;

	@FindBy(locator = "shippingtab.txt.nickname")
	private QAFWebElement shippingtabTxtNickname;

	@FindBy(locator = "shippingtab.btn.editcart")
	private QAFWebElement shippingtabBtnEditcart;

	@FindBy(locator = "shippingtab.lbl.errormsg")
	private QAFWebElement shippingtabLblErrormsg;

	@FindBy(locator = "shippingtab.lbl.shiptomultiad")
	private QAFWebElement shippingtabLblShiptomultiad;

	@FindBy(locator = "shippingtab.rbtn.shiptomultiad")
	private QAFWebElement shippingtabRbtnShiptomultiad;

	@FindBy(locator = "shippingtab.btn.shiptomultiaddropdown")
	private QAFWebElement shippingtabBtnShiptomultiaddropdown;

	@FindBy(locator = "shippingtab.li.items")
	private List<QAFWebElement> shippingtabLiItems;

	@FindBy(locator = "shippingtab.btn.save")
	private QAFWebElement shippingtabBtnSave;

	@FindBy(locator = "shippingtab.lnk.viewallshipping")
	private QAFWebElement shippingtabLnkViewAllShipping;
	
	@FindBy(locator = "shippingtab.lbl.deliveryandreturns")
	private QAFWebElement shippingtabLblDeliveryandReturns;
	
	@FindBy(locator = "shippingtab.lbl.shippingandhandling")
	private QAFWebElement shippingtabLblShippingandhandling;
	
	@FindBy(locator = "shippingtab.lbl.shippingmethod")
	private QAFWebElement shippingtabLblShippingmethod; 
	
	
	/**
	 * EditView for firstname
	 */
	public QAFWebElement getShippingtabTxtFirstname(){ return shippingtabTxtFirstname; }

	/**
	 * EditView for lastname
	 */
	public QAFWebElement getShippingtabTxtLastname(){ return shippingtabTxtLastname; }

	/**
	 * EditView for phonenumber part one
	 */
	public QAFWebElement getShippingtabTxtPhonenumber1(){ return shippingtabTxtPhonenumber1; }

	/**
	 * EditView for phonenumber part two
	 */
	public QAFWebElement getShippingtabTxtPhonenumber2(){ return shippingtabTxtPhonenumber2; }

	/**
	 * EditView for phonenumber part three
	 */
	public QAFWebElement getShippingtabTxtPhonenumber3(){ return shippingtabTxtPhonenumber3; }

	/**
	 * EditView for street address 1
	 */
	public QAFWebElement getShippingtabTxtStreetaddress1(){ return shippingtabTxtStreetaddress1; }

	/**
	 * EditView for street address 2
	 */
	public QAFWebElement getShippingtabTxtStreetaddress2(){ return shippingtabTxtStreetaddress2; }

	/**
	 * EditView for city
	 */
	public QAFWebElement getShippingtabTxtCity(){ return shippingtabTxtCity; }

	/**
	 * EditView for zipcode 1
	 */
	public QAFWebElement getShippingtabTxtZipcode1(){ return shippingtabTxtZipcode1; }

	/**
	 * EditView for zipcode 2
	 */
	public QAFWebElement getShippingtabTxtZipcode2(){ return shippingtabTxtZipcode2; }

	/**
	 * TextView for is this a business purchase
	 */
	public QAFWebElement getShippingtabLblIsbusinesspurchase(){ return shippingtabLblIsbusinesspurchase; }

	/**
	 * DropdownView for selecting state
	 */
	public QAFWebElement getShippingtabTxtStatedropdown(){ return shippingtabTxtStatedropdown; }

	/**
	 * TextView for shipping to
	 */
	public QAFWebElement getShippingtabLblShippingto(){ return shippingtabLblShippingto; }

	/**
	 * ListView for shipping to address
	 */
	public List<QAFWebElement> getShippingtabLiLblShippingtoaddresslist(){ return shippingtabLiLblShippingtoaddresslist; }

	/**
	 * TextView for prefix dropdown
	 */
	public QAFWebElement getShippingtabTxtPrefixdropdown(){ return shippingtabTxtPrefixdropdown; }

	/**
	 * TextView for country dropdown
	 */
	public QAFWebElement getShippingtabTxtCountrydropdown(){ return shippingtabTxtCountrydropdown; }

	/**
	 * TextView for create a new shipping address
	 */
	public QAFWebElement getShippingtabLblCreatenewshippingaddress(){ return shippingtabLblCreatenewshippingaddress; }

	/**
	 * TextView for shipping address
	 */
	public QAFWebElement getShippingtabLblShippingaddress(){ return shippingtabLblShippingaddress; }

	/**
	 * TextView for shipping tab header
	 */
	public QAFWebElement getShippingtabLblShippingheader(){ return shippingtabLblShippingheader; }

	/**
	 * TextView for verifying shipping address
	 */
	public QAFWebElement getShippingtabLblVerifyshippingsddress(){ return shippingtabLblVerifyshippingsddress; }

	/**
	 * ButtonView for use this address
	 */
	public QAFWebElement getShippingtabBtnUsethisaddress(){ return shippingtabBtnUsethisaddress; }

	/**
	 * ButtonView for continue in existing address
	 */
	public QAFWebElement getShippingtabBtnContinueexistingaddress(){ return shippingtabBtnContinueexistingaddress; }

	/**
	 * ButtonView for continue for new address
	 */
	public QAFWebElement getShippingtabBtnContinuenewaddress(){ return shippingtabBtnContinuenewaddress; }

	/**
	 * TextView for nickname field
	 */
	public QAFWebElement getShippingtabTxtNickname(){ return shippingtabTxtNickname; }

	/**
	 * ButtonView for Edit Cart
	 */
	public QAFWebElement getShippingtabBtnEditcart(){ return shippingtabBtnEditcart; }

	/**
	 * TextView for error message
	 */
	public QAFWebElement getShippingtabLblErrormsg(){ return shippingtabLblErrormsg; }

	/**
	 * TextView for Ship to Multiple addresses
	 */
	public QAFWebElement getShippingtabLblShiptomultiad(){ return shippingtabLblShiptomultiad; }

	/**
	 * RadioButtonView for Ship to Multiple addresses
	 */
	public QAFWebElement getShippingtabRbtnShiptomultiad(){ return shippingtabRbtnShiptomultiad; }

	/**
	 * ButtonView for Ship to Mutiple addresses select drop down
	 */
	public QAFWebElement getShippingtabBtnShiptomultiaddropdown(){ return shippingtabBtnShiptomultiaddropdown; }

	/**
	 * ListView for items in Shipping address tab
	 */
	public List<QAFWebElement> getShippingtabLiItems(){ return shippingtabLiItems; }

	/**
	 * Buttonview of save
	 */
	public QAFWebElement getShippingtabBtnSave(){ return shippingtabBtnSave; }
	
	public QAFWebElement getShippingtabDDShipTo(){ return shippingtabDDShipTo; }
	
	public QAFWebElement getShippingtabLblShippingToAddressNickName(){ return shippingtabLblShippingToAddressNickName; }
	
	public QAFWebElement getShippingtabRbtnNewShippingAddress(){ return shippingtabRbtnNewShippingAddress; }
	
	public QAFWebElement getShippingtabLnkViewAllShipping(){ return shippingtabLnkViewAllShipping; }
	
	public QAFWebElement getShippingtabLblDeliveryandReturns(){ return shippingtabLblDeliveryandReturns; }
	
	public QAFWebElement getShippingtabLblShippingandhandling(){ return shippingtabLblShippingandhandling; }
	
	public QAFWebElement getShippingtabLblShippingmethod(){ return shippingtabLblShippingmethod; }
	
	
}