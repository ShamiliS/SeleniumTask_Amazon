package com.automation.web.pages.coupons;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CouponsOverlayTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "couponsoverlay.img.popupimg")
	private QAFWebElement imgPopupimg;
	@FindBy(locator = "couponsoverlay.lbl.couponname")
	private QAFWebElement lblCouponname;
	@FindBy(locator = "couponsoverlay.btn.select")
	private QAFWebElement btnSelect;
	@FindBy(locator = "couponsoverlay.img.twitter")
	private QAFWebElement imgTwitter;
	@FindBy(locator = "couponsoverlay.img.sendemail")
	private QAFWebElement imgSendemail;
	@FindBy(locator = "couponsoverlay.img.popupclose")
	private QAFWebElement imgPopupclose;
	@FindBy(locator = "couponsoverlay.lbl.expirydate")
	private QAFWebElement lblExpirydate;
	@FindBy(locator = "couponsoverlay.lbl.limitdescription")
	private QAFWebElement lblLimitdescription;
	@FindBy(locator = "couponsoverlay.lbl.termsandconditionsheader")
	private QAFWebElement lblTermsandconditionsheader;
	@FindBy(locator = "couponsoverlay.lbl.termsandconditionscontent")
	private QAFWebElement lblTermsandconditionscontent;

	public QAFWebElement getLblExpirydate() {
		return lblExpirydate;
	}

	public QAFWebElement getLblLimitdescription() {
		return lblLimitdescription;
	}

	public QAFWebElement getLblTermsandconditionsheader() {
		return lblTermsandconditionsheader;
	}

	public QAFWebElement getLblTermsandconditionscontent() {
		return lblTermsandconditionscontent;
	}

	public QAFWebElement getImgPopupimg() {
		return imgPopupimg;
	}

	public QAFWebElement getLblCouponname() {
		return lblCouponname;
	}

	public QAFWebElement getBtnSelect() {
		return btnSelect;
	}

	public QAFWebElement getImgTwitter() {
		return imgTwitter;
	}

	public QAFWebElement getImgSendemail() {
		return imgSendemail;
	}

	public QAFWebElement getImgPopupclose() {
		return imgPopupclose;
	}

}