package com.automation.web.pages.coupons;

import java.util.List;

import com.automation.web.components.coupons.PrintableCouponBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PrintableCouponsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "printablecoupons.lbl.printablecouponsheader")
	private QAFWebElement lblPrintablecouponsheader;
	@FindBy(locator = "printablecoupons.lbl.categories")
	private QAFWebElement lblCategories;
	@FindBy(locator = "printablecoupons.li.categorieslist")
	private List<QAFWebElement> liCategorieslist;
	@FindBy(locator = "printablecoupons.lbl.availablesavings")
	private QAFWebElement lblAvailablesavings;
	@FindBy(locator = "printablecoupons.lbl.availablesavingsvalue")
	private QAFWebElement lblAvailablesavingsvalue;

	@FindBy(locator = "printablecoupons.img.savingsmeter")
	private QAFWebElement imgSavingsmeter;

	@FindBy(locator = "printablecoupons.btn.printcoupons")
	private QAFWebElement btnPrintcoupons;

	@FindBy(locator = "printablecoupons.lbl.freeprintablecoupons")
	private QAFWebElement lblFreeprintablecoupons;

	@FindBy(locator = "printablecoupons.li.couponblocks")
	private List<PrintableCouponBlocks> liCouponblocks;

	@FindBy(locator = "printablecoupons.btn.showmorecoupons")
	private QAFWebElement btnShowmorecoupons;

	public QAFWebElement getLblPrintablecouponsheader() {
		return lblPrintablecouponsheader;
	}

	public QAFWebElement getLblCategories() {
		return lblCategories;
	}

	public List<QAFWebElement> getLiCategorieslist() {
		return liCategorieslist;
	}

	public QAFWebElement getLblAvailablesavings() {
		return lblAvailablesavings;
	}

	public QAFWebElement getLblAvailablesavingsvalue() {
		return lblAvailablesavingsvalue;
	}

	public QAFWebElement getImgSavingsmeter() {
		return imgSavingsmeter;
	}

	public QAFWebElement getBtnPrintcoupons() {
		return btnPrintcoupons;
	}

	public QAFWebElement getLblFreeprintablecoupons() {
		return lblFreeprintablecoupons;
	}

	public List<PrintableCouponBlocks> getLiCouponblocks() {
		return liCouponblocks;
	}

	public QAFWebElement getBtnShowmorecoupons() {
		return btnShowmorecoupons;
	}

}