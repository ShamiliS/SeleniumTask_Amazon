package com.automation.web.pages.homepage;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class FooterTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}

	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "footer.lnk.shiptohome")
	private QAFWebElement footerLnkShiptohome;

	@FindBy(locator = "footer.lnk.curbsidepick")
	private QAFWebElement footerLnkCurbsidepick;

	@FindBy(locator = "footer.lnk.grocerydelivery")
	private QAFWebElement footerLnkGrocerydelivery;

	
	@FindBy(locator = "footer.lnk.giftcards")
	private QAFWebElement footerLnkGiftcards;

	@FindBy(locator = "footer.lnk.customerservice")
	private QAFWebElement footerLnkCustomerservice;

	@FindBy(locator = "footer.lnk.contactus")
	private QAFWebElement footerLnkContactus;

	@FindBy(locator = "footer.lnk.Couponpolicy")
	private QAFWebElement footerLnkCouponpolicy;

	@FindBy(locator = "footer.lnk.faq")
	private QAFWebElement footerLnkFaq;

	@FindBy(locator = "footer.lnk.productrecall")
	private QAFWebElement footerLnkProductrecall;

	@FindBy(locator = "footer.lnk.refundpolicy")
	private QAFWebElement footerLnkRefundpolicy;

	@FindBy(locator = "footer.lnk.sitemap")
	private QAFWebElement footerLnkSitemap;
	
	@FindBy(locator = "footer.lbl.header")
	private QAFWebElement lblheader;
	
	@FindBy(locator = "footer.lbl.header1")
	private QAFWebElement lblheader1;
	
	@FindBy(locator = "footer.lbl.headerCentralmarket")
	private QAFWebElement lblheaderCentralmarket;
	
	

	

	@FindBy(locator = "footer.lnk.aboutus")
	private QAFWebElement footerLnkAboutus;

	@FindBy(locator = "footer.lnk.careers")
	private QAFWebElement footerLnkCareers;

	@FindBy(locator = "footer.lnk.community")
	private QAFWebElement footerLnkCommunity;

	@FindBy(locator = "footer.lnk.environmentalresponsibility")
	private QAFWebElement footerLnkEnvironmentalresponsibility;

	@FindBy(locator = "footer.lnk.partners")
	private QAFWebElement footerLnkPartners;

	@FindBy(locator = "footer.lnk.pressreleases")
	private QAFWebElement footerLnkPressreleases;

	@FindBy(locator = "footer.lnk.suppliers")
	private QAFWebElement footerLnkSuppliers;

	@FindBy(locator = "footer.lnk.tvcommercials")
	private QAFWebElement footerLnkTvcommercials;

	@FindBy(locator = "footer.lnk.centralmarket")
	private QAFWebElement footerLnkCentralmarket;

	@FindBy(locator = "footer.lnk.hebmexico")
	private QAFWebElement footerLnkHebmexico;

	@FindBy(locator = "footer.lnk.bussinesscentre")
	private QAFWebElement footerLnkBussinesscentre;

	@FindBy(locator = "footer.lnk.curbside")
	private QAFWebElement footerLnkCurbside;

	@FindBy(locator = "footer.lnk.sth")
	private QAFWebElement footerLnkSth;

	@FindBy(locator = "footer.lnk.giftcard")
	private QAFWebElement footerLnkGiftcard;

	@FindBy(locator = "footer.lnk.optical")
	private QAFWebElement footerLnkOptical;

	@FindBy(locator = "footer.lnk.restaurants")
	private QAFWebElement footerLnkRestaurants;

	@FindBy(locator = "footer.lnk.ticketsale")
	private QAFWebElement footerLnkTicketsale;

	@FindBy(locator = "footer.lnk.weeklyaddcoupons")
	private QAFWebElement footerLnkWeeklyaddcoupons;
	
	@FindBy(locator = "footer.lbl.footer")
	private QAFWebElement lblfooter;
	
	
	public QAFWebElement getLblheader1() {
		return lblheader1;
	}

	public QAFWebElement lblheaderCentralmarket() {
		return lblheaderCentralmarket;
	}


	/**
	 * LinkTextView of Ship To Home
	 */
	public QAFWebElement getFooterLnkShiptohome(){ return footerLnkShiptohome; }

	/**
	 * LinkTextView of Curbside Pickup
	 */
	public QAFWebElement getFooterLnkCurbsidepick(){ return footerLnkCurbsidepick; }

	/**
	 * LinkTextView of Grocery Delivery
	 */


	/**
	 * LinkTextView of Gift Cards
	 */
	public QAFWebElement getFooterLnkGiftcards(){ return footerLnkGiftcards; }

	/**
	 * text view for customer service 
	 */
	public QAFWebElement getFooterLnkCustomerservice(){ return footerLnkCustomerservice; }

	/**
	 * text view for contact us
	 */
	public QAFWebElement getFooterLnkContactus(){ return footerLnkContactus; }

	/**
	 * text view for Coupon Policy
	 */
	public QAFWebElement getFooterLnkCouponpolicy(){ return footerLnkCouponpolicy; }

	/**
	 * text view for faqs
	 */
	public QAFWebElement getFooterLnkFaq(){ return footerLnkFaq; }

	/**
	 * text view for product recall
	 */
	public QAFWebElement getFooterLnkProductrecall(){ return footerLnkProductrecall; }

	/**
	 * text view for refund policy
	 */
	public QAFWebElement getFooterLnkRefundpolicy(){ return footerLnkRefundpolicy; }

	/**
	 * text view for site map
	 */
	public QAFWebElement getFooterLnkSitemap(){ return footerLnkSitemap; }
	
	


	public QAFWebElement getLblheader() {
		return lblheader;
	}

	/**
	 * text view for about us 
	 */
	public QAFWebElement getFooterLnkAboutus(){ return footerLnkAboutus; }

	/**
	 * text view for careers 
	 */
	public QAFWebElement getFooterLnkCareers(){ return footerLnkCareers; }

	/**
	 * text view for community 
	 */
	public QAFWebElement getFooterLnkCommunity(){ return footerLnkCommunity; }

	/**
	 * text view for environmental responsibility 
	 */
	public QAFWebElement getFooterLnkEnvironmentalresponsibility(){ return footerLnkEnvironmentalresponsibility; }

	/**
	 * text view for Partners
	 */
	public QAFWebElement getFooterLnkPartners(){ return footerLnkPartners; }

	/**
	 * text view for Press Releases 
	 */
	public QAFWebElement getFooterLnkPressreleases(){ return footerLnkPressreleases; }

	/**
	 * text view for suppliers 
	 */
	public QAFWebElement getFooterLnkSuppliers(){ return footerLnkSuppliers; }

	/**
	 * text view for TV Commercials 
	 */
	public QAFWebElement getFooterLnkTvcommercials(){ return footerLnkTvcommercials; }

	/**
	 * text view for Central Market 
	 */
	public QAFWebElement getFooterLnkCentralmarket(){ return footerLnkCentralmarket; }

	/**
	 * text view for H-E-B Mexico 
	 */
	public QAFWebElement getFooterLnkHebmexico(){ return footerLnkHebmexico; }

	/**
	 * text view for Business Center 
	 */
	public QAFWebElement getFooterLnkBussinesscentre(){ return footerLnkBussinesscentre; }

	/**
	 * text view for Curbside Pickup 
	 */
	public QAFWebElement getFooterLnkCurbside(){ return footerLnkCurbside; }

	/**
	 * text view for Ship to Home
	 */
	public QAFWebElement getFooterLnkSth(){ return footerLnkSth; }

	/**
	 * text view for Gift Cards
	 */
	public QAFWebElement getFooterLnkGiftcard(){ return footerLnkGiftcard; }

	/**
	 * text view for Optical By H-E-B
	 */
	public QAFWebElement getFooterLnkOptical(){ return footerLnkOptical; }

	/**
	 * text view for Restaurants & Food to Go 
	 */
	public QAFWebElement getFooterLnkRestaurants(){ return footerLnkRestaurants; }

	/**
	 * text view for Ticket Sales
	 */
	public QAFWebElement getFooterLnkTicketsale(){ return footerLnkTicketsale; }

	/**
	 * text view for Weekly Ad & Coupons
	 */
	public QAFWebElement getFooterLnkWeeklyaddcoupons(){ return footerLnkWeeklyaddcoupons; }

	
	public QAFWebElement getLblfooter() {
		return lblfooter;
	}
	
	public QAFWebElement getFooterLnkGrocerydelivery() {
		return footerLnkGrocerydelivery;
	}

	

}