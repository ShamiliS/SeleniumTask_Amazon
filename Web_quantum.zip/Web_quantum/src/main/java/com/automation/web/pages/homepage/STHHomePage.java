package com.automation.web.pages.homepage;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class STHHomePage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "sthhome.lbl.yourfirstorder")
	private QAFWebElement sthhomeLblYourfirstorder;

	@FindBy(locator = "sthhome.edt.searchbar")
	private QAFWebElement sthhomeEdtSearchbar;

	@FindBy(locator = "sthhome.btn.search")
	private QAFWebElement sthhomeBtnSearch;

	@FindBy(locator = "sthhome.btn.cart")
	private QAFWebElement sthhomeBtnCart;
	
	@FindBy(locator = "sthhome.btn.allstores")
	private QAFWebElement sthhomebtnallstores;
	
	@FindBy(locator = "sthhome.txt.soldonline")
	private QAFWebElement sthhometxtsoldonline;
	
	@FindBy(locator = "sthhome.btn.addtocart")
	private QAFWebElement sthhomebtnaddtocart;

	/**
	 * TextView for Your First Order in Ship to Home page
	 */
	public QAFWebElement getSthhomeLblYourfirstorder(){ return sthhomeLblYourfirstorder; }
	
	/**
	 * Button view of Add To Cart
	 */
	public QAFWebElement getSthHomeBtnAddToCart(){ return sthhomebtnaddtocart; }
	
	/**
	 * TextView for sold online from filter
	 */
	public QAFWebElement getSthHomeTxtSoldOnline(){ return sthhometxtsoldonline; }
	
	/**
	 * Button view of All Stores from filter
	 */
	public QAFWebElement getSthHomeBtnAllStores(){ return sthhomebtnallstores; }

	/**
	 * EditTextView of Search bar
	 */
	public QAFWebElement getSthhomeEdtSearchbar(){ return sthhomeEdtSearchbar; }

	/**
	 * ButtonView of Search
	 */
	public QAFWebElement getSthhomeBtnSearch(){ return sthhomeBtnSearch; }

	/**
	 * ButtonView of Cart
	 */
	public QAFWebElement getSthhomeBtnCart(){ return sthhomeBtnCart; }

}