package com.automation.web.pages.login;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LoginTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "login.lnk.logout")
	private QAFWebElement loginLnkLogout;
	
	@FindBy(locator = "login.lbl.email")
	private QAFWebElement loginLblEmail;

	@FindBy(locator = "login.lbl.password")
	private QAFWebElement loginLblPassword;

	@FindBy(locator = "login.btn.login")
	private QAFWebElement loginBtnLogin;
	
	@FindBy(locator = "login.lbl.error")
	private QAFWebElement loginlblerror;
	
	@FindBy(locator = "login.lnk.forgotpwd")
	private QAFWebElement loginlnkforgotpwd;
	
	@FindBy(locator = "login.edt.emailpwdreset")
	private QAFWebElement loginedtemailpwdreset;
	
	@FindBy(locator = "login.btn.sendemail")
	private QAFWebElement loginbtnsendemail;
	
	@FindBy(locator = "login.lbl.restlinksent")
	private QAFWebElement loginlblrestlinksent;
	
	@FindBy(locator = "login.lnk.createone")
	private QAFWebElement loginlnkcreateone;
	
	/**
	 * Text view of email
	 */
	public QAFWebElement getLoginLblEmail(){ return loginLblEmail; }
	
	public QAFWebElement getLoginLnkLogout(){ return loginLnkLogout; }

	/**
	 * Text view of password
	 */
	public QAFWebElement getLoginLblPassword(){ return loginLblPassword; }

	/**
	 * Button view of Login
	 */
	public QAFWebElement getLoginBtnLogin(){ return loginBtnLogin; }
	
	/**
	 * Text view of Error Message
	 */
	public QAFWebElement getLoginLblError() { return loginlblerror; }
	
	/**
	 * Link view of Forgot Your Password
	 */
	public QAFWebElement getLoginLnkForgotpwd(){ return loginlnkforgotpwd; }
	
	/**
	 * Edit view of email in Password Reset
	 */
	public QAFWebElement getLoginEdtEmailpwdReset(){ return loginedtemailpwdreset; }
	
	/**
	 * Button view for Send Email
	 */
	public QAFWebElement getLoginBtnSendEmail(){ return loginbtnsendemail; }
	
	/**
	 * Text view of Password Reset Confirmation Message
	 */
	public QAFWebElement getLoginLblRestLinkSent(){ return loginlblrestlinksent; }
	
	/**
	 * Link view of create one from login page
	 */
	public QAFWebElement getLoginLnkCreateOne(){ return loginlnkcreateone; }
	
}