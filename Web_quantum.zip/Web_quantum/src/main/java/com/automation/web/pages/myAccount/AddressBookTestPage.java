package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AddressBookTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "addressbook.lbl.addressbookheader")
	private QAFWebElement addressbookLblAddressbookheader;
	@FindBy(locator = "addressbook.list.addresscount")
	private List<QAFWebElement> addressbookListAddressCount;
	@FindBy(locator = "addressbook.lbl.recentaddressnickname")
	private QAFWebElement addressbookLblRecentAddressNickname;
	@FindBy(locator = "addressbook.lbl.addnewaddress")
	private QAFWebElement addressbookLblAddnewaddress;
	@FindBy(locator = "addressbook.lbl.countrybox")
	private QAFWebElement addressbookLblCountrybox;
	@FindBy(locator = "addressbook.txt.nickname")
	private QAFWebElement addressbookTxtNickname;
	@FindBy(locator = "addressbook.txt.firstname")
	private QAFWebElement addressbookTxtFirstname;
	@FindBy(locator = "addressbook.txt.lastname")
	private QAFWebElement addressbookTxtLastname;
	@FindBy(locator = "addressbook.txt.phno1")
	private QAFWebElement addressbookTxtPhno1;
	@FindBy(locator = "addressbook.txt.phno2")
	private QAFWebElement addressbookTxtPhno2;
	@FindBy(locator = "addressbook.txt.phno3")
	private QAFWebElement addressbookTxtPhno3;
	@FindBy(locator = "addressbook.txt.streetaddress")
	private QAFWebElement addressbookTxtStreetaddress;
	@FindBy(locator = "addressbook.txt.city")
	private QAFWebElement addressbookLblCity;
	@FindBy(locator = "addressbook.txt.zipCodeBox1")
	private QAFWebElement addressbookLblZipCodeBox1;
	@FindBy(locator = "addressbook.txt.zipCodeBox2")
	private QAFWebElement addressbookLblZipCodeBox2;
	@FindBy(locator = "addressbook.lbl.state")
	private QAFWebElement addressbookLblState;
	@FindBy(locator = "addressbook.btn.save")
	private QAFWebElement addressbookBtnSave;
	@FindBy(locator = "addressbook.lnk.cancel")
	private QAFWebElement addressbookLnkCancel;
	@FindBy(locator = "addressbook.lbl.savedaddress")
	private QAFWebElement addressbookLblSavedaddress;
	@FindBy(locator = "addressbook.lbl.defaultaddresstitle")
	private QAFWebElement addressbookLblDefaultaddresstitle;
	@FindBy(locator = "addressbook.lnk.edit")
	private QAFWebElement addressbookLnkEdit;
	@FindBy(locator = "addressbook.lnk.remove")
	private QAFWebElement addressbookLnkRemove;
	@FindBy(locator = "addressbook.lbl.savednickname")
	private QAFWebElement addressbookLblSavednickname;
	@FindBy(locator = "addressbook.btn.yes")
	private QAFWebElement addressbookBtnYes;
	@FindBy(locator = "addressbook.btn.no")
	private QAFWebElement addressbookBtnNo;
	@FindBy(locator = "addressbook.lbl.defaultshippingaddressname")
	private QAFWebElement addressbookLbldefaultshippingaddressname;
	
	public QAFWebElement getAddressbookLblheader() {
		return addressbookLblAddressbookheader;
	}
	
	public QAFWebElement getAddressbookLbldefaultshippingaddressname() {
		return addressbookLbldefaultshippingaddressname;
	}
	
	public QAFWebElement getAddressbookBtnYes() {
		return addressbookBtnYes;
	}


	public QAFWebElement getAddressbookBtnNo() {
		return addressbookBtnNo;
	}


	public QAFWebElement getAddressbookLblSavednickname() {
		return addressbookLblSavednickname;
	}


	public QAFWebElement getAddressbookLblSavedaddress() {
		return addressbookLblSavedaddress;
	}


	public QAFWebElement getAddressbookLblDefaultaddresstitle() {
		return addressbookLblDefaultaddresstitle;
	}


	public QAFWebElement getAddressbookLnkEdit() {
		return addressbookLnkEdit;
	}


	public QAFWebElement getAddressbookLnkRemove() {
		return addressbookLnkRemove;
	}


	public QAFWebElement getAddressbookLblAddnewaddress() {
		return addressbookLblAddnewaddress;
	}


	public QAFWebElement getAddressbookLblCountrybox() {
		return addressbookLblCountrybox;
	}


	public QAFWebElement getAddressbookTxtNickname() {
		return addressbookTxtNickname;
	}


	public QAFWebElement getAddressbookTxtFirstname() {
		return addressbookTxtFirstname;
	}


	public QAFWebElement getAddressbookTxtLastname() {
		return addressbookTxtLastname;
	}


	public QAFWebElement getAddressbookTxtPhno1() {
		return addressbookTxtPhno1;
	}


	public QAFWebElement getAddressbookTxtPhno2() {
		return addressbookTxtPhno2;
	}


	public QAFWebElement getAddressbookTxtPhno3() {
		return addressbookTxtPhno3;
	}


	public QAFWebElement getAddressbookTxtStreetaddress() {
		return addressbookTxtStreetaddress;
	}


	public QAFWebElement getAddressbookLblCity() {
		return addressbookLblCity;
	}


	public QAFWebElement getAddressbookLblZipCodeBox1() {
		return addressbookLblZipCodeBox1;
	}


	public QAFWebElement getAddressbookLblZipCodeBox2() {
		return addressbookLblZipCodeBox2;
	}


	public QAFWebElement getAddressbookLblState() {
		return addressbookLblState;
	}


	public QAFWebElement getAddressbookBtnSave() {
		return addressbookBtnSave;
	}


	public QAFWebElement getAddressbookLnkCancel() {
		return addressbookLnkCancel;
	}
	
	public List<QAFWebElement> getAddressbookListAddressCount() {
		return addressbookListAddressCount;
	}
	
	public QAFWebElement getAddressbookLblRecentAddressNickname() {
		return addressbookLblRecentAddressNickname;
	}


}