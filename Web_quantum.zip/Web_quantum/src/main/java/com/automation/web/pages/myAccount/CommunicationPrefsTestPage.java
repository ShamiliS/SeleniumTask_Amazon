package com.automation.web.pages.myAccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CommunicationPrefsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "commpref.txt.commprefheader")
	private QAFWebElement commprefTxtCommprefheader;	
	@FindBy(locator = "commpref.chk.monthlynewsletter")
	private QAFWebElement commprefChkMonthlynewsletter;
	@FindBy(locator = "commpref.chkbox.monthlynewsletter")
	private QAFWebElement commprefChkBoxMonthlynewsletter;
	@FindBy(locator = "commpref.chk.weeklyads")
	private QAFWebElement commprefChkWeeklyads;
	@FindBy(locator = "commpref.btn.save")
	private QAFWebElement commprefBtnSave;
	
	public QAFWebElement getCommprefChkMonthlynewsletter() {
		return commprefChkMonthlynewsletter;
	}


	public QAFWebElement getCommprefChkBoxMonthlynewsletter() {
		return commprefChkBoxMonthlynewsletter;
	}


	public QAFWebElement getCommprefChkWeeklyads() {
		return commprefChkWeeklyads;
	}


	public QAFWebElement getCommprefBtnSave() {
		return commprefBtnSave;
	}


	public QAFWebElement getCommPrefLblCommPrefheader() {
		return commprefTxtCommprefheader;
	}

}