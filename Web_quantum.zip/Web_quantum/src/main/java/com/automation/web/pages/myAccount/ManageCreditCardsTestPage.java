package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ManageCreditCardsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "manageCC.txt.header")
	private QAFWebElement manageCCTxtHeader;

	@FindBy(locator = "managecc.li.lbl.creditcardnamelist")
	private List<QAFWebElement> manageccLiLblCreditcardnamelist;

	@FindBy(locator = "managecc.li.lbl.creditcarddeletelist")
	private List<QAFWebElement> manageccLiLblCreditcarddeletelist;

	@FindBy(locator = "managecc.lbl.creditcarddeletepopuptitle")
	private QAFWebElement manageccLblCreditcarddeletepopuptitle;

	@FindBy(locator = "managecc.btn.creditcarddeletepopupyes")
	private QAFWebElement manageccBtnCreditcarddeletepopupyes;

	@FindBy(locator = "managecc.lbl.mycreditcards")
	private QAFWebElement manageccLblMycreditcards;

	@FindBy(locator = "managecc.btn.addanewcreditcard")
	private QAFWebElement manageccBtnAddanewcreditcard;

	@FindBy(locator = "managecc.lbl.addnewcreditordebitcardheader")
	private QAFWebElement manageccLblAddnewcreditordebitcardheader;

	@FindBy(locator = "managecc.lbl.mypaymentinfo")
	private QAFWebElement manageccLblMypaymentinfo;

	@FindBy(locator = "managecc.btn.addcreditcard")
	private QAFWebElement manageccBtnAddcreditcard;

	@FindBy(locator = "managecc.btn.canceladdingcreditcard")
	private QAFWebElement manageccBtnCanceladdingcreditcard;

	@FindBy(locator = "managecc.lbl.youdonothavecreditcard")
	private QAFWebElement manageccLblYoudonothavecreditcard;
	
	private QAFWebElement manageCCTxtheader;	
	@FindBy(locator = "manageCC.lbl.addnewcardtitle")
	private QAFWebElement manageCCTLblAddnewcardtitle;	
	@FindBy(locator = "manageCC.txt.nameoncard")
	private QAFWebElement manageCCTxtNameoncard;
	@FindBy(locator = "manageCC.drop.cardtype")
	private QAFWebElement manageCCDropCardtype;	
	@FindBy(locator = "manageCC.txt.cardnumber")
	private QAFWebElement manageCCTxtCardnumber;	
	@FindBy(locator = "manageCC.drop.expmonth")
	private QAFWebElement manageCCDropExpmonth;	
	@FindBy(locator = "manageCC.drop.expyear")
	private QAFWebElement manageCCDropExpyear;	
	@FindBy(locator = "manageCC.txt.cvc")
	private QAFWebElement manageCCTxtCvc;	
	@FindBy(locator = "manageCC.txt.billfname")
	private QAFWebElement manageCCTxtBillfname;	
	@FindBy(locator = "manageCC.txt.billlname")
	private QAFWebElement manageCCTxtBilllname;	
	@FindBy(locator = "manageCC.txt.phoneNumber1")
	private QAFWebElement manageCCTxtPhoneNumber1;	
	@FindBy(locator = "manageCC.txt.phoneNumber2")
	private QAFWebElement manageCCTxtPhoneNumber2;	
	@FindBy(locator = "manageCC.txt.phoneNumber3")
	private QAFWebElement manageCCTxtPhoneNumber3;	
	@FindBy(locator = "manageCC.txt.billAddr1")
	private QAFWebElement manageCCTxtBillAddr1;	
	@FindBy(locator = "manageCC.txt.billcity")
	private QAFWebElement manageCCTxtBillcity;	
	@FindBy(locator = "manageCC.txt.billzipcode")
	private QAFWebElement manageCCTxtBillzipcode;	
	@FindBy(locator = "manageCC.txt.billemail")
	private QAFWebElement manageCCTxtBillemail;	
	@FindBy(locator = "manageCC.txt.billconfirmemail")
	private QAFWebElement manageCCTxtBillconfirmemail;	
	@FindBy(locator = "manageCC.btn.addcreditcardsubmit")
	private QAFWebElement manageCCBtnAddcreditcardsubmit;	
	@FindBy(locator = "manageCC.lnk.addcreditcardcancel")
	private QAFWebElement manageCCLnkAddcreditcardcancel;	
	@FindBy(locator = "manageCC.btn.addnewcreditcard")
	private QAFWebElement manageCCBtnAddnewcreditcard;	
	@FindBy(locator = "manageCC.lbl.mycreditcards")
	private QAFWebElement manageCCLblMycreditcards;	
	@FindBy(locator = "manageCC.lbl.defaultCard")
	private QAFWebElement manageCCLblDefaultCard;	
	@FindBy(locator = "manageCC.lbl.deleteContainer")
	private QAFWebElement manageCCLblDeleteContainer;	
	@FindBy(locator = "manageCC.btn.yes")
	private QAFWebElement manageCCBtnYes;	
	@FindBy(locator = "manageCC.lbl.deleteContainer")
	private QAFWebElement manageCCLnkDeleteContainer;
	@FindBy(locator = "manageCC.lnk.cancel")
	private QAFWebElement manageCCLnkCancel;
	@FindBy(locator = "manageCC.lbl.addedbillname")
	private QAFWebElement manageCCLblAddedbillname;
	@FindBy(locator = "manageCC.lnk.deleteCard")
	private QAFWebElement manageCCLnkDeleteCard;
	
	public QAFWebElement getManageCCLnkDeleteCard() {
		return manageCCLnkDeleteCard;
	}


	public QAFWebElement getManageCCLblAddedbillname() {
		return manageCCLblAddedbillname;
	}


	/**
	 * Manage Credit Cards TextView Title
	 */
	public QAFWebElement getManageCCTxtHeader(){ return manageCCTxtHeader; }

	/**
	 * TextView for credit card names
	 */
	public List<QAFWebElement> getManageccLiLblCreditcardnamelist(){ return manageccLiLblCreditcardnamelist; }

	/**
	 * LinkView for card delete link list
	 */
	public List<QAFWebElement> getManageccLiLblCreditcarddeletelist(){ return manageccLiLblCreditcarddeletelist; }

	/**
	 * TextView for delete card pop up title
	 */
	public QAFWebElement getManageccLblCreditcarddeletepopuptitle(){ return manageccLblCreditcarddeletepopuptitle; }

	/**
	 * ButtonView for delete card pop up yes button
	 */
	public QAFWebElement getManageccBtnCreditcarddeletepopupyes(){ return manageccBtnCreditcarddeletepopupyes; }

	/**
	 * TextView for my credit cards section header
	 */
	public QAFWebElement getManageccLblMycreditcards(){ return manageccLblMycreditcards; }

	/**
	 * ButtonView for add a new credit card
	 */
	public QAFWebElement getManageccBtnAddanewcreditcard(){ return manageccBtnAddanewcreditcard; }

	/**
	 * TextView for add a new credit ir debit card page header
	 */
	public QAFWebElement getManageccLblAddnewcreditordebitcardheader(){ return manageccLblAddnewcreditordebitcardheader; }

	/**
	 * TextView for my payment information
	 */
	public QAFWebElement getManageccLblMypaymentinfo(){ return manageccLblMypaymentinfo; }

	/**
	 * ButtonView for add credit card
	 */
	public QAFWebElement getManageccBtnAddcreditcard(){ return manageccBtnAddcreditcard; }

	/**
	 * ButtonView for cancel adding a credit card
	 */
	public QAFWebElement getManageccBtnCanceladdingcreditcard(){ return manageccBtnCanceladdingcreditcard; }

	/**
	 * TextView for you do not have a credit card label
	 */
	public QAFWebElement getManageccLblYoudonothavecreditcard(){ return manageccLblYoudonothavecreditcard; }

	
	public QAFWebElement getManageCCLblMycreditcards() {
		return manageCCLblMycreditcards;
	}


	public QAFWebElement getManageCCLblDefaultCard() {
		return manageCCLblDefaultCard;
	}


	public QAFWebElement getManageCCLblDeleteContainer() {
		return manageCCLblDeleteContainer;
	}


	public QAFWebElement getManageCCBtnYes() {
		return manageCCBtnYes;
	}


	public QAFWebElement getManageCCLnkCancel() {
		return manageCCLnkCancel;
	}


	public QAFWebElement getManageCCTLblAddnewcardtitle() {
		return manageCCTLblAddnewcardtitle;
	}


	public QAFWebElement getManageCCTxtNameoncard() {
		return manageCCTxtNameoncard;
	}


	public QAFWebElement getManageCCDropCardtype() {
		return manageCCDropCardtype;
	}


	public QAFWebElement getManageCCTxtCardnumber() {
		return manageCCTxtCardnumber;
	}


	public QAFWebElement getManageCCDropExpmonth() {
		return manageCCDropExpmonth;
	}


	public QAFWebElement getManageCCDropExpyear() {
		return manageCCDropExpyear;
	}


	public QAFWebElement getManageCCTxtCvc() {
		return manageCCTxtCvc;
	}


	public QAFWebElement getManageCCTxtBillfname() {
		return manageCCTxtBillfname;
	}


	public QAFWebElement getManageCCTxtBilllname() {
		return manageCCTxtBilllname;
	}


	public QAFWebElement getManageCCTxtPhoneNumber1() {
		return manageCCTxtPhoneNumber1;
	}


	public QAFWebElement getManageCCTxtPhoneNumber2() {
		return manageCCTxtPhoneNumber2;
	}


	public QAFWebElement getManageCCTxtPhoneNumber3() {
		return manageCCTxtPhoneNumber3;
	}


	public QAFWebElement getManageCCTxtBillAddr1() {
		return manageCCTxtBillAddr1;
	}


	public QAFWebElement getManageCCTxtBillcity() {
		return manageCCTxtBillcity;
	}


	public QAFWebElement getManageCCTxtBillzipcode() {
		return manageCCTxtBillzipcode;
	}


	public QAFWebElement getManageCCTxtBillemail() {
		return manageCCTxtBillemail;
	}


	public QAFWebElement getManageCCTxtBillconfirmemail() {
		return manageCCTxtBillconfirmemail;
	}


	public QAFWebElement getManageCCBtnAddcreditcardsubmit() {
		return manageCCBtnAddcreditcardsubmit;
	}


	public QAFWebElement getManageCCLnkAddcreditcardcancel() {
		return manageCCLnkAddcreditcardcancel;
	}


	public QAFWebElement getManageCCBtnAddnewcreditcard() {
		return manageCCBtnAddnewcreditcard;
	}


	public QAFWebElement getManageCreditCardsTxtheader() {
		return manageCCTxtheader;
	}

}