package com.automation.web.pages.myAccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ManageSubscriptionTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "manageSubscription.txt.header")
	private QAFWebElement manageSubscriptionTxtHeader;
	@FindBy(locator = "manageSubscription.lnk.editshipaddress")
	private QAFWebElement manageSubscriptionLnkeditshipaddress;	
	@FindBy(locator = "manageSubscription.lbl.newaddressupdate")
	private QAFWebElement manageSubscriptionLblnewaddressupdate;	
	@FindBy(locator = "manageSubscription.radio.newaddressupdate")
	private QAFWebElement manageSubscriptionRadionewaddressupdate;	
	@FindBy(locator = "manageSubscription.link.addressbook")
	private QAFWebElement manageSubscriptionLnkAddressbook;	
	@FindBy(locator = "manageSubscription.link.save")
	private QAFWebElement manageSubscriptionLnkSave;
	@FindBy(locator = "manageSubscription.lbl.shippingaddressname")
	private QAFWebElement manageSubscriptionLblshippingaddressname;	
	@FindBy(locator = "manageSubscription.lbl.cannotremove")
	private QAFWebElement manageSubscriptionLblCannotRemove;
	@FindBy(locator = "manageSubscription.radio.defaultaddress")
	private QAFWebElement manageSubscriptionRadiodefaultaddress;
	@FindBy(locator = "manageSubscription.lnk.removeaddedaddress")
	private QAFWebElement manageSubscriptionLnkremoveaddedaddress;
	@FindBy(locator = "manageSubscription.lnk.yesremoveaddedaddress")
	private QAFWebElement manageSubscriptionLnkyesremoveaddedaddress;
	@FindBy(locator = "manageSubscription.lbl.subscribeditem")
	private QAFWebElement manageSubscriptionLblsubscribeditem;
	@FindBy(locator = "manageSubscription.lnk.editpaymentinfo")
	private QAFWebElement manageSubscriptionLnkeditpaymentinfo;
	@FindBy(locator = "manageSubscription.lnk.managecreditcard")
	private QAFWebElement manageSubscriptionLnkmanagecreditcard;
	@FindBy(locator = "manageSubscription.lnk.addnewcreditcard")
	private QAFWebElement manageSubscriptionLnkAddnewcreditcard;
	@FindBy(locator = "manageSubscription.lbl.addedvisacreditcard")
	private QAFWebElement manageSubscriptionLblAddedvisacreditcard;
	@FindBy(locator = "manageSubscription.radio.newcreditupdate")
	private QAFWebElement manageSubscriptionRadioNewcreditupdate;
	@FindBy(locator = "manageSubscription.link.savecredit")
	private QAFWebElement manageSubscriptionLnksavecredit;
	@FindBy(locator = "manageSubscription.lbl.newcreditupdate")
	private QAFWebElement manageSubscriptionLblnewcreditupdate;
	@FindBy(locator = "manageSubscription.lnk.cannotdeletesubscriptioncard")
	private QAFWebElement manageSubscriptionLnkcannotdeletesubscriptioncard;
	@FindBy(locator = "manageSubscription.radio.defaultcreditupdate")
	private QAFWebElement manageSubscriptionRadiodefaultcreditupdate;
	@FindBy(locator = "manageSubscription.lnk.deletecard")
	private QAFWebElement manageSubscriptionLnkdeletecard;
	@FindBy(locator = "manageSubscription.lnk.yesdeletecard")
	private QAFWebElement manageSubscriptionLnkyesdeletecard;
	
	public QAFWebElement getManageSubscriptionTxtheader() {
		return manageSubscriptionTxtHeader;
	}
	
	public QAFWebElement getManageSubscriptionLnkmanagecreditcard() {
		return manageSubscriptionLnkmanagecreditcard;
	}
	
	public QAFWebElement getManageSubscriptionLnkyesdeletecard() {
		return manageSubscriptionLnkyesdeletecard;
	}
	
	public QAFWebElement getManageSubscriptionRadiodefaultcreditupdate() {
		return manageSubscriptionRadiodefaultcreditupdate;
	}
	
	public QAFWebElement getManageSubscriptionLnkdeletecard() {
		return manageSubscriptionLnkdeletecard;
	}
	
	public QAFWebElement getManageSubscriptionLnkcannotdeletesubscriptioncard() {
		return manageSubscriptionLnkcannotdeletesubscriptioncard;
	}
	
	public QAFWebElement getManageSubscriptionLblnewcreditupdate() {
		return manageSubscriptionLblnewcreditupdate;
	}
	
	public QAFWebElement getManageSubscriptionLnksavecredit() {
		return manageSubscriptionLnksavecredit;
	}
	
	public QAFWebElement getManageSubscriptionRadioNewcreditupdate() {
		return manageSubscriptionRadioNewcreditupdate;
	}
	
	public QAFWebElement getManageSubscriptionLblAddedvisacreditcard() {
		return manageSubscriptionLblAddedvisacreditcard;
	}
	
	public QAFWebElement getManageSubscriptionLnkAddnewcreditcard() {
		return manageSubscriptionLnkAddnewcreditcard;
	}
	
	public QAFWebElement getManageSubscriptionLnkeditpaymentinfo() {
		return manageSubscriptionLnkeditpaymentinfo;
	}
	
	public QAFWebElement getManageSubscriptionLnkeditshipaddress() {
		return manageSubscriptionLnkeditshipaddress;
	}
	
	public QAFWebElement getManageSubscriptionLblnewaddressupdate() {
		return manageSubscriptionLblnewaddressupdate;
	}
	
	public QAFWebElement getManageSubscriptionRadionewaddressupdate() {
		return manageSubscriptionRadionewaddressupdate;
	}
	
	public QAFWebElement getManageSubscriptionLnkAddressbook() {
		return manageSubscriptionLnkAddressbook;
	}
	
	public QAFWebElement getManageSubscriptionLnkSave() {
		return manageSubscriptionLnkSave;
	}
	
	public QAFWebElement getManageSubscriptionLblshippingaddressname() {
		return manageSubscriptionLblshippingaddressname;
	}
	
	public QAFWebElement getManageSubscriptionLblCannotRemove() {
		return manageSubscriptionLblCannotRemove;
	}
	
	public QAFWebElement getManageSubscriptionRadiodefaultaddress() {
		return manageSubscriptionRadiodefaultaddress;
	}
	
	public QAFWebElement getManageSubscriptionLnkremoveaddedaddress() {
		return manageSubscriptionLnkremoveaddedaddress;
	}
	
	public QAFWebElement getManageSubscriptionLnkyesremoveaddedaddress() {
		return manageSubscriptionLnkyesremoveaddedaddress;
	}
	
	public QAFWebElement getManageSubscriptionLblsubscribeditem() {
		return manageSubscriptionLblsubscribeditem;
	}

}