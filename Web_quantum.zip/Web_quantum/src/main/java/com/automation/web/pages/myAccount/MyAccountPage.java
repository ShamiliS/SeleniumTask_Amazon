package com.automation.web.pages.myAccount;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MyAccountPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "myaccount.lnk.username")
	private QAFWebElement myaccountLnkUsername;

	@FindBy(locator = "myaccount.lnk.myaccountusername")
	private QAFWebElement myaccountLnkMyAccountUserName;

	@FindBy(locator = "myaccount.lbl.myaccountheader")
	private QAFWebElement myaccountLblMyAccountHeader;

	@FindBy(locator = "myaccount.lnk.leftmyaccount")
	private QAFWebElement myaccountLnkLeftmyaccount;

	@FindBy(locator = "myaccount.lnk.leftprofileinformation")
	private QAFWebElement myaccountLnkLeftprofileinformation;

	@FindBy(locator = "myaccount.lnk.leftpharmacyprofiles")
	private QAFWebElement myaccountLnkLeftpharmacyprofiles;

	@FindBy(locator = "myaccount.lnk.leftcommunicationprefs")
	private QAFWebElement myaccountLnkLeftcommunicationprefs;

	@FindBy(locator = "myaccount.lbl.leftonlineorders")
	private QAFWebElement myaccountLblLeftonlineorders;

	@FindBy(locator = "myaccount.lnk.leftaddressbook")
	private QAFWebElement myaccountLnkLeftaddressbook;

	@FindBy(locator = "myaccount.lnk.leftorderhistory")
	private QAFWebElement myaccountLnkLeftorderhistory;

	@FindBy(locator = "myaccount.lnk.leftquickreorder")
	private QAFWebElement myaccountLnkLeftquickreorder;

	@FindBy(locator = "myaccount.lnk.leftchangepassword")
	private QAFWebElement myaccountLnkLeftchangepassword;

	@FindBy(locator = "myaccount.lnk.lefttaxexemption")
	private QAFWebElement myaccountLnkLefttaxexemption;

	@FindBy(locator = "myaccount.lnk.leftmanagecreditcards")
	private QAFWebElement myaccountLnkLeftmanagecreditcards;

	@FindBy(locator = "myaccount.lnk.leftmanagesubscriptions")
	private QAFWebElement myaccountLnkLeftmanagesubscriptions;

	@FindBy(locator = "myaccount.lbl.leftsavings")
	private QAFWebElement myaccountLblLeftsavings;

	@FindBy(locator = "myaccount.lnk.leftdigitalcoupons")
	private QAFWebElement myaccountLnkLeftdigitalcoupons;

	@FindBy(locator = "myaccount.lbl.leftfeatures")
	private QAFWebElement myaccountLblLeftfeatures;

	@FindBy(locator = "myaccount.lnk.leftrecipebox")
	private QAFWebElement myaccountLnkLeftrecipebox;

	@FindBy(locator = "myaccount.lnk.leftshoppinglist")
	private QAFWebElement myaccountLnkLeftshoppinglist;

	@FindBy(locator = "myaccount.lbl.informationtab")
	private QAFWebElement myaccountLblInformationtab;

	@FindBy(locator = "myaccount.lbl.onlineorderstab")
	private QAFWebElement myaccountLblOnlineorderstab;

	@FindBy(locator = "myaccount.lbl.mysavingstab")
	private QAFWebElement myaccountLblMysavingstab;

	@FindBy(locator = "myaccount.lbl.featurestab")
	private QAFWebElement myaccountLblFeaturestab;

	@FindBy(locator = "myaccount.lbl.profileinformationsubtitle")
	private QAFWebElement myaccountLblProfileinformationsubtitle;

	@FindBy(locator = "myaccount.lbl.nameemailpwdleftcontainer")
	private QAFWebElement myaccountLblNameemailpwdleftcontainer;

	@FindBy(locator = "myaccount.lbl.myhebleftcontainer")
	private QAFWebElement myaccountLblMyhebleftcontainer;

	@FindBy(locator = "myaccount.lbl.pharmacysubtitle")
	private QAFWebElement myaccountLblPharmacysubtitle;

	@FindBy(locator = "myaccount.lnk.editprofileinfo")
	private QAFWebElement myaccountLnkEditprofileinfo;

	@FindBy(locator = "myaccount.lnk.editcommpref")
	private QAFWebElement myaccountLnkEditcommpref;

	@FindBy(locator = "myaccount.lnk.changepwd")
	private QAFWebElement myaccountLnkChangepwd;

	@FindBy(locator = "myaccount.lnk.createpharmacyprofile")
	private QAFWebElement myaccountLnkCreatepharmacyprofile;

	@FindBy(locator = "myaccount.lbl.addressbooksubtitle")
	private QAFWebElement myaccountLblAddressbooksubtitle;

	@FindBy(locator = "myaccount.lbl.orderhistorysubtitle")
	private QAFWebElement myaccountLblOrderhistorysubtitle;

	@FindBy(locator = "myaccount.lnk.editaddbk")
	private QAFWebElement myaccountLnkEditaddbk;

	@FindBy(locator = "myaccount.lnk.startshoppingnw")
	private QAFWebElement myaccountLnkStartshoppingnw;

	@FindBy(locator = "myaccount.lbl.digitalcouponssubtitle")
	private QAFWebElement myaccountLblDigitalcouponssubtitle;

	@FindBy(locator = "myaccount.lnk.editmobpref")
	private QAFWebElement myaccountLnkEditmobpref;

	@FindBy(locator = "myaccount.lnk.seecurrentcoupons")
	private QAFWebElement myaccountLnkSeecurrentcoupons;

	@FindBy(locator = "myaccount.lbl.shoppinglistsubtitle")
	private QAFWebElement myaccountLblShoppinglistsubtitle;

	@FindBy(locator = "myaccount.lbl.recipeboxsubtitle")
	private QAFWebElement myaccountLblRecipeboxsubtitle;

	@FindBy(locator = "myaccount.lnk.managemylist")
	private QAFWebElement myaccountLnkManagemylist;

	@FindBy(locator = "myaccount.lnk.gotorecipebox")
	private QAFWebElement myaccountLnkGotorecipebox;

	@FindBy(locator = "myaccount.lbl.shoplist")
	private QAFWebElement myaccountLblShoplist;

	@FindBy(locator = "myaccount.lbl.myaacountbreadcrumblast")
	private QAFWebElement myaccountLblMyaacountbreadcrumblast;

	@FindBy(locator = "myaccount.lnk.change")
	private QAFWebElement myaccountLnkChange;

	@FindBy(locator = "myaccount.lbl.mypreferredstore")
	private QAFWebElement myaccountLblMypreferredstore;

	@FindBy(locator = "myaccount.lnk.orderstatus")
	private QAFWebElement myaccountLnkOrderstatus;

	@FindBy(locator = "myaccount.lnk.myrecipebox")
	private QAFWebElement myaccountLnkMyrecipebox;

	@FindBy(locator = "myaccount.lnk.mycoupons")
	private QAFWebElement myaccountLnkMycoupons;

	@FindBy(locator = "myaccount.lnk.pharmacyprofile")
	private QAFWebElement myaccountLnkPharmacyprofile;

	@FindBy(locator = "myaccount.lnk.logout")
	private QAFWebElement myaccountLnkLogout;
	
	/**
	 * Textview for LogIn Link
	 */
	public QAFWebElement getMyAccountLnkUserName() {
		return myaccountLnkUsername;
	}

	/**
	 * TextView for user logged in
	 */
	public QAFWebElement getMyAccountLnkMyAccountUserName() {
		return myaccountLnkMyAccountUserName;
	}

	/**
	 * TextView for food n drinks
	 */
	public QAFWebElement getMyAccountLblMyAccountHeader() {
		return myaccountLblMyAccountHeader;
	}

	/**
	 * TextView for home and kitchen
	 */
	public QAFWebElement getMyAccountLnkChange() {
		return myaccountLnkChange;
	}

	/**
	 * TextView for Megamenu bar
	 */
	public QAFWebElement getMyAccountLblMypreferredstore() {
		return myaccountLblMypreferredstore;
	}
	

	public QAFWebElement getMyAccountLnkOrderstatus() {
		return myaccountLnkOrderstatus;
	}

	/**
	 * TextView for Megamenu title
	 */
	public QAFWebElement getMyAccountLnkMyrecipebox() {
		return myaccountLnkMyrecipebox;
	}

	/**
	 * ListView for submenu for food and drinks
	 */
	public QAFWebElement getMyAccountLnkMycoupons() {
		return myaccountLnkMycoupons;
	}

	/**
	 * ImageView for Right arrow
	 */
	public QAFWebElement getMyAccountLnkPharmacyprofile() {
		return myaccountLnkPharmacyprofile;
	}

	/**
	 * ImageView for Left arrow
	 */
	public QAFWebElement getMyAccountLnkLogout() {
		return myaccountLnkLogout;
	}

	/**
	 * ImageView for all corusels display
	 */
	public QAFWebElement getMyAccountLblInformationtab() {
		return myaccountLblInformationtab;
	}

	/**
	 * ListView for home and kitchen
	 */
	public QAFWebElement getMyAccountLblOnlineorderstab() {
		return myaccountLblOnlineorderstab;
	}

	/**
	 * ListView for baby and toy
	 */
	public QAFWebElement getMyAccountLblMysavingstab() {
		return myaccountLblMysavingstab;
	}

	/**
	 * ListView for health and beauty
	 */
	public QAFWebElement getMyAccountLblFeaturestab() {
		return myaccountLblFeaturestab;
	}

	/**
	 * ListView for activities and toy
	 */
	public QAFWebElement getMyAccountLblProfileinformationsubtitle() {
		return myaccountLblProfileinformationsubtitle;
	}

	/**
	 * ListView for office and school
	 */
	public QAFWebElement getMyAccountLblNameemailpwdleftcontainer() {
		return myaccountLblNameemailpwdleftcontainer;
	}

	/**
	 * ListView for flowers
	 */
	public QAFWebElement getMyAccountLblMyhebleftcontainer() {
		return myaccountLblMyhebleftcontainer;
	}

	/**
	 * ListView for more
	 */
	public QAFWebElement getMyAccountLblPharmacysubtitle() {
		return myaccountLblPharmacysubtitle;
	}

	/**
	 * ListView for pet
	 */
	public QAFWebElement getMyAccountLnkEditprofileinfo() {
		return myaccountLnkEditprofileinfo;
	}

	/**
	 * TextView for Pharmacy
	 */
	public QAFWebElement getMyAccountLnkEditcommpref() {
		return myaccountLnkEditcommpref;
	}

	/**
	 * TextView for Weekly Ad & Coupons
	 */
	public QAFWebElement getMyAccountLnkChangepwd() {
		return myaccountLnkChangepwd;
	}

	/**
	 * TextView for Weekly Ad & Coupons
	 */
	public QAFWebElement getMyAccountLnkCreatepharmacyprofile() {
		return myaccountLnkCreatepharmacyprofile;
	}

	/**
	 * TextView for My Store
	 */
	public QAFWebElement getMyAccountLblAddressbooksubtitle() {
		return myaccountLblAddressbooksubtitle;
	}

	/**
	 * TextView for My Account
	 */
	public QAFWebElement getMyAccountLblOrderhistorysubtitle() {
		return myaccountLblOrderhistorysubtitle;
	}

	/**
	 * TextView for Gift Card
	 */
	public QAFWebElement getMyAccountLnkEditaddbk() {
		return myaccountLnkEditaddbk;
	}

	/**
	 * TextView for More option
	 */
	public QAFWebElement getMyAccountLnkStartshoppingnw() {
		return myaccountLnkStartshoppingnw;
	}

	/**
	 * TextView for order status
	 */
	public QAFWebElement getMyAccountLblDigitalcouponssubtitle() {
		return myaccountLblDigitalcouponssubtitle;
	}

	/**
	 * TextView for weekly ad and coupons page
	 */
	public QAFWebElement getMyAccountLnkEditmobpref() {
		return myaccountLnkEditmobpref;
	}

	/**
	 * TextView for Digital Coupons from home page
	 */
	public QAFWebElement getMyAccountLnkSeecurrentcoupons() {
		return myaccountLnkSeecurrentcoupons;
	}

	/**
	 * TextView for shopping list page
	 */
	public QAFWebElement getMyAccountLblShoppinglistsubtitle() {
		return myaccountLblShoppinglistsubtitle;
	}

	/**
	 * ImageView for Mini Cart logo
	 */
	public QAFWebElement getMyAccountLblRecipeboxsubtitle() {
		return myaccountLblRecipeboxsubtitle;
	}

	/**
	 * TextView for Online corusels text
	 */
	public QAFWebElement getMyAccountLnkManagemylist() {
		return myaccountLnkManagemylist;
	}

	/**
	 * ImageView for Right Arrow Online Corusuels orders
	 */
	public QAFWebElement getMyAccountLnkGotorecipebox() {
		return myaccountLnkGotorecipebox;
	}

	/**
	 * TextView for Order Online title
	 */
	public QAFWebElement getMyAccountLblShoplist() {
		return myaccountLblShoplist;
	}

	/**
	 * ButtonView for Select
	 */
	public QAFWebElement getMyAccountLblMyaacountbreadcrumblast() {
		return myaccountLblMyaacountbreadcrumblast;
	}

	/**
	 * TextView for Digital coupons
	 */
	public QAFWebElement getMyAccountLnkLeftmyaccount() {
		return myaccountLnkLeftmyaccount;
	}

	/**
	 * TextView for Watch video in digital coupons
	 */
	public QAFWebElement getMyAccountLnkLeftprofileinformation() {
		return myaccountLnkLeftprofileinformation;
	}

	/**
	 * LinkView for Load More Receipe
	 */
	public QAFWebElement getMyAccountLnkLeftpharmacyprofiles() {
		return myaccountLnkLeftpharmacyprofiles;
	}

	/**
	 * ListView for receipe name
	 */
	public QAFWebElement getMyAccountLnkLeftcommunicationprefs() {
		return myaccountLnkLeftcommunicationprefs;
	}

	/**
	 * Textview for UserName
	 */
	public QAFWebElement getMyAccountLblLeftonlineorders() {
		return myaccountLblLeftonlineorders;
	}

	/**
	 * Editview for searchText
	 */
	public QAFWebElement getMyAccountLnkLeftaddressbook() {
		return myaccountLnkLeftaddressbook;
	}

	/**
	 * Imageview for Search Button
	 */
	public QAFWebElement getMyAccountLnkLeftorderhistory() {
		return myaccountLnkLeftorderhistory;
	}

	/**
	 * Textview for Register Link
	 */
	public QAFWebElement getMyAccountLnkLeftquickreorder() {
		return myaccountLnkLeftquickreorder;
	}

	/**
	 * ButtonView for Cart
	 */
	public QAFWebElement getMyAccountLnkLeftchangepassword() {
		return myaccountLnkLeftchangepassword;
	}

	/**
	 * ButtonView for Start Shopping under Cart
	 */
	public QAFWebElement getMyAccountLnkLefttaxexemption() {
		return myaccountLnkLefttaxexemption;
	}

	/**
	 * TextView for Cart Item
	 */
	public QAFWebElement getMyAccountLnkLeftmanagecreditcards() {
		return myaccountLnkLeftmanagecreditcards;
	}

	/**
	 * ButtonView for View Cart under Cart
	 */
	public QAFWebElement getMyAccountLnkLeftmanagesubscriptions() {
		return myaccountLnkLeftmanagesubscriptions;
	}

	/**
	 * LinkTextView for BreadCrumb Shop
	 */
	public QAFWebElement getMyAccountLblLeftsavings() {
		return myaccountLblLeftsavings;
	}

	/**
	 * TextView for StoreName
	 */
	public QAFWebElement getMyAccountLnkLeftdigitalcoupons() {
		return myaccountLnkLeftdigitalcoupons;
	}

	/**
	 * H-E-B logo
	 */
	public QAFWebElement getMyAccountLblLeftfeatures() {
		return myaccountLblLeftfeatures;
	}

	/**
	 * TextView for shoppinglist from page hedaer
	 */
	public QAFWebElement getMyAccountLnkLeftrecipebox() {
		return myaccountLnkLeftrecipebox;
	}

	/**
	 * LinkView for create account from shopping list mouse over
	 */
	public QAFWebElement getMyAccountLnkLeftshoppinglist() {
		return myaccountLnkLeftshoppinglist;
	}
	
}