package com.automation.web.pages.myAccount;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class QuickReorderTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}
	@FindBy(locator = "quickReorder.txt.quickReorderheader")
	private QAFWebElement quickReorderTxtQuickReorderheader;
	
	@FindBy(locator = "quickReorder.lbl.productname")
	private QAFWebElement lblProductName;
	
	@FindBy(locator = "quickReorder.lbl.addtocart")
	private QAFWebElement lblAddtocart;
	
	public QAFWebElement getQuickReoderTxtheader() {
		return quickReorderTxtQuickReorderheader;
	}
	
	public QAFWebElement getLblProductName() {
		return lblProductName;
	}
	
	public QAFWebElement getLblAddtocart() {
		return lblAddtocart;
	}
	
	public QAFWebElement getQuickreorderlblPrice(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.price"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblSize(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.size"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblBorder(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.border"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblTopborder(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.topborder"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblColor(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.color"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblIcing(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.icing"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblFilling(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.filling"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblFlavor(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.flavor"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getQuickreorderlblMessage(String linktext) {
		String loc = String.format(pageProps.getString("quickreorder.get.lbl.message"), linktext);
		return new QAFExtendedWebElement(loc);
	}

}