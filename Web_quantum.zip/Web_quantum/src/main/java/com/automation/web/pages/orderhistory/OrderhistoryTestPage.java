package com.automation.web.pages.orderhistory;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OrderhistoryTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "odrhistory.btn.addtocart")
	private QAFWebElement odrhistoryBtnAddtocart;

	@FindBy(locator = "odrhistory.lnk.viewcart")
	private QAFWebElement odrhistoryLnkViewcart;

	@FindBy(locator = "odrhistory.btn.checkout")
	private QAFWebElement odrhistoryBtnCheckout;

	@FindBy(locator = "odrhistory.lnk.orderstatus")
	private QAFWebElement odrhistoryLnkOrderstatus;

	@FindBy(locator = "odrhistory.txt.orderstatus")
	private QAFWebElement odrhistoryTxtOrderstatus;

	@FindBy(locator = "odrhistory.tbx.ordernumber")
	private QAFWebElement odrhistoryTbxOrdernumber;

	@FindBy(locator = "odrhistory.tbx.emailaddress")
	private QAFWebElement odrhistoryTbxEmailaddress;

	@FindBy(locator = "odrhistory.btn.submit")
	private QAFWebElement odrhistoryBtnSubmit;

	@FindBy(locator = "odrhistory.grd.orderdetails")
	private QAFWebElement odrhistoryGrdOrderdetails;

	@FindBy(locator = "odrhistory.lnk.username")
	private QAFWebElement odrhistoryLnkUsername;

	@FindBy(locator = "odrhistory.txt.myaccount")
	private QAFWebElement odrhistoryTxtMyaccount;

	@FindBy(locator = "odrhistory.lnk.orderhistory")
	private QAFWebElement odrhistoryLnkOrderhistory;

	@FindBy(locator = "odrhistory.txt.orderhistory")
	private QAFWebElement odrhistoryTxtOrderhistory;

	@FindBy(locator = "odrhistory.grd.myorders")
	private QAFWebElement odrhistoryGrdMyorders;

	@FindBy(locator = "odrhistory.btn.viewdetails")
	private QAFWebElement odrhistoryBtnViewdetails;

	@FindBy(locator = "odrhistory.lnk.myorderstatus")
	private QAFWebElement odrhistoryLnkMyorderstatus;

	@FindBy(locator = "odrhistory.btn.cancelproducts")
	private QAFWebElement odrhistoryBtnCancelproducts;

	@FindBy(locator = "odrhistory.txt.cancelorderpopup")
	private QAFWebElement odrhistoryTxtCancelorderpopup;

	@FindBy(locator = "odrhistory.btn.yescancelorder")
	private QAFWebElement odrhistoryBtnYescancelorder;

	@FindBy(locator = "odrhistory.btn.hidedetails")
	private QAFWebElement odrhistoryBtnHidedetails;

	@FindBy(locator = "odrhistory.txt.cancelrequested")
	private QAFWebElement odrhistoryTxtCancelrequested;

	@FindBy(locator = "odrhistory.list.orders")
	private QAFWebElement odrhistoryListOrders;

	@FindBy(locator = "odrhistory.lbl.ordnumdynamic")
	private QAFWebElement odrhistoryLblOrdnumdynamic;

	@FindBy(locator = "odrhistory.lbl.orderdate")
	private QAFWebElement odrhistoryLblOrderdate;

	@FindBy(locator = "odrhistory.lbl.orderno")
	private QAFWebElement odrhistoryLblOrderno;

	@FindBy(locator = "odrhistory.lbl.ordertotal")
	private QAFWebElement odrhistoryLblOrdertotal;

	@FindBy(locator = "odrhistory.lbl.orderstatussummary")
	private QAFWebElement odrhistoryLblOrderstatussummary;

	@FindBy(locator = "odrhistory.lnk.viewdetailssummary")
	private QAFWebElement odrhistoryLnkViewdetailssummary;

	@FindBy(locator = "odrhistory.lbl.sectiontitle")
	private QAFWebElement odrhistoryLblSectiontitle;

	@FindBy(locator = "odrhistory.lbl.ordertotaldetails")
	private QAFWebElement odrhistoryLblOrdertotaldetails;

	@FindBy(locator = "odrhistory.btn.delicancel")
	private QAFWebElement odrhistoryBtnDelicancel;

	@FindBy(locator = "odrhistory.btn.addtocartorderhsty")
	private QAFWebElement odrhistoryBtnAddtocartorderhsty;

	@FindBy(locator = "odrhistory.list.orderhistory")
	private QAFWebElement odrhistoryListOrderhistory;

	@FindBy(locator = "odrhistory.lbl.cartdrpdwn")
	private QAFWebElement odrhistoryLblCartdrpdwn;

	@FindBy(locator = "odrhistory.lnk.itemname1")
	private QAFWebElement odrhistoryLnkItemname1;

	@FindBy(locator = "odrhistory.btn.reorderallitems")
	private QAFWebElement odrhistoryBtnReorderallitems;

	@FindBy(locator = "odrhistory.lbl.errormodal")
	private QAFWebElement odrhistoryLblErrormodal;

	@FindBy(locator = "odrhistory.lnk.viewdetailswithaddtocart")
	private List<QAFWebElement> lnkViewdetailswithaddtocart;

	@FindBy(locator = "odrhistory.btn.addtocartinsideviewdetails")
	private List<QAFWebElement> btnAddtocartinsideviewdetails;
	
	@FindBy(locator = "odrhistory.lnk.remove")
	private List<QAFWebElement> lnkRemove;

	@FindBy(locator = "odrhistory.lbl.yesrmvprodalert")
	private QAFWebElement lblYesrmvprodalert;
	
	
	/**
	 * Button for Add to Cart
	 */
	public QAFWebElement getOdrhistoryBtnAddtocart() {
		return odrhistoryBtnAddtocart;
	}

	/**
	 * LinkText for View Cart
	 */
	public QAFWebElement getOdrhistoryLnkViewcart() {
		return odrhistoryLnkViewcart;
	}

	/**
	 * Button for Checkout
	 */
	public QAFWebElement getOdrhistoryBtnCheckout() {
		return odrhistoryBtnCheckout;
	}

	/**
	 * LinkText for Order Status
	 */
	public QAFWebElement getOdrhistoryLnkOrderstatus() {
		return odrhistoryLnkOrderstatus;
	}

	/**
	 * TextView for Order Status
	 */
	public QAFWebElement getOdrhistoryTxtOrderstatus() {
		return odrhistoryTxtOrderstatus;
	}

	/**
	 * TextBox for Order Number
	 */
	public QAFWebElement getOdrhistoryTbxOrdernumber() {
		return odrhistoryTbxOrdernumber;
	}

	/**
	 * TextBox for Email Address
	 */
	public QAFWebElement getOdrhistoryTbxEmailaddress() {
		return odrhistoryTbxEmailaddress;
	}

	/**
	 * Button for Submit
	 */
	public QAFWebElement getOdrhistoryBtnSubmit() {
		return odrhistoryBtnSubmit;
	}

	/**
	 * GridView for Order Details
	 */
	public QAFWebElement getOdrhistoryGrdOrderdetails() {
		return odrhistoryGrdOrderdetails;
	}

	/**
	 * LinkText for User Name
	 */
	public QAFWebElement getOdrhistoryLnkUsername() {
		return odrhistoryLnkUsername;
	}

	/**
	 * TextView for My Account
	 */
	public QAFWebElement getOdrhistoryTxtMyaccount() {
		return odrhistoryTxtMyaccount;
	}

	/**
	 * LinkText for Order History
	 */
	public QAFWebElement getOdrhistoryLnkOrderhistory() {
		return odrhistoryLnkOrderhistory;
	}

	/**
	 * TextView for Order History
	 */
	public QAFWebElement getOdrhistoryTxtOrderhistory() {
		return odrhistoryTxtOrderhistory;
	}

	/**
	 * GridView for My Orders
	 */
	public QAFWebElement getOdrhistoryGrdMyorders() {
		return odrhistoryGrdMyorders;
	}

	/**
	 * Button for View Details
	 */
	public QAFWebElement getOdrhistoryBtnViewdetails() {
		return odrhistoryBtnViewdetails;
	}

	/**
	 * LinkText for Order Status
	 */
	public QAFWebElement getOdrhistoryLnkMyorderstatus() {
		return odrhistoryLnkMyorderstatus;
	}

	/**
	 * Button for Cancel Products
	 */
	public QAFWebElement getOdrhistoryBtnCancelproducts() {
		return odrhistoryBtnCancelproducts;
	}

	/**
	 * TextView for Cancel Order Pop Up
	 */
	public QAFWebElement getOdrhistoryTxtCancelorderpopup() {
		return odrhistoryTxtCancelorderpopup;
	}

	/**
	 * Button for Yes in Cancel Order
	 */
	public QAFWebElement getOdrhistoryBtnYescancelorder() {
		return odrhistoryBtnYescancelorder;
	}

	/**
	 * Button for Hide Details
	 */
	public QAFWebElement getOdrhistoryBtnHidedetails() {
		return odrhistoryBtnHidedetails;
	}

	/**
	 * TextView for Cancel Requested
	 */
	public QAFWebElement getOdrhistoryTxtCancelrequested() {
		return odrhistoryTxtCancelrequested;
	}

	/**
	 * ListView for all orders
	 */
	public QAFWebElement getOdrhistoryListOrders() {
		return odrhistoryListOrders;
	}

	/**
	 * TextView for dynamic order number
	 */
	public QAFWebElement getOdrhistoryLblOrdnumdynamic() {
		return odrhistoryLblOrdnumdynamic;
	}

	/**
	 * TextView for order date
	 */
	public QAFWebElement getOdrhistoryLblOrderdate() {
		return odrhistoryLblOrderdate;
	}

	/**
	 * TextView for order number
	 */
	public QAFWebElement getOdrhistoryLblOrderno() {
		return odrhistoryLblOrderno;
	}

	/**
	 * TextView for order total
	 */
	public QAFWebElement getOdrhistoryLblOrdertotal() {
		return odrhistoryLblOrdertotal;
	}

	/**
	 * TextView for order status
	 */
	public QAFWebElement getOdrhistoryLblOrderstatussummary() {
		return odrhistoryLblOrderstatussummary;
	}

	/**
	 * LinkView for View details
	 */
	public QAFWebElement getOdrhistoryLnkViewdetailssummary() {
		return odrhistoryLnkViewdetailssummary;
	}

	/**
	 * TextView for order title section
	 */
	public QAFWebElement getOdrhistoryLblSectiontitle() {
		return odrhistoryLblSectiontitle;
	}

	/**
	 * TextView for order total in details section
	 */
	public QAFWebElement getOdrhistoryLblOrdertotaldetails() {
		return odrhistoryLblOrdertotaldetails;
	}

	/**
	 * ButtonView for cancel deli
	 */
	public QAFWebElement getOdrhistoryBtnDelicancel() {
		return odrhistoryBtnDelicancel;
	}

	/**
	 * ButtonView for add to cart
	 */
	public QAFWebElement getOdrhistoryBtnAddtocartorderhsty() {
		return odrhistoryBtnAddtocartorderhsty;
	}

	/**
	 * ListView for order history
	 */
	public QAFWebElement getOdrhistoryListOrderhistory() {
		return odrhistoryListOrderhistory;
	}

	/**
	 * TextView for cart drop down
	 */
	public QAFWebElement getOdrhistoryLblCartdrpdwn() {
		return odrhistoryLblCartdrpdwn;
	}

	/**
	 * LinkView for item name
	 */
	public QAFWebElement getOdrhistoryLnkItemname1() {
		return odrhistoryLnkItemname1;
	}

	/**
	 * ButtonView for reorder all items
	 */
	public QAFWebElement getOdrhistoryBtnReorderallitems() {
		return odrhistoryBtnReorderallitems;
	}

	/**
	 * TextView for error modal
	 */
	public QAFWebElement getOdrhistoryLblErrormodal() {
		return odrhistoryLblErrormodal;
	}

	public QAFExtendedWebElement getViewDetails(int item) {
		String retElm = String.format(pageProps.getString("orderhistory.get.lnk.viewdetails"), item);
		return new QAFExtendedWebElement(retElm);
	}

	public List<QAFWebElement> getLnkViewdetailswithaddtocart() {
		return lnkViewdetailswithaddtocart;
	}

	public List<QAFWebElement> getBtnAddtocartinsideviewdetails() {
		return btnAddtocartinsideviewdetails;
	}
	
	public List<QAFWebElement> getLnkRemove() {
		return lnkRemove;
	}
	
	public QAFWebElement getLblYesrmvprodalert() {
		return lblYesrmvprodalert;
	}
}
