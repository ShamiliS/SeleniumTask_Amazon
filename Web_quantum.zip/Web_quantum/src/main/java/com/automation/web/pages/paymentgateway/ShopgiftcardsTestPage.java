package com.automation.web.pages.paymentgateway;

import java.util.List;

import com.automation.web.components.GiftCardComponents;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShopgiftcardsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "shopgc.lbl.pageheader")
	private QAFWebElement shopgcLblPageheader;
	@FindBy(locator = "shopgc.lbl.maintext")
	private QAFWebElement shopgcLblMaintext;
	@FindBy(locator = "shopgc.img.giftcardimageslist")
	private List<QAFWebElement> shopgcImgGiftcardimageslist;
	@FindBy(locator = "shopgc.lbl.quantitylist")
	private List<QAFWebElement> shopgcLblQuantitylist;
	@FindBy(locator = "shopgc.txt.quantitydropdownlist")
	private List<QAFWebElement> shopgcTxtQuantitydropdownlist;
	@FindBy(locator = "shopgc.lbl.amount")
	private List<QAFWebElement> shopgcLblAmount;
	@FindBy(locator = "shopgc.txt.amountdropdown")
	private List<QAFWebElement> shopgcTxtAmountdropdown;
	@FindBy(locator = "shopgc.lbl.amountdropdownvalues")
	private List<QAFWebElement> shopgcLblAmountdropdownvalues;
	@FindBy(locator = "shopgc.btn.addtocart")
	private List<QAFWebElement> shopgcBtnAddtocart;

	@FindBy(locator = "shopgc.list.giftcarditems")
	private List<GiftCardComponents> listGiftcarditems;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPageheader() {
		return shopgcLblPageheader;
	}

	public QAFWebElement getLblMaintext() {
		return shopgcLblMaintext;
	}

	public List<QAFWebElement> getImgGiftcardimageslist() {
		return shopgcImgGiftcardimageslist;
	}

	public List<QAFWebElement> getLblQuantitylist() {
		return shopgcLblQuantitylist;
	}

	public List<QAFWebElement> getTxtQuantitydropdownlist() {
		return shopgcTxtQuantitydropdownlist;
	}

	public List<QAFWebElement> getLblAmount() {
		return shopgcLblAmount;
	}

	public List<QAFWebElement> getTxtAmountdropdown() {
		return shopgcTxtAmountdropdown;
	}

	public List<QAFWebElement> getLblAmountdropdownvalues() {
		return shopgcLblAmountdropdownvalues;
	}

	public List<QAFWebElement> getBtnAddtocart() {
		return shopgcBtnAddtocart;
	}

	public List<GiftCardComponents> getListGiftcarditems() {
		return listGiftcarditems;
	}

}
