package com.automation.web.pages.pharmacy;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PatienInformationTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "pi.txt.firstname")
	private QAFWebElement txtFirstname;
	@FindBy(locator = "pi.txt.lastname")
	private QAFWebElement txtLastname;
	@FindBy(locator = "pi.txt.address1")
	private QAFWebElement txtAddress1;
	@FindBy(locator = "pi.txt.city")
	private QAFWebElement txtCity;
	@FindBy(locator = "pi.txt.dobmonth")
	private QAFWebElement txtDobmonth;
	@FindBy(locator = "pi.txt.dobdate")
	private QAFWebElement txtDobdate;
	@FindBy(locator = "pi.txt.dobyear")
	private QAFWebElement txtDobyear;
	@FindBy(locator = "pi.txt.phonenumber1")
	private QAFWebElement txtPhonenumber1;
	@FindBy(locator = "pi.txt.phonenumber2")
	private QAFWebElement txtPhonenumber2;
	@FindBy(locator = "pi.txt.phonenumber3")
	private QAFWebElement txtPhonenumber3;
	@FindBy(locator = "pi.btn.continue")
	private QAFWebElement btnContinue;

	public QAFWebElement getTxtFirstname() {
		return txtFirstname;
	}

	public QAFWebElement getTxtLastname() {
		return txtLastname;
	}

	public QAFWebElement getTxtAddress1() {
		return txtAddress1;
	}

	public QAFWebElement getTxtCity() {
		return txtCity;
	}

	public QAFWebElement getTxtDobmonth() {
		return txtDobmonth;
	}

	public QAFWebElement getTxtDobdate() {
		return txtDobdate;
	}

	public QAFWebElement getTxtDobyear() {
		return txtDobyear;
	}

	public QAFWebElement getTxtPhonenumber1() {
		return txtPhonenumber1;
	}

	public QAFWebElement getTxtPhonenumber2() {
		return txtPhonenumber2;
	}

	public QAFWebElement getTxtPhonenumber3() {
		return txtPhonenumber3;
	}

	public QAFWebElement getBtnContinue() {
		return btnContinue;
	}

}