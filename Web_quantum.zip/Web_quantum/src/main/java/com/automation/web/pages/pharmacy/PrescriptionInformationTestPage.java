package com.automation.web.pages.pharmacy;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PrescriptionInformationTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "presinfo.txt.pharmacyname")
	private QAFWebElement txtPharmacyname;

	@FindBy(locator = "presinfo.txt.phonePart1")
	private QAFWebElement txtPhonePart1;

	@FindBy(locator = "presinfo.txt.phonePart2")
	private QAFWebElement txtPhonePart2;

	@FindBy(locator = "presinfo.txt.phonePart3")
	private QAFWebElement txtPhonePart3;

	@FindBy(locator = "presinfo.txt.drugname")
	private QAFWebElement txtDrugname;

	@FindBy(locator = "presinfo.txt.prescriptionnumber")
	private QAFWebElement txtPrescriptionnumber;

	@FindBy(locator = "presinfo.btn.continue")
	private QAFWebElement btnContinue;

	public QAFWebElement getTxtPharmacyname() {
		return txtPharmacyname;
	}

	public QAFWebElement getTxtPhonePart1() {
		return txtPhonePart1;
	}

	public QAFWebElement getTxtPhonePart2() {
		return txtPhonePart2;
	}

	public QAFWebElement getTxtPhonePart3() {
		return txtPhonePart3;
	}

	public QAFWebElement getTxtDrugname() {
		return txtDrugname;
	}

	public QAFWebElement getTxtPrescriptionnumber() {
		return txtPrescriptionnumber;
	}

	public QAFWebElement getBtnContinue() {
		return btnContinue;
	}

}