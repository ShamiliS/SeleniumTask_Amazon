package com.automation.web.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ArtifycakedetailaTestPage
		extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "artifycake.lbl.sheetsize")
	private QAFWebElement lblSheetsize;
	@FindBy(locator = "artifycake.lbl.sheetsizecurrent")
	private QAFWebElement lblSheetsizecurrent;
	@FindBy(locator = "artifycake.btn.sheetsizecurrent")
	private QAFWebElement btnSheetsizecurrent;
	@FindBy(locator = "artifycake.list.choicestitle")
	private List<QAFWebElement> listChoicestitle;
	@FindBy(locator = "artifycake.list.firstchoice")
	private List<QAFWebElement> listFirstchoice;
	@FindBy(locator = "artifycake.list.secondchoice")
	private List<QAFWebElement> listSecondchoice;
	@FindBy(locator = "artifycake.list.thirdchoice")
	private List<QAFWebElement> listThirdchoice;
	@FindBy(locator = "artifycake.list.fourthchoice")
	private List<QAFWebElement> listFourthchoice;
	@FindBy(locator = "artifycake.list.fifthchoice")
	private List<QAFWebElement> listFifthchoice;
	@FindBy(locator = "artifycake.list.sixthchoice")
	private List<QAFWebElement> listSixthchoice;
	@FindBy(locator = "artifycake.lbl.cardmsgtitle")
	private QAFWebElement lblCardmsgtitle;
	@FindBy(locator = "artifycake.lbl.cardmsg")
	private QAFWebElement lblCardmsg;
	@FindBy(locator = "artifycake.img.cake")
	private QAFWebElement imgCake;
	@FindBy(locator = "artifycake.img.cakebackground")
	private QAFWebElement imgCakebackground;
	@FindBy(locator = "artifycake.list.seventhchoice")
	private List<QAFWebElement> listSeventhchoice;
	@FindBy(locator = "artifycake.btn.updatetext")
	private QAFWebElement btnUpdatetext;
	@FindBy(locator = "artifycake.li.btn.sheetsize")
	private List<QAFWebElement> artifycakeLiBtnSheetsize;
	@FindBy(locator = "artifycake.lbl.price")
	private QAFWebElement artifycakeLblPrice;
	@FindBy(locator = "artifycake.parent.frame")
	private QAFWebElement artifycakeParentFrame;
	
	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblSheetsize() {
		return lblSheetsize;
	}

	public QAFWebElement getLblSheetsizecurrent() {
		return lblSheetsizecurrent;
	}

	public QAFWebElement getBtnSheetsizecurrent() {
		return btnSheetsizecurrent;
	}

	public List<QAFWebElement> getListChoicestitle() {
		return listChoicestitle;
	}

	public List<QAFWebElement> getListFirstchoice() {
		return listFirstchoice;
	}

	public List<QAFWebElement> getListSecondchoice() {
		return listSecondchoice;
	}

	public List<QAFWebElement> getListThirdchoice() {
		return listThirdchoice;
	}

	public List<QAFWebElement> getListFourthchoice() {
		return listFourthchoice;
	}

	public List<QAFWebElement> getListFifthchoice() {
		return listFifthchoice;
	}

	public List<QAFWebElement> getListSixthchoice() {
		return listSixthchoice;
	}

	public QAFWebElement getLblCardmsgtitle() {
		return lblCardmsgtitle;
	}

	public QAFWebElement getLblCardmsg() {
		return lblCardmsg;
	}
	
	public QAFWebElement getImgCake() {
		return imgCake;
	}
	
	public QAFWebElement getImgCakebackground() {
		return imgCakebackground;
	}
	
	public List<QAFWebElement> getListSeventhchoice() {
		return listSeventhchoice;
	}
	
	public QAFWebElement getBtnUpdatetext() {
		return btnUpdatetext;
	}
	
	public List<QAFWebElement> getArtifycakeLiBtnSheetsize() {
		return artifycakeLiBtnSheetsize;
	}
	
	public QAFWebElement getArtifycakeLblPrice() {
		return artifycakeLblPrice;
	}
	
	public QAFWebElement getArtifycakeParentFrame() {
		return artifycakeParentFrame;
	}

}
