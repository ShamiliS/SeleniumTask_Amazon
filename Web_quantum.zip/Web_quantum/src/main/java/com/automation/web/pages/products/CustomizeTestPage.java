package com.automation.web.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CustomizeTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "customize.lbl.selectdelivery")
	private QAFWebElement customizeLblSelectdelivery;
	@FindBy(locator = "customize.btn.delivery")
	private QAFWebElement customizeBtnDelivery;
	@FindBy(locator = "customize.btn.storepickup")
	private QAFWebElement customizeBtnStorepickup;
	@FindBy(locator = "customize.txt.zipcode")
	private QAFWebElement customizeTxtZipcode;
	@FindBy(locator = "customize.btn.zipcodego")
	private QAFWebElement customizeBtnZipcodego;
	@FindBy(locator = "customize.lbl.deliverydatetitle")
	private QAFWebElement customizeLblDeliverydatetitle;
	@FindBy(locator = "customize.lbl.deliverydate")
	private QAFWebElement customizeLblDeliverydate;
	@FindBy(locator = "customize.btn.deliverydatecalender")
	private QAFWebElement customizeBtnDeliverydatecalender;
	@FindBy(locator = "customize.lbl.bqtquality")
	private QAFWebElement customizeLblBqtquality;
	@FindBy(locator = "customize.lbl.bqtqualityoption")
	private QAFWebElement customizeLblBqtqualityoption;
	@FindBy(locator = "cutomize.img.bqtqualitypicker")
	private QAFWebElement cutomizeImgBqtqualitypicker;
	@FindBy(locator = "customize.lbl.primarycolor")
	private QAFWebElement customizeLblPrimarycolor;
	@FindBy(locator = "customize.lbl.primarycoloroptions")
	private List<QAFWebElement> customizeLblPrimarycoloroptions;
	@FindBy(locator = "customize.lbl.message")
	private QAFWebElement customizeLblMessage;
	@FindBy(locator = "customize.txt.message")
	private QAFWebElement customizeTxtMessage;
	@FindBy(locator = "customize.btn.calenderdatepicker")
	private List<QAFWebElement> customizeBtnCalenderdatepicker;
	@FindBy(locator = "customize.lbl.secondarycoloroptions")
	private List<QAFWebElement> customizeLblSecondarycoloroptions;

	@FindBy(locator = "customcake.lbl.shoppingfordelivery")
	private QAFWebElement lblShoppingfordelivery;
	@FindBy(locator = "customize.txt.pricelabel")
	private QAFWebElement TxtPriceLabel;
	@FindBy(locator = "customize.btn.addtocart")
	private QAFWebElement btnAddtocart;
	
	@FindBy(locator = "customize.lnk.findotherstores")
	private QAFWebElement lnkFindotherstores;
	@FindBy(locator = "customize.txt.findotherstoreszip")
	private QAFWebElement txtFindotherstoresZip;
	@FindBy(locator = "customize.btn.findotherstoresgo")
	private QAFWebElement btnFindotherstoresGo;
	@FindBy(locator = "customize.btn.findotherstoreszipselect")
	private List<QAFWebElement> btnFindotherstoresZipSelect;
	@FindBy(locator = "customize.li.lbl.calenderdates")
	private List<QAFWebElement> liLblCalenderdates;
	@FindBy(locator = "customize.lbl.calendermonth")
	private QAFWebElement lblCalendermonth;
	@FindBy(locator = "customize.lbl.calenderyear")
	private QAFWebElement lblCalenderyear;

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public QAFWebElement getCustomizeLblSelectdelivery() {
		return customizeLblSelectdelivery;
	}

	public QAFWebElement getCustomizeBtnDelivery() {
		return customizeBtnDelivery;
	}

	public QAFWebElement getCustomizeBtnStorepickup() {
		return customizeBtnStorepickup;
	}

	public QAFWebElement getCustomizeTxtZipcode() {
		return customizeTxtZipcode;
	}

	public QAFWebElement getCustomizeBtnZipcodego() {
		return customizeBtnZipcodego;
	}

	public QAFWebElement getCustomizeLblDeliverydatetitle() {
		return customizeLblDeliverydatetitle;
	}

	public QAFWebElement getCustomizeLblDeliverydate() {
		return customizeLblDeliverydate;
	}

	public QAFWebElement getCustomizeBtnDeliverydatecalender() {
		return customizeBtnDeliverydatecalender;
	}

	public QAFWebElement getCustomizeLblBqtquality() {
		return customizeLblBqtquality;
	}

	public QAFWebElement getCustomizeLblBqtqualityoption() {
		return customizeLblBqtqualityoption;
	}

	public QAFWebElement getCutomizeImgBqtqualitypicker() {
		return cutomizeImgBqtqualitypicker;
	}

	public QAFWebElement getCustomizeLblPrimarycolor() {
		return customizeLblPrimarycolor;
	}

	public List<QAFWebElement> getCustomizeLblPrimarycoloroptions() {
		return customizeLblPrimarycoloroptions;
	}

	public QAFWebElement getCustomizeLblMessage() {
		return customizeLblMessage;
	}

	public QAFWebElement getCustomizeTxtMessage() {
		return customizeTxtMessage;
	}

	public List<QAFWebElement> getCustomizeBtnCalenderdatepicker() {
		return customizeBtnCalenderdatepicker;
	}

	public List<QAFWebElement> getCustomizeLblSecondarycoloroptions() {
		return customizeLblSecondarycoloroptions;
	}

	public QAFWebElement getLblShoppingfordelivery() {
		return lblShoppingfordelivery;
	}

	public QAFWebElement getTxtPriceLabel() {
		return TxtPriceLabel;
	}

	public QAFWebElement getBtnAddtocart() {
		return btnAddtocart;
	}
	
	public QAFWebElement getLblStoreNamefromFindotherstores(String item) {
		String reElm = String.format(pageProps.getString("customize.get.lbl.findotherstoreszipselectstorename"), item);
		return new QAFExtendedWebElement(reElm);
	}
	
	public List<QAFWebElement> getCustomizeBtnFindotherstoresZipSelect() {
		return btnFindotherstoresZipSelect;
	}
	
	public QAFWebElement getLnkFindotherstores() {
		return lnkFindotherstores;
	}
	
	public QAFWebElement getTxtFindotherstoresZip() {
		return txtFindotherstoresZip;
	}
	
	public QAFWebElement getBtnFindotherstoresGo() {
		return btnFindotherstoresGo;
	}
	
	public List<QAFWebElement> getLiLblCalenderdates() {
		return liLblCalenderdates;
	}
	
	public QAFWebElement getLblCalendermonth() {
		return lblCalendermonth;
	}
	
	public QAFWebElement getLblCalenderyear() {
		return lblCalenderyear;
	}
	
}
