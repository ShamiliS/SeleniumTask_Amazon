package com.automation.web.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CustomizebakeryTestPage
		extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "customcake.lbl.sheetsize")
	private QAFWebElement customcakeLblSheetsize;
	@FindBy(locator = "customcake.lbl.sheetsizecurrent")
	private QAFWebElement customcakeLblSheetsizecurrent;
	@FindBy(locator = "customcake.btn.sheetsizecurrent")
	private QAFWebElement customcakeBtnSheetsizecurrent;
	@FindBy(locator = "customcake.list.choicestitle")
	private List<QAFWebElement> customcakeListChoicestitle;
	@FindBy(locator = "customcake.list.firstchoice")
	private List<QAFWebElement> customcakeListFirstchoice;
	@FindBy(locator = "customcake.list.secondchoice")
	private List<QAFWebElement> customcakeListSecondchoice;
	@FindBy(locator = "customcake.list.thirdchoice")
	private List<QAFWebElement> customcakeListThirdchoice;
	@FindBy(locator = "customcake.list.fourthchoice")
	private List<QAFWebElement> customcakeListFourthchoice;
	@FindBy(locator = "customcake.list.fifthchoice")
	private List<QAFWebElement> customcakeListFifthchoice;
	@FindBy(locator = "customcake.list.sixthchoice")
	private List<QAFWebElement> customcakeListSixthchoice;
	@FindBy(locator = "customcake.lbl.cardmsgtitle")
	private QAFWebElement customcakeLblCardmsgtitle;
	@FindBy(locator = "customcake.lbl.cardmsg")
	private QAFWebElement customcakeLblCardmsg;
	@FindBy(locator = "customcake.list.seventhchoice")
	private List<QAFWebElement> customcakeListSeventhchoice;
	@FindBy(locator = "customcake.list.sheetsize")
	private List<QAFWebElement> customcakeListSheetsize;
	
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getCustomcakeLblSheetsize() {
		return customcakeLblSheetsize;
	}

	public QAFWebElement getCustomcakeLblSheetsizecurrent() {
		return customcakeLblSheetsizecurrent;
	}

	public QAFWebElement getCustomcakeBtnSheetsizecurrent() {
		return customcakeBtnSheetsizecurrent;
	}

	public List<QAFWebElement> getCustomcakeListChoicestitle() {
		return customcakeListChoicestitle;
	}

	public List<QAFWebElement> getCustomcakeListFirstchoice() {
		return customcakeListFirstchoice;
	}

	public List<QAFWebElement> getCustomcakeListSecondchoice() {
		return customcakeListSecondchoice;
	}

	public List<QAFWebElement> getCustomcakeListThirdchoice() {
		return customcakeListThirdchoice;
	}

	public List<QAFWebElement> getCustomcakeListFourthchoice() {
		return customcakeListFourthchoice;
	}

	public List<QAFWebElement> getCustomcakeListFifthchoice() {
		return customcakeListFifthchoice;
	}

	public List<QAFWebElement> getCustomcakeListSixthchoice() {
		return customcakeListSixthchoice;
	}

	public QAFWebElement getCustomcakeLblCardmsgtitle() {
		return customcakeLblCardmsgtitle;
	}

	public QAFWebElement getCustomcakeLblCardmsg() {
		return customcakeLblCardmsg;
	}
	
	public List<QAFWebElement> getCustomcakeListSeventhchoice() {
		return customcakeListSeventhchoice;
	}

	public List<QAFWebElement> getCustomcakeListSheetsize() {
		return customcakeListSheetsize;
	}
}
