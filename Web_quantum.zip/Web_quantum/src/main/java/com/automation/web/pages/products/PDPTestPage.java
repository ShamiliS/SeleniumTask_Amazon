package com.automation.web.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PDPTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "pdp.lbl.productname")
	private QAFWebElement pdpLblProductname;

	@FindBy(locator = "pdp.lbl.productprice")
	private QAFWebElement pdpLblProductprice;

	@FindBy(locator = "pdp.lbl.name")
	private QAFWebElement pdpLblName;

	@FindBy(locator = "pdp.btn.addtocart")
	private QAFWebElement pdpBtnAddtocart;

	@FindBy(locator = "pdp.lbl.productdesc")
	private QAFWebElement pdpLblProductdesc;

	@FindBy(locator = "pdp.edt.quantity")
	private QAFWebElement pdpEdtQuantity;

	@FindBy(locator = "pdp.lbl.minquantity")
	private QAFWebElement pdpLblMinquantity;

	@FindBy(locator = "pdp.list.featureicons")
	private List<QAFWebElement> pdpListFeatureicons;

	@FindBy(locator = "pdp.lbl.socialblock")
	private QAFWebElement lblsocialblock;

	@FindBy(locator = "pdp.lbl.addtolist")
	private QAFWebElement lbladdtolist;

	@FindBy(locator = "pdp.lbl.print")
	private QAFWebElement lblprint;

	@FindBy(locator = "pdp.lbl.email")
	private QAFWebElement lblemail;

	@FindBy(locator = "pdp.lbl.nutritionfact")
	private QAFWebElement lblnutritionfact;

	@FindBy(locator = "pdp.lbl.rating ")
	private QAFWebElement lblrating;

	@FindBy(locator = "pdp.lbl.recentlyviewed")
	private QAFWebElement lblrecentlyviewed;

	@FindBy(locator = "pdp.lbl.wrtreview")
	private QAFWebElement lblwrtreview;

	@FindBy(locator = "pdp.lbl.whatuthink")
	private QAFWebElement lblwhatuthink;

	@FindBy(locator = "pdp.lbl.whatdoesthismean")
	private QAFWebElement lblwhatdoesthismean;

	@FindBy(locator = "pdp.lbl.nutrionaltag")
	private List<QAFWebElement> lblnutrionaltag;

	@FindBy(locator = "pdp.lbl.moqerror")
	private QAFWebElement lblmoqerror;

	@FindBy(locator = "pdp.lbl.emailtofriend")
	private QAFWebElement lblEmailtoFriend;

	@FindBy(locator = "pdp.lbl.recipientemails")
	private QAFWebElement lblRecipientEmails;

	@FindBy(locator = "pdp.lbl.yourname")
	private QAFWebElement LblYourName;

	@FindBy(locator = "pdp.lbl.youremail")
	private QAFWebElement LblYourEmail;

	@FindBy(locator = "pdp.lbl.recaptcha")
	private QAFWebElement LblRecaptcha;

	@FindBy(locator = "pdp.btn.sendemail")
	private QAFWebElement BtnSendEmail;

	@FindBy(locator = "pdp.btn.cancel")
	private QAFWebElement BtnCancel;

	@FindBy(locator = "pdp.dpd.expandropdown")
	private QAFWebElement pdpdpdexpandropdown;

	@FindBy(locator = "pdp.lnk.mylist")
	private QAFWebElement pdplnkmylist;

	@FindBy(locator = "pdp.lbl.itemnamefromdefaultlist")
	private QAFWebElement pdplblitemnamefromdefaultlist;

	@FindBy(locator = "pdp.lnk.closelink")
	private QAFWebElement pdplnkcloselink;

	@FindBy(locator = "pdp.lbl.itemsinyourlist")
	private QAFWebElement pdplblitemsinyourlist;

	@FindBy(locator = "pdp.lbl.estimatedshipdate")
	private QAFWebElement lblEstimatedshipdate;
	
	@FindBy(locator = "pdp.lbl.estimatedshipdateformat")
	private QAFWebElement lblEstimatedshipdateFormat;

	@FindBy(locator = "pdp.btn.editbutton")
	private QAFWebElement pdpbtneditbutton;

	@FindBy(locator = "pdp.lbl.editlistnametextbox")
	private QAFWebElement pdplbleditlistnametextbox;

	@FindBy(locator = "pdp.btn.editsave")
	private QAFWebElement pdpbtneditsave;

	@FindBy(locator = "pdp.lbl.editlistname")
	private QAFWebElement pdplbleditlistname;

	@FindBy(locator = "pdp.lbl.errormsg")
	private QAFWebElement pdpLblErrormsg;
	
	@FindBy(locator = "pdp.txt.minimumqtyerror")
	private QAFWebElement pdptxtminimumqtyerror;
	
	@FindBy(locator = "pdp.lbl.errorblock")
	private QAFWebElement pdplblerrorblock;
	
	/**
	 * TextView of product name
	 */
	public QAFWebElement getPdpLblProductname() {
		return pdpLblProductname;
	}

	@FindBy(locator = "pdp.lbl.marketingbug")
	private List<QAFWebElement> lblmarketingbug;

	@FindBy(locator = "pdp.lbl.reviewmenu")
	private QAFWebElement lblreviewmenu;

	@FindBy(locator = "pdp.lbl.reviewtitle")
	private QAFWebElement lblreviewtitle;

	@FindBy(locator = "pdp.lbl.reviewcomment")
	private QAFWebElement lblreviewcomment;

	@FindBy(locator = "pdp.lbl.reviewstars")
	private QAFWebElement lblreviewstars;

	@FindBy(locator = "pdp.lbl.star4")
	private QAFWebElement lblstar4;

	@FindBy(locator = "pdp.btn.submit")
	private QAFWebElement btnsubmit;

	@FindBy(locator = "pdp.lbl.reviewerror")
	private QAFWebElement lblreviewerror;
	
	@FindBy(locator = "pdp.rgb.subscription")
	private QAFWebElement rgbSubscription;

	@FindBy(locator = "pdp.img.digitalcoupons")
	private QAFWebElement imgDigitalcoupons;
	@FindBy(locator = "pdp.lbl.digitalcouponsname")
	private QAFWebElement lblDigitalcouponsname;
	@FindBy(locator = "pdp.btn.selectcoupons")
	private QAFWebElement btnSelectcoupons;

	public QAFWebElement getLblEmailtoFriend() {
		return lblEmailtoFriend;
	}
	
	public QAFWebElement geTxtMinimumQtyError() {
		return pdptxtminimumqtyerror;
	}
	
	public QAFWebElement getLblErrorBlock() {
		return pdplblerrorblock;
	}

	public QAFWebElement getLblRecipientEmails() {
		return lblRecipientEmails;
	}

	public QAFWebElement getPdpdpdexpandropdown() {
		return pdpdpdexpandropdown;
	}

	public QAFWebElement getPdplnkmylist() {
		return pdplnkmylist;
	}

	public QAFWebElement getPdplblitemnamefromdefaultlist() {
		return pdplblitemnamefromdefaultlist;
	}

	public QAFWebElement getPdplnkcloselink() {
		return pdplnkcloselink;
	}

	public QAFWebElement getPdplblitemsinyourlist() {
		return pdplblitemsinyourlist;
	}

	public QAFWebElement getPdpbtneditbutton() {
		return pdpbtneditbutton;
	}

	public QAFWebElement getPdplbleditlistnametextbox() {
		return pdplbleditlistnametextbox;
	}

	public QAFWebElement getPdpbtneditsave() {
		return pdpbtneditsave;
	}

	public QAFWebElement getPdplbleditlistname() {
		return pdplbleditlistname;
	}

	public QAFWebElement getImgDigitalcoupons() {
		return imgDigitalcoupons;
	}

	public QAFWebElement getLblDigitalcouponsname() {
		return lblDigitalcouponsname;
	}

	public QAFWebElement getBtnSelectcoupons() {
		return btnSelectcoupons;
	}

	/**
	 * TextView of product price
	 */
	public QAFWebElement getPdpLblProductprice() {
		return pdpLblProductprice;
	}

	/**
	 * TextView of product name
	 */
	public QAFWebElement getPdpLblName() {
		return pdpLblName;
	}

	/**
	 * ButtonView of Add to Cart
	 */
	public QAFWebElement getPdpBtnAddtocart() {
		return pdpBtnAddtocart;
	}

	/**
	 * TextView of Product description
	 */
	public QAFWebElement getPdpLblProductdesc() {
		return pdpLblProductdesc;
	}

	/**
	 * EditTextView of Quantity
	 */
	public QAFWebElement getPdpEdtQuantity() {
		return pdpEdtQuantity;
	}

	/**
	 * TextView of Minimum Quantity
	 */
	public QAFWebElement getPdpLblMinquantity() {
		return pdpLblMinquantity;
	}

	public List<QAFWebElement> getPdpListFeatureicons() {
		return pdpListFeatureicons;
	}

	public QAFWebElement getLblprint() {
		return lblprint;
	}

	public QAFWebElement getLblsocialblock() {
		return lblsocialblock;
	}

	public QAFWebElement getLbladdtolist() {
		return lbladdtolist;
	}

	public QAFWebElement getLblemail() {
		return lblemail;
	}

	public QAFWebElement getLblnutritionfact() {
		return lblnutritionfact;
	}

	public QAFWebElement getLblrating() {
		return lblrating;
	}

	public QAFWebElement getLblrecentlyviewed() {
		return lblrecentlyviewed;
	}

	public QAFWebElement getLblwrtreview() {
		return lblwrtreview;
	}

	public QAFWebElement getLblwhatuthink() {
		return lblwhatuthink;
	}

	public QAFWebElement getLblwhatdoesthismean() {
		return lblwhatdoesthismean;
	}

	public List<QAFWebElement> getLblnutrionaltag() {
		return lblnutrionaltag;
	}

	public QAFWebElement getLblmoqerror() {
		return lblmoqerror;
	}

	public QAFWebElement getlblEmailtoFriend() {
		return lblEmailtoFriend;
	}

	public QAFWebElement getlblRecipientEmails() {
		return lblRecipientEmails;
	}

	public QAFWebElement getLblYourName() {
		return LblYourName;
	}

	public QAFWebElement getLblYourEmail() {
		return LblYourEmail;
	}

	public QAFWebElement getLblRecaptcha() {
		return LblRecaptcha;
	}

	public QAFWebElement getBtnSendEmail() {
		return BtnSendEmail;
	}

	public QAFWebElement getBtnCancel() {
		return BtnCancel;
	}

	/**
	 * Drop down view of Add to Shopping List Expand Icon
	 */
	public QAFWebElement getPdpDpdExpanDropdown() {
		return pdpdpdexpandropdown;
	}

	/**
	 * Link view of My List under Add to shopping List
	 */
	public QAFWebElement getPdpLnkMyList() {
		return pdplnkmylist;
	}

	/**
	 * Text view of item description from default list
	 */
	public QAFWebElement getPdpLblItemNameFromDefaultList() {
		return pdplblitemnamefromdefaultlist;
	}

	/**
	 * Link view of close from default list
	 */
	public QAFWebElement getPdpLnkCloseLink() {
		return pdplnkcloselink;
	}

	/**
	 * Text view of items in your list
	 */
	public QAFWebElement getPdpLblItemsInYourList() {
		return pdplblitemsinyourlist;
	}

	public QAFWebElement getLblEstimatedshipdate() {
		return lblEstimatedshipdate;
	}
	
	public QAFWebElement getLblEstimatedshipdateFormat() {
		return lblEstimatedshipdateFormat;
	}

	/**
	 * Button View for Edit
	 */
	public QAFWebElement getPdpBtnEditButton() {
		return pdpbtneditbutton;
	}

	/**
	 * Edit View for List name Edit Text Box
	 */
	public QAFWebElement getPdpLblEditListNameTextBox() {
		return pdplbleditlistnametextbox;
	}

	/**
	 * Button View for Edit Save Button
	 */
	public QAFWebElement getPdpBtnEditSave() {
		return pdpbtneditsave;
	}

	/**
	 * TextView of Edited List Name
	 */
	public QAFWebElement getPdpLblEditListName() {
		return pdplbleditlistname;
	}

	public QAFWebElement getPdpLblErrormsg() {
		return pdpLblErrormsg;
	}

	public List<QAFWebElement> getLblmarketingbug() {
		return lblmarketingbug;
	}

	public QAFWebElement getLblreviewmenu() {
		return lblreviewmenu;
	}

	public QAFWebElement getLblreviewtitle() {
		return lblreviewtitle;
	}

	public QAFWebElement getLblreviewcomment() {
		return lblreviewcomment;
	}

	public QAFWebElement getLblreviewstars() {
		return lblreviewstars;
	}

	public QAFWebElement getLblstar4() {
		return lblstar4;
	}

	public QAFWebElement getBtnsubmit() {
		return btnsubmit;
	}

	public QAFWebElement getLblreviewerror() {
		return lblreviewerror;
	}
	
	public QAFWebElement getRgbSubscription() {
		return rgbSubscription;
	}
}