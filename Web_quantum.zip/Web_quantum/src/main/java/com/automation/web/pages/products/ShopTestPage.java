package com.automation.web.pages.products;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ShopTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	public QAFWebElement getGetCdpcategories(String category) {
		String loc = String.format(pageProps.getString("shop.get.cdpcategories"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getFirstCategory(String category) {
		String loc = String.format(pageProps.getString("shop.get.firstcategories"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getSubCategory(String category){
		String loc = String.format(pageProps.getString("shoppage.list.subcategory"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getFirstCategoryImg(String category) {
		String loc = String.format(pageProps.getString("shop.get.firstcategoriesImg"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	@FindBy(locator = "shop.lbl.shopbytype")
	private QAFWebElement LblShopbyType;
	
	@FindBy(locator = "shop.lbl.departments")
	private List<QAFWebElement> shopLblDepartments;
	
	@FindBy(locator = "shop.img.subcategory")
	private List<QAFWebElement> shopImgSubcategory;
	
	@FindBy(locator = "shopage.lbl.sellercorusel")
	private List<QAFWebElement> LblSellercorusel;
	
	@FindBy(locator = "shoppage.list.subcategory")
	private List<QAFWebElement> ListSubcategory;
	
	@FindBy(locator = "shoppage.list.subcategoryproductname")
	private List<QAFWebElement> ListSubcategoryproductname;
	
	public QAFWebElement getLblShopbyType(){ return LblShopbyType; }
	
	public List<QAFWebElement> getshopLblDepartments() {
		return shopLblDepartments;
	}
	
	@FindBy(locator = "shoppage.lbl.ourbrands")
	private QAFWebElement LblOurBrands;
	
	@FindBy(locator = "shopage.lbl.primopicks")
	private QAFWebElement LblPrimoPicks;
	
	@FindBy(locator = "shop.lbl.brandnprimopick")
	private QAFWebElement shopLblBrandnPrimoPick;
	
	@FindBy(locator = "shop.lbl.header")
	private QAFWebElement shopLblHeader;
		
	public List<QAFWebElement> getshopImgSubcategory() {
		return shopImgSubcategory;
	}
	public QAFWebElement getMainCategory(String category) {
		String loc = String.format(pageProps.getString("shop.get.cdpmaincategory"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblFlower(String category) {
		String loc = String.format(pageProps.getString("shop.lbl.flower"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getLblRoses(String category) {
		String loc = String.format(pageProps.getString("shop.lbl.roses"), category);
		return new QAFExtendedWebElement(loc);
	}
	
	public List<QAFWebElement> getLblSellercorusel() {
		return LblSellercorusel;
	}
	
	public QAFWebElement getLblOurBrands() {
		return LblOurBrands;
	}
	
	public QAFWebElement getLblPrimoPicks() {
		return LblPrimoPicks;
	}
	
	public List<QAFWebElement> getListSubcategory() {
		return ListSubcategory;
	}
	
	public List<QAFWebElement> getListSubcategoryproductname() {
		return ListSubcategoryproductname;
	}
	
	public QAFWebElement getShopLblBrandnPrimoPick() {
		return shopLblBrandnPrimoPick;
	}
	
	public QAFWebElement getShopLblHeader() {
		return shopLblHeader;
	}
	
}