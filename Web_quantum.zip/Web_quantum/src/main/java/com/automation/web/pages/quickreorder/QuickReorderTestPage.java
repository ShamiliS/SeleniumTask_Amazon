package com.automation.web.pages.quickreorder;

import java.util.List;

import com.automation.web.components.QuickReorderProducts;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class QuickReorderTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "quickreorder.btn.cart")
	private QAFWebElement quickreorderBtnCart;
	
	@FindBy(locator = "quickreorder.btn.addtocart")
	private QAFWebElement btnaddtocart;
	
	@FindBy(locator = "quickreorder.lbl.productname")
	private QAFWebElement lblProductName;
	
	@FindBy(locator = "quickreorder.lbl.addtocart")
	private QAFWebElement lblAddtocart;
	
	@FindBy(locator = "quickreorder.box.product")
	private List<QuickReorderProducts> quickreorderBoxProduct;
	
	@FindBy(locator = "quickreorder.txt.quantitybox")
	private QuickReorderProducts quickreorderQuantity;
	
	@FindBy(locator = "quickreorder.lbl.sth")
	private QuickReorderProducts quickreorderSTH;
	
	@FindBy(locator = "quickreorder.lbl.cake")
	private QuickReorderProducts quickreorderCake;
	
	@FindBy(locator = "quickreorder.lbl.pgc")
	private QuickReorderProducts quickreorderPGC;
	
	@FindBy(locator = "quickreorder.lbl.itemqty")
	private QuickReorderProducts quickreorderItemqty;
	
	/**
	 * Button for Add to Cart
	 */
	public QAFWebElement getQuickreorderBtnCart() {
		return quickreorderBtnCart;
	}

	/**
	 * AddtoCart icon in PGC
	 */
	public QAFWebElement getBtnaddtocart() {
		return btnaddtocart;
	}
	
	public QAFWebElement getLblProductName() {
		return lblProductName;
	}
	
	public QAFWebElement getLblAddtocart() {
		return lblAddtocart;
	}
	
	public QAFWebElement getTxtQuantity() {
		return quickreorderQuantity;
	}
	
	public QAFWebElement getLblSTH() {
		return quickreorderSTH;
	}
	
	public QAFWebElement getLblCake() {
		return quickreorderCake;
	}
	
	public QAFWebElement getLblPGC() {
		return quickreorderPGC;
	}
	
	public QAFWebElement getLblItemqty() {
		return quickreorderItemqty;
	}
	
	public List<QuickReorderProducts> getQuickreorderBoxProduct() {
		return quickreorderBoxProduct;
	}

}