package com.automation.web.pages.recipes;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class CookingVideodetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "cv.icon.video")
	private QAFWebElement iconVideo;
	
	@FindBy(locator = "cv.lbl.cvreciperating")
	private QAFWebElement lblRecipeRating;
	
	@FindBy(locator = "cv.lnk.cvrecipeaddtolist")
	private QAFWebElement lnkRecipeAddtoList;
	
	@FindBy(locator = "cv.lnk.cvrecipeaddtorecipebox")
	private QAFWebElement lnkRecipeAddtoRecipeBox;
	
	@FindBy(locator = "cv.lbl.cvmorevideos")
	private QAFWebElement lblMoreVideos;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getIconVideo() {
		return iconVideo;
	}
	
	public QAFWebElement getLblRecipeRating() {
		return lblRecipeRating;
	}
	
	public QAFWebElement getLnkRecipeAddtoList() {
		return lnkRecipeAddtoList;
	}
	
	public QAFWebElement getLnkRecipeAddtoRecipeBox() {
		return lnkRecipeAddtoRecipeBox;
	}
	
	public QAFWebElement getLblMoreVideos() {
		return lblMoreVideos;
	}
	
	public QAFWebElement getCookingconnectionVideoHeader(String linktext) {
		String loc = String.format(pageProps.getString("cv.get.lbl.connectionvideoheader"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCookingconnectionVideoRecipeImage(String linktext) {
		String loc = String.format(pageProps.getString("cv.get.img.cvrecipeimage"), linktext);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getCookingconnectionVideoRecipeTitle(String linktext) {
		String loc = String.format(pageProps.getString("cv.get.lbl.cvrecipetitle"), linktext);
		return new QAFExtendedWebElement(loc);
	}

}
