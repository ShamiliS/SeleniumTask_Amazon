package com.automation.web.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipeBoxTestpage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "recipeBox.lbl.header")
	private QAFWebElement recipeboxLblHeader;

	@FindBy(locator = "recipeBox.lbl.recipename")
	private QAFWebElement recipeBoxLblRecipeName;

	@FindBy(locator = "recipeBox.lbl.recipeitemslist")
	private List<QAFWebElement> recipeBoxLblRecipeItemsList;

	@FindBy(locator = "recipeBox.lbl.recipenameslist")
	private List<QAFWebElement> recipeBoxLblRecipeNamesList;
	
	@FindBy(locator = "recipeBox.lbl.moreoptionslist")
	private List<QAFWebElement> recipeBoxLblMoreOptionsList;
	
	@FindBy(locator = "recipeBox.lbl.deleterecipelist")
	private List<QAFWebElement> recipeBoxLblDeleteRecipeList;
	
	
	/**
	 * Textview of Recipe Box header
	 */
	public QAFWebElement getRecipeBoxLblHeader() {
		return recipeboxLblHeader;
	}

	public QAFWebElement getRecipeBoxLblRecipeName() {
		return recipeBoxLblRecipeName;
	}

	public List<QAFWebElement> getRecipeBoxLblRecipeItemsList() {
		return recipeBoxLblRecipeItemsList;
	}
	
	public List<QAFWebElement> getRecipeBoxLblRecipeNamesList() {
		return recipeBoxLblRecipeNamesList;
	}
	
	public List<QAFWebElement> getRecipeBoxLblMoreOptionsList() {
		return recipeBoxLblMoreOptionsList;
	}
	
	public List<QAFWebElement> getRecipeBoxLblDeleteRecipeList() {
		return recipeBoxLblDeleteRecipeList;
	}
}