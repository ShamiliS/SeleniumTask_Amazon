package com.automation.web.pages.recipes;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RecipelandingTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "recipes.lbl.recipename")
	private QAFWebElement recipeLblRecipename;
	@FindBy(locator = "recipes.lnk.recipename")
	private QAFWebElement recipeLnkRecipename;
	@FindBy(locator = "recipes.link.recipebox")
	private QAFWebElement recipeLinkRecipebox;
	@FindBy(locator = "recipes.lbl.pagetitle")
	private QAFWebElement recipeLblPagetitle;
	@FindBy(locator = "recipes.link.recipeoftheday")
	private QAFWebElement recipeLinkRecipeoftheday;
	@FindBy(locator = "recipes.link.viewall")
	private QAFWebElement recipeLinkViewall;
	@FindBy(locator = "recipes.img.recentlyviewed")
	private QAFWebElement recipeImgRecentlyviewed;
	@FindBy(locator = "recipes.list.recentlyviewedrecipenames")
	private List<QAFWebElement> recipeListRecentlyviewedrecipenames;
	@FindBy(locator = "recipes.lbl.topratedrecipes")
	private QAFWebElement recipeLblTopratedrecipe;
	@FindBy(locator = "recipes.lbl.firstrecipeaddtolist")
	private QAFWebElement recipeLblFirstrecipeaddtolist;
	@FindBy(locator = "recipes.lbl.randomrecipeaddtolist")
	private QAFWebElement recipeLblRandomrecipeaddtolist;
	@FindBy(locator = "recipes.lbl.recipes")
	private QAFWebElement recipeslblrecipes;
	@FindBy(locator = "recipes.link.addtolist")
	private QAFWebElement recipeslinkaddtolist;
	@FindBy(locator = "recipes.btn.checkall")
	private QAFWebElement recipesbtncheckall;
	@FindBy(locator = "recipes.btn.addtolist")
	private QAFWebElement recipesbtnaddtolist;
	@FindBy(locator = "recipes.lbl.selectingredients")
	private QAFWebElement recipeslblselectingredients;
	@FindBy(locator = "recipes.lbl.minishoppinglist")
	private QAFWebElement recipeslblminishoppinglist;
	@FindBy(locator = "recipes.lbl.topratedrecipes")
	private QAFWebElement recipeslbltopratedrecipes;
	@FindBy(locator = "recipes.btn.addtolistcollapse")
	private QAFWebElement recipesBtnAddtolistcollapse;
	@FindBy(locator = "recipes.list.topratedrecipes")
	private List<QAFWebElement> recipeListTopratedrecipes;
	@FindBy(locator = "recipes.lbl.lastrecipeaddtolist")
	private QAFWebElement recipeLblLastrecipeaddtolist;

	@FindBy(locator = "recipes.lbl.cookingconnection")
	private QAFWebElement lblCookingconnection;
	@FindBy(locator = "recipes.lbl.cookingtips")
	private QAFWebElement lblCookingtips;
	@FindBy(locator = "recipes.lbl.browserecipes")
	private QAFWebElement lblBrowserecipes;
	@FindBy(locator = "recipes.lbl.recipebox")
	private QAFWebElement lblRecipebox;
	@FindBy(locator = "recipes.img.primopicks")
	private List<QAFWebElement> imgPrimopicks;
	@FindBy(locator = "recipes.lbl.primopicksrecipenames")
	private List<QAFWebElement> lblPrimopicksrecipenames;

	@FindBy(locator = "recipes.lbl.chickenrecipes")
	private QAFWebElement lblChickenrecipes;

	@FindBy(locator = "recipes.lbl.seafood")
	private QAFWebElement lblSeafood;

	@FindBy(locator = "recipes.img.quickrecipefinder")
	private QAFWebElement imgQuickrecipefinder;
	@FindBy(locator = "recipes.lbl.mealtypedropdown1")
	private QAFWebElement lblMealtypedropdown1;
	@FindBy(locator = "recipes.lbl.mealtypedropdown2")
	private QAFWebElement lblMealtypedropdown2;
	@FindBy(locator = "recipes.btn.quickrecipefinder")
	private QAFWebElement btnQuickrecipefinder;

	@FindBy(locator = "recipes.list.addtolist")
	private List<QAFWebElement> listAddtolist;

	@FindBy(locator = "recipes.chk.bynutritioncheckboxes")
	private List<QAFWebElement> chkBynutritioncheckboxes;
	@FindBy(locator = "recipes.chk.bydietcheckboxes")
	private List<QAFWebElement> chkBydietcheckboxes;
	@FindBy(locator = "recipes.chk.bycookingmethodcheckboxes")
	private List<QAFWebElement> chkBycookingmethodcheckboxes;
	@FindBy(locator = "recipes.chk.bysourcecheckboxes")
	private List<QAFWebElement> chkBysourcecheckboxes;
	@FindBy(locator = "recipes.btn.searchadvanced")
	private QAFWebElement btnSearchadvanced;
	@FindBy(locator = "recipes.lnk.advancedsearch")
	private QAFWebElement lnkAdvancedsearch;
	@FindBy(locator = "recipes.lnk.loginundercreaterecipebox")
	private QAFWebElement lnkLoginUnderCreateRecipeBox;
	@FindBy(locator = "recipes.btn.createanaccundercreaterecipebox")
	private QAFWebElement btnCreateAnAccUnderCreateRecipeBox;
	@FindBy(locator = "recipes.lbl.ratingrecipespecs")
	private QAFWebElement lblRatingRecipeSpecs;
	@FindBy(locator = "recipes.lst.ratingrecipespecs")
	private List<QAFWebElement> lstRatingRecipeSpecs;
	@FindBy(locator = "recipes.btn.loadmoreitems")
	private QAFWebElement btnLoadmoreitems;
	
	@FindBy(locator = "recipes.btn.addtolistcollapse1")
	private QAFWebElement recipesBtnAddTolistCollapse1;
	
	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}
	
	public QAFWebElement getLblRatingRecipeSpecs() {
		return lblRatingRecipeSpecs;
	}
	
	public List<QAFWebElement> getLstRatingRecipeSpecs() {
		return lstRatingRecipeSpecs;
	}
	
	public QAFWebElement getLnkLoginUnderCreateRecipeBox() {
		return lnkLoginUnderCreateRecipeBox;
	}

	public QAFWebElement getBtnCreateAnAccUnderCreateRecipeBox() {
		return btnCreateAnAccUnderCreateRecipeBox;
	}

	public QAFWebElement getRecipeLblRecipename() {
		return recipeLblRecipename;
	}
	
	public QAFWebElement getRecipeLnkRecipename() {
		return recipeLnkRecipename;
	}

	public QAFWebElement getRecipeLinkRecipebox() {
		return recipeLinkRecipebox;
	}

	public QAFWebElement getRecipeLblPagetitle() {
		return recipeLblPagetitle;
	}

	public QAFWebElement getRecipeLinkRecipeoftheday() {
		return recipeLinkRecipeoftheday;
	}

	public QAFWebElement getRecipeLinkViewall() {
		return recipeLinkViewall;
	}

	public QAFWebElement getRecipeImgRecentlyviewed() {
		return recipeImgRecentlyviewed;
	}

	public List<QAFWebElement> getRecipeListRecentlyviewedrecipenames() {
		return recipeListRecentlyviewedrecipenames;
	}

	public QAFWebElement getRecipesLblRecipes() {
		return recipeslblrecipes;
	}

	public QAFWebElement getRecipesLinkAddtoList() {
		return recipeslinkaddtolist;
	}

	public QAFWebElement getRecipesBtnCheckAll() {
		return recipesbtncheckall;
	}

	public QAFWebElement getRecipesBtnAddtoList() {
		return recipesbtnaddtolist;
	}

	public QAFWebElement getRecipesLblSelectIngredients() {
		return recipeslblselectingredients;
	}

	public QAFWebElement getRecipesLblMiniShoppingList() {
		return recipeslblminishoppinglist;
	}

	public QAFWebElement getRecipesLblTopRatedRecipes() {
		return recipeslbltopratedrecipes;
	}

	public QAFWebElement getRecipeLblTopratedrecipe() {
		return recipeLblTopratedrecipe;
	}

	public QAFWebElement getRecipeLblFirstrecipeaddtolist() {
		return recipeLblFirstrecipeaddtolist;
	}

	public QAFWebElement getRecipeLblRandomrecipeaddtolist() {
		return recipeLblRandomrecipeaddtolist;
	}

	// DYNAMIC value declaring
	public QAFWebElement getRecipenameBylabel(String lable) {
		String loc = String.format(pageProps.getString("recipes.lbl.recipenamedynamic"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getRecipesBtnAddtolistcollapse() {
		return recipesBtnAddtolistcollapse;
	}

	public List<QAFWebElement> getRecipeListTopratedrecipes() {
		return recipeListTopratedrecipes;
	}

	// DYNAMIC value declaring
	public QAFWebElement getAddtoListByRecipeSize(int lable) {
		String loc = String.format(pageProps.getString("recipes.lbl.lastrecipeaddtolist"), lable);
		return new QAFExtendedWebElement(loc);
	}

	public QAFWebElement getLblCookingconnection() {
		return lblCookingconnection;
	}

	public QAFWebElement getLblCookingtips() {
		return lblCookingtips;
	}

	public QAFWebElement getLblBrowserecipes() {
		return lblBrowserecipes;
	}

	public QAFWebElement getLblRecipebox() {
		return lblRecipebox;
	}

	public List<QAFWebElement> getImgPrimopicks() {
		return imgPrimopicks;
	}

	public List<QAFWebElement> getLblPrimopicksrecipenames() {
		return lblPrimopicksrecipenames;
	}

	public QAFWebElement getLblChickenrecipes() {
		return lblChickenrecipes;
	}

	public QAFWebElement getLblSeafood() {
		return lblSeafood;
	}

	public QAFWebElement getImgQuickrecipefinder() {
		return imgQuickrecipefinder;
	}

	public QAFWebElement getLblMealtypedropdown1() {
		return lblMealtypedropdown1;
	}

	public QAFWebElement getLblMealtypedropdown2() {
		return lblMealtypedropdown2;
	}

	public QAFWebElement getBtnQuickrecipefinder() {
		return btnQuickrecipefinder;
	}

	public List<QAFWebElement> getListAddtolist() {
		return listAddtolist;
	}

	public List<QAFWebElement> getChkBynutritioncheckboxes() {
		return chkBynutritioncheckboxes;
	}

	public List<QAFWebElement> getChkBydietcheckboxes() {
		return chkBydietcheckboxes;
	}

	public List<QAFWebElement> getChkBycookingmethodcheckboxes() {
		return chkBycookingmethodcheckboxes;
	}

	public List<QAFWebElement> getChkBysourcecheckboxes() {
		return chkBysourcecheckboxes;
	}

	public QAFWebElement getBtnSearchadvanced() {
		return btnSearchadvanced;
	}

	public QAFWebElement getLnkAdvancedsearch() {
		return lnkAdvancedsearch;
	}

	public QAFWebElement getBtnLoadmoreitems() {
		return btnLoadmoreitems;
	}
	
	public QAFWebElement getBtnRecipesSectionWithId(int lable) {
		String loc = String.format(pageProps.getString("recipes.get.btn.recipesections"), lable);
		return new QAFExtendedWebElement(loc);
	}
	
	public QAFWebElement getRecipesBtnAddTolistCollapse1() {
		return recipesBtnAddTolistCollapse1;
	}
	

}
