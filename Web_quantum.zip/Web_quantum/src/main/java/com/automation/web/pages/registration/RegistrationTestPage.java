package com.automation.web.pages.registration;

import com.automation.web.databean.CheckOutRegistrationBean;
import com.automation.web.databean.RegistrationBean;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class RegistrationTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	private RegistrationBean registrationBean = new RegistrationBean();

	public RegistrationBean getRegistrationBean() {
		return registrationBean;
	}

	private CheckOutRegistrationBean checkOutRegistration = new CheckOutRegistrationBean();

	public CheckOutRegistrationBean getCheckOutRegistration() {
		return checkOutRegistration;
	}

	@FindBy(locator = "rgstr.lbl.header")
	private QAFWebElement rgstrLblHeader;

	@FindBy(locator = "rgstr.edt.firstname")
	private QAFWebElement rgstrEdtFirstname;

	@FindBy(locator = "rgstr.edt.lastname")
	private QAFWebElement rgstrEdtLastname;

	@FindBy(locator = "rgstr.edt.email")
	private QAFWebElement rgstrEdtEmail;

	@FindBy(locator = "rgstr.edt.password")
	private QAFWebElement rgstrEdtPassword;

	@FindBy(locator = "rgstr.chk.alert")
	private QAFWebElement rgstrChkAlert;

	@FindBy(locator = "rgstr.btn.createaccount")
	private QAFWebElement rgstrBtnCreateaccount;

	@FindBy(locator = "rgstr.btn.backtoheb")
	private QAFWebElement rgstrBtnBacktoheb;

	@FindBy(locator = "rgstr.lbl.firstnameerror")
	private QAFWebElement rgstrLblFirstnameError;

	@FindBy(locator = "rgstr.lbl.emailerror")
	private QAFWebElement rgstrlblemailerror;

	@FindBy(locator = "rgstr.lbl.passworderror")
	private QAFWebElement rgstrlblpassworderror;

	/**
	 * LabelView of Registration page header
	 */
	public QAFWebElement getRgstrLblHeader() {
		return rgstrLblHeader;
	}

	/**
	 * EditTextView of first name
	 */
	public QAFWebElement getRgstrEdtFirstname() {
		return rgstrEdtFirstname;
	}

	/**
	 * EditTextView of last name
	 */
	public QAFWebElement getRgstrEdtLastname() {
		return rgstrEdtLastname;
	}

	/**
	 * EditTextView of email
	 */
	public QAFWebElement getRgstrEdtEmail() {
		return rgstrEdtEmail;
	}

	/**
	 * EditTextView of password
	 */
	public QAFWebElement getRgstrEdtPassword() {
		return rgstrEdtPassword;
	}

	/**
	 * CheckBoxView of Alert
	 */
	public QAFWebElement getRgstrChkAlert() {
		return rgstrChkAlert;
	}

	/**
	 * ButtonView of CreateAccount
	 */
	public QAFWebElement getRgstrBtnCreateaccount() {
		return rgstrBtnCreateaccount;
	}

	/**
	 * ButtonView of Back to HEB
	 */
	public QAFWebElement getRgstrBtnBacktoheb() {
		return rgstrBtnBacktoheb;
	}

	/**
	 * Text view of Please enter valid first name error message
	 */
	public QAFWebElement getRgstrLblfirstnameerror() {
		return rgstrLblFirstnameError;
	}

	/**
	 * Text view of Please enter valid email error message
	 */
	public QAFWebElement getRgstrLblEmailError() {
		return rgstrlblemailerror;
	}

	/**
	 * Text view of Please enter a valid password
	 */
	public QAFWebElement getRgstrLblPasswordError() {
		return rgstrlblpassworderror;
	}

}