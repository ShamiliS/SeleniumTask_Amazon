package com.automation.web.pages.registration;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ThankYouTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "thnku.lbl.header")
	private QAFWebElement thnkuLblHeader;

	@FindBy(locator = "thnku.btn.gotit")
	private QAFWebElement thnkuBtnGotit;
	
	@FindBy(locator = "thnku.btn.savebutton")
	private QAFWebElement thnkubtnsavebutton;

	@FindBy(locator = "thnku.btn.gotodigitalcoupons")
	private QAFWebElement btnGotodigitalcoupons;
	
	@FindBy(locator = "thnku.lbl.hostaddress")
	private QAFWebElement thnkuLblHostaddress;
	
	/**
	 * Label View of ThankYou page header
	 */
	public QAFWebElement getThnkuLblHeader(){ return thnkuLblHeader; }

	/**
	 * Button View of ThankYou Got it
	 */
	public QAFWebElement getThnkuBtnGotit(){ return thnkuBtnGotit; }
	
	/**
	 * Button View of save to go shopping list page
	 */
	public QAFWebElement getThnkuBtnSaveButton(){ return thnkubtnsavebutton; }
	
	public QAFWebElement getBtnGotodigitalcoupons() {
		return btnGotodigitalcoupons;
	}

	public QAFWebElement getThnkuLblHostaddress() {
		return thnkuLblHostaddress;
	}

}