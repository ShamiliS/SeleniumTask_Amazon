package com.automation.web.pages.storelocator;

import java.util.List;

import com.automation.web.components.CDPProductBlocks;
import com.automation.web.components.ChoosingStore;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class FindAStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "findstore.lbl.pagetitle")
	private QAFWebElement findstoreLblPagetitle;

	@FindBy(locator = "findstore.txt.enterzipcode")
	private QAFWebElement findstoreTxtEnterzipcode;

	@FindBy(locator = "findstore.btn.search")
	private QAFWebElement findstoreBtnSearch;

	@FindBy(locator = "findstore.li.storenameslist")
	private List<QAFWebElement> findstoreLiStorenameslist;

	@FindBy(locator = "findstore.btn.select")
	private List<QAFWebElement> findstoreBtnSelect;
	
	@FindBy(locator = "findstore.ddl.distanceoptions")
	private QAFWebElement DdlDistanceOptions;
	
	@FindBy(locator = "findstore.btn.loadnext")
	private QAFWebElement BtnLoadNext;
	
	@FindBy(locator = "findstore.lbl.pagestorecount")
	private QAFWebElement LblPageStoreCount;
	
	@FindBy(locator = "findstore.lbl.pageinitialcount")
	private QAFWebElement LblPageInitialCount;
	
	@FindBy(locator = "findstore.table.storeresults")
	private List<ChoosingStore> StoreResults;
	
	//public List<CDPProductBlocks> getCdpLiProductblock(){ return cdpLiProductblock; }

	public QAFWebElement getBtnStoreforSelect(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.btn.maxstoreforselect"), count);
		return new QAFExtendedWebElement(reElm);
	}	
	
	public QAFWebElement getLblStoreNameforSelect(int count) {
		String reElm = String.format(pageProps.getString("findstore.get.lbl.rndmstoreforstorename"), count);
		return new QAFExtendedWebElement(reElm);
	}	
	
	public QAFWebElement getMaxMilestoStore(String count) {
		String reElm = String.format(pageProps.getString("findstore.get.lbl.maxstoremiles"), count);
		return new QAFExtendedWebElement(reElm);
	}
	
	public List<ChoosingStore> getStoreResults() {
		return StoreResults;
	}


	public void setStoreResults(List<ChoosingStore> storeResults) {
		StoreResults = storeResults;
	}


	public QAFWebElement getLblPageInitialCount(){ return LblPageInitialCount; }
	public QAFWebElement getLblPageStoreCount(){ return LblPageStoreCount; }
	public QAFWebElement getBtnLoadNext(){ return BtnLoadNext; }
	public QAFWebElement getDdlDistanceOptions(){ return DdlDistanceOptions; }

	/**
	 * TextView for page title
	 */
	public QAFWebElement getFindstoreLblPagetitle(){ return findstoreLblPagetitle; }

	/**
	 * EditView for Zip code text field
	 */
	public QAFWebElement getFindstoreTxtEnterzipcode(){ return findstoreTxtEnterzipcode; }

	/**
	 * ButtonView for Search
	 */
	public QAFWebElement getFindstoreBtnSearch(){ return findstoreBtnSearch; }

	/**
	 * ListView for Store Names
	 */
	public List<QAFWebElement> getFindstoreLiStorenameslist(){ return findstoreLiStorenameslist; }

	/**
	 * ButtonView for Select
	 */
	public List<QAFWebElement> getFindstoreBtnSelect(){ return findstoreBtnSelect; }
	
	public void clickLoadMoreStoresuntilVisible(){
		do{
			getBtnLoadNext().click();
		}while(getBtnLoadNext().isPresent());
	}


	
	
}