package com.automation.web.pages.storelocator;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class StoreDetailsTestPage extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "storedetails.lbl.addresssubtitle")
	private QAFWebElement LblAddresssubtitle;
	@FindBy(locator = "storedetails.lbl.addressdesc1")
	private QAFWebElement LblAddressdesc1;
	@FindBy(locator = "storedetails.lbl.addressdesc2")
	private QAFWebElement LblAddressdesc2;
	@FindBy(locator = "storedetails.lbl.addressdesc3")
	private QAFWebElement LblAddressdesc3;
	@FindBy(locator = "storedetails.lbl.addressmiles")
	private QAFWebElement LblAddressMiles;
	@FindBy(locator = "storedetails.lnk.directiontostore")
	private QAFWebElement LnkDirectiontostore;
	@FindBy(locator = "storedetails.lbl.storehrsphnnum")
	private QAFWebElement LblStorehrsphnnum;
	@FindBy(locator = "storedetails.lbl.mainphnsubtitle")
	private QAFWebElement Lblmainphnsubtitle;
	@FindBy(locator = "storedetails.lbl.storehrssubtitle")
	private QAFWebElement LblStorehrssubtitle;
	@FindBy(locator = "storedetails.lbl.pharmacysubtitle")
	private QAFWebElement LblPharmacysubtitle;
	@FindBy(locator = "storedetails.lbl.pharmacyhrssubtitle")
	private QAFWebElement LblPharmacyhrssubtitle;
	@FindBy(locator = "storedetails.lbl.phonenum")
	private QAFWebElement Lblphonenum;
	@FindBy(locator = "storedetails.lnk.viewstoread")
	private QAFWebElement LnkViewstoread;
	@FindBy(locator = "storedetails.lbl.availabledeptservice")
	private QAFWebElement LblAvailabledeptservice;
	@FindBy(locator = "storedetails.lbl.storefeatures")
	private QAFWebElement LblStoreFeatures;
	
	public QAFWebElement getSelectStoreDetailswithstoreid(String storeid) {
		String reElm = String.format(pageProps.getString("storedetails.get.lnk.storedetailswithid"), storeid);
		return new QAFExtendedWebElement(reElm);
	}
	public QAFWebElement getLnkAddressHeader(String header){ 
		String reElm = String.format(pageProps.getString("storedetails.get.lnk.addressheader"), header);
		return new QAFExtendedWebElement(reElm); 
	}
	public QAFWebElement getLblAddresssubtitle(){ return LblAddresssubtitle; }
	public QAFWebElement getLblAddressdesc1(){ return LblAddressdesc1; }
	public QAFWebElement getLblAddressdesc2(){ return LblAddressdesc2; }
	public QAFWebElement getLblAddressdesc3(){ return LblAddressdesc3; }
	public QAFWebElement getLblAddressMiles(){ return LblAddressMiles; }
	public QAFWebElement getLnkDirectiontostore(){ return LnkDirectiontostore; }
	public QAFWebElement getLblStorehrsphnnum(){ return LblStorehrsphnnum; }
	public QAFWebElement getLblmainphnsubtitle(){ return Lblmainphnsubtitle; }
	public QAFWebElement getLblStorehrssubtitle(){ return LblStorehrssubtitle; }
	public QAFWebElement getLblPharmacysubtitle(){ return LblPharmacysubtitle; }
	public QAFWebElement getLblPharmacyhrssubtitle(){ return LblPharmacyhrssubtitle; }
	public QAFWebElement getLblphonenum(){ return Lblphonenum; }
	public QAFWebElement getLnkViewstoread(){ return LnkViewstoread; }
	public QAFWebElement getLblAvailabledeptservice(){ return LblAvailabledeptservice; }
	public QAFWebElement getLblStoreFeatures(){ return LblStoreFeatures; }

}