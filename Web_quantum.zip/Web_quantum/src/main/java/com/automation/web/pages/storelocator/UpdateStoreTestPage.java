package com.automation.web.pages.storelocator;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class UpdateStoreTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1) {
	}

	public synchronized void waitForPageToLoad() {
		super.waitForPageToLoad();
	}

	@FindBy(locator = "updatestore.lbl.pageheader")
	private QAFWebElement lblPageheader;

	@FindBy(locator = "updatestore.txt.enterzipcode")
	private QAFWebElement txtEnterzipcode;

	@FindBy(locator = "updatestore.btn.go")
	private QAFWebElement btnGo;

	@FindBy(locator = "updatestore.li.storenameslist")
	private List<QAFWebElement> liStorenameslist;

	@FindBy(locator = "updatestore.btn.select")
	private List<QAFWebElement> btnSelect;

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getTxtEnterzipcode() {
		return txtEnterzipcode;
	}

	public QAFWebElement getBtnGo() {
		return btnGo;
	}

	public List<QAFWebElement> getLiStorenameslist() {
		return liStorenameslist;
	}

	public List<QAFWebElement> getBtnSelect() {
		return btnSelect;
	}

}