package com.automation.web.pages.weeklyads;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MapsAndDirectionsTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "mapanddir.lbl.availdepandservices")
	private QAFWebElement lblAvaildepandservices;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblAvaildepandservices() {
		return lblAvaildepandservices;
	}

}
