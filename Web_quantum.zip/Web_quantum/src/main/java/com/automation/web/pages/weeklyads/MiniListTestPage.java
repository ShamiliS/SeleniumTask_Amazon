package com.automation.web.pages.weeklyads;

import java.util.List;

import com.automation.web.components.MiniListPdtBlocks;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class MiniListTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "minilist.lbl.pagetitle")
	private QAFWebElement lblPagetitle;

	@FindBy(locator = "minilist.lbl.gotofulllist")
	private QAFWebElement lblGotofulllist;

	@FindBy(locator = "minilist.li.Itemsegments")
	private List<MiniListPdtBlocks> liItemsegments;

	@FindBy(locator = "minilist.img.closewindow")
	private QAFWebElement imgClosewindow;
	
	@FindBy(locator = "minilist.lbl.itemcount")
	private QAFWebElement lblItemcount;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getLblPagetitle() {
		return lblPagetitle;
	}

	public QAFWebElement getLblGotofulllist() {
		return lblGotofulllist;
	}

	public List<MiniListPdtBlocks> getLiItemsegments() {
		return liItemsegments;
	}

	public QAFWebElement getImgClosewindow() {
		return imgClosewindow;
	}

	public QAFWebElement getLblItemcount() {
		return lblItemcount;
	}
}
