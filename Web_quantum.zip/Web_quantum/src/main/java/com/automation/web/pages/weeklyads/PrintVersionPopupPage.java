package com.automation.web.pages.weeklyads;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class PrintVersionPopupPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "pvpopup.img.popupfullview")
	private QAFWebElement imgPopupfullview;

	@FindBy(locator = "pvpopup.img.popupheader")
	private QAFWebElement imgPopupheader;

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getImgPopupfullview() {
		return imgPopupfullview;
	}

	public QAFWebElement getImgPopupheader() {
		return imgPopupheader;
	}

}
