package com.automation.web.pages.weeklyads;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class WeeklyadprintversionTestPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@FindBy(locator = "printversion.img.iframeitems")
	private QAFWebElement imgIframeitems;
	@FindBy(locator = "printversion.lbl.pageheader")
	private QAFWebElement lblPageheader;
	@FindBy(locator = "printversion.lbl.doubleclicktozoom")
	private QAFWebElement lblDoubleclicktozoom;
	@FindBy(locator = "printversion.lbl.dateheader")
	private QAFWebElement lblDateheader;
	@FindBy(locator = "printversion.img.iframeitems1pageimage")
	private QAFWebElement imgIframeitems1pageimage;
	@FindBy(locator = "printversion.lbl.tutorial")
	private QAFWebElement lblTutorial;
	@FindBy(locator = "printversion.btn.tutorialclose")
	private QAFWebElement btnTutorialclose;
	@FindBy(locator = "printversion.iframe.secondchild")
	private QAFWebElement IframeSecondchild;
	@FindBy(locator = "printversion.iframe.firstchild")
	private QAFWebElement IframeFirstchild;
	@FindBy(locator = "printversion.iframe.parent")
	private QAFWebElement IframeParent;
	@FindBy(locator = "printversion.li.img.weeklyadproducts")
	private List<QAFWebElement> liimgWeeklyadproducts;
	@FindBy(locator = "printversion.lbl.more")
	private QAFWebElement lblMore;
	@FindBy(locator = "printversion.lnk.print")
	private QAFWebElement lnkPrint;
	@FindBy(locator = "printversion.lbl.printtitle")
	private QAFWebElement lblPrinttitle;
	@FindBy(locator = "printversion.lbl.printall")
	private QAFWebElement lblPrintall;
	@FindBy(locator = "printversion.lbl.printcurrent")
	private QAFWebElement lblPrintcurrent;
	@FindBy(locator = "printversion.lbl.printrange")
	private QAFWebElement lblPrintrange;
	@FindBy(locator = "printversion.img.closeprint")
	private QAFWebElement imgCloseprint;
	@FindBy(locator = "printversion.btn.printsubmit")
	private QAFWebElement btnPrintsubmit;
	@FindBy(locator = "printversion.btn.choosestore")
	private QAFWebElement btnChoosestore;
	@FindBy(locator = "printversion.btn.categoryview")
	private QAFWebElement btnCategoryview;
	@FindBy(locator = "printversion.img.menu")
	private QAFWebElement ImgMenu;
	@FindBy(locator = "printversion.lbl.breadcrumb")
	private QAFWebElement lblBreadcrumb;
	@FindBy(locator = "printversion.li.img.weeklyads")
	private List<QAFWebElement> printversionLiImgWeeklyads;
	@FindBy(locator = "printversion.li.img.weeklyaddeals")
	private List<QAFWebElement> printversionLiImgWeeklyaddeals;
	@FindBy(locator = "printversion.lbl.hoverOverlay")
	private QAFWebElement printversionLblHoverOverlay;
	@FindBy(locator = "printversion.img.selectedweeklyaddeals")
	private QAFWebElement printversionImgSelectedweeklyaddeals;
	

	@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
	}

	public QAFWebElement getImgIframeitems() {
		return imgIframeitems;
	}

	public QAFWebElement getLblPageheader() {
		return lblPageheader;
	}

	public QAFWebElement getLblDateheader() {
		return lblDateheader;
	}

	public QAFWebElement getImgIframeitems1pageimage() {
		return imgIframeitems1pageimage;
	}

	public QAFWebElement getLblTutorial() {
		return lblTutorial;
	}

	public QAFWebElement getBtnTutorialclose() {
		return btnTutorialclose;
	}

	public QAFWebElement getIframeSecondchild() {
		return IframeSecondchild;
	}

	public QAFWebElement getIframeFirstchild() {
		return IframeFirstchild;
	}

	public QAFWebElement getIframeParent() {
		return IframeParent;
	}

	public List<QAFWebElement> getLiImgWeeklyadproducts() {
		return liimgWeeklyadproducts;
	}

	public QAFWebElement getLblMore() {
		return lblMore;
	}

	public QAFWebElement getLnkPrint() {
		return lnkPrint;
	}

	public QAFWebElement getLblPrinttitle() {
		return lblPrinttitle;
	}

	public QAFWebElement getLblPrintall() {
		return lblPrintall;
	}

	public QAFWebElement getLblPrintcurrent() {
		return lblPrintcurrent;
	}

	public QAFWebElement getLblPrintrange() {
		return lblPrintrange;
	}

	public QAFWebElement getImgCloseprint() {
		return imgCloseprint;
	}

	public QAFWebElement getBtnPrintsubmit() {
		return btnPrintsubmit;
	}

	public QAFWebElement getBtnChoosestore() {
		return btnChoosestore;
	}
	
	public QAFWebElement getBtnCategoryview() {
		return btnCategoryview;
	}
	
	public QAFWebElement getImgMenu() {
		return ImgMenu;
	}
	
	public QAFWebElement getLblBreadcrumb() {
		return lblBreadcrumb;
	}
	
	public List<QAFWebElement> getPrintversionLiImgWeeklyads() {
		return printversionLiImgWeeklyads;
	}
	
	public List<QAFWebElement> getPrintversionLiImgWeeklyaddeals() {
		return printversionLiImgWeeklyaddeals;
	}
	
	public QAFWebElement getPrintversionLblHoverOverlay() {
		return printversionLblHoverOverlay;
	}
	
	public QAFWebElement getPrintversionImgSelectedweeklyaddeals() {
		return printversionImgSelectedweeklyaddeals;
	}
	
}
