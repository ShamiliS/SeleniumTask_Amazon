package com.automation.web.pages.weeklyads;

import java.util.List;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class Weeklyadsdealsmodel extends WebDriverBaseTestPage<WebDriverTestPage>  {

	@Override
	protected void openPage(PageLocator arg0, Object... arg1){}


	public synchronized void waitForPageToLoad(){
		super.waitForPageToLoad();
	}

	@FindBy(locator = "weeklyadmodel.grid.lbl.header")
	private QAFWebElement weeklyadmodelGridLblHeader;

	@FindBy(locator = "weeklyadmodel.grid.lbl.description")
	private QAFWebElement weeklyadmodelGridLblDescription;

	@FindBy(locator = "weeklyadmodel.grid.btn.addtolist")
	private QAFWebElement weeklyadmodelGridBtnAddtolist;

	@FindBy(locator = "weeklyadmodel.grid.lbl.validdate")
	private QAFWebElement weeklyadmodelGridLblValiddate;

	@FindBy(locator = "weeklyadmodel.grid.btn.collpase")
	private QAFWebElement weeklyadmodelGridBtnCollpase;
	
	@FindBy(locator = "weeklyadmodel.print.lbl.header")
	private QAFWebElement weeklyadmodelPrintLblHeader;

	@FindBy(locator = "weeklyadmodel.print.lbl.description")
	private QAFWebElement weeklyadmodelPrintLblDescription;

	@FindBy(locator = "weeklyadmodel.print.btn.addtolist")
	private QAFWebElement weeklyadmodelPrintBtnAddtolist;

	@FindBy(locator = "weeklyadmodel.print.lbl.validdate")
	private QAFWebElement weeklyadmodelPrintLblValiddate;

	@FindBy(locator = "weeklyadmodel.print.btn.collpase")
	private QAFWebElement weeklyadmodelPrintBtnCollpase;

	public QAFWebElement getWeeklyadmodelGridLblHeader() {
		return weeklyadmodelGridLblHeader;
	}


	public QAFWebElement getWeeklyadmodelGridLblDescription() {
		return weeklyadmodelGridLblDescription;
	}


	public QAFWebElement getWeeklyadmodelGridBtnAddtolist() {
		return weeklyadmodelGridBtnAddtolist;
	}


	public QAFWebElement getWeeklyadmodelGridLblValiddate() {
		return weeklyadmodelGridLblValiddate;
	}


	public QAFWebElement getWeeklyadmodelGridBtnCollpase() {
		return weeklyadmodelGridBtnCollpase;
	}


	public QAFWebElement getWeeklyadmodelPrintLblHeader() {
		return weeklyadmodelPrintLblHeader;
	}


	public QAFWebElement getWeeklyadmodelPrintLblDescription() {
		return weeklyadmodelPrintLblDescription;
	}


	public QAFWebElement getWeeklyadmodelPrintBtnAddtolist() {
		return weeklyadmodelPrintBtnAddtolist;
	}


	public QAFWebElement getWeeklyadmodelPrintLblValiddate() {
		return weeklyadmodelPrintLblValiddate;
	}


	public QAFWebElement getWeeklyadmodelPrintBtnCollpase() {
		return weeklyadmodelPrintBtnCollpase;
	}	

}