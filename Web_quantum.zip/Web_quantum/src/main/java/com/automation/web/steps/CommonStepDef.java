package com.automation.web.steps;

import com.automation.web.steps.homepage.HomePage;
import com.automation.web.steps.myaccount.myaccountpage;
import static com.qmetry.qaf.automation.core.ConfigurationManager.getBundle;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

/*List of steps in CommonStepDef

* I am a tax exempt user

*/

public class CommonStepDef {

	public static void entervalueintothetextbox(QAFWebElement elementname, String elementvalue) {

		elementname.click();
		elementname.sendKeys(elementvalue);
	}

	@QAFTestStep(description = "I am a tax exempt user")
	public synchronized void iAmATaxExemptUser() {
		myaccountpage myaccount = new myaccountpage();

		String username = getBundle().getString("taxexemptuser.user");
		String password = getBundle().getString("taxexemptuser.pass");

		HomePage.iAmOnHomePage();
		HomePage.iNavigateToInstoreHomePage();
		myaccount.iClickonLoginlink();
		myaccount.iEnteremailandpassword(username, password);
		myaccount.iClickonLoginbutton();
		myaccount.iSeetheuserisloggedin();
		getBundle().setProperty("User", "Hot");
		getBundle().setProperty("myEmail", username);
	}

	public static void clearAndEntervalueintothetextbox(QAFWebElement elementname, String elementvalue) {

		elementname.click();
		elementname.clear();
		elementname.sendKeys(elementvalue);
	}

}
